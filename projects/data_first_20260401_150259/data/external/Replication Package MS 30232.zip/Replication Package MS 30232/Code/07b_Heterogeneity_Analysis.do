/*******************************************************************************

	DESCRIPTION: Heterogeneity analysis using regression sample merged
		with heterogeneity groups.

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/07b_Heterogeneity_Analysis`curr_date'", replace

***** Including or dropping the 1976 reform
	* 0 -> drop 1976 reform and extend the pre-period
	* 1 -> include the 1976 reform w/ limited pre-period
local include1976 1

***** Outcomes for the main and alternative analysis
	* Don't add yrFwd here -- automatically added from $earnF
local main_outcomes earn_Diff_f /*realizedRRChange_f*/
local alt_outcomes /*mover_f recalled_f ENE_f EUE_f mth_non_emp_f mth_UE_f mth_sick_f  UIdur_NE_f  takeup_f UIdur_f*/

***** Level of instrument aggregation
local aggregations earn_pct /*benr indocc*/

***** Control specifications
* Baseline controls following main specification
	* Adding interactions between the heterogeneity group and (1) the ln earnings control and (2) the earnings percentile control
local controls4 reform#year##c.(exp25 exp25_sq exp25_cub tenure tenure_sq tenure_cub refage refage_sq refage_cub) het_grp#reform#year##c.lnearnings reform#year#frau reform#year#REBPcontrol
local FE_controls4 het_grp#earn_pct_bin#reform nace08#whitecoll#reform#year
local controlname4 ctrls

* Adding to baseline controls interacting everything with the heterogeneity groups
local controls5 het_grp#reform#year##c.(exp25 exp25_sq exp25_cub tenure tenure_sq tenure_cub refage refage_sq refage_cub) het_grp#reform#year##c.lnearnings het_grp#reform#year#frau het_grp#reform#year#REBPcontrol
local FE_controls5 het_grp#earn_pct_bin#reform het_grp#nace08#whitecoll#reform#year
local controlname5 indOcc_hetInt

* Adding to baseline controls firm FEs
local controls6 `controls4'
local FE_controls6 `FE_controls4' benr#year#reform
local controlname6 firmyr

* Baseline + interactions + firmXyearXhet FEs
local controls7 `controls5'
local FE_controls7 `FE_controls5' benr#year#reform#het_grp#het_grp
local controlname7 firmyrHet_ctrlsHet


****************************************************************************
* Regression
****************************************************************************
foreach yrFwd in $earnF {

foreach group in `include1976' {


	***** Adding the yrFwd suffixes to each outcomes variable
	local main_outcomes_mod ""
	local alt_outcomes_mod ""
	foreach outcome in `main_outcomes' {
		local main_outcomes_mod `main_outcomes_mod' `outcome'`yrFwd'
	}
	foreach outcome in `alt_outcomes' {
		local alt_outcomes_mod `alt_outcomes_mod' `outcome'`yrFwd'
	}

	local outcomes `main_outcomes_mod' `alt_outcomes_mod'


	***** Sample restrictions whether or not the 1976 reform is included
	if `group' == 0 { // 6 Years back
		local grprestriction inlist(reform, 1985, 1989, 2001)
		local samplename Without76_stable
		local coefflist1 l5 l4 l3 l2 l0
		local coefflist2 l5 l4 l3 l0
		local coefflist3 l5 l4 l0
	}

	if `group' == 1 { // 4 years Back
		local grprestriction inlist(reform, 1976, 1985, 1989, 2001) & inlist(yr_l5,.,0) & inlist(yr_l4,.,0)
		local samplename With76_stable
		local coefflist1 l3 l2 l0
		local coefflist2 l3 l0
		local coefflist3 l0
	}

	foreach suffix in `aggregations' {

		***** Specifying cluster variables
		if "`suffix'" == "earn_pct" {
			local cluster svnr earn_pct_bin
		}
		else {
			local cluster `suffix' svnr
		}

		**** Looping through different heterogeneity variable
		use ${temp}/07a_Heterogeneity_yrFwd`yrFwd'.dta if `grprestriction', clear


		drop exp10

		* Indicator for REBP eligibility
			* rebp -- indicate REBP geographic eligibility
			* eREBP -- indicates age and experience eligibility
		gen REBPcontrol = rebp != 0 & eREBP == 1 & reform == 1989 & year >= 1987

		* Winsorize earnings outcomes
		winsor2 earn_Diff_f`yrFwd', replace cut(1 99) by(reform year)

		* Keep if employed in December
		keep if status == 3

		if $shorten76and89 == 1 {
			*Shorten 1976 and 1989 by 1 pct
			foreach reform in 1976 1989 {
				su earn_pct if treatment_`reform' == 1
				local min = r(min)
				su earn_pct if control_`reform' == 1
				local max = r(max)
				local new_min = `min' + 1
				local new_max = `max' - 1
				drop if reform == `reform' & earn_pct <= `new_min' & !mi(earn_pct)
				drop if reform == `reform' & earn_pct >= `new_max' & !mi(earn_pct)
			}
		}

		if `group' == 1  {
			drop *_l4_f`yrFwd' *_l5_f`yrFwd' yr_l5 yr_l4
		}


		***** Generating numeric version of benr -> used as FE
		rename benr benr_str
		gegen benr = group(benr_str)


		tempfile het_data
		save `het_data', replace


		* Looping through the different heterogeneity groups
		foreach hetergroup in $hetgroups {
			local lab`hetergroup' lab`hetergroup'

			use `het_data', clear

			* Generating the het_grp variable used to interact things with controls
			gen het_grp = `hetergroup'

			***** Different sample restrictions + control specs for different het cuts
				* For the months since UI and UE, we want to not impose the stable earner restriction
				* Heterogeneity variables -> control number 4
				* Switchers group 1 -> control number 4
				* Switchers group 2 -> control numbers mincer + ind occ, trans-specifc, firm FE alone, firm FE + trans-specific

			if "`hetergroup'" == "UI_grp" | "`hetergroup'" == "nonemp_grp" {
				local control_num_list 4
			}
			else if "`hetergroup'" == "switch_anal2_grp" {
				local control_num_list 4 5 6 7
				keep if mth_emp == 12
			}
			else {
				local control_num_list 4
				keep if mth_emp == 12
			}

			* Run specification program
			foreach cnt_grp in `control_num_list' {
				cap program drop run_specification_hetcuts
				run_specification_hetcuts, outcomes(`outcomes') ///
					instr_aggreg(`suffix') ///
					controlname(`controlname`cnt_grp'') ///
					instr_yrFwd(1) ///
					regvars(" ") ///
					absorbvars(`controls`cnt_grp'' `FE_controls`cnt_grp'') ///
					coefflist(`coefflist`yrFwd'') ///
					aux_info(RRcoeff RRSE intcoeff intSE R N F avg) ///
					cluster(`cluster') ///
					samplename(`samplename') ///
					yrFwd(`yrFwd') ///
					hetergroup(`hetergroup') ///
					heterlabel(`lab`hetergroup'')

			} // Specifications

		} // Heterogeneity group

	} // Aggregation level

} // With or Without 1976

} // Years forward

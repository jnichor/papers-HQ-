*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================


* Combined Graph in a vertical format
local name_1 "Agriculture"
local name_2 "Mining"
local name_3 "Manufacturing"
local name_4 "Electricity, gas, steam, and air conditioning supply"
local name_5 "Water/Sewerage"
local name_6 "Construction"
local name_7 "Wholesale"
local name_8 "Transportation"
local name_9 "Accommodation/Food"
local name_10 "Communications"
local name_11 "Finance/Insurance"
local name_12 "Real Estate"
local name_13 "Professional/Scientific"
local name_15 "Administration/Support"
local name_16 "Public Administration"
local name_17 "Education"
local name_18 "Health/Social Work"
local name_19 "Arts/Entertainment"
local name_20 "Other Services"

local letter_1 A //not included
local letter_2 B
local letter_3 C
local letter_4 D //not included
local letter_5 E //not included
local letter_6 F
local letter_7 G
local letter_8 H
local letter_9 I //not included
local letter_10 J
local letter_11 K
local letter_12 L
local letter_13 M
local letter_15 N
local letter_16 O //not included
local letter_17 P //not included
local letter_18 Q //not included
local letter_19 R
local letter_20 S

clear
set obs 1
gen n = .
local n = 0
gen DiD = 0
gen Diff= 0
gen RD = 0
local labelgraph
gen empt = 0

forvalues i = 1/20 {

	if `i' == 14 {
		noi di "Skipping NACE `i' since it is the same as 13"
	}
	else if `i' == 4 | `i' == 16 |`i' == 1 |`i' == 5 |`i' == 9 |`i' == 17 | `i' == 18 {
		noi di "Skipping NACE `i' since they are excluded from the analysis or no BvD data"
	}

	else {

			append using "${iab}/214/Industry_DiD_i_nace_`letter_`i''_spec1.dta" , gen(i_nace_`i'_DiD)
			append using "${iab}/214/Industry_Diff_i_nace_`letter_`i''_spec1.dta" , gen(i_nace_`i'_Diff)
			append using "${iab}/214/Industry_RD_i_nace_`letter_`i''_spec1.dta" , gen(i_nace_`i'_RD)

			replace DiD = 1 if i_nace_`i'_DiD == 1
			replace Diff = 1 if i_nace_`i'_Diff == 1
			replace RD = 1 if i_nace_`i'_RD == 1


			local n = `n' + 3

			replace n = `n'			if i_nace_`i'_DiD == 1
			replace n = `n' - 0.5		if i_nace_`i'_Diff == 1
			replace n = `n'	+ 0.5	if i_nace_`i'_RD == 1

			qui su n if i_nace_`i'_DiD == 1

            local m = `r(mean)'

			local nacenumber = `i'

			local labelgraph `labelgraph' `m' "`name_`nacenumber''"
	}
}
label define Graph1 `labelgraph', replace
label values n Graph1

replace RD = 2 if i_nace_2_RD == 1 | i_nace_12_RD == 1 | i_nace_19_RD == 1| i_nace_20_RD == 1
replace empt = 0 if empt == .
gen ub = b + (1.96*s)
gen lb = b - (1.96*s)

qui su n
local max = `r(max)' - 0.5

tw ///
 (scatter b n if Diff == 1, mcolor(sea) m(S) msize(medium) ) ///
 (rcap ub lb n if Diff == 1, lcolor(sea) lwidth(medthick) ) ///
 (scatter  b n if DiD == 1, mcolor(gs7%80) m(Oh) msize(medium) ) ///
 (rcap ub lb n if DiD == 1, lcolor(gs7%80) lwidth(medthick) ) ///
 (scatter  b n if RD == 1 , mcolor(gs10%80) m(th) msize(large) ) ///
 (rcap ub lb n if RD == 1 , lcolor(gs10%80) lwidth(medthick) ) ///
 (scatter  empt n if RD == 2, mcolor(gs5%100) m(x) msize(large) ) ///
, yline(0, lcolor(red) lpattern(solid)) ///
xlabel(3(3)`max', valuelabel notick labsize(medsmall) angle(45)) ///
ylabel(, labsize(medsmall) ) ///
ytitle("") xtitle("") ///
legend(label(1 "Difference") label(3 "DiD") label(5 "RD") ///
order(1 3 5) r(1) position(6) size(medlarge)) ///

graph display, xsize(14) ysize(8)
graph export "${figures}/figA2.pdf", replace

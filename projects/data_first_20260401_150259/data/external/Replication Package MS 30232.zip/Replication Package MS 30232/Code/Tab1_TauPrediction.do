/*******************************************************************************

	DESCRIPTION: Table 1 Tau Prediction

*******************************************************************************/

clear all

********************************************************************************
* Tau Tables macros
********************************************************************************

local n_EN "None"
local n_ENE4 "4-Year"

local n_Death${age} "No Restriction"
local n_DeathRet${age}_PermEU "Retirement"
local n_DeathRetDis${age}_PermEU "Ret'nt or Disability"

local numsamples: list sizeof global(tausamples)
local numconditions: list sizeof global(conditions)

local numcol = `numsamples' * `numconditions'
local valcols = "c" * `numcol'

di `numcol'


local endobs_1 17
local endobs_0 11

local tau_1 \hat{\tau}
local tau_0 \tau

********************************************************************************

file open fh using ${table}/Tab1_TauPrediction.tex, write replace
file write fh "\begin{tabular}{l`valcols'} \hline \hline" _n

* Header
local headerline1 "\textit{Time Restriction}: "
local headerline2 "\textit{Reemployment Restriction}: "
local cline " "
local cline_counter = 2
foreach tausample in $tausamples {
	local headerline1 "`headerline1' & \multicolumn{`numconditions'}{c}{`n_`tausample''}"
	local cline_end = `cline_counter' + `numconditions' - 1
	local cline "`cline' \cmidrule(lr){`cline_counter'-`cline_end'}"
	local cline_counter = `cline_counter' + `numconditions'
	foreach condition in ${conditions} {
		local headerline2 "`headerline2' & `n_`condition''"
	}
}
local specline " "

forval i = 1/`numcol' {
	local specline "`specline' & (`i') "
}

file write fh "`headerline1' \\" _n "`cline' `headerline2' \\" _n "\hline `specline' \\" _n

* Results

local panela "\multicolumn{7}{c}{\textbf{Panel A: Fraction of Post-Separation Time ($\tau$) (Predicted Values)}} \medskip"
local panelb "\multicolumn{7}{c}{\textbf{Panel B: Predicted Wage-Benefit Sensitivity ($ dw/db $)}}"
local model_2state_title "\textit{Baseline: Two-State dw/db Prediction}"
local model_3state_title "\textit{Robustness: Three-State dw/db Prediction}"

local pred0_panelA_title " & \multicolumn{6}{c}{Panel A: Separators}"
local pred0_panelB_title " & \multicolumn{6}{c}{Panel B: Full Sample}"

local tabshort \hspace{0.2cm}
local tablong \hspace{0.4cm}


local line1 "`tabshort' UI-Affected Nonemployment - \(`tau_${prediction}'^{U}\)"
local line2 "`tablong' Unemployment Insurance - \(`tau_${prediction}'^{U:UI}\)"
local line3 "`tablong' Unemployment Assistance - \(`tau_${prediction}'^{U:UA}\)"
local line4 "`tabshort' Employment - \(`tau_${prediction}'^{E}\)"
local line5 "`tabshort' Other Nonemployment - \(`tau_${prediction}'^{O}\)"

local line6 "`tabshort' \(\text{E}[dw/db(`tau_${prediction}'_{i})]\)"
local line7 "`tabshort' \(dw/db(\text{E}[`tau_${prediction}'_{i}])\)"

local line8 "`tabshort' \(\text{E}[dw/db(`tau_${prediction}'_{i})]\)"
local line9 "`tabshort' \(dw/db(\text{E}[`tau_${prediction}'_{i}])\)"

local blankline " "

local counter = 3

foreach tausample in $tausamples {

	foreach condition in ${conditions} {

		local share_title "`panela'"
		local model_2state_title "`model_2state_title' &"
		local model_3state_title "`model_3state_title' &"
		local blankline "`blankline' &"

		use column`counter' using ${temp}/Tau_NewTable_stable_With76_age${age}_pred${prediction}_`condition'.dta, clear


		qui forval i = 1/`endobs_${prediction}' {
			sum column if _n == `i'
			local mean`i' = `r(mean)'
		}

		local val1: di %4.3f `mean4' + `mean5'
		local val2: di %4.3f `mean4'
		local val3: di %4.3f `mean5'
		local val4: di %4.3f `mean1'
		local val5: di %4.3f `mean2' + `mean3'
		local val6: di %4.3f `mean15'
		local val7: di %4.3f `mean17'
		local val8: di %4.3f `mean14'
		local val9: di %4.3f `mean16'

		forval i = 1/9 {
			if `counter' == 3 & "`condition'" == "ENE4" & `i' != 7 & `i' != 9 {
				local line`i' "`line`i'' & \textbf{`val`i''} "
			}
			else if `counter' == 3 & "`condition'" == "ENE4" & (`i' == 7 | `i' == 9) {
				local line`i' "`line`i'' & \boxed{\textbf{`val`i''}} "
			}
			else {
				local line`i' "`line`i'' & `val`i'' "
			}
		}

	}

	local counter = `counter' - 1

}

	file write fh "\hline" _n "`blankline' \\" _n "`share_title' \\" _n


if ${prediction} == 0 {
	file write fh "\cmidrule(lr){2-7}" _n "`pred0_panelA_title' \\ \cmidrule(lr){2-7}" _n
}

local stop = 9
if ${prediction} == 0 {
	local stop = 5
}

forval i = 1/`stop' {
	file write fh "`line`i'' \\" _n
	if `i' == 5 & ${prediction} == 1 {
		file write fh "`blankline' \\" _n "`panelb' \medskip \\" _n
		file write fh "`model_2state_title' \\" _n
	}
	if `i' == 7 & ${prediction} == 1 {
		file write fh "`blankline' \\" _n "`model_3state_title' \\" _n
	}
	if `i' == 5 & ${prediction} == 0 {
		file write fh "`blankline' \\" _n "\cmidrule(lr){2-7} `pred0_panelB_title' \\ \cmidrule(lr){2-7}" _n
	}
}



if ${prediction} == 0 {

	local line1 "`tabshort' UI-Affected Nonemployment - \(`tau_${prediction}'^{N}\)"
	local line2 "`tablong' Unemployment Insurance - \(`tau_${prediction}'^{UI}\)"
	local line3 "`tablong' Unemployment Assistance - \(`tau_${prediction}'^{UA}\)"
	local line4 "`tabshort' Employment - \(`tau_${prediction}'^{E}\)"
	local line5 "`tabshort' Other Nonemployment - \(`tau_${prediction}'^{O}\)"

	local counter = 1

	foreach tausample in $tausamples {

		foreach condition in ${conditions} {

			use column`counter' using ${temp}/Tau_NewTable_stable_With76_age${age}_pred${prediction}_`condition'.dta, clear

			qui forval i = 1/`endobs_${prediction}' {
				sum column if _n == `i'
				local mean`i' = `r(mean)'
			}

			local val1: di %4.3f `mean4' + `mean5'
			local val2: di %4.3f `mean4'
			local val3: di %4.3f `mean5'
			local val4: di %4.3f `mean1'
			local val5: di %4.3f `mean2' + `mean3'
			local val6: di %4.3f `mean15'
			local val7: di %4.3f `mean17'
			local val8: di %4.3f `mean14'
			local val9: di %4.3f `mean16'

			forval i = 1/5 {
				if `i' == 1 & "`condition'" == "ENE4" {
					local line`i' "`line`i'' & N/A "
				}
				if `i' != 1 & "`condition'" == "ENE4" {
					local line`i' "`line`i'' & "
				}
				if "`condition'" == "EN" {
					local line`i' "`line`i'' & `val`i'' "
				}
			}

		}

		local counter = `counter' + 1

	}


	forval i = 1/`stop' {
		file write fh "`line`i'' \\" _n
	}

}

file write fh "`blankline' \\" _n "\hline \hline" _n "\end{tabular}" _n

file close fh

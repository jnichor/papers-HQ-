/*******************************************************************************

	DESCRIPTION: Figure A.13 Implied Sigma

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA13_ImpliedSigma`curr_date'", replace


use "${temp}/03a_Nonparametric_DTAFiles/03b_NonParametric_GroupedScatter_earn_pct_yrFwd1_stable.dta", clear

local list
forval i = -.5(0.1)9.9 {
	local list `list' `i'
}
/*
forval i = 5/9 {
	local list `list' `i'
}*/
forval i = 10(10)100 {
	local list `list' `i'
}
	local i = 1

foreach x in `list' {
	gen pred_hi = min(0.484*mean, `x')
	gen pred_low = min(0.244*mean, `x')

	qui reg pred_hi mean [weight=N], vce(robust)
	local b_hi_`i' = _b[mean]
	local s_hi_`i' = _se[mean]

	qui reg pred_low mean [weight=N], vce(robust)
	local b_low_`i' = _b[mean]
	local s_low_`i' = _se[mean]

	drop pred*

	local x_`i' = `x'
	local i = `i' + 1
}
clear
set obs 500

gen x = .
gen b_hi = .
gen s_hi = .

gen b_low = .
gen s_low = .

local counter = 1
foreach x in `list' {
	local name = subinstr("`x'", ".","",.)

	replace x = `x_`counter'' if _n == `counter'

	replace b_hi = `b_hi_`counter'' if _n == `counter'
	replace s_hi = `s_hi_`counter'' if _n == `counter'

	replace b_low = `b_low_`counter'' if _n == `counter'
	replace s_low = `s_low_`counter'' if _n == `counter'

	local counter = `counter' + 1
}

tw  (line b_hi x if x<=10, lpattern(shortdash)) (line b_low x if x<=10, lpattern(longdash) yline(0.484, lpattern(shortdash)) yline(0.244, lpattern(longdash)) xlab(-1/10) legend(label(1 "dw/db{superscript:*} = .48") label(2 "dw/db{superscript:*} = .24") ) xtitle("Maximum (% of Wage)") ytitle("Estimate of {&sigma}"))
graph export ${figures}/FigA13_ImpliedSigma.pdf, replace


tw  (line b_hi x if x<=5, lcolor(maroon)), ///
yline(0.484) yline(0,lpattern(dash)) xlab(-1/5) legend(off) xline(0, lpattern(dash)) ///
xtitle("Maximum (% of Wage)") ytitle("Estimate of {&sigma}")
graph export ${figures}/Sigma_Max_5ppt.pdf, replace

tw  (line b_hi x if x<=1, lcolor(maroon)), ///
yline(0.484) yline(0,lpattern(dash)) xlab(-.5(.1)1) ylab(0(.05).4) legend(off) xline(0, lpattern(dash)) ///
xtitle("Maximum (% of Wage)")
graph export ${figures}/Sigma_Max_1ppt.pdf, replace

log close

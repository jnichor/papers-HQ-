*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================


********************************************************************************
*
*
*	    11 Set Globals
*
*
********************************************************************************

* sample restriction
global bhpminyear 1990
global bhpmaxyear 2014


*** specifications: control variables
global controls1 const // No Controls
global controls2 i.jahr const  // Year FEs
global controls3 i.nace_d2_grp#i.jahr const  // Industry-Year FEs

*** robustness checks: sample restrictions based on BvD variables
global robust1 ""
global robust2 "& log_fias != ."
global robust3 "& log_av_per_empl != ."

global robustness1
global robustness2 "_robust_fias"
global robustness3 "_robust_av_per_empl"

* other choices
global bw_standard 2*365 // does not set sample bandwidth from BvD population; five-year window is set manually in file 105 (line 103)
global bw_rentsharing = 4*365 // for rentsharing
global bw_extensive = 5*365 // for figures, bandwidth plots, and donutholes

global winsor_values 1
global specifications 1 2 3 // no control, year fixed effects, industry-year fixed effects
global placebo_reform_years 1996 1997

global akm_radius_in_years 2
global akm_start_year = 1990+${akm_radius_in_years}
global akm_end_year = 2014-${akm_radius_in_years}

global bandwidth_windows= 60
global donutholes = 48



** cluster variable
* if changing cluster variable, used in 106 to generate cluster_variable
* rerun 106 if changing this global
global default_cluster idnr // firm level

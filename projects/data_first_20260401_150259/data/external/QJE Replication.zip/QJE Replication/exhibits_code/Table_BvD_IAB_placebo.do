*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================

cap file close fh

set more off

* Store Table Names in Globals
do "${code}/Set_Table_Names.do"

local wname = 1

global outcomes_wage ///
	log_te_mw  ///
	log_te_p50 ///
	az_ft_zens_p_empl ///
	ln_m_residuals  ///
	akm_firm_fe  ///
	pers_fe ///
	capital_share

global outcomes_profitability ///
	ebta_opre ///
	ebit_opre ///
	pl_opre ///
	ebta_toas ///
	ebit_toas ///
	pl_toas

global outcomes_skill ///
	log_ten_ges ///
	tenure ///
	fscl ///
	av_opre ///
	az_gq_per_empl ///
	az_mq_per_empl ///
	az_hq_per_empl ///
	separation_p_empl


global groups  wage  profitability 

global robustness1 ""
global robustness2 "_robust_fias"
global robustness3 "_robust_av_per_empl"


* IAB Outcomes
local pathDiff ${iab}/207
local pathDiD ${iab}/207
local pathRDTwoyear ${iab}/207
local pathRDFiveyear ${iab}/207

* Table Names
local file_wage "TableA4"
local file_profitability "TableA9"


********************************************************************************
*
*		DiD and Diff Output Table - Orbis Historical Sample
*
********************************************************************************



foreach robust in 1  {
foreach group in $groups {

		local name1_upper "Year FE"
		local name1_lower ""
		local name2_upper "Industry-Year FE"
		local name2_lower ""
		local name3_upper ""
		local name3_lower " "
********** Muted DiD **********
		local name4_upper "Year FE"
		local name4_lower ""
		local name5_upper "Industry FE"
		local name5_lower ""
		local name6_upper "Industry-Year FE"
		local name6_lower ""
**********     RD    **********
		local name7_upper "Year FE"
		local name7_lower ""
		local name8_upper "Industry-Year FE"
		local name8_lower ""
		local name9_upper "RD Five-year "
		local name9_lower "Year FE"
		local name10_upper "RD Five-year "
		local name10_lower "Industry-Year FE"

****************************************
*       Placebo Year
****************************************
		local name11_upper "Year FE"
		local name11_lower ""
		local name12_upper "Industry-Year FE"
		local name12_lower ""
		local name13_upper ""
		local name13_lower ""
********** Muted DiD **********
		local name14_upper "Year FE"
		local name14_lower ""
		local name15_upper "Industry FE"
		local name15_lower ""
		local name16_upper "Industry-Year FE"
		local name16_lower ""
**********     RD    **********
		local name17_upper "Year FE"
		local name17_lower ""
		local name18_upper "Industry-Year FE"
		local name18_lower ""
		local name19_upper "RD Five-year "
		local name19_lower "Year FE"
		local name20_upper "RD Five-year "
		local name20_lower "Industry-Year FE"


		* fill in with specs you want to use
		local x1 2
		local x2 3
		local x3 3
		local x4 2
		local x5 3
		local x6 3
		local x7 2
		local x8 3
		local x9 2
		local x10 3

		* fill in with specs you want to use
		local x11 2
		local x12 3
		local x13 3
		local x14 2
		local x15 3
		local x16 3
		local x17 2
		local x18 3
		local x19 2
		local x20 3

		local blocks 1 2 4 6 7 8 11 12 14 16 17 18/* 1 2 3 4 5 6 7 8 */

		local Winsor Winsor
		local DiD DiD
		local bw_standard


	local blank_line " "

	local columns "l "

	local name1_line " "
	local name2_line " "
	local colnumber_line " "

	local lineNYag1997 "\textit{N}, Firm-Years Stock Cs "
	local lineNYnag1997 "\textit{N}, Firm-Years  LLCs "
	local controlmean_lineAG1997 "Control Mean: Stock Cs "
	local controlmean_linenAG1997 "Control Mean: LLCs "
	local lineNag1997 "\textit{N}, Stock Cs "
	local lineNnag1997 "\textit{N}, LLCs "

	local lineNYag1996 "\textit{N}, Firm-Years Stock Cs "
	local lineNYnag1996 "\textit{N}, Firm-Years  LLCs "
	local controlmean_lineAG1996 "Control Mean: Stock Cs "
	local controlmean_linenAG1996 "Control Mean: LLCs "
	local lineNag1996 "\textit{N}, Stock Cs "
	local lineNnag1996 "\textit{N}, LLCs "



	local num_outcomes = 0
	foreach outcome in ${outcomes_`group'} {
		local num_outcomes = `num_outcomes' + 1
	}

	foreach block in `blocks' {
		local block`block'_lineB "\text{`name`block'_upper'}"
		local block`block'_lineSE " \text{`name`block'_lower'}"

		local colnumber = 0
		foreach outcome in ${outcomes_`group'} {

			if `block' == 1 {

				* Blank line
				local blank_line "`blank_line' & "

				* Number of columns
				local columns "`columns' c "

				* Name of outcome
				local name1_line "`name1_line' & ${name1_`outcome'}"
				local name2_line "`name2_line' & ${name2_`outcome'}"

				*Column number
				local colnumber = `colnumber' + 1
				local colnumber_line "`colnumber_line' & (`colnumber')"

			}

			* Panel A

			local RDtype
			* Use different result name for the simple differences
			if `block' < 10 {
			if `block' <= 2 {

					local DiD Diff
					local path `pathDiff'
					local placeboyear 1996

			}


            else if `block' == 7 | `block' == 8{

					local DiD RD
					local path `pathRDTwoyear'
					local placeboyear 1996
					local RDtype _AG

			}

			else if `block' == 9 | `block' == 10{

					local DiD RD
					local path `pathRDFiveyear'
					local placeboyear 1996
					local RDtype _AG

			}


			else {

					local DiD DiD
					local path `pathDiD'
					local placeboyear 1996

			}

			use "`path'/`DiD'_Placebo_`placeboyear'_`outcome'_`Winsor'`wname'_spec`x`block''`RDtype'.dta", clear
            }

			if `block' >= 10 {
			if `block' <= 12 {

					local DiD Diff
					local path `pathDiff'
					local placeboyear 1997

			}


            else if `block' == 17 | `block' == 18{

					local DiD RD
					local path `pathRDTwoyear'
					local placeboyear 1997
					local RDtype _AG

			}

			else if `block' == 19 | `block' == 20{

					local DiD RD
					local path `pathRDFiveyear'
					local placeboyear 1997
					local RDtype _AG

			}


			else {

					local DiD DiD
					local path `pathDiD'
					local placeboyear 1997

			}

			use "`path'/`DiD'_Placebo_`placeboyear'_`outcome'_`Winsor'`wname'_spec`x`block''`RDtype'.dta", clear
            }

			cap rename Nf N_AG
            cap rename controlmean controlmean_AG

			cap foreach var in b s p controlmean_AG N_AG N_nonAG controlmean_nonAG Nfirmyears_AG Nfirmyears_nonAG  {
				if inlist("`var'","p", "pag", "pind") {
					local display
				}
				else if inlist("`var'", "N", "Nfirms", "N_AG", "N_nonAG", "Nfirmyears_nonAG", "Nfirmyears_AG") {
					local display %8.0fc
				}
				else if inlist("`var'", "controlmean_AG", "controlmean_nonAG") & "`outcome'" == "av" {
					local display %5.2f
				}
				else if inlist("`var'", "controlmean_AG", "controlmean_nonAG") & strpos("`group'", "RobGroup") > 0  {
					local display %9.2fc
				}
				else {
					qui su `var'
					if int(abs(r(mean))*1000)<1 {
						if int(abs(r(mean))*10000)<1 {
							if int(abs(r(mean))*10000)<1 {
								local display %8.6f
							}
							else {
								local display %8.5f
							}
						}
						else {
							local display %5.4f
						}
					}
					else {
						local display %5.3f
					}
				}

				if inlist("`var'", "p", "pag", "pind", "bag", "sag", "bind", "sind", "controlmean_nonAG", "N_nonAG") {
					replace `var' = 1 if `var' == .
				}
				qui su `var'


				if (strpos("`outcome'", "_per_empl") > 0 | "`outcome'" == "av" | "`outcome'" == "diff_opre_av"  ) & ///
				(strpos("`outcome'", "log") == 0 & strpos("`outcome'", "i_") == 0 & strpos("`outcome'", "_cm") == 0) & ///
				inlist("`var'", "b", "s", "controlmean_AG", "controlmean_nonAG") ///
				& strpos("`group'", "ADIAB") == 0 & ///
				strpos("`outcome'", "az_") == 0 & ///
				strpos("`outcome'", "bet_") == 0 & strpos("`outcome'", "te_") == 0 & ///
				strpos("`outcome'", "alter_") == 0 & strpos("`outcome'", "man_from_") == 0 & ///
				strpos("`outcome'", "fscl_") == 0 & strpos("`outcome'", "aus") == 0 & strpos("`outcome'", "rank_") == 0 {
					local value = `r(mean)' / 1000
				}
				else {
					local value = `r(mean)'
				}

				if "`outcome'" == "ten_ges" & inlist("`var'", "b", "s", "controlmean_AG", "controlmean_nonAG") {
					local value = `value' / 365
				}

				if "`outcome'" == "tenure" & inlist("`var'", "b", "s", "controlmean_AG", "controlmean_nonAG"){
					   local value = `value' * 365.25
				}

				if "`outcome'" == "capital_share" & inlist("`var'", "b"){
					   local value = (-1) *`value'
					}

				if "`outcome'" == "capital_share" & inlist("`var'", "controlmean_AG", "controlmean_nonAG"){
					   local value = 1 - `value'
				}

				local `var': di `display' `value'
			}

			local s "(`s')"

			foreach var in p {
				if ``var'' > .1 {
					local star_`var' ""
				}
				if inrange(``var'',.05,.1) {
					local star_`var' "$^{*}$"
				}
				if inrange(``var'',.01,.05) {
					local star_`var' "$^{**}$"
				}
				if ``var'' <= .01 {
					local star_`var' "$^{***}$"
				}
			}

			if `block' == 6 {

				local controlmean_lineAG1996 "`controlmean_lineAG1996' & `controlmean_AG' "
				local controlmean_linenAG1996 "`controlmean_linenAG1996' & `controlmean_nonAG' "
				local lineNag1996 "`lineNag1996' & `N_AG'"
				local lineNnag1996 "`lineNnag1996' & `N_nonAG'"
				local lineNYag1996 "`lineNYag1996' & `Nfirmyears_AG'"
				local lineNYnag1996 "`lineNYnag1996' & `Nfirmyears_nonAG'"

			}

			if `block' == 16 {

				local controlmean_lineAG1997 "`controlmean_lineAG1997' & `controlmean_AG' "
				local controlmean_linenAG1997 "`controlmean_linenAG1997' & `controlmean_nonAG' "
				local lineNag1997 "`lineNag1997' & `N_AG'"
				local lineNnag1997 "`lineNnag1997' & `N_nonAG'"
				local lineNYag1997 "`lineNYag1997' & `Nfirmyears_AG'"
				local lineNYnag1997 "`lineNYnag1997' & `Nfirmyears_nonAG'"

			}

			local block`block'_title "`block`block'_title' & "
			local block`block'_lineB "`block`block'_lineB' & `b'`star_p'"
			local block`block'_lineSE "`block`block'_lineSE' & `s'"




		} // Outcomes in Group
	} // Specification

	* Place all the locals into a table
	* open file
	local num_panel = `num_outcomes' + 1
	local blank_line " "
	local Placebo_1996_title_line "\multicolumn{`num_outcomes'}{c}{\textbf{Panel A: Placebo Reform 1996}}"
	local Placebo_1997_title_line "\multicolumn{`num_outcomes'}{c}{\textbf{Panel B: Placebo Reform 1997}}"
		local Diff_1996_title_line "\multicolumn{`num_panel'}{l}{\textit{Panel A.a: Difference Design (Stock Corporations)}}"
		local DiD_1996_title_line1 "\multicolumn{`num_panel'}{l}{\textit{Panel A.b:  Difference-in-Differences Design (Stock Corporations + LLC Control Group)}}"
		local RD_1996_title_line "\multicolumn{`num_panel'}{l}{\textit{Panel A.c: Regression Discontinuity Design (Stock Corporations)}}"
        local Diff_1997_title_line "\multicolumn{`num_panel'}{l}{\textit{Panel B.a: Difference Design (Stock Corporations)}}"
		local DiD_1997_title_line1 "\multicolumn{`num_panel'}{l}{\textit{Panel B.b:  Difference-in-Differences Design (Stock Corporations + LLC Control Group)}}"
		local RD_1997_title_line "\multicolumn{`num_panel'}{l}{\textit{Panel B.c: Regression Discontinuity Design (Stock Corporations)}}"


	file open fh using "${tables}/`file_`group''.tex", write replace

	* header
	file write fh "\begin{tabular}{`columns'}" _n ///
	"\hline \hline" _n ///
	"`blank_line' \\" _n ///
	"`name1_line' \\ " _n ///
	"`name2_line' \\ " _n ///
	"`colnumber_line' \\ " _n ///
	"\hline" _n


	* coefficients and SEs for different specs
	foreach block in `blocks' {

	if `block' == 1 {
	file write fh "\hline" _n  "& `Placebo_1996_title_line' \\" _n
	file write fh "`Diff_1996_title_line' \\" _n "\hline" _n "`blank_line' \\" _n
	}

	if `block' == 4 {
	file write fh "\hline" _n  "`DiD_1996_title_line1' \\" _n "\hline" _n "`blank_line' \\" _n
	}

	if `block' == 7 {
	file write fh 	 "\hline" _n "`RD_1996_title_line'\\" _n "\hline" _n "`blank_line' \\" _n
	}

	if `block' == 11 {

	file write fh  "\hline" _n  "& `Placebo_1997_title_line' \\" _n
	file write fh " `Diff_1997_title_line' \\" _n "\hline" _n "`blank_line' \\" _n
	}

	if `block' == 14 {
	file write fh "\hline" _n  "`DiD_1997_title_line1' \\" _n  "\hline" _n "`blank_line' \\" _n
	}

	if `block' == 17 {
	file write fh 	 "\hline" _n "`RD_1997_title_line'\\" _n "\hline" _n "`blank_line' \\" _n
	}

	file write fh "`block`block'_lineB' \\" _n ///
		"`block`block'_lineSE' \\" _n ///


	if `block' == 8 {
	file write fh  "\hline" _n ///
	"`controlmean_lineAG1996' \\" _n ///
	"`lineNag1996' \\" _n ///
	"`lineNYag1996' \\" _n ///
	"\hline" _n ///
   "`controlmean_linenAG1996' \\" _n ///
	"`lineNnag1996' \\" _n ///
	"`lineNYnag1996' \\" _n
	}

	if `block' == 18 {
	file write fh  "\hline" _n ///
	"`controlmean_lineAG1997' \\" _n ///
	"`lineNag1997' \\" _n ///
	"`lineNYag1997' \\" _n ///
	"\hline" _n ///
   "`controlmean_linenAG1997' \\" _n ///
	"`lineNnag1997' \\" _n ///
	"`lineNYnag1997' \\" _n
	}

	}

	* footer
	file write fh "\hline \hline" _n ///
	"\end{tabular}" _n

	file close fh

} // Group of Outcomes
} // Robustness

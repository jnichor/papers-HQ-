/*******************************************************************************

	DESCRIPTION: Figures A.2-A.5 Additional Nonparametric Figures.



*******************************************************************************/

set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA2-5_Additional_NonParametric`curr_date'", replace

local counter = 1

local color1 sea
local color2 sky

local s1 S
local s2 O

local h1
local h2 h


foreach reform in $reforms {
local counter = `counter' + 1
* Figures (a) through (d)
forval yr = 1/2 {
use ${temp}/03a_Nonparametric_DTAFiles/03a_NonParametric_Sample_Reform`reform'_stable.dta if in_sample_`reform' == 1, clear


	**** Defining different earnings concepts for the x-axis
	if `reform' == 2001 {
		local earn_cpt adj_earnings
	}
	else {
		local earn_cpt infl1_adj_earnings
	}

	if `reform' == 1985 {
		su earn_pct_bin if treatment_`reform' > 0 & !mi(treatment_`reform')
		local relPct = r(min)
	}
	else {
		su earn_pct_bin if treatment_`reform' >0  & !mi(treatment_`reform')
		local relPct = r(max)
	}

	**** For 2001, requiring that the entire percentile is treated
	if `reform' == 2001 {
		local relPct = `relPct' - 1
	}

	su `earn_cpt' if earn_pct_bin == `relPct'
	local zeroEarn = r(mean)


	* Plotting additional line for 1985
	if "`reform'" == "1985" {
		local addLine 16700
	}
	else {
		local addLine `zeroEarn'
	}

	local baseyr = `reform' - 1 - 1900
	local yrplus = `baseyr' + `yr'
	local pboyr = `baseyr' - `yr'
	local pboyrplus = `pboyr' + `yr'


	foreach var in baseyr yrplus pboyr pboyrplus {
		if ``var'' >= 100 {
			local `var' = ``var'' - 100
			local `var' = "0``var''"
		}
	}

	local letter = word("a b", `yr')

	tw (connected earn_Diff_f`yr' `earn_cpt', lcolor(reddish) mcolor(reddish) msymbol(T`h`yr''))  ///
	(connected pbo_earn_Diff_f`yr' `earn_cpt', lcolor(brown) mcolor(brown) msymbol(D`h`yr'')) ///
	(connected diff_w_pbo`yr' `earn_cpt', lcolor(`color`yr'') mcolor(`color`yr'') msymbol(`s`yr''`h`yr'')  ///
	ytitle("Wage Growth (dw/w)") ///
	xtitle("Nominal Earnings in Base Year") ///
	/*xline(`zeroEarn', lpattern(shortdash) lcolor(gray)) ///
	xline(`addLine', lpattern(shortdash) lcolor(gray))*/ ///
	xlab(, labsize(medium)) ylab(, labsize(medium)) ///
	legend(size(medium) label(1 "Wage Growth '`baseyr'-'`yrplus'") ///
	label(2 "Wage Growth '`pboyr'-'`pboyrplus'") ///
	label(3 "Difference") order(2 1 3) col(1) pos(6) on))

	graph export "${figures}/FigA`counter'`letter'.pdf", replace

	local letter = word("c d", `yr')

	local thickness medthick
	local shape dash

	tw (line RRdiff_f`yr'_RRRY_BRRY `earn_cpt' `earn_rest', lcolor(dknavy) lpattern(dash) ) ///
	(line RRdiff_f1_RRiBY_BRiBY `earn_cpt' `earn_rest', lcolor(green%50) lwidth(thick) lpattern(solid) ///
	xlab(, labsize(medium)) ylab(, labsize(medium)) ///
	ytitle("Change (Pct Pts)") ///
	xtitle("Nom. Earnings in Base Year") ///
	legend(size(medium) label(1 "Realized RR Change") label(2 "Replacement Rate Change") order(2 1) pos(6)))

	graph export "${figures}/FigA`counter'`letter'.pdf", replace

* Figures (e) and (f)

if `reform' == 1976 & `yr' == 2 {
}
else {
	use ${temp}/03a_Nonparametric_DTAFiles/03a_NonParametric_Sample_Reform`reform'_stable_pbo`yr'.dta if in_sample_`reform' == 1, clear

	**** Adding different treatment line s.t. the same percentiles are treated
	if `reform' == 1985 {
		su earn_pct_bin if treatment_`reform' > 0 & !mi(treatment_`reform')
		local relPct = r(min)
	}
	else {
		su earn_pct_bin if treatment_`reform' >0  & !mi(treatment_`reform')
		local relPct = r(max)
	}

	**** For 2001, requiring that the entire percentile is treated
	if `reform' == 2001 {
		local relPct = `relPct' - 1
	}

	su `earn_cpt' if earn_pct_bin == `relPct'
	local zeroEarn = r(mean)

	* Plotting additional line for 1985
	if "`reform'" == "1985" {
		local addLine 16700
	}
	else {
		local addLine `zeroEarn'
	}


	local letter = word("e f", `yr')

	local baseyr = `reform' - 1 - 1900 - `yr'
	local yrplus = `baseyr' + `yr'
	local pboyr = `baseyr' - `yr'
	local pboyrplus = `pboyr' + `yr'


	foreach var in baseyr yrplus pboyr pboyrplus {
		if ``var'' >= 100 {
			local `var' = ``var'' - 100
			local `var' = "0``var''"
		}
	}

	tw (connected earn_Diff_f`yr' `earn_cpt', lcolor(reddish) mcolor(reddish) msymbol(T`h`yr''))  ///
	(connected pbo_earn_Diff_f`yr' `earn_cpt', lcolor(brown) mcolor(brown) msymbol(D`h`yr'')) ///
	(connected diff_w_pbo`yr' `earn_cpt', lcolor(`color`yr'') mcolor(`color`yr'') msymbol(`s`yr''`h`yr'')  ///
	ytitle("Wage Growth (dw/w)") ///
	xtitle("Nominal Earnings in Base Year") ///
	/*xline(`zeroEarn', lpattern(shortdash) lcolor(gray)) ///
	xline(`addLine', lpattern(shortdash) lcolor(gray))*/ ///
	legend(size(medium) label(1 "Wage Growth '`baseyr'-'`yrplus'") ///
	label(2 "Wage Growth '`pboyr'-'`pboyrplus'") ///
	label(3 "Difference") order(2 1 3) col(1) pos(6) on))

	graph export "${figures}/FigA`counter'`letter'.pdf", replace
} //all placebo but 1976
} //Time horizon

} //Reforms

log close

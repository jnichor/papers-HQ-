/*******************************************************************************

	DESCRIPTION:  Creates variables requiring monthly observations
		across many years.

*******************************************************************************/




********************************************************************************
***** Preliminaries
********************************************************************************
cap log close
local curr_date = c(current_date)
log using "${logs}/01c_Build_SpellVariables`curr_date'", replace




****************************************************************************
* Looping though Male and Female Samples + random splits
****************************************************************************
foreach sex_sample in $sexSamples {
foreach group in 1 2 {

	use svnr status_temp benr_temp lastfirm nextfirm m_date using ${temp}/01_SpellData_`sex_sample'_Group`group'.dta, clear




	****************************************************************************
	* Editing data
	****************************************************************************


	***** Generating labor force status spells = sequential observations in the same labor market status
		* Note this generates spells in each labor market state not just nonemployment
	gen spell = 1
	bysort svnr (m_date): replace spell = cond(_n == 1, spell, /// /* Don't replace first obs */
				 cond(status_temp != status_temp[_n - 1], /// /* Change in emp status */
				 spell[_n - 1] + 1, /// /* First obs of new emp stat -> add one*/
				 spell[_n - 1])) /* Other observations -> prev value*/

	* Generating the length of each spell (in months)
	tempvar ind
	gen `ind' = 1
	bysort svnr spell: gegen spell_len = sum(`ind')

	* Generating observation number within spell
	bysort svnr spell (m_date): gen svnr_spell_id = _n


	***** Generating the number of months since specific statuses
	assert !mi(status_temp)

	* Months since nonemployment
	gen mths_since_nonemp = 0 if status_temp != 3  /* Nonemployment -> 0 months */
	bys svnr (m_date): replace mths_since_nonemp = 1 if _n == 1 & mi(mths_since_nonemp) /* First obs -> 1 months */
	bysort svnr (m_date): replace mths_since_nonemp = mths_since_nonemp[_n-1] + 1 if !mi(mths_since_nonemp[_n-1]) & mi(mths_since_nonemp) /* Add one to prev obs if not already defined */

	* Months since UIB receipt (status == 1)
	gen mths_since_UI = 0 if status_temp == 1 /* Nonemployment -> 0 months */
	bys svnr (m_date): replace mths_since_UI = 1 if _n == 1 & mi(mths_since_UI)
	bysort svnr (m_date): replace mths_since_UI = mths_since_UI[_n-1] + 1 ///
		if !mi(mths_since_UI[_n-1]) & mi(mths_since_UI)


	gen recall = nextfirm == lastfirm & lastfirm != "" & status_temp != 3

	* Months since nonemployment, skipping recalls to same firm after nonemployment spell
	gen mths_since_nonemp_skiprecalls = 0 if status_temp != 3 & recall == 0
	bys svnr (m_date): replace mths_since_nonemp_skiprecalls = 1 if _n == 1 & mi(mths_since_nonemp_skiprecalls)
	bys svnr (m_date): replace mths_since_nonemp_skiprecalls = mths_since_nonemp_skiprecalls[_n-1] + 1 ///
		if !mi(mths_since_nonemp_skiprecalls[_n-1]) & mi(mths_since_nonemp_skiprecalls)

	* Months since unemployment, skipping recalls to same firm after unemployment spell
	gen mths_since_UI_skiprecalls = 0 if status_temp == 1 & recall == 0
	bys svnr (m_date): replace mths_since_UI_skiprecalls = 1 if _n == 1 & mi(mths_since_UI_skiprecalls)
	bys svnr (m_date): replace mths_since_UI_skiprecalls = mths_since_UI_skiprecalls[_n-1] + 1 ///
		if !mi(mths_since_UI_skiprecalls[_n-1]) & mi(mths_since_UI_skiprecalls)

	drop lastfirm nextfirm recall

	***** Variable indicating employment status in month before current spell began.
		* Note that the first spell (i.e. from January 1972) will have a missing value, since we do not
		* know what the previous employment status was.
	gen byte stat_prespell = .
	bys svnr (m_date): replace stat_prespell = status_temp[_n-1] if svnr_spell_id == 1
	bys svnr (m_date): replace stat_prespell = stat_prespell[_n-1] if svnr_spell_id != 1




	****************************************************************************
	* Some Asserts
	****************************************************************************

	* Current spell duration less than spell length
	assert svnr_spell_id <= spell_len

	* Spell length equal to maximum spell duration
	bysort svnr spell: egen temp_max = max(svnr_spell_id)
	assert spell_len == temp_max
	drop temp_max

	* Months since labor market status for first obs
	bysort svnr (m_date): gen first_obs = _n == 1
	assert mths_since_nonemp == 1 if first_obs == 1 & status == 3
	assert mths_since_nonemp == 0 if first_obs == 1 & status != 3
	assert mths_since_UI == 1 if first_obs == 1 & status != 1
	assert mths_since_UI == 0 if first_obs == 1 & status == 1
	assert mths_since_nonemp_skiprecalls == 1 if first_obs == 1 & status == 3
	assert mths_since_nonemp_skiprecalls == 0 if first_obs == 1 & status != 3
	assert mths_since_UI_skiprecalls == 1 if first_obs == 1 & status != 1
	assert mths_since_UI_skiprecalls == 0 if first_obs == 1 & status == 1


	* Individuals with one months since XX status should have XX status last observation or first obs
	sort svnr m_date
	assert status_temp[_n - 1] != 3 if mths_since_nonemp == 1 & first_obs != 1
	assert status_temp[_n - 1] == 1 if mths_since_UI == 1 & first_obs != 1
	assert status_temp[_n - 1] != 3 if mths_since_nonemp_skiprecalls == 1 & first_obs != 1
	assert status_temp[_n - 1] == 1 if mths_since_UI_skiprecalls == 1 & first_obs != 1

	* Status pre-spell
	assert mi(stat_prespell) if first_obs == 1
	assert stat_prespell == 1 if mths_since_UI == 1 & first_obs != 1
	assert stat_prespell != status_temp



	****************************************************************************
	* Saving annual data (each December)
	****************************************************************************

	keep svnr spell spell_len svnr_spell_id stat_prespell m_date mths_since_*
	keep if month(dofm(m_date)) == 12
	compress
	save ${temp}/01_SpellVariables_`sex_sample'_`group'.dta, replace

} // Groups 1 and 2




****************************************************************************
* Appending together spell variables for each sex sample
****************************************************************************
clear
use  ${temp}/01_SpellVariables_`sex_sample'_1.dta
append using ${temp}/01_SpellVariables_`sex_sample'_2.dta

save ${temp}/01_SpellVariables_`sex_sample'.dta, replace

forval i = 1/2 {
	erase ${temp}/01_SpellVariables_`sex_sample'_`i'.dta
}

} // Different sex samples


log close

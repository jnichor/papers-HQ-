/*******************************************************************************

	DESCRIPTION: Figure A.18 PBD Reform DiD



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
clear all
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA18_PBD_DiD`curr_date'", replace

********************************************************************************

local treat_yr 1988

local color1 sea
local color2 sky

local s1 S
local s2 O

local h1
local h2 h

foreach yrfwd in $earnF {
	local letter = word("a b", `yrfwd')

	* Saving estimated coeffs

	use "${resDat}/05c_Coeffs_YrFwd`yrfwd'_Controls.dta", clear

	tw (rcap LB UB year if year < `treat_yr', lcolor(`color`yrfwd'')) ///
	(scatter coeff year if year < `treat_yr', mcolor(`color`yrfwd'') msymbol(`s`yrfwd''`h`yrfwd'')) ///
	(rcap LB UB year if year == `treat_yr', lcolor(navy) lwidth(medthick)) ///
	(scatter coeff year if year == `treat_yr', yline(0) xtitle("") ///
	ytitle("Earnings Growth Effect of PBD Extension") ysc(titlegap(-12)) ///
	ylab(-1(.2)1, grid) legend(label(2 "Placebo Years") label(4 "Treated Year") ///
	order(2 4) pos(6)) mcolor(navy) msize(large) mlwidth(medthick) msymbol(`s`yrfwd''`h`yrfwd'') )

	graph export "${figures}/FigA18`letter'_DiD.pdf", replace
}

log close

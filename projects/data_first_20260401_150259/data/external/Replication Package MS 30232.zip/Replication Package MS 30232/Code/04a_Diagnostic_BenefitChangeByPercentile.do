/*******************************************************************************

	DESCRIPTION: Creates dataset of db/w by percentile for each reform.



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/04a_Diagnostic_BenefitChangeByPercentile`curr_date'", replace

********************************************************************************

foreach reform in $reforms {

	use earn_pct RRdiff_f*_RRiBY_BRiBY treatment_`reform' control_`reform' in_sample_`reform' year ///
	if year == `reform' - 1 ///
	using ${temp}/02b_Reform`reform'.dta, clear

	gen earn_pct_bin = round(earn_pct, 1)

	collapse RRdiff_f1_RRiBY_BRiBY treatment_`reform' control_`reform' in_sample_`reform', by(earn_pct_bin)

	gen year = `reform'

	rename treatment_`reform' treatment
	rename control_`reform' control
	rename in_sample_`reform' in_sample

	tempfile colData`reform'
	save `colData`reform'', replace


} // Looping through multiple reforms

**** Appending reforms together
clear
set obs 1
gen filler = 1
foreach reform in $reforms {

	append using `colData`reform''
}

drop if filler == 1
drop filler

* Replacing the 1985 replacement rate to be non-zero for plotting
replace RRdiff_f1_RRiBY_BRiBY = .2 if RRdiff_f1_RRiBY_BRiBY == 0 & year == 1985

save  ${temp}/04a_BenefitChanges_byReform_Percentiles.dta, replace

log close

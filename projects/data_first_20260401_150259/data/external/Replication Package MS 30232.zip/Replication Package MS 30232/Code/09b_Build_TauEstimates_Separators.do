/*******************************************************************************

	DESCRIPTION: estimate days in U / days in N for separators.

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off


***** Logging
cap log close
local curr_date = c(current_date)
log using "${logs}/09b_Build_TauEstimates_Separators`curr_date'", replace


scalar Adjustment = 1




********************************************************************************
***** Adjusting the appended qual files
********************************************************************************
if scalar(Adjustment) == 1 {
	* use data
	noi use "${temp}/09a_Data_Tau_year${vyear}-${byear}_age${vage}-${bage}_days1_qualappended_UIvsUA.dta", clear

	* Indicators for status at age limit -- CHECK THAT EVERYONE HAS NON-MISSING BIRTHDAY INFO
	foreach age in $age_limit {
		gen date_turn_`age' = birthdat + (`age'*365)
		format date_turn_`age' %td
		gen temp = status if inrange(date_turn_`age', vdat, bdat)
		bys svnr (vdat bdat): gegen status_at_age`age' = firstnm(temp)
		drop temp
	}

	* Defining retirement and disability -- note these match the spell definitions in definestatus.do
	gen retirement = inlist(detailqual, "05", "09", "D5", "D6", "D8", "D9", "J5", "N9", "Y5") | inlist(detailqual, "Y6", "Y8", "Y9", "Z3")
	gen disability = inlist(detailqual, "07", "08", "7A", "D7", "Y7", "ZM", "FE")

	assert status == 4 if retirement == 1 | disability == 1

	*Last date of unemployment spells
	gen empl_date = bdat if status == 3
	format empl_date %td


	save "${temp}/09b_Data_Tau_year${vyear}-${byear}_age${vage}-${bage}_days1_qualappended_Adjusted_UIvsUA.dta", replace
}




********************************************************************************
***** Looping through different sample restrictions to generate tau for
	* These different tau samples correspond to the different columns in the tau tables
	* Ret’nt or Disability -- DeathRetDis`age'_PermEU
	* Retirement -- DeathRet`age'_PermEU
	* No restriction -- Death`age'
********************************************************************************
foreach x in $tau_samples {

	noi di "Prepare data for N > ${days}..."

	foreach year in $prereformyears {
		timer clear
		timer on 1


		********************************************************************************
		***** Identifying employment separations that occur within a year + subsequent spells
		********************************************************************************

		***** Loading spells if the end date is past the year starting dates
		noi use "${temp}/09b_Data_Tau_year${vyear}-${byear}_age${vage}-${bage}_days1_qualappended_Adjusted_UIvsUA.dta" if bdat >= mdy(1,1,`year'), clear

		* Dropping nonemployment spells that span the whole year.
		drop if status != 3 & vdat <= mdy(12,31,`year' - 1) & bdat >= mdy(1,1,`year')

		* Find the date of the first separation of employment
		bys svnr: gegen firstsep = min(empl_date)
		format firstsep %d

		* Drop individuals who don't separate in that year
		drop if year(firstsep) > `year' | mi(firstsep)

		* Find the date that is 16 years after the separation
		gen sixteenyearslater = firstsep + (16*365)
		format sixteenyearslater %d
		gen datetype_text = "16 Years Later"

		* Indicators for whether you return to employment with 1, 2, 4 years
		foreach i in ${returnWorkLim} {
			gen postsep_empl_date = vdat if vdat > firstsep & status == 3
			bys svnr (vdat bdat): gegen postsep_empl_start = min(postsep_empl_date)
			gen length_till_emp = postsep_empl_start - firstsep
			gen ENE`i' = length_till_emp <= `i'*365
			drop length_till_emp postsep_empl_start postsep_empl_date
		}




		********************************************************************************
		***** For each age limit -- calculating the counting ending date based on different criteria
		********************************************************************************
		foreach age in $age_limit {

			***** Ending at the minimum of 16 years later, turning age $age_limit, or death
			if "`x'" == "Death`age'" {
				* Persons who first turn 70
				replace sixteenyearslater =  floor(birthdat + `age'*365.25)	if floor(birthdat + `age'*365.25)<sixteenyearslater

				* Persons who first die
				replace datetype_text = "Death" 					if deathdat<sixteenyearslater	& !mi(deathdat)
				replace sixteenyearslater = deathdat				if deathdat<sixteenyearslater	& !mi(deathdat)

			}

			***** Ending at 16 years later, turning age limit, death, or absorbing retirement or disability
			if "`x'" == "DeathRetDis`age'_PermEU" {
				* Persons who first turn 70
				replace sixteenyearslater =  floor(birthdat + `age'*365.25)	if floor(birthdat + `age'*365.25)<sixteenyearslater

				* Persons who first die
				replace datetype_text = "Death" 					if deathdat<sixteenyearslater	& !mi(deathdat)
				replace sixteenyearslater = deathdat				if deathdat<sixteenyearslater	& !mi(deathdat)


				***** Absorbing retirement or disability
					* Note defines last_EUenddate as last EU end date before sixteen years later
					* this causes problems for very old people but it won't matter
				* Find the end date of each E or U spell
				gen EU_enddate = bdat if inlist(status, 1,2,3) & vdat < sixteenyearslater & bdat <= sixteenyearslater
				* Find the last end date of each E/U spell in the data
				bys svnr (vdat bdat): gegen last_EUenddate = max(EU_enddate)
				* Find the start dates of any retirement or disability spell after the last end date of E/U spells
				gen RD_startdate_postEU = vdat if vdat > last_EUenddate & (retirement == 1 | disability == 1)
				* Find the earliest start date of the retirement/disability spells after the last end date of E/U spells
				bys svnr (vdat bdat): gegen first_RDstart_postEU = min(RD_startdate_postEU)
				* Replace the last day of counting with this date if it is earlier than the date of turning `age' or dying
				replace datetype_text = "R/D Post"					if first_RDstart_postEU<sixteenyearslater	& !mi(first_RDstart_postEU)		// persons on disability before age 54
				replace sixteenyearslater = first_RDstart_postEU		if first_RDstart_postEU<sixteenyearslater & !mi(first_RDstart_postEU)
				* Drop temporary variables
				drop EU_enddate last_EUenddate RD_startdate_postEU
			}

			if "`x'" == "DeathRet`age'_PermEU" {
				* Persons who first turn 70
				replace sixteenyearslater =  floor(birthdat + `age'*365.25)	if floor(birthdat + `age'*365.25)<sixteenyearslater

				* Persons who first die
				replace datetype_text = "Death" 					if deathdat<sixteenyearslater	& !mi(deathdat)
				replace sixteenyearslater = deathdat				if deathdat<sixteenyearslater	& !mi(deathdat)


				***** Absorbing retirement

				* Find the end date of each E or U spell
				gen EU_enddate = bdat if inlist(status, 1,2,3) & vdat < sixteenyearslater & bdat <= sixteenyearslater
				* Find the last end date of each E/U spell in the data
				bys svnr (vdat bdat): gegen last_EUenddate = max(EU_enddate)
				* Find the start dates of any retirement or disability spell after the last end date of E/U spells
				gen RD_startdate_postEU = vdat if vdat > last_EUenddate & retirement == 1
				* Find the earliest start date of the retirement/disability spells after the last end date of E/U spells
				bys svnr (vdat bdat): gegen first_RDstart_postEU = min(RD_startdate_postEU)
				* Replace the last day of counting with this date if it is earlier than the date of turning `age' or dying
				replace datetype_text = "R Post"					if first_RDstart_postEU<sixteenyearslater	& !mi(first_RDstart_postEU)		// persons on disability before age 54
				replace sixteenyearslater = first_RDstart_postEU		if first_RDstart_postEU<sixteenyearslater & !mi(first_RDstart_postEU)
				* Drop temporary variables
				drop EU_enddate last_EUenddate RD_startdate_postEU
			} //
		} // Age limits




		********************************************************************************
		***** Total amount of time spent in each state up until the ending date
		********************************************************************************
		* Total find from separation to end -- sometimes negative for individuals over 70
		gen total_time = sixteenyearslater - firstsep + 1

		* Keep only spells that start after the separation but before 16 years post-separation
		keep if vdat >= firstsep
		drop if vdat > sixteenyearslater
		assert total_time > 0

		* Keep only portion of subsequent spells that is within 16 years of separation
		replace bdat = sixteenyearslater if bdat > sixteenyearslater

		gen byte UI = status == 1
		gen byte UA = status == 2
		gen byte E = status == 3
		gen byte O = status == 4

		gen datetype = .
		replace datetype = 1 if datetype_text == "16 Years Later"
		replace datetype = 2 if datetype_text == "Death"
		replace datetype = 3 if datetype_text == "Retirement"
		replace datetype = 4 if datetype_text == "Disability"
		replace datetype = 5 if datetype_text == "R/D Post"
		gen length = bdat - vdat + 1

		fcollapse (sum) E UI UA O (mean) total_time ENE* datetype [weight = length], by(svnr)
		gen tot_obs_time = E + UI + UA + O
		assert tot_obs_time <= total_time
		drop tot_obs_time

		ds E UI UA O
		foreach var in `r(varlist)' {
			gen `var'_frac = `var' / total_time
		}

		gen N_frac = 1 - UI_frac - UA_frac - E_frac - O_frac



		compress
		save ${temp_qual}/09b_Tau_Year`year'_`x'_WithDateType_UIvsUA.dta, replace
		timer off 1
		qui timer list 1
		local time: di %5.3f `r(t1)'/60
		noi di "Time for `year': `time' minutes"

	}
}




***** Appending together the tau samples
foreach x in $tau_samples {
clear
set obs 1
gen year = 999
foreach year in $prereformyears {
	append using ${temp_qual}/09b_Tau_Year`year'_`x'_WithDateType_UIvsUA.dta
	replace year = `year' - 1 if mi(year)
}
drop if year == 999
save ${temp}/09b_Tau_Appended_`x'_WithDateType_UIvsUA.dta, replace
}


log close

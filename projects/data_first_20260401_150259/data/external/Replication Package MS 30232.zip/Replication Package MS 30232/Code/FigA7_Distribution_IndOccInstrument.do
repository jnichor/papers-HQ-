/*******************************************************************************

	DESCRIPTION: Figure A.7 Distribution of benefit change at firm and
	             industry-occupation levels.



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
clear all
set more off
clear all
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA7_Distribution_IndOccInstrument`curr_date'", replace

********************************************************************************

local x benr
local yrFwd 1
local grprestriction  inlist(reform, 1976, 1985, 1989, 2001) & inlist(yr_l5,.,0) & inlist(yr_l4,.,0) & mth_emp == 12
local xtitle_benr Average Reform-Induced Benefit Change at Firm Level
local xtitle_indocc Average Reform-Induced Benefit Change at Industry-Occupation Level


clear
set obs 1
gen filler = 1

use ${temp}/02c_PooledReforms_yrFwd`yrFwd'.dta if `grprestriction', clear

foreach x in benr indocc {
	histogram RRinstrument_`x'_f`yrFwd', ///
	xtitle("`xtitle_`x''")

	graph export "${figures}/FigA7_Distribution_`x'.pdf", replace

}

log close

*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================



* Generates rent sharing graphs
* --------------- --------------- --------------- ---------------  -------------




* --------------- --------------- --------------- ---------------  -------------
*
* Graphical Settings
* --------------- --------------- --------------- ---------------  -------------
graph set window fontface "Verdana"
set scheme plotplainblind
local fontsize 4.5
local fontsize2 3.5
local msize 3
* --------------- --------------- --------------- ---------------  -------------
*
* Pooled Rent Sharing
* --------------- --------------- --------------- ---------------  -------------
use "${iab}/212/restriction4/rent_meanlnavemp_mean_akmfirmfe_0.dta", clear
qui sum b
local b = `r(mean)'
qui 	sum s
local s = `r(mean)'
use "${iab}/212/restriction4/bins_rent_meanlnavemp_mean_akmfirmfe_0.dta"


local slope : di %4.3f `b'
local slopese : di %4.3f `s'

sum r_meanlnavemp
local min =  `r(min)'
local max =  `r(max)'

local min = -2
local max = 2
twoway ///
(scatter  r_mean_akmfirmfe r_meanlnavemp, mcolor(gs6) lcolor(gs6)  msymbol(square) msize(`msize')) ///
(function `b'*x,  lcolor(gs6) lp(solid) range(`min' `max'))    ///
, graphregion(fcolor(white))  xtitle("Residualized Firm-Level Mean of Log Value Added per Worker", size(`fontsize'))  ///
ytitle("Residualized Firm Pay Premia",  size(`fontsize'))  xlab(-2(1)2,labsize(`fontsize')) ylab(-0.2(0.1)0.2,labsize(`fontsize')) /*yscale(titlegap(*-40))*/ ///
legend( order(-  "Slope: `slope' (SE `slopese')") size(`fontsize')  pos(5) ring(0)  )

graph display ,	xsize(20) ysize(9)
graph export "$figures/figA7.pdf" , replace


* --------------- --------------- --------------- ---------------  -------------
*
* Rent Sharing With and Without Shared Governance
* --------------- --------------- --------------- ---------------  -------------

use "${iab}/212/restriction4/rent_meanlnavemp_mean_akmfirmfe_2.dta", clear

foreach est in b0 s1 s0 b1 c1   {
qui sum `est'
local `est' = `r(mean)'
}

local slope : di %4.3f `b0'
local slopese : di %4.3f `s0'
local diff : di %4.3f `b1'
local  diffse : di %4.3f `s1'



use "${iab}/212/restriction4/rent_meanlnavemp_mean_akmfirmfe_4.dta", clear
foreach est in b3 s3  {
qui sum `est'
local `est' = `r(mean)'
}
local did : di %4.3f `b3'
local  didse : di %4.3f `s3'

use "${iab}/212/restriction4/bins_rent_meanlnavemp_mean_akmfirmfe_2.dta"
cap rename (meanlnavemp mean_akmfirmfe)  ( r_meanlnavemp r_mean_akmfirmfe)

qui sum r_meanlnavemp
local min =  `r(min)'
local max =  `r(max)'

local min = -2
local max = 2

local b1  = `b0' + `b1'

twoway ///
(function `b1'*x  , range(`min' `max') lcolor(navy) lp(solid)) ///
(scatter  r_mean_akmfirmfe r_meanlnavemp if prereformcohort==1, mcolor(navy) lcolor(navy) msymbol(circle) msize(`msize')) ///
(function  `b0'*x   , range(`min' `max')  lcolor(maroon) lp(dash)) ///
(scatter r_mean_akmfirmfe r_meanlnavemp if prereformcohort==0 , mcolor(maroon) lcolor(maroon) msymbol(circle_hollow) msize(`msize') ) ///
, graphregion(fcolor(white))   ///
xtitle("Residualized Firm-Level Mean of Log Value Added per Worker", size(`fontsize')) ytitle("Residualized Firm Pay Premia", size(`fontsize'))  ///
legend(order(1 "" 2 "Old Stock Corp's (Shared Gov.)" 3 ""  4 "Young Stock Corp's (No Shared Gov.)"  )  colgap(0) col(2) ring(0) pos(11)  size(`fontsize')) ///
xlab(,labsize(`fontsize'))  ylab(,labsize(`fontsize')) ///
text(-0.13 0.86 "Slope of Control Group (Young Stock Corps): `slope' (SE `slopese')", size(`fontsize2')) ///
text(-0.16 0.74 "Simple Difference Effect (Old - Young Stock Corps): `diff' (SE `diffse')", size(`fontsize2')) ///
text(-0.19 0.79 "DiD Effect (w/ LLCs as Additional Control Group): `did' (SE `didse')" , size(`fontsize2'))

graph display ,	xsize(20) ysize(9)

graph export "$figures/fig8.pdf" , replace

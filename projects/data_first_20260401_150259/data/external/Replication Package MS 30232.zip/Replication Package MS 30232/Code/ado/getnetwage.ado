*********************************************************************************
* programmer: martina.fink@univie.ac.at
* version: 28.01.2011
* calculate unemployment benefit on the basis of yearly gross wages incl. month 13  
* and 14 and claim start
* to run programm type getbenefit nameofwagevariable nameofclaimstartvariable
* the output variable is called benefit 
* with the option gen(nameofbenefitvariable) another name for the output variable 
* can be specified
*********************************************************************************

cap pr drop getnetwage
pr de getnetwage

set more off

syntax varlist(min=2 max=2 numeric), [GENerate(str)]

loc k = 13.7603
loc var `generate'
loc w : word 1 of `varlist'
loc c : word 2 of `varlist'
tempvar wage claim


if "`var'" == "" {
	loc var netwage
	cap conf v `var', ex
	if _rc == 0 {
		di as err "variable benefit already exists"
		exit
	}
	if _rc ~= 0 {
		qui g netwage = .
		la var netwage "net wage"
	}
}
else {
	cap conf v `var', ex
	if _rc == 0 {
		di as err "variable `var' already exists" 
		exit
	}
	else {
		qui g `var' = .
		la var `var' "net wage"
	}
}

qui g `wage' = `w'/12
qui g `claim' = `c'

* BGBl. Nr. 609/1977 (21.12.1977)
qui replace `var' = 987 / 30 / `k' if `wage' <= 1690 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1251 / 30 / `k' if `wage' > 1690 / `k' & `wage' <= 1950 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1362 / 30 / `k' if `wage' > 1950 / `k' & `wage' <= 2210 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1458 / 30 / `k' if `wage' > 2210 / `k' & `wage' <= 2470 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1539 / 30 / `k' if `wage' > 2470 / `k' & `wage' <= 2730 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1605 / 30 / `k' if `wage' > 2730 / `k' & `wage' <= 2990 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1653 / 30 / `k' if `wage' > 2990 / `k' & `wage' <= 3250 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1686 / 30 / `k' if `wage' > 3250 / `k' & `wage' <= 3510 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1704 / 30 / `k' if `wage' > 3510 / `k' & `wage' <= 3770 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1740 / 30 / `k' if `wage' > 3770 / `k' & `wage' <= 4030 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1776 / 30 / `k' if `wage' > 4030 / `k' & `wage' <= 4290 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1869 / 30 / `k' if `wage' > 4290 / `k' & `wage' <= 4550 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 1959 / 30 / `k' if `wage' > 4550 / `k' & `wage' <= 4810 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 2049 / 30 / `k' if `wage' > 4810 / `k' & `wage' <= 5070 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 2142 / 30 / `k' if `wage' > 5070 / `k' & `wage' <= 5330 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 2241 / 30 / `k' if `wage' > 5330 / `k' & `wage' <= 5590 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 2346 / 30 / `k' if `wage' > 5590 / `k' & `wage' <= 5850 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 2448 / 30 / `k' if `wage' > 5850 / `k' & `wage' <= 6110 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 2553 / 30 / `k' if `wage' > 6110 / `k' & `wage' <= 6370 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 2658 / 30 / `k' if `wage' > 6370 / `k' & `wage' <= 6630 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 2760 / 30 / `k' if `wage' > 6630 / `k' & `wage' <= 6890 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 2865 / 30 / `k' if `wage' > 6890 / `k' & `wage' <= 7150 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 2970 / 30 / `k' if `wage' > 7150 / `k' & `wage' <= 7410 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 3072 / 30 / `k' if `wage' > 7410 / `k' & `wage' <= 7670 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 3177 / 30 / `k' if `wage' > 7670 / `k' & `wage' <= 7930 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 3282 / 30 / `k' if `wage' > 7930 / `k' & `wage' <= 8190 / `k' & `claim' >= mdy(12,21,1977)
qui replace `var' = 3384 / 30 / `k' if `wage' > 8190 / `k' & `claim' >= mdy(12,21,1977)


* BGBl. Nr. 55/1978 (30.01.1978)
forv low = 8190(260)12090 {
	qui replace `var' = ((`low' + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > `low' / `k' & `wage' <= `low' + 260 & `claim' >= mdy(1,1,1978)
	gl low = `low' + 260
}
qui replace `var' = (($low + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > $low / `k' & `claim' >= mdy(1,1,1978)

* BGBl. Nr. 37/1979
forv low = 12350(260)13390 {
	qui replace `var' = ((`low' + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > `low' / `k' & `wage' <= `low' + 260 & `claim' >= mdy(1,1,1979)
	gl low = `low' + 260
}
qui replace `var' = (($low + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > $low / `k' & `claim' >= mdy(1,1,1979)

* BGBl. Nr. 41/1980
forv low = 13650(260)13910 {
	qui replace `var' = ((`low' + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > `low' / `k' & `wage' <= `low' + 260 & `claim' >= mdy(1,1,1980)
	gl low = `low' + 260
}
qui replace `var' = (($low + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > $low / `k' & `claim' >= mdy(1,1,1980)

*BGBl. Nr. 83/1981
forv low = 14170(260)14950 {
	qui replace `var' = ((`low' + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > `low' / `k' & `wage' <= `low' + 260 & `claim' >= mdy(1,1,1981)
	gl low = `low' + 260
}
qui replace `var' = (($low + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > $low / `k' & `claim' >= mdy(1,1,1981)

* BGBl. Nr. 29/1982
forv low = 15210(260)17550 {
	qui replace `var' = ((`low' + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > `low' / `k' & `wage' <= `low' + 260 & `claim' >= mdy(1,1,1982)
	gl low = `low' + 260
}
qui replace `var' = (($low + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > $low / `k' & `claim' >= mdy(1,1,1982)

* BGBl. Nr. 56/1983
forv low = 17810(260)18330 {
	qui replace `var' = ((`low' + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > `low' / `k' & `wage' <= `low' + 260 & `claim' >= mdy(1,1,1983)
	gl low = `low' + 260
}
qui replace `var' = (($low + 195) * 0.4 + 30) * 12 / 365 / `k' if `wage' > $low / `k' & `claim' >= mdy(1,1,1983)

* BGBl. Nr. 594/1983
* Lohnklassen neu definiert
qui replace `var' = 45.40 / `k' if `wage' <= 2210 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 48.60 / `k' if `wage' > 2210 / `k' & `wage' <= 2470 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 51.30 / `k' if `wage' > 2470 / `k' & `wage' <= 2730 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 53.50 / `k' if `wage' > 2730 / `k' & `wage' <= 2990 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 55.10 / `k' if `wage' > 2990 / `k' & `wage' <= 3250 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 56.20 / `k' if `wage' > 3250 / `k' & `wage' <= 3510 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 56.80 / `k' if `wage' > 3510 / `k' & `wage' <= 3770 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 58.00 / `k' if `wage' > 3770 / `k' & `wage' <= 4030 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 59.20 / `k' if `wage' > 4030 / `k' & `wage' <= 4290 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 62.30 / `k' if `wage' > 4290 / `k' & `wage' <= 4550 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 65.30 / `k' if `wage' > 4550 / `k' & `wage' <= 4810 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 68.30 / `k' if `wage' > 4810 / `k' & `wage' <= 5070 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 71.40 / `k' if `wage' > 5070 / `k' & `wage' <= 5330 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 74.70 / `k' if `wage' > 5330 / `k' & `wage' <= 5590 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 78.20 / `k' if `wage' > 5590 / `k' & `wage' <= 5850 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 81.60 / `k' if `wage' > 5850 / `k' & `wage' <= 6110 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 85.10 / `k' if `wage' > 6110 / `k' & `wage' <= 6370 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 88.60 / `k' if `wage' > 6370 / `k' & `wage' <= 6630 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 92.00 / `k' if `wage' > 6630 / `k' & `wage' <= 6890 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 95.50 / `k' if `wage' > 6890 / `k' & `wage' <= 7150 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 99.00 / `k' if `wage' > 7150 / `k' & `wage' <= 7410 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 102.40 / `k' if `wage' > 7410 / `k' & `wage' <= 7670 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 105.90 / `k' if `wage' > 7670 / `k' & `wage' <= 7930 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 109.40 / `k' if `wage' > 7930 / `k' & `wage' <= 8190 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 112.80 / `k' if `wage' > 8190 / `k' & `wage' <= 8450 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 116.30 / `k' if `wage' > 8450 / `k' & `wage' <= 8710 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 119.80 / `k' if `wage' > 8710 / `k' & `wage' <= 8970 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 123.20 / `k' if `wage' > 8970 / `k' & `wage' <= 9230 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 126.70 / `k' if `wage' > 9230 / `k' & `wage' <= 9490 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 130.20 / `k' if `wage' > 9490 / `k' & `wage' <= 9750 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 133.60 / `k' if `wage' > 9750 / `k' & `wage' <= 10010 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 137.10 / `k' if `wage' > 10010 / `k' & `wage' <= 10270 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 140.60 / `k' if `wage' > 10270 / `k' & `wage' <= 10530 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 144.00 / `k' if `wage' > 10530 / `k' & `wage' <= 10790 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 147.50 / `k' if `wage' > 10790 / `k' & `wage' <= 11050 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 151.00 / `k' if `wage' > 11050 / `k' & `wage' <= 11310 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 154.40 / `k' if `wage' > 11310 / `k' & `wage' <= 11570 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 157.90 / `k' if `wage' > 11570 / `k' & `wage' <= 11830 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 161.40 / `k' if `wage' > 11830 / `k' & `wage' <= 12090 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 164.80 / `k' if `wage' > 12090 / `k' & `wage' <= 12350 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 168.30 / `k' if `wage' > 12350 / `k' & `wage' <= 12610 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 171.80 / `k' if `wage' > 12610 / `k' & `wage' <= 12870 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 175.20 / `k' if `wage' > 12870 / `k' & `wage' <= 13130 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 178.70 / `k' if `wage' > 13130 / `k' & `wage' <= 13390 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 182.20 / `k' if `wage' > 13390 / `k' & `wage' <= 13650 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 185.60 / `k' if `wage' > 13650 / `k' & `wage' <= 13910 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 189.10 / `k' if `wage' > 13910 / `k' & `wage' <= 14170 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 192.60 / `k' if `wage' > 14170 / `k' & `wage' <= 14430 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 196.00 / `k' if `wage' > 14430 / `k' & `wage' <= 14690 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 199.50 / `k' if `wage' > 14690 / `k' & `wage' <= 14950 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 203.00 / `k' if `wage' > 14950 / `k' & `wage' <= 15210 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 206.40 / `k' if `wage' > 15210 / `k' & `wage' <= 15470 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 209.90 / `k' if `wage' > 15470 / `k' & `wage' <= 15730 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 213.40 / `k' if `wage' > 15730 / `k' & `wage' <= 15990 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 216.80 / `k' if `wage' > 15990 / `k' & `wage' <= 16250 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 220.30 / `k' if `wage' > 16250 / `k' & `wage' <= 16510 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 223.80 / `k' if `wage' > 16510 / `k' & `wage' <= 16770 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 227.20 / `k' if `wage' > 16770 / `k' & `wage' <= 17030 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 230.70 / `k' if `wage' > 17030 / `k' & `wage' <= 17290 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 234.20 / `k' if `wage' > 17290 / `k' & `wage' <= 17550 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 237.60 / `k' if `wage' > 17550 / `k' & `wage' <= 17810 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 241.10 / `k' if `wage' > 17810 / `k' & `wage' <= 18070 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 244.60 / `k' if `wage' > 18070 / `k' & `wage' <= 18330 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 248.00 / `k' if `wage' > 18330 / `k' & `wage' <= 18590 / `k' & `claim' >= mdy(1,1,1984)
qui replace `var' = 251.50 / `k' if `wage' > 18590 / `k' & `claim' >= mdy(1,1,1984)


* BGBl. Nr. 416/1984
forv low = 18590(260)23530 {
	qui replace `var' = ((`low' + 270) * 4 / 300) / `k' if `wage' > `low' / `k' & `wage' <= `low' + 260 & `claim' >= mdy(1,1,1985)
	gl low = `low' + 260
}
qui replace `var' = (($low + 270) * 4 / 300) / `k' if `wage' > $low / `k' & `claim' >= mdy(1,1,1985)


* BGBl. Nr. 441/1985
forv low = 23790(260)24310 {
	qui replace `var' = ((`low' + 270) * 4 / 300) / `k' if `wage' > `low' / `k' & `wage' <= `low' + 260 & `claim' >= mdy(1,1,1986)
	gl low = `low' + 260
}
qui replace `var' = (($low + 270) * 4 / 300) / `k' if `wage' > $low / `k' & `claim' >= mdy(1,1,1986)

* BGBl. Nr. 594/1986
forv low = 24570(260)25350 {
	qui replace `var' = ((`low' + 270) * 4 / 300) / `k' if `wage' > `low' / `k' & `wage' <= `low' + 260 & `claim' >= mdy(1,1,1987)
	gl low = `low' + 260
}
qui replace `var' = (($low + 270) * 4 / 300) / `k' if `wage' > $low / `k' & `claim' >= mdy(1,1,1987)

* BGBl. Nr. 555/1987
forv low = 25610(260)26130 {
	qui replace `var' = ((`low' + 270) * 4 / 300) / `k' if `wage' > `low' / `k' & `wage' <= `low' + 260 & `claim' >= mdy(1,1,1988)
	gl low = `low' + 260
}
qui replace `var' = (($low + 270) * 4 / 300) / `k' if `wage' > $low / `k' & `claim' >= mdy(1,1,1988)

* BGBl. Nr. 639/1988
forv low = 26390(260)27170 {
	qui replace `var' = ((`low' + 270) * 4 / 300) / `k' if `wage' > `low' / `k' & `wage' <= `low' + 260 & `claim' >= mdy(1,1,1989)
	gl low = `low' + 260
}
qui replace `var' = (($low + 270) * 4 / 300) / `k' if `wage' > $low / `k' & `claim' >= mdy(1,1,1989)

* BGBl. Nr. 364/1989
qui replace `var' = 51.30 / `k' if `wage' <= 2730 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 53.50 / `k' if `wage' > 2730 / `k' & `wage' <= 2990 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 55.10 / `k' if `wage' > 2990 / `k' & `wage' <= 3250 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 56.20 / `k' if `wage' > 3250 / `k' & `wage' <= 3510 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 58.50 / `k' if `wage' > 3510 / `k' & `wage' <= 3770 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 61.50 / `k' if `wage' > 3770 / `k' & `wage' <= 4030 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 66.40 / `k' if `wage' > 4030 / `k' & `wage' <= 4290 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 71.20 / `k' if `wage' > 4290 / `k' & `wage' <= 4550 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 74.20 / `k' if `wage' > 4550 / `k' & `wage' <= 4810 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 79.00 / `k' if `wage' > 4810 / `k' & `wage' <= 5070 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 83.90 / `k' if `wage' > 5070 / `k' & `wage' <= 5330 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 86.90 / `k' if `wage' > 5330 / `k' & `wage' <= 5590 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 91.70 / `k' if `wage' > 5590 / `k' & `wage' <= 5850 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 94.70 / `k' if `wage' > 5850 / `k' & `wage' <= 6110 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 99.50 / `k' if `wage' > 6110 / `k' & `wage' <= 6370 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 104.30 / `k' if `wage' > 6370 / `k' & `wage' <= 6630 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 107.30 / `k' if `wage' > 6630 / `k' & `wage' <= 6890 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 112.10 / `k' if `wage' > 6890 / `k' & `wage' <= 7150 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 116.90 / `k' if `wage' > 7150 / `k' & `wage' <= 7410 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 119.80 / `k' if `wage' > 7410 / `k' & `wage' <= 7670 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 124.60 / `k' if `wage' > 7670 / `k' & `wage' <= 7930 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 127.60 / `k' if `wage' > 7930 / `k' & `wage' <= 8190 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 132.40 / `k' if `wage' > 8190 / `k' & `wage' <= 8450 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 137.20 / `k' if `wage' > 8450 / `k' & `wage' <= 8710 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 140.10 / `k' if `wage' > 8710 / `k' & `wage' <= 8970 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 145.00 / `k' if `wage' > 8970 / `k' & `wage' <= 9230 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 149.80 / `k' if `wage' > 9230 / `k' & `wage' <= 9490 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 152.70 / `k' if `wage' > 9490 / `k' & `wage' <= 9750 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 157.50 / `k' if `wage' > 9750 / `k' & `wage' <= 10010 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 160.50 / `k' if `wage' > 10010 / `k' & `wage' <= 10270 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 162.40 / `k' if `wage' > 10270 / `k' & `wage' <= 10530 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 165.40 / `k' if `wage' > 10530 / `k' & `wage' <= 10790 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 167.80 / `k' if `wage' > 10790 / `k' & `wage' <= 11050 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 168.80 / `k' if `wage' > 11050 / `k' & `wage' <= 11310 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 168.80 / `k' if `wage' > 11310 / `k' & `wage' <= 11570 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 168.80 / `k' if `wage' > 11570 / `k' & `wage' <= 11830 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 168.80 / `k' if `wage' > 11830 / `k' & `wage' <= 12090 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 168.80 / `k' if `wage' > 12090 / `k' & `wage' <= 12350 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 168.80 / `k' if `wage' > 12350 / `k' & `wage' <= 12610 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 171.80 / `k' if `wage' > 12610 / `k' & `wage' <= 12870 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 175.20 / `k' if `wage' > 12870 / `k' & `wage' <= 13130 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 178.70 / `k' if `wage' > 13130 / `k' & `wage' <= 13390 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 182.20 / `k' if `wage' > 13390 / `k' & `wage' <= 13650 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 185.60 / `k' if `wage' > 13650 / `k' & `wage' <= 13910 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 189.10 / `k' if `wage' > 13910 / `k' & `wage' <= 14170 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 192.60 / `k' if `wage' > 14170 / `k' & `wage' <= 14430 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 196.00 / `k' if `wage' > 14430 / `k' & `wage' <= 14690 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 199.50 / `k' if `wage' > 14690 / `k' & `wage' <= 14950 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 203.00 / `k' if `wage' > 14950 / `k' & `wage' <= 15210 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 206.40 / `k' if `wage' > 15210 / `k' & `wage' <= 15470 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 209.90 / `k' if `wage' > 15470 / `k' & `wage' <= 15730 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 213.40 / `k' if `wage' > 15730 / `k' & `wage' <= 15990 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 216.80 / `k' if `wage' > 15990 / `k' & `wage' <= 16250 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 220.30 / `k' if `wage' > 16250 / `k' & `wage' <= 16510 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 223.80 / `k' if `wage' > 16510 / `k' & `wage' <= 16770 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 227.20 / `k' if `wage' > 16770 / `k' & `wage' <= 17030 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 230.70 / `k' if `wage' > 17030 / `k' & `wage' <= 17290 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 234.20 / `k' if `wage' > 17290 / `k' & `wage' <= 17550 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 237.60 / `k' if `wage' > 17550 / `k' & `wage' <= 17810 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 241.10 / `k' if `wage' > 17810 / `k' & `wage' <= 18070 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 244.60 / `k' if `wage' > 18070 / `k' & `wage' <= 18330 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 248.00 / `k' if `wage' > 18330 / `k' & `wage' <= 18590 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 251.50 / `k' if `wage' > 18590 / `k' & `wage' <= 18850 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 254.90 / `k' if `wage' > 18850 / `k' & `wage' <= 19110 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 258.40 / `k' if `wage' > 19110 / `k' & `wage' <= 19370 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 261.90 / `k' if `wage' > 19370 / `k' & `wage' <= 19630 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 265.30 / `k' if `wage' > 19630 / `k' & `wage' <= 19890 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 268.80 / `k' if `wage' > 19890 / `k' & `wage' <= 20150 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 272.30 / `k' if `wage' > 20150 / `k' & `wage' <= 20410 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 275.70 / `k' if `wage' > 20410 / `k' & `wage' <= 20670 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 279.20 / `k' if `wage' > 20670 / `k' & `wage' <= 20930 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 282.70 / `k' if `wage' > 20930 / `k' & `wage' <= 21190 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 286.10 / `k' if `wage' > 21190 / `k' & `wage' <= 21450 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 289.60 / `k' if `wage' > 21450 / `k' & `wage' <= 21710 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 293.10 / `k' if `wage' > 21710 / `k' & `wage' <= 21970 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 296.50 / `k' if `wage' > 21970 / `k' & `wage' <= 22230 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 300.00 / `k' if `wage' > 22230 / `k' & `wage' <= 22490 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 303.50 / `k' if `wage' > 22490 / `k' & `wage' <= 22750 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 306.90 / `k' if `wage' > 22750 / `k' & `wage' <= 23010 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 310.40 / `k' if `wage' > 23010 / `k' & `wage' <= 23270 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 313.90 / `k' if `wage' > 23270 / `k' & `wage' <= 23530 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 317.30 / `k' if `wage' > 23530 / `k' & `wage' <= 23790 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 320.80 / `k' if `wage' > 23790 / `k' & `wage' <= 24050 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 324.30 / `k' if `wage' > 24050 / `k' & `wage' <= 24310 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 327.70 / `k' if `wage' > 24310 / `k' & `wage' <= 24570 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 331.20 / `k' if `wage' > 24570 / `k' & `wage' <= 24830 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 334.70 / `k' if `wage' > 24830 / `k' & `wage' <= 25090 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 338.10 / `k' if `wage' > 25090 / `k' & `wage' <= 25350 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 341.60 / `k' if `wage' > 25350 / `k' & `wage' <= 25610 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 345.10 / `k' if `wage' > 25610 / `k' & `wage' <= 25870 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 348.50 / `k' if `wage' > 25870 / `k' & `wage' <= 26130 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 352.00 / `k' if `wage' > 26130 / `k' & `wage' <= 26390 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 355.50 / `k' if `wage' > 26390 / `k' & `wage' <= 26650 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 358.90 / `k' if `wage' > 26650 / `k' & `wage' <= 26910 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 362.40 / `k' if `wage' > 26910 / `k' & `wage' <= 27170 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 365.90 / `k' if `wage' > 27170 / `k' & `wage' <= 27430 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 369.30 / `k' if `wage' > 27430 / `k' & `claim' >= mdy(8,1,1989)


* BGBl. Nr. 601/1989
qui replace `var' = 369.30 / `k' if `wage' > 27430 / `k' & `wage' <= 27690 / `k' & `claim' >= mdy(1,1,1990)
qui replace `var' = 371.40 / `k' if `wage' > 27690 / `k' & `wage' <= 27950 / `k' & `claim' >= mdy(1,1,1990)
qui replace `var' = 374.80 / `k' if `wage' > 27950 / `k' & `claim' >= mdy(1,1,1990) 

* BGBl. Nr. 412/1990
qui replace `var' = 171.70 / `k' if `wage' > 11050 / `k' & `wage' <= 11310 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 175.60 / `k' if `wage' > 11310 / `k' & `wage' <= 11570 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 178.00 / `k' if `wage' > 11570 / `k' & `wage' <= 11830 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 181.90 / `k' if `wage' > 11830 / `k' & `wage' <= 12090 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 185.70 / `k' if `wage' > 12090 / `k' & `wage' <= 12350 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 188.20 / `k' if `wage' > 12350 / `k' & `wage' <= 12610 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 192.00 / `k' if `wage' > 12610 / `k' & `wage' <= 12870 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 194.50 / `k' if `wage' > 12870 / `k' & `wage' <= 13130 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 198.30 / `k' if `wage' > 13130 / `k' & `wage' <= 13390 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 202.20 / `k' if `wage' > 13390 / `k' & `wage' <= 13650 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 204.70 / `k' if `wage' > 13650 / `k' & `wage' <= 13910 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 208.50 / `k' if `wage' > 13910 / `k' & `wage' <= 14170 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 212.40 / `k' if `wage' > 14170 / `k' & `wage' <= 14430 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 214.90 / `k' if `wage' > 14430 / `k' & `wage' <= 14690 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 218.70 / `k' if `wage' > 14690 / `k' & `wage' <= 14950 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 221.20 / `k' if `wage' > 14950 / `k' & `wage' <= 15210 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 225.00 / `k' if `wage' > 15210 / `k' & `wage' <= 15470 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 228.90 / `k' if `wage' > 15470 / `k' & `wage' <= 15730 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 231.40 / `k' if `wage' > 15730 / `k' & `wage' <= 15990 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 235.20 / `k' if `wage' > 15990 / `k' & `wage' <= 16250 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 239.10 / `k' if `wage' > 16250 / `k' & `wage' <= 16510 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 241.50 / `k' if `wage' > 16510 / `k' & `wage' <= 16770 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 245.40 / `k' if `wage' > 16770 / `k' & `wage' <= 17030 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 247.80 / `k' if `wage' > 17030 / `k' & `wage' <= 17290 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 251.70 / `k' if `wage' > 17290 / `k' & `wage' <= 17550 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 255.60 / `k' if `wage' > 17550 / `k' & `wage' <= 17810 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 257.80 / `k' if `wage' > 17810 / `k' & `wage' <= 18070 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 261.30 / `k' if `wage' > 18070 / `k' & `wage' <= 18330 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 264.80 / `k' if `wage' > 18330 / `k' & `wage' <= 18590 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 267.00 / `k' if `wage' > 18590 / `k' & `wage' <= 18850 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 270.40 / `k' if `wage' > 18850 / `k' & `wage' <= 19110 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 273.80 / `k' if `wage' > 19110 / `k' & `wage' <= 19370 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 276.00 / `k' if `wage' > 19370 / `k' & `wage' <= 19630 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 279.50 / `k' if `wage' > 19630 / `k' & `wage' <= 19890 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 281.70 / `k' if `wage' > 19890 / `k' & `wage' <= 20150 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 285.20 / `k' if `wage' > 20150 / `k' & `wage' <= 20410 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 288.60 / `k' if `wage' > 20410 / `k' & `wage' <= 20670 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 290.80 / `k' if `wage' > 20670 / `k' & `wage' <= 20930 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 294.20 / `k' if `wage' > 20930 / `k' & `wage' <= 21190 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 297.70 / `k' if `wage' > 21190 / `k' & `wage' <= 21450 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 299.90 / `k' if `wage' > 21450 / `k' & `wage' <= 21710 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 303.30 / `k' if `wage' > 21710 / `k' & `wage' <= 21970 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 305.50 / `k' if `wage' > 21970 / `k' & `wage' <= 22230 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 309.00 / `k' if `wage' > 22230 / `k' & `wage' <= 22490 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 312.40 / `k' if `wage' > 22490 / `k' & `wage' <= 22750 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 314.60 / `k' if `wage' > 22750 / `k' & `wage' <= 23010 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 318.10 / `k' if `wage' > 23010 / `k' & `wage' <= 23270 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 321.50 / `k' if `wage' > 23270 / `k' & `wage' <= 23530 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 323.70 / `k' if `wage' > 23530 / `k' & `wage' <= 23790 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 327.10 / `k' if `wage' > 23790 / `k' & `wage' <= 24050 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 329.30 / `k' if `wage' > 24050 / `k' & `wage' <= 24310 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 332.80 / `k' if `wage' > 24310 / `k' & `wage' <= 24570 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 336.30 / `k' if `wage' > 24570 / `k' & `wage' <= 24830 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 338.50 / `k' if `wage' > 24830 / `k' & `wage' <= 25090 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 341.90 / `k' if `wage' > 25090 / `k' & `wage' <= 25350 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 345.30 / `k' if `wage' > 25350 / `k' & `wage' <= 25610 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 347.50 / `k' if `wage' > 25610 / `k' & `wage' <= 25870 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 351.00 / `k' if `wage' > 25870 / `k' & `wage' <= 26130 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 353.20 / `k' if `wage' > 26130 / `k' & `wage' <= 26390 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 356.60 / `k' if `wage' > 26390 / `k' & `wage' <= 26650 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 360.10 / `k' if `wage' > 26650 / `k' & `wage' <= 26910 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 362.40 / `k' if `wage' > 26910 / `k' & `wage' <= 27170 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 365.90 / `k' if `wage' > 27170 / `k' & `wage' <= 27430 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 369.30 / `k' if `wage' > 27430 / `k' & `wage' <= 27690 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 371.40 / `k' if `wage' > 27690 / `k' & `wage' <= 27950 / `k' & `claim' >= mdy(7,1,1990)
qui replace `var' = 374.80 / `k' if `wage' > 27950 / `k' & `claim' >= mdy(7,1,1990)

* BGBl. Nr. 717/1990
qui replace `var' = 374.80 / `k' if `wage' > 27950 / `k' & `wage' <= 28210 / `k' & `claim' >= mdy(1,1,1991)
qui replace `var' = 379.00 / `k' if `wage' > 28210 / `k' & `wage' <= 28470 / `k' & `claim' >= mdy(1,1,1991)
qui replace `var' = 381.30 / `k' if `wage' > 28470 / `k' & `wage' <= 28730 / `k' & `claim' >= mdy(1,1,1991)
qui replace `var' = 384.70 / `k' if `wage' > 28730 / `k' & `claim' >= mdy(1,1,1991)

* BGBl. Nr. 594/1991
qui replace `var' = 53.50 / `k' if `wage' <= 2730 / `k' & `claim' >= mdy(1,1,1992)
qui replace `var' = 384.70 / `k' if `wage' > 28730 / `k' & `wage' <= 28990 / `k' & `claim' >= mdy(1,1,1992)
qui replace `var' = 386.90 / `k' if `wage' > 28990 / `k' & `wage' <= 29250 / `k' & `claim' >= mdy(1,1,1992)
qui replace `var' = 390.40 / `k' if `wage' > 29250 / `k' & `wage' <= 29510 / `k' & `claim' >= mdy(1,1,1992)
qui replace `var' = 393.80 / `k' if `wage' > 29510 / `k' & `wage' <= 29770 / `k' & `claim' >= mdy(1,1,1992)
qui replace `var' = 396.00 / `k' if `wage' > 29770 / `k' & `claim' >= mdy(1,1,1992)

* BGBl. Nr. 753/1992
qui replace `var' = 396.00 / `k' if `wage' > 29770 / `k' & `wage' <= 30030 / `k' & `claim' >= mdy(1,1,1993)
qui replace `var' = 396.40 / `k' if `wage' > 30030 / `k' & `wage' <= 30290 / `k' & `claim' >= mdy(1,1,1993)
qui replace `var' = 399.80 / `k' if `wage' > 30290 / `k' & `wage' <= 30550 / `k' & `claim' >= mdy(1,1,1993)
qui replace `var' = 402.00 / `k' if `wage' > 30550 / `k' & `wage' <= 30810 / `k' & `claim' >= mdy(1,1,1993)
qui replace `var' = 405.40 / `k' if `wage' > 30810 / `k' & `wage' <= 31070 / `k' & `claim' >= mdy(1,1,1993)
qui replace `var' = 407.50 / `k' if `wage' > 31070 / `k' & `wage' <= 31330 / `k' & `claim' >= mdy(1,1,1993)
qui replace `var' = 411.00 / `k' if `wage' > 31330 / `k' & `wage' <= 31590 / `k' & `claim' >= mdy(1,1,1993)
qui replace `var' = 414.50 / `k' if `wage' > 31590 / `k' & `claim' >= mdy(1,1,1993)

* BGBl. Nr. 817/1992
qui replace `var' = 303.30 / `k' if `wage' > 21710 / `k' & `wage' <= 21943 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 304.00 / `k' if `wage' > 21943 / `k' & `wage' <= 22176 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 304.70 / `k' if `wage' > 22176 / `k' & `wage' <= 22409 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 305.50 / `k' if `wage' > 22409 / `k' & `wage' <= 22674 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 309.00 / `k' if `wage' > 22674 / `k' & `wage' <= 22939 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 312.40 / `k' if `wage' > 22939 / `k' & `wage' <= 23204 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 314.60 / `k' if `wage' > 23204 / `k' & `wage' <= 23469 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 318.10 / `k' if `wage' > 23469 / `k' & `wage' <= 23734 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 321.50 / `k' if `wage' > 23734 / `k' & `wage' <= 23999 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 323.70 / `k' if `wage' > 23999 / `k' & `wage' <= 24264 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 327.10 / `k' if `wage' > 24264 / `k' & `wage' <= 24529 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 329.30 / `k' if `wage' > 24529 / `k' & `wage' <= 24794 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 332.80 / `k' if `wage' > 24794 / `k' & `wage' <= 25059 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 336.30 / `k' if `wage' > 25059 / `k' & `wage' <= 25324 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 338.50 / `k' if `wage' > 25324 / `k' & `wage' <= 25589 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 341.90 / `k' if `wage' > 25589 / `k' & `wage' <= 25854 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 345.30 / `k' if `wage' > 25854 / `k' & `wage' <= 26119 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 347.50 / `k' if `wage' > 26119 / `k' & `wage' <= 26384 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 351.00 / `k' if `wage' > 26384 / `k' & `wage' <= 26649 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 353.20 / `k' if `wage' > 26649 / `k' & `wage' <= 26914 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 356.60 / `k' if `wage' > 26914 / `k' & `wage' <= 27179 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 360.10 / `k' if `wage' > 27179 / `k' & `wage' <= 27444 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 362.40 / `k' if `wage' > 27444 / `k' & `wage' <= 27709 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 365.90 / `k' if `wage' > 27709 / `k' & `wage' <= 27974 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 369.30 / `k' if `wage' > 27974 / `k' & `wage' <= 28239 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 371.40 / `k' if `wage' > 28239 / `k' & `wage' <= 28504 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 374.80 / `k' if `wage' > 28504 / `k' & `wage' <= 28769 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 379.00 / `k' if `wage' > 28769 / `k' & `wage' <= 29034 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 381.30 / `k' if `wage' > 29034 / `k' & `wage' <= 29299 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 384.70 / `k' if `wage' > 29299 / `k' & `wage' <= 29564 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 386.90 / `k' if `wage' > 29564 / `k' & `wage' <= 29829 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 390.40 / `k' if `wage' > 29829 / `k' & `wage' <= 30094 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 393.80 / `k' if `wage' > 30094 / `k' & `wage' <= 30359 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 396.00 / `k' if `wage' > 30359 / `k' & `wage' <= 30624 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 396.40 / `k' if `wage' > 30624 / `k' & `wage' <= 30889 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 399.80 / `k' if `wage' > 30889 / `k' & `wage' <= 31154 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 402.00 / `k' if `wage' > 31154 / `k' & `wage' <= 31419 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 405.40 / `k' if `wage' > 31419 / `k' & `wage' <= 31684 / `k' & `claim' >= mdy(1,1,1994)
qui replace `var' = 407.50 / `k' if `wage' > 31684 / `k' & `claim' >= mdy(1,1,1994)

* BGBl. Nr. 977/1994
qui replace `var' = 55.10 / `k' if `wage' <= 2730 / `k' & `claim' >= mdy(1,1,1995)
qui replace `var' = 55.10 / `k' if `wage' > 2730 / `k' & `wage' <= 2990 / `k' & `claim' >= mdy(1,1,1995)
qui replace `var' = 407.50 / `k' if `wage' > 31684 / `k' & `wage' <= 31949 / `k' & `claim' >= mdy(1,1,1995)
qui replace `var' = 407.60 / `k' if `wage' > 31949 / `k' & `wage' <= 32214 / `k' & `claim' >= mdy(1,1,1995)
qui replace `var' = 410.80 / `k' if `wage' > 32214 / `k' & `wage' <= 32479 / `k' & `claim' >= mdy(1,1,1995)
qui replace `var' = 412.90 / `k' if `wage' > 32479 / `k' & `wage' <= 32744 / `k' & `claim' >= mdy(1,1,1995)
qui replace `var' = 416.30 / `k' if `wage' > 32744 / `k' & `wage' <= 33009 / `k' & `claim' >= mdy(1,1,1995)
qui replace `var' = 419.80 / `k' if `wage' > 33009 / `k' & `wage' <= 33274 / `k' & `claim' >= mdy(1,1,1995)
qui replace `var' = 421.90 / `k' if `wage' > 33274 / `k' & `wage' <= 33539 / `k' & `claim' >= mdy(1,1,1995)
qui replace `var' = 425.30 / `k' if `wage' > 33539 / `k' & `claim' >= mdy(1,1,1995)

* BGBl. Nr. 297/1995
qui replace `var' = 290.80 / `k' if `wage' > 20930 / `k' & `wage' <= 21190 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 292.60 / `k' if `wage' > 21190 / `k' & `wage' <= 21450 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 294.80 / `k' if `wage' > 21450 / `k' & `wage' <= 21710 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 298.20 / `k' if `wage' > 21710 / `k' & `wage' <= 21943 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 298.80 / `k' if `wage' > 21943 / `k' & `wage' <= 22176 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 299.40 / `k' if `wage' > 22176 / `k' & `wage' <= 22409 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 300.20 / `k' if `wage' > 22409 / `k' & `wage' <= 22674 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 303.70 / `k' if `wage' > 22674 / `k' & `wage' <= 22939 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 307.00 / `k' if `wage' > 22939 / `k' & `wage' <= 23204 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 309.10 / `k' if `wage' > 23204 / `k' & `wage' <= 23469 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 312.60 / `k' if `wage' > 23469 / `k' & `wage' <= 23734 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 316.00 / `k' if `wage' > 23734 / `k' & `wage' <= 23999 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 318.10 / `k' if `wage' > 23999 / `k' & `wage' <= 24264 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 321.40 / `k' if `wage' > 24264 / `k' & `wage' <= 24529 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 323.60 / `k' if `wage' > 24529 / `k' & `wage' <= 24794 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 327.00 / `k' if `wage' > 24794 / `k' & `wage' <= 25059 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 330.50 / `k' if `wage' > 25059 / `k' & `wage' <= 25324 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 332.60 / `k' if `wage' > 25324 / `k' & `wage' <= 25589 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 336.00 / `k' if `wage' > 25589 / `k' & `wage' <= 25854 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 339.40 / `k' if `wage' > 25854 / `k' & `wage' <= 26119 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 341.50 / `k' if `wage' > 26119 / `k' & `wage' <= 26384 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 344.90 / `k' if `wage' > 26384 / `k' & `wage' <= 26649 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 347.10 / `k' if `wage' > 26649 / `k' & `wage' <= 26914 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 350.40 / `k' if `wage' > 26914 / `k' & `wage' <= 27179 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 353.90 / `k' if `wage' > 27179 / `k' & `wage' <= 27444 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 356.10 / `k' if `wage' > 27444 / `k' & `wage' <= 27709 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 359.60 / `k' if `wage' > 27709 / `k' & `wage' <= 27974 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 362.90 / `k' if `wage' > 27974 / `k' & `wage' <= 28239 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 365.00 / `k' if `wage' > 28239 / `k' & `wage' <= 28504 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 368.30 / `k' if `wage' > 28504 / `k' & `wage' <= 28769 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 372.40 / `k' if `wage' > 28769 / `k' & `wage' <= 29034 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 374.70 / `k' if `wage' > 29034 / `k' & `wage' <= 29299 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 378.00 / `k' if `wage' > 29299 / `k' & `wage' <= 29564 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 380.20 / `k' if `wage' > 29564 / `k' & `wage' <= 29829 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 383.70 / `k' if `wage' > 29829 / `k' & `wage' <= 30094 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 387.00 / `k' if `wage' > 30094 / `k' & `wage' <= 30359 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 389.20 / `k' if `wage' > 30359 / `k' & `wage' <= 30624 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 389.50 / `k' if `wage' > 30624 / `k' & `wage' <= 30889 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 392.80 / `k' if `wage' > 30889 / `k' & `wage' <= 31154 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 395.00 / `k' if `wage' > 31154 / `k' & `wage' <= 31419 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 398.30 / `k' if `wage' > 31419 / `k' & `wage' <= 31684 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 400.40 / `k' if `wage' > 31684 / `k' & `wage' <= 31949 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 400.50 / `k' if `wage' > 31949 / `k' & `wage' <= 32214 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 403.60 / `k' if `wage' > 32214 / `k' & `wage' <= 32479 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 405.60 / `k' if `wage' > 32479 / `k' & `wage' <= 32744 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 409.00 / `k' if `wage' > 32744 / `k' & `wage' <= 33009 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 412.40 / `k' if `wage' > 33009 / `k' & `wage' <= 33274 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 414.50 / `k' if `wage' > 33274 / `k' & `wage' <= 33539 / `k' & `claim' >= mdy(5,1,1995)
qui replace `var' = 417.80 / `k' if `wage' > 33539 / `k' & `claim' >= mdy(5,1,1995)

* BGBl. Nr. 677/1996
*qui replace `var' = 56.20 / `k' if `wage' <= 2730 / `k' & `claim' >= mdy(8,1,1989)
qui replace `var' = 56.20 / `k' if `wage' > 2730 / `k' & `wage' <= 2990 / `k' & `claim' >= mdy(1,1,1997)
qui replace `var' = 56.20 / `k' if `wage' > 2990 / `k' & `wage' <= 3250 / `k' & `claim' >= mdy(1,1,1997)
qui replace `var' = 417.80 / `k' if `wage' > 33539 / `k' & `wage' <= 33804 / `k' & `claim' >= mdy(1,1,1997)
qui replace `var' = 421.30 / `k' if `wage' > 33804 / `k' & `wage' <= 34069 / `k' & `claim' >= mdy(1,1,1997)
qui replace `var' = 423.30 / `k' if `wage' > 34069 / `k' & `wage' <= 34334 / `k' & `claim' >= mdy(1,1,1997)
qui replace `var' = 426.70 / `k' if `wage' > 34334 / `k' & `wage' <= 34599 / `k' & `claim' >= mdy(1,1,1997)
qui replace `var' = 428.80 / `k' if `wage' > 34599 / `k' & `wage' <= 34864 / `k' & `claim' >= mdy(1,1,1997)
qui replace `var' = 432.20 / `k' if `wage' > 34864 / `k' & `wage' <= 35129 / `k' & `claim' >= mdy(1,1,1997)
qui replace `var' = 435.60 / `k' if `wage' > 35129 / `k' & `wage' <= 35394 / `k' & `claim' >= mdy(1,1,1997)
qui replace `var' = 437.60 / `k' if `wage' > 35394 / `k' & `wage' <= 35659 / `k' & `claim' >= mdy(1,1,1997)
qui replace `var' = 441.00 / `k' if `wage' > 35659 / `k' & `wage' <= 35924 / `k' & `claim' >= mdy(1,1,1997)
qui replace `var' = 442.90 / `k' if `wage' > 35924 / `k' & `claim' >= mdy(1,1,1997)

* BGBl. Nr. 364/1997
qui replace `var' = 442.90 / `k' if `wage' > 35924 / `k' & `wage' <= 36189 / `k' & `claim' >= mdy(1,1,1998)
qui replace `var' = 450.30 / `k' if `wage' > 36189 / `k' & `wage' <= 36454 / `k' & `claim' >= mdy(1,1,1998)
qui replace `var' = 453.20 / `k' if `wage' > 36454 / `k' & `wage' <= 36719 / `k' & `claim' >= mdy(1,1,1998)
qui replace `var' = 454.90 / `k' if `wage' > 36719 / `k' & `wage' <= 36984 / `k' & `claim' >= mdy(1,1,1998)
qui replace `var' = 457.80 / `k' if `wage' > 36984 / `k' & `wage' <= 37249 / `k' & `claim' >= mdy(1,1,1998)
qui replace `var' = 460.70 / `k' if `wage' > 37249 / `k' & `wage' <= 37514 / `k' & `claim' >= mdy(1,1,1998)
qui replace `var' = 462.50 / `k' if `wage' > 37514 / `k' & `wage' <= 37779 / `k' & `claim' >= mdy(1,1,1998)
qui replace `var' = 465.40 / `k' if `wage' > 37779 / `k' & `claim' >= mdy(1,1,1998)

* BGBl. Nr. 417/1998
qui replace `var' = 58.50 / `k' if `wage' <= 2730 / `k' & `claim' >= mdy(8,1,1999)
qui replace `var' = 55.50 / `k' if `wage' > 2730 / `k' & `wage' <= 2990 / `k' & `claim' >= mdy(8,1,1999)
qui replace `var' = 58.50 / `k' if `wage' > 2990 / `k' & `wage' <= 3250 / `k' & `claim' >= mdy(8,1,1999)
qui replace `var' = 58.50 / `k' if `wage' > 3250 / `k' & `wage' <= 3510 / `k' & `claim' >= mdy(8,1,1999)
qui replace `var' = 465.40 / `k' if `wage' > 37779 / `k' & `wage' <= 38044 / `k' & `claim' >= mdy(1,1,1999)
qui replace `var' = 466.80 / `k' if `wage' > 38044 / `k' & `wage' <= 38309 / `k' & `claim' >= mdy(1,1,1999)
qui replace `var' = 468.00 / `k' if `wage' > 38309 / `k' & `wage' <= 38574 / `k' & `claim' >= mdy(1,1,1999)
qui replace `var' = 469.30 / `k' if `wage' > 38574 / `k' & `wage' <= 38839 / `k' & `claim' >= mdy(1,1,1999)
qui replace `var' = 470.60 / `k' if `wage' > 38839 / `k' & `claim' >= mdy(1,1,1999)

* BGBl. Nr. 451/1999
qui replace `var' = 470.60 / `k' if `wage' > 38839 / `k' & `wage' <= 39104 / `k' & `claim' >= mdy(1,1,2000)
qui replace `var' = 473.50 / `k' if `wage' > 39104 / `k' & `wage' <= 39369 / `k' & `claim' >= mdy(1,1,2000)
qui replace `var' = 476.40 / `k' if `wage' > 39369 / `k' & `wage' <= 39634 / `k' & `claim' >= mdy(1,1,2000)
qui replace `var' = 478.10 / `k' if `wage' > 39634 / `k' & `wage' <= 39899 / `k' & `claim' >= mdy(1,1,2000)
qui replace `var' = 481.00 / `k' if `wage' > 39899 / `k' & `wage' <= 40164 / `k' & `claim' >= mdy(1,1,2000)
qui replace `var' = 482.70 / `k' if `wage' > 40164 / `k' & `wage' <= 40429 / `k' & `claim' >= mdy(1,1,2000)
qui replace `var' = 485.60 / `k' if `wage' > 40429 / `k' & `wage' <= 40694 / `k' & `claim' >= mdy(1,1,2000)
qui replace `var' = 488.50 / `k' if `wage' > 40694 / `k' & `claim' >= mdy(1,1,2000)

* BGBl. Nr. 142/2000
* benefit = 55% of net wage

** contribution caps for social security contributions for earnings from 14 monthly wages
sca	hbg_1972 = 8851.551202
sca	hbg_1973 = 9614.61596
sca	hbg_1974 = 10682.90662
sca	hbg_1975 = 11903.81024
sca	hbg_1976 = 13429.93975
sca	hbg_1977 = 15261.29518
sca	hbg_1978 = 17092.6506
sca	hbg_1979 = 18924.00602
sca	hbg_1980 = 19839.68373
sca	hbg_1981 = 20755.36144
sca	hbg_1982 = 21976.26505
sca	hbg_1983 = 23197.16867
sca	hbg_1984 = 24418.07228
sca	hbg_1985 = 25028.52409
sca	hbg_1986 = 26249.4277
sca	hbg_1987 = 26859.87951
sca	hbg_1988 = 28080.78312
sca	hbg_1989 = 28691.23493
sca	hbg_1990 = 29301.68674
sca	hbg_1991 = 30522.59035
sca	hbg_1992 = 32353.94577
sca	hbg_1993 = 34185.30119
sca	hbg_1994 = 36627.10842
sca	hbg_1995 = 38458.46384
sca	hbg_1996 = 39679.36746
sca	hbg_1997 = 41510.72288
sca	hbg_1998 = 42731.62649
sca	hbg_1999 = 43342.0783
sca	hbg_2000 = 43952.5301
sca	hbg_2001 = 45173.43372
sca	hbg_2002 = 45780
sca	hbg_2003 = 47040
sca	hbg_2004 = 48300
sca	hbg_2005 = 50820
sca	hbg_2006 = 52500
sca	hbg_2007 = 53760
sca	hbg_2008 = 55020
sca	hbg_2009 = 56280
sca	hbg_2010 = 57540

** earnings for UI benefits (12 monthly wages)
sca	hbgal_1977 = 7142.286142
sca	hbgal_1978 = 10770.11402
sca	hbgal_1979 = 11903.81024
sca	hbgal_1980 = 11903.81024
sca	hbgal_1981 = 13264.24569
sca	hbgal_1982 = 15531.63812
sca	hbgal_1983 = 15339.78184
sca	hbgal_1984 = 16211.86
sca	hbgal_1985 = 20746.6407
sca	hbgal_1986 = 21426.85843
sca	hbgal_1987 = 22333.8154
sca	hbgal_1988 = 23014.03312
sca	hbgal_1989 = 23920.99009
sca	hbgal_1990 = 24374.46858
sca	hbgal_1991 = 25054.68631
sca	hbgal_1992 = 25961.64328
sca	hbgal_1993 = 27548.81798
sca	hbgal_1994 = 27630.79293
sca	hbgal_1995 = 29248.49022
sca	hbgal_1996 = 29248.49022
sca	hbgal_1997 = 31328.38674
sca	hbgal_1998 = 32946.08402
sca	hbgal_1999 = 33870.48247
sca	hbgal_2000 = 35488.17976
sca	hbgal_2001 = 36627.10842
sca	hbgal_2002 = 37150.35283
sca	hbgal_2003 = 37673.59723
sca	hbgal_2004 = 38720.08604
sca	hbgal_2005 = 39240
sca	hbgal_2006 = 40320
sca	hbgal_2007 = 41400
sca	hbgal_2008 = 43560
sca	hbgal_2009 = 45000

** rates for social security contributions - employee shares
sca rSV_2000 = 0.1775
sca rSV_2001 = 0.1775
sca rSV_2002 = 0.1775
sca rSV_2003 = 0.1775
sca rSV_2004 = 0.1795
sca rSV_2005 = 0.18
sca rSV_2006 = 0.18
sca rSV_2007 = 0.18
sca rSV_2008 = 0.1807
sca rSV_2009 = 0.1807

/* 
	Mit 1.7.2008 gab es eine ƒnderung bei der Arbeitslosenversicherung (Dienstnehmeranteil)
	f¸r niedrige Einkommen. Der Sozialversicherungssatz betr‰gt bis zu einem Bruttolohn
	von Ä 1.100,00 (2009: Ä 1.128,00) 15,07 % bis Ä 1.200 (Ä 1.230,00), 16,07 %,
	bis Ä 1.350,00 (Ä 1.384,00), 17,07 % und bis Ä 3.930,00 (Ä 4.020,00), 18,07 %. Sozialversicherungss‰tze
	bei den Sonderzahlungen auch hier jeweils -1 %.
	source: http://www.arbeiterkammer.at/bilder/d111/AK-Studie-Abgabenentwicklung-99-09.pdf
*/

tempvar touse touse1 touse2
g `touse' = year(`claim') > 2000
g `touse1' = year(`claim') < 2005 & `touse' == 1 /* tax regime 1 */
g `touse2' = year(`claim') >= 2005 & `touse' == 1 /* tax regime 2 */

** yearly absetzbetraege ohne veranlagung
** arbeitnehmerabsetzbetrag 54 Euro 750 Schilling (S in 2001)
loc a = 54
** verkehrsabsetzbetrag 291 Euro 4000 Schilling (S in 2001)
loc v = 291
** sonderausgaben 60 Euro 819 Schilling (S in 2001)
loc s = 60
** werbungskosten 132 Euro 1800 Schilling (S in 2001)
loc w = 132
** yearly freibetrag social security contributions
sca fb_2000 = 618
sca fb_2001 = 618
sca fb_2002 = 620
sca fb_2003 = 620
sca fb_2004 = 620
sca fb_2005 = 620
sca fb_2006 = 620
sca fb_2007 = 620
sca fb_2008 = 620
sca fb_2009 = 620
** yearly freigrenze social security contributions
sca fg_2000 = 1671
sca fg_2001 = 1671
sca fg_2002 = 1680
sca fg_2003 = 1680
sca fg_2004 = 1900
sca fg_2005 = 2000
sca fg_2006 = 2000
sca fg_2007 = 2000
sca fg_2008 = 2000
sca fg_2009 = 2000

/*
Allgemeiner Steuerabsetzbetrag

Rechtslage seit der Steuerreform 2005 ab 1.1.2005:
Der allgemeine Steuerabsetzbetrag entf‰llt, da er in die Tarifberechnung integriert ist.

Rechtslage bis 31.12.2004:
Der allgemeine Steuerabsetzbetrag steht allen Arbeitnehmern (in manchen F‰llen auch beschr‰nkt steuerpflichtigen Arbeitnehmern) zu und ist von jedem Arbeitgeber bei der laufenden Lohnverrechnung zu ber¸cksichtigen. EUR 1.264,00 p. a.

Der allgemeine Steuerabsetzbetrag vermindert sich gleichm‰ﬂig einschleifend f¸r die Einkommensteile
von EUR 10.000,00 bis EUR 15.000,00 um EUR 375,00 p. a.
von EUR 15.000,00 bis EUR 21.800,00 um EUR 272,00 p. a.
von EUR 21.800,00 bis EUR 35.511,00 um EUR 617,00 p. a.
*/


** calculation:
** gross wage - social security contributions - werbungskosten - sonderausgaben = tax basis
** tax = tax calculation - arbeitnehmerabsetzbetrag - verkehrsabsetzbetrag - allgemeiner absetzbetrag
** net wage = gross wage - social security - tax

* calculations on a yearly basis
tempvar wage2 sz sv_w sv_sz taxb_w taxb_sz tax_w tax_sz
qui g `wage2' = `wage' * 12 * 12 / 14 if `touse' == 1 /* yearly wage excl. month 13 and 14 */
qui g `sz' = `wage2' * 2 / 12 if `touse' == 1 /* month 13 and 14 */
** earnings > hˆchstbemessungsgrundlage f¸r UI benefit
loc above = 0
tempvar i
g `i' = 0
forv c = 2001/2008 {
	qui count if `wage2' > hbgal_`c' * 12 / 14 & year(`claim') == `c'
	loc above = `above' + r(N)
	replace `i' = 0 
	replace `i' = 1 if year(`claim') == `c' & `wage2' > hbgal_`c' * 12 / 14 
//	qui replace `wage2' = hbgal_`c' * 12 / 14 if `i' == 1
//	qui replace `sz' = hbgal_`c' * 2 / 14 if `i' == 1
}

* social security contributions
qui g `sv_w' = .
qui g `sv_sz' = .
forv c = 2001/2008 {
	qui replace `sv_w' = `wage2' * rSV_`c' if year(`claim') == `c'
	qui replace `sv_sz' = `sz' * (rSV_`c' - 0.01) if year(`claim') == `c'
}

* tax basis
qui g `taxb_w' = `wage2' - `sv_w' - `w' - `s' if `touse' == 1
qui g `taxb_sz' = 0 if `touse' == 1
forv c = 2001/2008 {
	qui replace `taxb_sz' = `sz' - `sv_sz' - fb_`c' if `sz' - `sv_sz' > fg_`c' & `touse' == 1
	
}

* tax
**tax month 13 and 14 6% (constant)
	
qui g `tax_sz' = `taxb_sz' * 0.06 if `touse' == 1

qui g `tax_w' = 0 if `touse' == 1

qui replace `tax_w' = (min(`taxb_w',7270) - 3640) * 0.21 if `touse1' == 1 & `taxb_w' > 3640
qui replace `tax_w' = `tax_w' + (min(`taxb_w',21800) - 7270) * 0.31 if `touse1' == 1 & `taxb_w' > 7270
qui replace `tax_w' = `tax_w' + (min(`taxb_w',50870) - 21800) * 0.41 if `touse1' == 1 & `taxb_w' > 21800
qui replace `tax_w' = `tax_w' + (`taxb_w' - 50870) * 0.50 if `touse1' == 1 & `taxb_w' > 50870

qui replace `tax_w' = (min(`taxb_w',25000) - 10000) * 0.3833 if `touse2' == 1 & `taxb_w' > 10000
qui replace `tax_w' = `tax_w' + (min(`taxb_w',51000) - 25000) * 0.4359 if `touse2' == 1 & `taxb_w' > 25000
qui replace `tax_w' = `tax_w' + (`taxb_w' - 51000) * 0.50 if `touse2' == 1 & `taxb_w' > 51000

qui replace `tax_w' = `tax_w' - `a' - `v' if `touse' == 1
qui replace `tax_w' = `tax_w' - 887 if year(`claim') >= 2001 & year(`claim') < 2004 
qui replace `tax_w' = `tax_w' - 1264 if year(`claim') == 2004 
qui replace `tax_w' = `tax_w' + min((`taxb_w' - 8866)/(9811 - 8866),1) * 116 if year(`claim') >= 2001 & year(`claim') < 2004 & `taxb_w' > 8866
qui replace `tax_w' = `tax_w' - min((`taxb_w' - 9811)/(10901 - 9811),1) * 94 if year(`claim') >= 2001 & year(`claim') < 2004 & `taxb_w' > 9811
qui replace `tax_w' = `tax_w' + min((`taxb_w' - 10901)/(14535 - 10901),1) * 36 if year(`claim') >= 2001 & year(`claim') < 2004 & `taxb_w' > 10901
qui replace `tax_w' = `tax_w' + min((`taxb_w' - 14535)/(18168 - 14535),1) * 146 if year(`claim') >= 2001 & year(`claim') < 2004 & `taxb_w' > 14535
qui replace `tax_w' = `tax_w' + min((`taxb_w' - 18168)/(21800 - 18168),1) * 70 if year(`claim') >= 2001 & year(`claim') < 2004 & `taxb_w' > 18168
qui replace `tax_w' = `tax_w' + min((`taxb_w' - 21800)/(35421 - 21800),1) * 613 if year(`claim') >= 2001 & year(`claim') < 2004 & `taxb_w' > 21800
qui replace `tax_w' = `tax_w' + min((`taxb_w' - 10000)/(15000 - 10000),1) * 375 if year(`claim') == 2004 & `taxb_w' > 10000
qui replace `tax_w' = `tax_w' + min((`taxb_w' - 15000)/(21800 - 15000),1) * 272 if year(`claim') == 2004 & `taxb_w' > 15000
qui replace `tax_w' = `tax_w' + min((`taxb_w' - 21800)/(35511 - 21800),1) * 617 if year(`claim') == 2004 & `taxb_w' > 21800

* net wage
tempvar net
qui g `net' = `wage2' + `sz' - `sv_w' - `sv_sz' - `tax_w' - `tax_sz' 

* benefit
qui replace `var' =  `net'  if `touse' == 1


*	Durch den Erg‰nzungsbetrag wird das Arbeitslosengeld (Grundbetrag und Familienzuschl‰ge) jedenfalls auf die Hˆhe des 	Ausgleichszulagenrichtsatzes aufgestockt (siehe "Maﬂgebende Werte in der Arbeitslosenversicherung"). Voraussetzung daf¸r ist jedoch, dass durch diese Erhˆhung der Leistung

    * Arbeitslose, denen kein Familienzuschlag zusteht, nicht mehr erhalten als maximal 60 % des t‰glichen Nettoeinkommens laut Bemessungsgrundlage bzw.
    * Arbeitslose, denen Familienzuschl‰ge zuzuerkennen sind nicht mehr erhalten als 80 % des t‰glichen Nettoeinkommens laut Bemessungsgrundlage. 

** ausgleichzulagenrichts‰tze

sca azr_2001 = 613.14
sca azr_2002 = 630.92
sca azr_2003 = 643.54
sca azr_2004 = 653.19
sca azr_2005 = 662.99
sca azr_2006 = 690.00
sca azr_2007 = 726.00
sca azr_2008 = 747.00




qui count if `wage' == .
loc mis_w = r(N)
qui count if `claim' == .
loc mis_c = r(N)
noi di "`mis_w' wages are missing"
noi di "`mis_c' claim starts are missing"
noi di "`above' wages are above hˆchstbemssungsgrundlage"
noi di "`below' benefits are below ausgleichszulagenrichtsatz"



end


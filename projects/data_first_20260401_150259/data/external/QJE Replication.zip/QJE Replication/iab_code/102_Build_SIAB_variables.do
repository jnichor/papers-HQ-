*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================

cap log close

log using "$log/102_Build_SIAB_variables.txt", replace text


********************************************************************************
*
*
*			102 Build Variables for Worker Data
*
*
********************************************************************************

* 1. Append yearly data
*===============================================================================
	clear
	forvalues pnl_yr = $bhpminyear/$bhpmaxyear {
		append using "$data/siab_bvdid_clean_`pnl_yr'.dta"
	}


* 2. Build Variables
*===============================================================================


* Wage changes
*-------------------------------------------------------------------------------

forvalues j=1/3 {
	bys idnr persnr (jahr): gen  _logdailywage_l`j' = logdailywage[_n-`j'] if jahr-`j'==jahr[_n-`j']
	gen d_lnwage_l`j' =  logdailywage - _logdailywage_l`j'
	winsor2 d_lnwage_l`j',  cut(1 99) replace  by(jahr)
	drop _logdailywage_l`j'
}


* Mincerian Residuals
*-------------------------------------------------------------------------------

reg logdailywage  i.jahr##i.frau i.jahr##c.edu_exp_*   // gender, three skill groups interacted with cubic polynomial in age
predict predicted_y
gen ln_m_residuals = logdailywage-predicted_y
winsor2 ln_m_residuals, cut(1 99) replace  by(jahr)



* Tenure
*-------------------------------------------------------------------------------

* All workers (az_ges)

bysort idnr persnr: egen begin_date = min(begorig)
gen begin_year = year(begin_date)
gen tenure = max(jahr - begin_year + 1,0) // do not allow for negative tenure (should not be issue once we have cleaned - tested whether establishments exist before incorporation date XXX)

winsor2 tenure, cut(1 99) replace  by(jahr)



* Separation probability
*-------------------------------------------------------------------------------
sum jahr
global max_jahr = r(max)

bys persnr (jahr): gen same_idnr = (idnr==idnr[_n+1])&(jahr+1==jahr[_n+1])
replace same_idnr = 0 if same_idnr==.
replace same_idnr = . if jahr==${max_jahr}|jahr<2006
gen separation = 1-same_idnr
drop same_idnr



* 5. Save data
*===============================================================================

save $data\bvd_siab.dta, replace

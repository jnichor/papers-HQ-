/*******************************************************************************

	DESCRIPTION: 	Figures B1 through B4: Replacement Rate Schedules



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
clear all
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigB1-4_RR_Schedule_Flipbook`curr_date'", replace

****************************************************************************
* Simulating income and replacement rates
	* Income from 0 - 42500 ATS each year in 50 ATS bins
****************************************************************************

* Add July 1976 reform, which I label as 1976.5
set obs 1200
gen year = 1976.5
tempfile extra
save `extra'
clear

* Create simulated data

local start_year = 1972
local end_year = 2006

local num_obs = (`end_year' - `start_year' + 1)*1200
set obs `num_obs'

gen obs_num = _n
gen year = floor((obs_num - 1)/1200) + 1972

append using "`extra'" //Append 1976.5

bysort year: gen ATS_income = _n*50

* Defining the replacement rates
rr_rate_austria, new_var(replacement_rate) inc(ATS_income) year_t(year)

* Binning monthly income and taking the average replacement rate (to smooth graph)
gen ATS_bin = round(ATS_income/250,1)*250
collapse replacement_rate  x_earn_max ///
x_earn_min , by(year ATS_bin )

		* 1975.5: assume same earnings maximum/minimum as 1975
		foreach x in max min {
			qui su x_earn_`x' if year == 1976
			replace x_earn_`x' = r(mean) if year == 1976.5
		}

replace replacement_rate = replacement_rate*100
gen UIB_level = replacement_rate*ATS_bin/100

****************************************************************************
* Plotting the replacement rate for each year
****************************************************************************


local max = 60000

local group1 1972/1977
local group2 1978/1986
local group3 1987/1995
local group4 1996/2002

local counter1 = 0

forval i = 1/4 {
local counter1 = `counter1' + 1
local number = word("1 2 3 4", `counter1')
local counter2 = 0
forval year = `group`i'' {

	local counter2 = `counter2' + 1
	local letter = word("a b c d e f g h i", `counter2')
	local year_pl = `year' + 1

	local earnings_max = `max'

	foreach x in max min {
		su x_earn_`x' if year == `year'
		local base_`x' = r(mean)
		su x_earn_`x' if year == `year_pl'
		local future_`x' = r(mean)

	}

	if `base_min' < 2500 {
		local base_min = 2500
	}
	if `future_min' < 2500 {
		local future_min = 2500
	}

	* Replacement rate figure
	tw (line replacement_rate ATS_bin if year == `year' ///
	& ATS_bin <= `base_min' & replacement_rate <= 60, lcolor(none) lpattern(none)) ///
	(line replacement_rate ATS_bin if year == `year' ///
	& inrange(ATS_bin, `base_min', `earnings_max') & replacement_rate <= 60 , lcolor(dknavy) lpattern(dash)) ///
	(line replacement_rate ATS_bin if year == `year_pl' ///
	& ATS_bin <= `future_min' & replacement_rate <= 60 , lcolor(none) lpattern(none)) ///
	(line replacement_rate ATS_bin if year == `year_pl' ///
	& inrange(ATS_bin, `future_min', `earnings_max') & replacement_rate <= 60 , lcolor(green%50) lwidth(thick) lpattern(solid) ///
	ylab(0(10)60, grid) ///
	ylab(, nogrid labsize(medium)) xlab(, nogrid labsize(medium)) ///
	xline(`base_max', lpattern(shortdash) lcolor(gray)) ///
	legend(label(2 "`year'") label(4 "`year_pl'") ///
	order(2 4)) xtitle("Monthly Earnings (ATS)") ///
	ytitle("Benefits (b/w)"))

	graph export "${figures}/FigB`number'`letter'.pdf", replace

	} // Year
	} // Group of reform

log close

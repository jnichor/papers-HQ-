/*******************************************************************************

	DESCRIPTION: Analyze the predictive power of average wage growth to
		to predict individual wage growth.
		Calculate the total and by-percentile standard deviation of
		average wage growth.



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/04d_Diagnostic_WagePrediction`curr_date'", replace


		**** Looping through years forward
		foreach yrFwd in 1 {

		foreach suffix in earn_pct  {


		use ${temp}/02a_ReformGlobal.dta if inrange(earn_pct_bin, 1, 84), clear // stops at 84 because of earnings cap


*(A1) The RSq of a  regression of wage *levels* tomorrow regressed on wage level today  times “g”. We’d use the worker-level data, our sample restrictions for the various reforms. No controls.

		noi reg earn_f`yrFwd' infl`yrFwd'_adj_earnings, vce(cluster `suffix')

		local A1_b = round(_b[infl`yrFwd'_adj_earnings],0.001)
		local A1_Rsq = round(e(r2),0.0001)


*(A2) Same as (1) but only on reform years (i.e. base to reform year)

		noi reg earn_f`yrFwd' infl`yrFwd'_adj_earnings ///
		if inlist(year, 1975, 1977, 1981, 1984, 1988),  vce(cluster `suffix')

		local A2_b = round(_b[infl`yrFwd'_adj_earnings],0.001)
		local A2_Rsq = round(e(r2),0.0001)


*(A3) Instead of reporting the RSq, let’s report the slope - trivially ~=1 here

*PERCENTILE-WISE:
*(P1) Plotting *for each percentile* the RSq of this regression.

	qui su earn_pct_bin
	local min = r(min)
	local max = r(max)
	local num_percentiles = r(max) - r(min) + 1
	qui levelsof earn_pct_bin, local(levels)
	foreach p in `levels'  {
		di "Regression for Percentile `p'"
		noi reg earn_f`yrFwd' infl`yrFwd'_adj_earnings if earn_pct_bin == `p', vce(cluster `suffix')

		local P1_b_`p'pct = _b[infl`yrFwd'_adj_earnings]
		local P1_Rsq_`p'pct = e(r2)

		noi reg earn_f`yrFwd' infl`yrFwd'_adj_earnings if earn_pct_bin == `p' ///
		& inlist(year, 1975, 1977, 1981, 1984, 1988),  vce(cluster `suffix')

		local P2_b_`p'pct = _b[infl`yrFwd'_adj_earnings]
		local P2_Rsq_`p'pct = e(r2)
	}


*(P2) Like (P1) but WITH CONTROLS
*(P3) Perhaps a simple “slope” gradient — i.e. for each percentile, we plot the slope of the percentile-specific  w_{i,t+1} vs.  g_t * w_{i,t}


* standard deviation of wage growth

gen norm_wage_grwth`yrFwd' = 100*(wage_grwth`yrFwd' - 1)

qui su norm_wage_grwth`yrFwd'
local sdgrwth = round(r(sd),0.01)
collapse (sd) std_wage_grwth`yrFwd' = norm_wage_grwth`yrFwd', by(earn_pct_bin)
replace std_wage_grwth`yrFwd' = std_wage_grwth`yrFwd' / 100

rename earn_pct_bin pct
tempfile sds
save `sds', replace


forval i = 1/2 {


	clear

	set obs `num_percentiles'

	gen n = _n
	gen pct = `min' + n - 1

	drop n

	if `i' == 1 {
		local with allyrs
	}
	if `i' == 2 {
		local with reformyrs
	}

	gen P`i'_b = .
	gen P`i'_Rsq = .
	gen A`i'_b = `A`i'_b'
	gen A`i'_Rsq = `A`i'_Rsq'
	gen sdgrwth = `sdgrwth' / 100

	qui su pct

	forval p  = `r(min)'/`r(max)' {

		replace P`i'_b = `P`i'_b_`p'pct' if pct == `p'
		replace P`i'_Rsq = `P`i'_Rsq_`p'pct' if pct == `p'

	}

	merge 1:1 pct using "`sds'", nogen

	save ${temp}/04d_`with'_f`yrFwd'.dta, replace
} // Reform or all years



} // Instrument aggregation
} // Years forward

log close

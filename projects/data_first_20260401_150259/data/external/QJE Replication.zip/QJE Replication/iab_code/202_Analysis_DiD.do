*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/202/$today"
local output $log/202/$today

log using "`output'/202_Analysis_DiD.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*			202 Analysis DiD
*
********************************************************************************

foreach robust in 1 2 3 {

	foreach w in $winsor_values {
		noi di "Winsorization `w' %"

		use "${data}/iab_wage_analysis_winsor`w'.dta" if abs(d_rel) <= ${bw_standard} & (AG == 1 | GmbH == 1) ${robust`robust'} , clear

		qui foreach i in $specifications {

		timer on 2
		noi di "Specification `i'"


		foreach outcome in $outcomes  {

			timer on 2
			noi di "	Outcome: `outcome'"


			timer on 3

			* DiD Regression
			reghdfe `outcome' i.AG##i.prereformcohort , ///
			a(${controls`i'}) vce(cluster cluster_variable)

			global b`outcome'`w'`i' = _b[1.AG#1.prereformcohort]
			global s`outcome'`w'`i' = _se[1.AG#1.prereformcohort]
			global p`outcome'`w'`i' = (2 * ttail(e(df_r), abs(_b[1.AG#1.prereformcohort]/_se[1.AG#1.prereformcohort])))

			global bag`outcome'`w'`i' = _b[1.AG]
			global sag`outcome'`w'`i' = _se[1.AG]
			global pag`outcome'`w'`i' = (2 * ttail(e(df_r), abs(_b[1.AG]/_se[1.AG])))

			global bpre`outcome'`w'`i' = _b[1.prereformcohort]
			global spre`outcome'`w'`i' = _se[1.prereformcohort]
			global ppre`outcome'`w'`i' = (2 * ttail(e(df_r), abs(_b[1.prereformcohort]/_se[1.prereformcohort])))

			global N`outcome'`w'`i' `e(N)'

			* Number of AGs and GmbHs

			* Number of firm-years by legal type
			gstats su `outcome' if e(sample)==1 & AG==1
			global Nfyag1`outcome'`w'`i' = `r(N)'

			gstats su `outcome' if e(sample)==1 & AG==0
			global Nfyag0`outcome'`w'`i' = `r(N)'

			gdistinct idnr if e(sample) == 1
			global Nf`outcome'`w'`i' = `r(ndistinct)'

			gdistinct idnr if e(sample) == 1 & AG == 1
			global Nag1`outcome'`w'`i' = `r(ndistinct)'

			gdistinct idnr if e(sample) == 1 & AG == 0
			global Nag0`outcome'`w'`i' = `r(ndistinct)'


			* Control group mean at the discontinuity
			gstats su `outcome' if d_rel >= 0 & AG == 0
			global cmag0`outcome'`w'`i' = `r(mean)'

			gstats su `outcome' if d_rel >= 0 &  AG == 1
			global cmag1`outcome'`w'`i' = `r(mean)'


			timer off 3
			qui timer list 3
			noi di "		Time for regression: `r(t3)' seconds"
			timer clear 3

			} // Outcomes

		} // Specifications

	} // Winsor values


	foreach i in $specifications {

		qui foreach outcome in $outcomes {

			foreach w in $winsor_values {



				* Save data
				clear
				set obs 1
				gen spec = `i'
				gen outcome = "`outcome'"
				gen winsor = `w'
				gen bandwidth = $bw_standard
				gen N = ${N`outcome'`w'`i'}
				gen b = ${b`outcome'`w'`i'}
				gen s = ${s`outcome'`w'`i'}
				gen p = ${p`outcome'`w'`i'}
				gen bag = ${bag`outcome'`w'`i'}
				gen sag = ${sag`outcome'`w'`i'}
				gen pag = ${pag`outcome'`w'`i'}
				gen bprereformcohort = ${bpre`outcome'`w'`i'}
				gen spre = ${spre`outcome'`w'`i'}
				gen ppre = ${ppre`outcome'`w'`i'}
				gen controlmean_AG = ${cmag1`outcome'`w'`i'}
				gen controlmean_nonAG = ${cmag0`outcome'`w'`i'}
				gen Nfirms = ${Nf`outcome'`w'`i'}
				gen N_AG = ${Nag1`outcome'`w'`i'}
				gen N_nonAG = ${Nag0`outcome'`w'`i'}
				gen Nfirmyears_AG = ${Nfyag1`outcome'`w'`i'}
				gen Nfirmyears_nonAG = ${Nfyag0`outcome'`w'`i'}

				save "`output'/DiD_`outcome'_Winsor`w'_spec`i'${robustness`robust'}.dta", replace

			} // Winsor values
		} // Outcome
	} // Specification
} // Robustness

log close

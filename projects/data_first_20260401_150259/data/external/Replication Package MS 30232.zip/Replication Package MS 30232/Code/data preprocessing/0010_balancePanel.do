/*
	Balance panel

*/

/*
use $temp/0110_exploreREBP_birthcohorts.dta, clear
bysort svnr: keep if _n==1
keep svnr
merge 1:1 svnr using $temp/stammdaten.dta, keep(3) keepusing(deathmonth deathyear birthyear birthmonth) nogen
save $temp/balance_svnr.dta, replace
*/

clear
g svnr = .
save $temp/balance_svnr.dta, replace
set more off
forvalues y = 1983(1)1998 {
	global y = `y'
	
	global y = `y'
	
	foreach m of numlist 1 3 4 6 7 9 10 12 {
		global m = `m'
		
		global m = `m'
		
		use $data/0010_panelBal_year${y}_month${m}.dta, clear
		keep svnr
		append using $temp/balance_svnr.dta
		bysort svnr: keep if _n==1
		save $temp/balance_svnr.dta, replace

		/*merge 1:1 svnr using $temp/balance_svnr.dta, keep(1 2 3) nogen
		replace ref = mdy($m,15,$y) if ref==. & mdy($m,15,$y)<mdy(deathmonth,15,deathyear)
		replace status = 20 if status==. & mdy($m,15,$y)<mdy(deathmonth,15,deathyear)
		replace refage = (ref-mdy(birthmonth,15,birthyear))/365.25 if refage==. & mdy($m,15,$y)<mdy(deathmonth,15,deathyear)
		
		keep if ref<.
		
		drop death*
		
		save $data/0010_panelBal_year${y}_month${m}.dta, replace*/				
		
	} // m
} // y

use $temp/balance_svnr.dta, clear
capt drop birth* death* frau
merge 1:1 svnr using $temp/stammdaten.dta, keep(3) keepusing(deathmonth deathyear frau birthyear birthmonth frau) nogen
save $temp/balance_svnr.dta, replace


set more off
forvalues y = 1983(1)1998 {
	global y = `y'
	
	
	foreach m of numlist 1 3 4 6 7 9 10 12 {
		global m = `m'
		
		global m = `m'
		
		use $data/0010_panelBal_year${y}_month${m}.dta, clear
		
		drop if status==20

		merge 1:1 svnr using $temp/balance_svnr.dta, keep(1 2 3) nogen
		replace ref = mdy($m,15,$y) if ref==. & mdy($m,15,$y)<mdy(deathmonth,15,deathyear)
		replace status = 20 if status==. & mdy($m,15,$y)<mdy(deathmonth,15,deathyear)
		replace refage = (ref-mdy(birthmonth,15,birthyear))/365.25 if refage==. & mdy($m,15,$y)<mdy(deathmonth,15,deathyear)
		
		drop if refage<40 & status==20
		drop if refage>65 & status==20
		
		keep if ref<.
		
		*drop death*
		
		save $data/0010_panelBal_year${y}_month${m}.dta, replace			
		
	} // m
} // y

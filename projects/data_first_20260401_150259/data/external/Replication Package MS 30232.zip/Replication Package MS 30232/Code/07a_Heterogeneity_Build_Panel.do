/*******************************************************************************

	DESCRIPTION: Construct worker-year panel for heterogeneity analysis
		from the regular regression sample and the heterogeneity variable
		constructions. Note, it creates groups for the "heterogeneity variables"
		and for the labor market transitions

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/07a_Heterogeneity_Build_Panel`curr_date'", replace




****************************************************************************
* Defining heterogeneity variables to split the sample by
****************************************************************************
foreach yrFwd in $earnF {

	use ${temp}/02c_PooledReforms_yrFwd`yrFwd'.dta, clear


	**** Local unemployment rates
	* Merging on local unemployment rate
	fmerge m:1 gkz_work year using ${temp}/06a_LocalUnempRate.dta, keep(1 3) nogen

	gen preyear = year - 2
	rename (year preyear) (preyear year)

	*** Wage dispersion values
	* Merge wage dispersion values (based out of t - 3)
	merge m:1 benr year reform using ${temp}/06c_FirmLevelInfo.dta, keep(1 3) nogen

	**** Industry-occupation unemployment rates
	* Merging on industr-occupation unemployment measures
	fmerge m:1 nace08 whitecoll year using ${temp}/06d_IndOccUnempRate.dta, keep(1 3) nogen

	**** Industry growth rates (t-3 to t-2, e.g. 1982 to 1983)
	* Merging on firm
	merge m:1 benr year using ${temp}/06e_IndustryGrowthRate.dta, keep(1 3) nogen

	rename (preyear year) (year preyear)
	drop preyear

	**** AKM Firm FEs
	merge m:1 benr reform year using ${temp}/06b_AKMFirmEffects.dta, keep(1 3) nogen




	********************************************
	* Quantiles of the heterogeneity variables *
	********************************************

	* 1. Unemployment Risk

		* Predicted Months UE; Predicted Separation Rate
		local indocc_vars indocc_mth_UE indocc_unemp
		foreach var in  `indocc_vars' {
			gquantiles `var'_grp = `var', xtile by(reform year) nquantiles(5)
		}


		* Local Unemployment Rate (quartiles to get around clustered bin)
		gquantiles UE_grp = unemp_rate_gkz, xtile by(reform year) nquantiles(4)

		* Months since UI Receipt; Months since Non-Emp.
		rename mths_since_* ms_*
		rename *_skiprecalls *_sr
		foreach suffix in "" "_sr" {
			foreach var in UI nonemp {
				gquantiles `var'`suffix'_grp = ms_`var'`suffix', xtile by(reform year) nquantiles(5)
			}
		}
		rename ms_* mths_since_*

	* 2. Firm Characteristics

		* Industry Growth Rate
		gquantiles lom_ind_growth_grp = lom_ind_growth_w, xtile by(reform year) nquantiles(5)

		* Wage Premium (AKM FE)
		gquantiles AKMfirm_grp = firmFE, xtile by(reform year) nquantiles(5)

		* SD of Earnings Growth; Wage Distance from CBA Floor
		ds wage_growth*
		local wage_growth_vars `r(varlist)'
		ds CBA*
		local CBA_vars `r(varlist)'
		foreach var in `wage_growth_vars' `CBA_vars' {
			gquantiles `var'_grp = `var', xtile by(reform year) nquantiles(5)
		}

		* Share Non-Emp Last 2 Yrs
		gquantiles firmshNonemp_grp = firm_shNonemp2, xtile by(reform year) nquantiles(5)

	* 3. Worker Characteristics

		* Tenure
		gquantiles tenure_grp = tenure, xtile by(reform year) nquantiles(5)

		* Age
		gquantiles age_grp = refage, xtile by(reform year) nquantiles(5)

		* Male/Female
		gen gender_grp = cond(frau == 0, 1, 2)

		* Blue/White c\Collar
		gen occ_grp = cond(whitecoll == 0, 1, 2)


		* 4. Switcher groups

		* Switchers analysis level 1: Stayers vs. Switchers vs. Recalled
		assert recalled_f`yrFwd' == 0 if mover_f`yrFwd' == 1
		gen switch_anal1_grp = .
		replace switch_anal1_grp = 1 if stayer_f`yrFwd' == 1
		replace switch_anal1_grp = 2 if recalled_f`yrFwd' == 1
		replace switch_anal1_grp = 3 if mover_f`yrFwd' == 1

		label define list1 1 "Stayers" 2 "Recalled" 3 "Movers"
		label values switch_anal1_grp list1

		* Switchers analysis level 2: Stayers vs. Mover, EE vs. Mover, ENE but not EUE vs. Mover, EUE vs. Recalled
		gen switch_anal2_grp = .
		replace switch_anal2_grp = 1 if stayer_f`yrFwd' == 1
		replace switch_anal2_grp = 2 if recalled_f`yrFwd' == 1
		replace switch_anal2_grp = 3 if EE_f`yrFwd' == 1 & mover_f`yrFwd' == 1
		replace switch_anal2_grp = 4 if ENE_f`yrFwd' == 1 & mover_f`yrFwd' == 1 & EUE_f`yrFwd' == 0
		replace switch_anal2_grp = 5 if EUE_f`yrFwd' == 1 & mover_f`yrFwd' == 1

		label define list2 1 "Stayers" 2 "Recalled" 3 "Mover, EE" 4 "Mover, ENE not EUE" 5 "Mover, EUE"
		label values switch_anal2_grp list2




	* Save file
	compress
	save ${temp}/07a_Heterogeneity_yrFwd`yrFwd'.dta, replace

	} // Years forward


clear
log close

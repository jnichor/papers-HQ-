*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================


********************************************************************************
*
*
*	    0 Master Dofile
*
*
********************************************************************************



* 1. Set Paths and Settings
*-------------------------------------------------------------------------------

global		prog		N:\Ablagen\D01700-IAB-Projekte\D01700-HeiningJ\Simon_Jaeger_BvD\prog/
global		data		N:\Ablagen\D01700-IAB-Projekte\D01700-HeiningJ\Simon_Jaeger_BvD\data/
global		log			N:\Ablagen\D01700-IAB-Projekte\D01700-HeiningJ\Simon_Jaeger_BvD\log/
global 		orig		N:\Ablagen\D01700-IAB-Projekte\D01700-HeiningJ\Simon_Jaeger_BvD\orig/
global 		chk			Z:\Forschung\David Card Projekt\CHK_Effekte/
global 		orig_wz		"\\iab\DFS\017\Ablagen\D01700-IAB-Projekte\D01700-Projekte-FDZ\Datensaetze\_Endprodukte\BHP\_Archiv\BHP7514_v1\Grundgesamtheit"

sysdir set SITE "N:\Ablagen\D01700-Allgemein\STATA\bocode"
adopath ++ N:\Ablagen\D01700-IAB-Projekte\D01700-HeiningJ\Simon_Jaeger_BvD\prog\ado

set dp period , permanently
set varabbrev on
set matsize 11000
set more off

* 2. Create folder structure
*-------------------------------------------------------------------------------
forval dofile = 201/213 {
 cap mkdir ${log}/`dofile'
}
* 3. Run do-files
*-------------------------------------------------------------------------------

* 3.1 Globals
do ${prog}/11_globals
do ${prog}/12_globals_outcomes

* 3.2 Data Prep
do $prog\101_Build_SIAB_prep.do
do $prog\102_Build_SIAB_variables.do
do $prog\103_Build_SIAB_collapse.do
do $prog\104_Build_akm_estimation.do
do $prog\105_Build_IAB_analysis_sample.do
do $prog\106_Build_Winsorization.do
do $prog\114_CBA_Betriebspanel.do
do $prog\115_extract_industry_characteristics.do

* 3.3 Analysis
do $prog/201_Analysis_RD.do
do $prog/202_Analysis_DiD.do
do $prog/203_Analysis_Diff.do
do $prog/204_Analysis_DiD_RD_Figures.do
do $prog/205_Analysis_Bandwidth.do
do $prog/206_Analysis_DonutHole.do
do $prog/207_Analysis_PlaceboReformYear.do
do $prog/208_Analysis_McCrary.do
do $prog/209_Analysis_DiD_Heterogeneity.do
do $prog/210_Analysis_Diff_Heterogeneity.do
do $prog/211_Analysis_RD_Heterogeneity.do
do $prog/212_Analysis_Rent_Sharing.do
do $prog/213_Analysis_Industry_Selection.do
do $prog/214_Analysis_Industry_Selection_nonzero.do


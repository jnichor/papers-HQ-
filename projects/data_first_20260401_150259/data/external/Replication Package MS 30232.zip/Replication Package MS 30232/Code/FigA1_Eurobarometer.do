/*******************************************************************************

	DESCRIPTION: Figure A.1 Eurobarometer.



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
clear all
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA1_Eurobarometer`curr_date'", replace

use ${temp}/04b_Eurobarometer.dta, clear

qui sum meanactualRR_w_
global meanactualRR_w : di %5.2f `r(mean)'

gen RR_cat1 = 1 if actualRR >= .91 & !mi(actualRR)
gen RR_cat2 = 1 if inrange(actualRR, .71, .90)
gen RR_cat3 = 1 if inrange(actualRR, .51, .70)
gen RR_cat4 = 1 if inrange(actualRR, .31, .50)
gen RR_cat5 = 1 if inrange(actualRR, .0, .30)
gen noMi_RR = 1 if !mi(actualRR)

collapse (sum) RR_cat* noMi_RR

su noMi_RR
local num_obs = r(mean)
forvalues i = 1/5 {
	replace RR_cat`i' = RR_cat`i'/`num_obs'
}

gen sample = "Actual UIB Observed in AMS Data"
tempfile ASSD_Shares
save `ASSD_Shares'

use ${temp}/04b_Eurobarometer_Survey.dta, clear

qui sum meanpredRR_
global meanpredRR : di %5.2f `r(mean)'
qui sum sepredRR_
global sepredRR : di %5.2f `r(mean)'

forvalues i = 1/5 {
	gen RR_cat`i' = 1 if predRR == `i'
}
gen noMi_RR = inrange(predRR, 1, 5)

collapse (sum) RR_cat* noMi_RR

su noMi_RR
local num_obs = r(mean)
forvalues i = 1/5 {
	replace RR_cat`i' = RR_cat`i'/`num_obs'
}
drop noMi_RR

gen sample = "Beliefs (Eurobarometer)"

append using `ASSD_Shares'

drop noMi_RR

gen i = _n

reshape long RR_cat, i(i) j(cat)

drop i

gen temp = abs(cat-6)
drop cat
rename temp cat

graph bar RR_cat,  ///
over(cat, ///
relabel(1 "<30%" 2 "31-50%" 3 "51-70%" 4 "71-90%" 5 ">91%") ///
label(angle(45)) gap(50) ) ///
over(sample)  ///
ytitle("Share of Total") note("Mean observed UIB % = ${meanactualRR_w}%" ///
"Mean belief about UIB % = ${meanpredRR}%")

graph export "${figures}/FigA1_Eurobarometer.pdf", replace

noi di "SE of belief: ${sepredRR}"

log close

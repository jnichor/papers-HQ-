/*******************************************************************************

	DESCRIPTION: Difference-in-Differences analysis of pooled sample
	             interacting with tau heterogeneity.

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/09d_Heterogeneity_Tau`curr_date'", replace



* Choose which of controls below to use -- only run individual spec for tau het
local control_num_list_earn_pct 4

* set number of bins for percentiles
local bins	= 10
local adjustm 	= "highlow" // "low", "high", "highlow"
local nadjust	= 2




****************************************************************************
* Controls Lists for the Different Specifications
****************************************************************************
local controls1 reform#year##c.lnearnings reform#year#REBPcontrol
local controls2 reform#year##c.(exp25 exp25_sq exp25_cub tenure tenure_sq tenure_cub refage refage_sq refage_cub lnearnings)  reform#year#frau reform#year#REBPcontrol
local controls3 `controls1'
local controls4 `controls2'
local controls5 `controls1'
local controls6 `controls2'

local FE_controls1 earn_pct_bin#reform
local FE_controls2 `FE_controls1'
local FE_controls3 `FE_controls1' nace08#whitecoll#reform#year
local FE_controls4 `FE_controls3'
local FE_controls5 `FE_controls1' benr#year#reform
local FE_controls6 `FE_controls3' benr#year#reform

local controlname1 none
local controlname2 mincer
local controlname3 indocc
local controlname4 ctrls
local controlname5 firmyr
local controlname6 ctrlsfirmyr




****************************************************************************
* Pooled Analysis
****************************************************************************
foreach type in $types {
foreach yrFwd in $earnF {
foreach group in $include1976 {

	* define outcomes for the current earnings window
	local main_outcomes earn_Diff_f`yrFwd'
	local outcomes `main_outcomes'

	* settings for the current inclusion number
	if `group' == 0 { // 6 Years back
		local grprestriction inlist(reform, 1985, 1989, 2001)
		local samplename ""
		local coefflist1 l5 l4 l3 l2 l0
		local coefflist2 l5 l4 l3 l0
		local coefflist3 l5 l4 l0
	}
	if `group' == 1  { // 4 years Back
		local grprestriction inlist(reform, 1976, 1985, 1989, 2001) & inlist(yr_l5,.,0) & inlist(yr_l4,.,0)
		local samplename With76
		local coefflist1 l3 l2 l0
		local coefflist2 l3 l0
		local coefflist3 l0
	}

	* loop over aggregations (earn_pct)
	foreach suffix in $aggregations {




		****************************************************************************
		* Loading Analsys Data + Setting Up for main outcome regression analysis
		****************************************************************************
		* set cluster variable
		if "`suffix'" == "earn_pct" {
			local cluster svnr earn_pct_bin
		}
		else {
			local cluster `suffix' svnr
		}

		* load pooled reform data
		use ${temp}/02c_PooledReforms_yrFwd`yrFwd'.dta if `grprestriction', clear

		* Indicator for REBP eligibility
		gen REBPcontrol = rebp != 0 & eREBP == 1 & reform == 1989 & year >= 1987

		* winsorize earnings outcomes
		winsor2 earn_Diff_f`yrFwd', replace cut(1 99) by(reform year)

		* keep if employed in December
		keep if status == 3

		* shorten the 1976 and 1989 reform samples by one percentile
		if $Shorten76and89 == 1 {
			foreach reform in 1976 1989 {
				su earn_pct if treatment_`reform' == 1
				local min = r(min)
				su earn_pct if control_`reform' == 1
				local max = r(max)
				local new_min = `min' + 1
				local new_max = `max' - 1
				drop if reform == `reform' & earn_pct <= `new_min' & !mi(earn_pct)
				drop if reform == `reform' & earn_pct >= `new_max' & !mi(earn_pct)
			} // Looping through 1976 and 1989 code blocks
		} // Shorten 76 and 89 code block


		* settings for the current type
		if "`type'" == "_stable" {
			keep if mth_emp == 12
		}

		local short = substr("`type'",2,.)

		if inlist("`type'", "_stayer", "_mover", "_recalled") {
			keep if `short'_f`yrFwd' == 1 & mth_emp == 12
		}

		if inlist("`type'", "_ENE", "_EE", "_EUE") {
			keep if mover_f`yrFwd' == 1 & `short'_f`yrFwd'  == 1 & mth_emp == 12
		}

		if inlist("`type'", "_nonEUE") {
			keep if mover_f`yrFwd' == 1 & EUE_f`yrFwd' == 0 & ENE_f`yrFwd' == 1 & mth_emp == 12
		}

		if inlist("`type'", "_shortENE") {
			keep if mover_f`yrFwd' == 1 & ENE_f`yrFwd' == 1 & len_NE_premove_f`yrFwd' == 1 & mth_emp == 12
		}

		if inlist("`type'", "_longENE") {
			keep if mover_f`yrFwd' == 1 & ENE_f`yrFwd' == 1 & len_NE_premove_f`yrFwd' > 1 & !mi(len_NE_premove_f`yrFwd')  & mth_emp == 12
		}

		if `group' == 1  {
			drop *_l4_f`yrFwd' *_l5_f`yrFwd' yr_l5 yr_l4
		}




		****************************************************************************
		* Heterogeneity variables for the tau prediction model
		****************************************************************************

		***** Months since UI group
			* Within-year indicator for censored value + four other quartiles
		bys reform year: gegen max = max(mths_since_UI)
		gen ms_UI_cat = 0 if mths_since_UI == max
		gquantiles temp_cat = mths_since_UI ///
		if mths_since_UI != max & !mi(mths_since_UI), ///
		xtile by(reform year) nquantiles(5)
		replace ms_UI_cat = temp_cat if !mi(temp_cat)
		drop max temp_cat


		***** Calculate tenure categories in three-year steps up to 15 years
		gen tenure_cat = 1 if tenure != . & tenure < 3
		local i = 2
		forvalues k = 3(3)12 {
			replace tenure_cat = `i' if tenure >= `k' & tenure < `k'+3
			local ++i
		}
		sum tenure_cat
		replace tenure_cat = r(max)+1 if tenure !=. & tenure >= 15


		***** Calculate experience categories in 5-year steps up to 25 years
		gen exp_cat = 1 if exp25 != . & exp25 < 5
		local i = 2
		forval k = 5(5)15 {
			replace exp_cat = `i' if exp25 >= `k' & exp25 < `k' + 5
			local ++i
		}
		sum exp_cat
		replace exp_cat = r(max)+1 if exp25 != . & exp25 >= 20


		***** Calculate age categories in 5-year steps
		gen age_cat = 1 if refage != . & refage < 30
		local i = 2
		forval k = 30(5)50 {
			replace age_cat = `i' if refage >= `k' & refage < `k' + 5
			local ++i
		}


		***** Create 3-digit NUTZ based on place of work
		gen nutz = substr(string(gkz_work),1,3)
		destring nutz, replace




		****************************************************************************
		* Estimating predicted tau values + splitting up for heterogeneity groups
		****************************************************************************

		* save temp data
		compress
		tempfile prepared
		save "`prepared'"

		* generate summary stats matrix
		local C : list sizeof global(conditions_hetAnal) // conditions are columns
		local R : list sizeof global(tausamples_hetAnal)	// samples are rows
		matrix define M = J(`R'*3,`C',.) // we have a matrix with `R'*3 rows and `C' columns

		* loop over ENE conditions
		local c = 0
		qui foreach condition in $conditions_hetAnal {

			noi di "Condition: `condition'"

			* set condition for prediction (ENE4)
			if strpos("`condition'", "ENE") > 0 {
				local statement "& `condition' == 1"
			}

			* loop over tau samples
			local ++c
			local r = 1
			foreach tausample in $tausamples_hetAnal {
				noi di "Sample: `tausample'"

				* use the prepared data file
				use "`prepared'", clear

				***** merge tau's for the current sample
					* Won't be a complete match
					* Some individuals in the daily data won't be matched if the separations are very short
					* Some separations won't be matched (ex. an individual who separates after Dec 15th)
				noi fmerge m:1 svnr year using $temp/09b_Tau_Appended_`tausample'_WithDateType_UIvsUA.dta, keepusing(E_frac O_frac N_frac UI_frac UA_frac ENE?)
								noi tab _merge ENE_f1, m
				drop if _merge == 2
				drop _merge

				* the fractions are called taus everywhere else
				rename (UI_frac UA_frac) (tau_UI tau_UA)

				* generate actual tau's (U = UI + UA)
				gen tau_U 	= tau_UI + tau_UA

				* generate realized benefit sensitivity (currently two state version)
				gen sensitivity = ((1-${phi})*tau_U) / (1-(1-${phi})*(1-tau_U)) // = Sens_2

				***** Do regression of tau measures on covariates and predict tau hat
				foreach tau of varlist tau_U /*tau_UI tau_UA */ {
					noi reg `tau' i.nace08#i.whitecoll i.tenure_cat i.exp_cat i.age_cat i.nutz i.frau i.ms_UI_cat i.reform#i.year if (ENE_f1 == 1 | (mover_f1 == 0  & recalled_f1 == 0 & stayer_f1 == 0)) `statement'


					* save R-square
					local rsq = `e(r2)'
					local rsqa = `e(r2_a)'
					noi di "R2 for `tau': `rsq' and adjusted `rsqa'"
					matrix M[`r',`c'] = `rsqa'
					local ++r

					* predict tau hat
					predict `tau'_hat, xb
				} // Tau groups

				* use predicted values to calculate an estimated, individual-specific wage-benefit sensitivity
					* Note it uses the tau_U_hat values rather than tau_ui and tau_ua separately but it won't matter because everything is linear so we'll get the same predicted value.
				gen sensitivity_hat = ((1-${phi})*tau_U_hat) / (1-(1-${phi})*(1-tau_U_hat)) // = sens_2state

				* generate quintiles of predicted tau^U by reform and year
				gquantiles tau_U_qrt_K = tau_U_hat, xtile by(reform year) nquantiles(`bins')

				***** Splits up the bottom and top bins into smaller subdivisions
					* adjustm -- whether to adjust the top or b o
				if strpos("`adjustm'","low")>0 {
					local i = 1
					while `i' <= `nadjust' {
						su tau_U_qrt_K
						local bin = `r(min)'
						gen tau_U_hat_bin = tau_U_hat if tau_U_qrt_K==`bin' // lowest bin
						gquantiles tau_U_qrt_K_bin = tau_U_hat_bin, xtile by(reform year) nquantiles(2)
						replace tau_U_qrt_K = tau_U_qrt_K + 1
						replace tau_U_qrt_K = tau_U_qrt_K_bin if tau_U_qrt_K==(`bin'+1) // split lowest bin into two
						drop tau_U_hat_bin tau_U_qrt_K_bin
						local ++i
					}
				}
				if strpos("`adjustm'","high")>0 {
					local i = 1
					while `i' <= `nadjust' {
						su tau_U_qrt_K
						local bin = `r(max)'
						gen tau_U_hat_bin = tau_U_hat if tau_U_qrt_K==`bin' // highest bin
						gquantiles tau_U_qrt_K_bin = tau_U_hat_bin, xtile by(reform year) nquantiles(2)
						replace tau_U_qrt_K = tau_U_qrt_K + (tau_U_qrt_K_bin-1) if tau_U_qrt_K==`bin' // split highest bin into two
						drop tau_U_hat_bin tau_U_qrt_K_bin
						local ++i
					}
				}
				noi tab tau_U_qrt_K, miss



				****************************************************************************
				* Estimating the main baseline regression by the tau heterogeneity groups
				****************************************************************************
				* show temp timer
				qui timer list 1

				* run heterogeneity cut specification

				foreach hetergroup in tau_U_qrt_K {
					noi di "Running Heterogeneity Cut Specification for `hetergroup' after `time' minutes..."
					foreach cnt_grp in `control_num_list_`suffix'' {
						cap program drop run_specification_hetcuts
						noi run_specification_hetcuts, outcomes(`outcomes') ///
						instr_aggreg(`suffix') ///
						controlname(`controlname`cnt_grp'') ///
						instr_yrFwd(1) ///
						regvars(" ") ///
						absorbvars(`controls`cnt_grp'' `hetergroup'#reform#year##c.lnearnings ///
							`hetergroup'#earn_pct_bin#reform `FE_controls`cnt_grp'') ///
						coefflist(`coefflist`yrFwd'') ///
						aux_info(RRcoeff RRSE intcoeff intSE R N F avg) ///
						cluster(`cluster') ///
						samplename(`samplename'`type') ///
						yrFwd(`yrFwd') ///
						hetergroup(`hetergroup') ///
						heterlabel(`hetergroup')
					} // Specifications
				} // Heterogeneity group


				* generate the overall mean of tau^U and the wage-benefit sensitivity
				gegen tau_U_mean 		= mean(tau_U)
				gegen tau_U_hat_mean 		= mean(tau_U_hat)
				gegen sensitivity_mean 		= mean(sensitivity)
				gegen sensitivity_hat_mean 	= mean(sensitivity_hat)

				* collapse by quintile of predicted tau
				gcollapse (firstnm) tau_U_mean tau_U_hat_mean sensitivity_mean sensitivity_hat_mean (mean) tau_U /*tau_UI tau_UA*/ sensitivity tau_U_hat /*tau_UI_hat tau_UA_hat*/ sensitivity_hat, by(tau_U_qrt_K)

				* calculate sensitivity based on mean tau_U by quintile
				gen sensitivity_hat_tilde = ((1-${phi})*tau_U_hat) / (1-(1-${phi})*(1-tau_U_hat))


				* merge the actual wage-benefit sensitivities (i.e. coefficents) by quintile, which is saved by the run_specification_hetcuts.ado file
				* for each outcome, each heterogeneity group, and each control specification group and save the final data file

				foreach hetergroup in tau_U_qrt_K {
				foreach outcome of local outcomes {
				foreach cnt_grp in `control_num_list_`suffix'' {

				***** Reshaping the heterogeneity file to merge onto the summary file
				preserve

				use "${resDat}/Heterogeneity_`outcome'_`suffix'_`samplename'`type'_Spec`controlname`cnt_grp''`hetergroup'.dta", clear

				* Number of categories
				d, s
				local num_cat = (r(k)-1)/12

				forvalues i = 1/`num_cat' {

					rename ctrls_lev`i'RRcoeff ctrls_RRcoeff`i'
					rename ctrls_lev`i'RRSE ctrls_RRSE`i'
					rename ctrls_lev`i'intcoeff ctrls_intcoeff`i'
					rename ctrls_lev`i'intSE ctrls_intSE`i'
					rename ctrls_lev`i'R ctrls_R`i'
					rename ctrls_lev`i'N ctrls_N`i'
					rename ctrls_lev`i'F ctrls_F`i'
					rename ctrls_lev`i'avg ctrls_avg`i'
					rename ctrls_lev`i'RRUB ctrls_RRUB`i'
					rename ctrls_lev`i'RRLB ctrls_RRLB`i'
					rename ctrls_lev`i'intUB ctrls_intUB`i'
					rename ctrls_lev`i'intLB ctrls_intLB`i'
				}

				reshape long ctrls_RRcoeff ctrls_RRSE ctrls_intcoeff ctrls_intSE ctrls_R ctrls_N ctrls_F ctrls_avg ctrls_RRUB ctrls_RRLB ctrls_intUB ctrls_intLB, i(year) j(heteroGrp)

				* Only plotting the treated year coefficient
				keep if year == 0

				tempfile hetMerge
				save `hetMerge', replace

				restore

				preserve

				* merge coefficients by heterogeneity group
				gen heteroGrp = tau_U_qrt_K
				fmerge 1:1 heteroGrp using `hetMerge'
				drop heteroGrp

				* save final data set
				compress
				hashsort tau_U_qrt_K
				noi save "${temp}/09d_TauHeterogeneity_`samplename'`type'_`condition'_`tausample'_`outcome'_`hetergroup'_`bins'_`adjustm'`nadjust'.dta", replace

				restore

				} // control group
				} // outcomes
				} // heterogeneity groups
			} // Tau samples
		} // conditions
	} // Instrument aggregation
} // With or Without 1976
} // Years forward
} // Type

* show matrix with R2
matrix list M


log close

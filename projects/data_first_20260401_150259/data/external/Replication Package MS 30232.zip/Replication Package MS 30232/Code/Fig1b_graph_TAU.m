
close all

figure1 = figure;

  phi_50=0.5
  phi_20=0.2
  phi_10=0.1
  phi_2=0.02
  
  tau=0 :0.01:1

  dwdb_50= (1-phi_50)*1./(1+phi_50*(1./tau -1))
  dwdb_20= (1-phi_20)*1./(1+phi_20*(1./tau -1))
  dwdb_10= (1-phi_10)*1./(1+phi_10*(1./tau -1))
  dwdb_02= (1-phi_2)*1./(1+phi_2*(1./tau -1))

plot(tau,dwdb_02,':')
hold on 
plot(tau,dwdb_10,'-','color',[0.9290, 0.6940, 0.1250])
hold on 
plot(tau,dwdb_20,'-.','color',[0.8500, 0.3250, 0.0980]) 
hold on
plot(tau,dwdb_50,'--')

txt_2 = '\phi = 0.02';
%annotation('textbox',[0.25 0.8 0.04 0.04],'String', txt_2, 'HorizontalAlignment', 'center', 'FontSize', 16, 'BackgroundColor', 'w','FitBoxToText','on')
txt_10 = '\phi = 0.1';
%annotation('textbox',[0.25 0.6 0.04 0.04],'String', txt_10, 'HorizontalAlignment', 'center', 'FontSize', 16, 'BackgroundColor', 'w','FitBoxToText','on')
txt_20 = '\phi = 0.2';
%annotation('textbox',[0.25 0.43 0.04 0.04],'String', txt_20, 'HorizontalAlignment', 'center', 'FontSize', 16, 'BackgroundColor', 'w','FitBoxToText','on')
txt_50 = '\phi = 0.5';
%annotation('textbox',[0.25 0.25 0.04 0.04],'String', txt_50, 'HorizontalAlignment', 'center', 'FontSize', 16, 'BackgroundColor', 'w','FitBoxToText','on')
xlabel('Time in Nonemployment \tau','fontsize',12)
ylabel('Wage-Benefit Sensitivity','fontsize',12)
      set(findall(gca, 'Type', 'Line'),'LineWidth',4);
legend(txt_2,txt_10,txt_20,txt_50,'Location','southeast') 
set(gca,'FontSize',12)

% Creating horizontal and vertical lines 
annotation(figure1,'line',[0.209 0.209],[0.13 .51]);
annotation(figure1,'line',[0.209 0.13], [.51 .51]);

set(figure1, 'PaperPosition', [0 0 5 4]); 
set(figure1, 'PaperSize', [5 4]); %Keep the same paper size

file_path = 'C:\Users\sammy\Dropbox\Documents\MIT\Work\SimonJaegerWork\Est_BargainingPower\SY_Revision\Code\TwoState_MatlabFigures';
saveas(figure1, fullfile(file_path, 'graph_TAU'),'pdf')


/*******************************************************************************

	DESCRIPTION: build spell data from Stammdaten

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off

***** Logging
cap log close
local curr_date = c(current_date)
log using "${logs}/09a_Build_SpellData`curr_date'", replace

***** Scalars for running different subsections of code
scalar PrepareStammdaten = 1




*===============================================================================
* DATA - RAW
if scalar(PrepareStammdaten) == 1 {
	use svnr frau birthyear birthmonth deathyear deathmonth  using ///
	"${stamdattenData}/00_stammdaten_2016.dta", clear

	* Dropping complete duplicates
	gduplicates drop

	* Birth and death dates
	replace deathmonth = . if deathmonth == 0
	replace deathyear = . if deathyear == 0
	gen birthdat = mdy(birthmonth,15,birthyear)
	gen deathdat = mdy(deathmonth, 15, deathyear)

	format %td birthdat deathdat

	***** De-duplicating:
		* Some svnr are marked as both a woman and not. Drop.
		* Also drops individuals with missing frau variable
	gunique frau, by(svnr)
	drop if _U != 1
	drop _U

	* If one observation is missing death information and one isn't, take the latter.
	* Note -- this also drops individuals with multiple observations and no death info
		* See below tabulations -- 900 individuals so ignored
		// gen nonMi_death = !mi(deathyear)
		// bysort svnr: gegen sumNonMi = sum(nonMi_death)
		// bysort svnr: gen obs_num = _n
		// count if obs_num == 1 & mi(deathyear) & dup > 0 & sumNonMi == 0


	gduplicates tag svnr, gen(dup)
	drop if mi(deathyear) & dup > 0
	drop dup

	* Remaining duplicates differ in death dates. Take earlier one .
	gduplicates tag svnr, gen(dup)
	bys svnr: gegen earlierdeath = min(deathdat)
	drop if dup > 0 & deathdat != earlierdeath & !mi(deathdat) & !mi(earlierdeath)
	drop earlierdeath dup

	* There are three remaining duplicates. Two have a missing frau indicator. The third has two birth years: 1888 and 1988.
	gduplicates tag svnr, gen(dup)
	drop if dup > 0 & mi(frau)
	drop if dup > 0 & birthyear == 1888
	drop dup

	gduplicates tag svnr, gen(dup)
	gstats sum dup
	assert r(mean) == 0

	* Saving + compressing
	keep svnr birthdat deathdat frau
	compress
	save ${temp}/09a_stammdaten_unique.dta, replace
}


* we disregard non-employment spells that are shorter than `d' days
qui foreach d of global day { // 1 15 29 42
	global days = `d'

	* loop over qualification levels
	noi di "`d' days: Qualification level..."
	set more off
	qui forvalues q = 1/40 {
		cap timer clear 1
		timer on 1
		global q=`q'
		noi di "...`q'"

		* use qualification files
		use svnr vdat bdat qual ktkz using "${qualData}/qual_${q}.dta", clear

		* merge birth and death date as well as gender
			* Individuals not in the stammdaten file are dropped
		fmerge m:1 svnr using "${temp}/09a_stammdaten_unique.dta", nogen keep(3)



		* formatting
		order svnr vdat bdat qual
		hashsort svnr vdat bdat qual

		* we only keep time period 1972-2016 and age 25-100 (defined in globals above)
		gen vage = (vdat - birthdat)/365.25
		gen bage = (bdat - birthdat)/365.25
		gen vyear = year(vdat)
		gen byear = year(bdat)

		* Keeping if starting or ending age is within age range
			* Same for starting and ending year
		keep if (inrange(vage,${vage},${bage})		| inrange(bage,${vage},${bage}))
		keep if (inrange(vyear,${vyear},${byear}) 	| inrange(byear,${vyear},${byear}))
		drop vage bage vyear byear

		/* run status file to define labor market status based on qual variable:
		- 1:  dependent employment
		+ 2:  self-employment
		- 3:  civil servants                                 as far as observed
		+ 4:  minor employment
		+ 5:  old-age part time                              need extra files to get this (Simon Buechi's Altersteilzeit)
		- 6:  military and civil service
		- 7:  maternity insurance
		+ 8:  minor self-employment
		* 9:  quasi-employment                               employment to calculate daily earnings, otherwise not employed
		- 10: sick
		* 11: unemployment
		+ 12: retired
		+ 13: retired on disability
		- 14: parental leave
		+ 15: special pension (damaged/injured)
		+ 16: recovery/training benefit for sick/disabled
		- 17: on leave to care for family members
		+ 18: widower pension
		+ 19: receiving social assistance
		* 98: other
		* 99: unknown */

		run "${utilities}/definestatus.do"


		* U = UI/Notstandshilfe, E = dependant employment, O = everything else, N = observed N + unobserved
		* Note: before E was dependent employment (1), O everythying else except for other, unknown, and unemployment without UIB (2,3,4,5,6,7,8,10,12,13,14,15,16,17,18,19)
		* N was then other, unknown, unemployment without UIB and unobserved
			gen byte stat=.
			replace stat=1 if qual=="38" 				// UIB
			replace stat=2 if qual=="81" | qual=="C5"		//Notstandshilfe
			replace stat=3 if inlist(status,1,2,3,4,6,8,9) 		| (inlist(status,7,10,14) & ktkz=="K")		// employment (dependant, minor, self) and civil servants/military/civil service independent of whether the spell is associated with a firm (ktkz); maternity insurance, sickness, parental leave associated with a firm (ktkz==K)
			replace stat=4 if (stat !=1 & stat !=2 & stat !=3) // other insurance payments (special pension, widower pension, etc.); maternity insurance, sickness, parental leave associated without a firm (ktkz==F)
			label define statvals 1 "UI" 2 "UA" 3 "E" 4 "O"
			label values stat statvals




		* generate retirement date by person
		gen int temp = vdat if inlist(status,12) // Old age retirement
		bysort svnr (vdat bdat): gegen int retdat = min(temp)
		format retdat %td
		drop temp

		* generate retirement date by person
		gen int temp = vdat if inlist(status,13) // DI
		bysort svnr (vdat bdat): gegen int disdat = min(temp)
		format retdat disdat %td
		drop temp

		* Some asserts
		assert retdat <= vdat & !mi(retdat) if status == 12
		assert disdat <= vdat & !mi(disdat) if status == 13


		* drop unnecessary variables
		drop status ktkz
		rename stat status

		* drop intermediate spells (e.g. if one spell is from 2005m1-2006m1, we would drop a spell lasting from 2005m5-2005m6)
		* Note: we drop intermediate spells by person and status because dropping intermediate spells *overall* might be risky for non-employment spells where time in UI < total N duration because we would drop the UIB spell!!
		noi run "${utilities}/dropintspells.do" "svnr status" vdat bdat

		* connect spells with same status that start within e.g. 28 days
		noi run "${utilities}/connectspells.do" "svnr status" vdat bdat ${days}

		* now we need to consider overlapping spells with different status: we prioritize UI > UA > E > O and adjust the spells such that we have one status a day
		noi run "${utilities}/onestatusaday.do" svnr vdat bdat status "1 2 3 4"

		* generate number of qual file for these persons
		rename qual detailqual
		gen byte qual = ${q}

		* labelling
		label var svnr 		"person identifier (social security number)"
		label var birthdat	"birth date according to stammdaten (%td format)"
		label var deathdat	"death date according to stammdaten (%td format)"
		label var retdat	"retirement date according to first start date of DI, OA by person (%td)"
		label var vdat 		"start date of spell"
		label var bdat 		"end date of spell"
		label var status 	"labor market state (1=U, 2 = UA, 3=E, 4=O)"
		label var qual 		"number of ASSD qualification file"
		label var detailqual	"Original qual labor market status"
		label data "employment, unemployment, and other labor market spells, ${vyear}-${byear}"

		* do notes
		notes drop _dta

		if "${analysis}"=="lifecycle"{
			note: Days in employment, unemployment, and non-employment, ${vyear}-${byear}
			note: for workers aged ${vage}-${bage} at start or end date based on ASSD (2017) spell data.
			note: We divide unemployment into take-up of unemployment insurance benefits (UIB) and unemployment
			note: assistance (UA), and then define employment as dependant employment (including sickness and parental leave
			note: associated with the same firm, i.e. ktkz=K), other as other labor market states than
			note: employment and unemployment (i.e. other social insurance payments), and non-employment is the residual
			note: (i.e. observed non-employment states and unobserved). We connect spells by labor market state
			note: that start within ${days} days and prioritize spells according to UI>UA>E>O.
			note status: UI = qual=="38"
			note status: UA = qual=="81" | qual=="C5"
			note status: employment = dependant employment; maternity insurance, sickness, parental leave associated with a firm (ktkz==K)
			note status: other = other insurance payments (special pension, widower pension, etc.) but no OA, DI; maternity insurance, sickness, parental leave associated without a firm (ktkz==F)
			note status: non-employment = other, unknown, unobserved (residual)
		}

		timer off 1
		noi di r(t1)
		compress
		* save data
		save "${temp_qual}/09a_Data_Tau_year${vyear}-${byear}_age${vage}-${bage}_days${days}_qual`q'_UIvsUA.dta", replace

	}
}

clear
set obs 1
gen filler = 1
forval q = 1/40 {
	append using "${temp_qual}/09a_Data_Tau_year${vyear}-${byear}_age${vage}-${bage}_days${days}_qual`q'_UIvsUA.dta"
}
drop if filler == 1
drop filler

save "${temp}/09a_Data_Tau_year${vyear}-${byear}_age${vage}-${bage}_days${days}_qualappended_UIvsUA.dta", replace

forval q = 1/40 {
	erase "${temp_qual}/09a_Data_Tau_year${vyear}-${byear}_age${vage}-${bage}_days${days}_qual`q'_UIvsUA.dta"
}

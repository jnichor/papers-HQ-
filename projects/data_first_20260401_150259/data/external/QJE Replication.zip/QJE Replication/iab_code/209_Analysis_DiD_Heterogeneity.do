*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/209/$today"
local output $log/209/$today

log using "`output'/209_Analysis_Heterogeneity.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*		209 DiD Heterogeneity
*
********************************************************************************

foreach w in $winsor_values { // winsorization values

	use "$data\iab_wage_analysis_winsor`w'.dta"  if abs(d_rel) <= ${bw_standard} & (AG == 1 | GmbH == 1) , clear


	* merge CBA and works council agreements data
	merge m:1 nace_d3 using "$data/betriebspanel_industry_heterogeneity.dta", keep(1 3) nogen

	* merge BvD and AKM data
	merge m:1 nace_d3 using "${data}/bvd_akm_industry_heterogeneity.dta", keep(1 3) nogen



	* construct heterogeneity cuts
	foreach hetergroup in $hetgroups { // heterogeneity groups
		cap drop `hetergroup'_grp
		qui sum `hetergroup', d
		gen `hetergroup'_grp = (`hetergroup' >= r(p50) & `hetergroup' != .)

		* levels of each heterogeneity group
		levelsof `hetergroup'_grp, local(levels)
		qui sum `hetergroup'_grp
		local size = `r(max)'+1

	}

  replace AG_prereformcohort = AG & prereformcohort

	global treatment AG prereformcohort AG_prereformcohort cons

 	foreach i in 2 3 { // specifications

		noi di "Specification `i'"

		foreach outcome in $heterogeneity_outcomes  { // outcomes

			noi di "	Outcome: `outcome'"

			foreach hetergroup in $hetgroups { // heterogeneity groups

				* interact indicator for each level with treatment
				cap drop Het*
				foreach level in `levels' {
					foreach var in $treatment {
						gen double Het`level'`var' = (`hetergroup'_grp == `level') * `var'
					}
				}
				* regression variables
				local reg_vars Het*

				*------------------------------------------
				*-- DiD Regression with heterogeneity
				*------------------------------------------

				noi di "		Regressing..."

				reghdfe `outcome' `reg_vars', ///
					a(${controls`i'}) vce(cluster cluster_variable)


				foreach l in `levels' {

					* interacted coefficient and se
					global b_`hetergroup'_`l' = _b[Het`l'AG_prereformcohort]
					global s_`hetergroup'_`l' = _se[Het`l'AG_prereformcohort]

					* control mean: GmbH
					qui sum `outcome' if `hetergroup'_grp == `l' & d_rel >= 0 & AG == 0 & e(sample) == 1
					global cmag0_`hetergroup'_`l' = `r(mean)'

					* control mean: AG
					qui sum `outcome' if `hetergroup'_grp == `l' & d_rel >= 0 & AG == 1 & e(sample) == 1
					global cmag1_`hetergroup'_`l' = `r(mean)'

					* mean value of heterogeneity variable at each cut
					qui sum `hetergroup' if `hetergroup'_grp == `l' & e(sample) ==1
					global mh_`hetergroup'_`l' = `r(mean)'

				} // levels of heterogeneity group

				preserve
				noi di "		Storing Results..."

				clear
				set obs `size'
				gen outcome = "`outcome'"
				gen cut = _n-1
				gen hetergroup = "`hetergroup'_grp"

				foreach var in b s lb ub cmag0 cmag1 mh {
					gen `var' = .
				}
				foreach var in b s cmag0 cmag1 mh {
					foreach l in `levels' {
						replace `var' = ${`var'_`hetergroup'_`l'} if cut == `l'
					}
				}

				replace ub = b + 1.96 * s
				replace lb = b - 1.96 * s

				* save the results
				save "`output'/Heterogeneity_DiD_`outcome'_Winsor`w'_spec`i'_`hetergroup'.dta", replace
				restore

			} // heterogeneity groups
		} // outcomes
	} // specifications
} // winsorization

log close

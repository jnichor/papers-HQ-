*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================



cap log close

cap log using $log\105_Build_final.txt, text replace


********************************************************************************
*
*
*			105 Build IAB Analysis Sample
*
*
********************************************************************************



* Load data
********************************************************************************
use $data\idnr_jahr_collapsed_siab.dta, clear


* Merge additional BvD data
********************************************************************************


* Merge header information from BvD
*-------------------------------------------------------------------------------

tostring idnr, gen(_BVDID)

gen BVDID = "DE" + _BVDID
drop _BVDID

merge m:1 BVDID using $orig\header.dta, nogenerate keepusing(BVDID FEDERAL_STATE LEGALFRM NATPCOD NATSCOD1 NATSCOD2) keep(3) // header.dta has basic firm info




* Merge financial information from BvD
*-------------------------------------------------------------------------------
gen YEAR = jahr

merge 1:1 BVDID YEAR using $orig\Finanzenfertig.dta, nogenerate keepusing(FIAS TFAS IFAS CUAS TOAS EMPL PL OPPL OPRE TURN STAF AV EBTA) keep(1 3)

drop  YEAR
rename *, lower


* Define industry variable (5-digit NACE) and implement industries test, i.e. drop industries of Tendenzbetriebe, Public Utilities, Public Administration, etc.
gen nace_d5 = natpcod
replace nace_d5 = natscod1 if natpcod == .
replace nace_d5 = natscod2 if natpcod == . &  natscod2 == .
drop if nace_d5==.

* Create coarser NACE industry codes
forval i = 1/4 {
	gen nace_d`i' = floor(nace_d5/(10^(5-`i')))
	}

* Create financial Variables
* --------------------------

* clean
foreach var of varlist fias tfas ifas cuas toas opre turn staf av ebta  {
	replace `var' = . if `var' <= 0
	replace `var' = 100*`var'/62.9436768006212	if jahr == 1990
	replace `var' = 100*`var'/65.4910288078316	if jahr == 1991
	replace `var' = 100*`var'/68.8028970737547	if jahr == 1992
	replace `var' = 100*`var'/71.8815351801058	if jahr == 1993
	replace `var' = 100*`var'/73.8173455045538	if jahr == 1994
	replace `var' = 100*`var'/75.0767883662429	if jahr == 1995
	replace `var' = 100*`var'/76.1651957775791	if jahr == 1996
	replace `var' = 100*`var'/77.6423201215354	if jahr == 1997
	replace `var' = 100*`var'/78.349784938904	if jahr == 1998
	replace `var' = 100*`var'/78.8084709193957	if jahr == 1999
	replace `var' = 100*`var'/79.9435243626463	if jahr == 2000
	replace `var' = 100*`var'/81.5294894477363	if jahr == 2001
	replace `var' = 100*`var'/82.6878659069441	if jahr == 2002
	replace `var' = 100*`var'/83.5430431587083	if jahr == 2003
	replace `var' = 100*`var'/84.9346497774882	if jahr == 2004
	replace `var' = 100*`var'/86.248513009744	if jahr == 2005
	replace `var' = 100*`var'/87.6090222739143	if jahr == 2006
	replace `var' = 100*`var'/89.6225759848864	if jahr == 2007
	replace `var' = 100*`var'/91.9782005965641	if jahr == 2008
	replace `var' = 100*`var'/92.265851126703	if jahr == 2009
	replace `var' = 100*`var'/93.2842894901676	if jahr == 2010
	replace `var' = 100*`var'/95.2200998146156	if jahr == 2011
	replace `var' = 100*`var'/97.1325871231064	if jahr == 2012
	replace `var' = 100*`var'/98.5941627897579	if jahr == 2013
	replace `var' = 100*`var'/99.4882117347841	if jahr == 2014
	replace `var' = 100*`var'/100				if jahr == 2015
	replace `var' = 100*`var'/100.491748624771	if jahr == 2016
	replace `var' = 100*`var'/102.008668111352	if jahr == 2017
	replace `var' = 100*`var'/103.775629271545	if jahr == 2018
	replace `var' = 100*`var'/105.275879313219	if jahr == 2019
}

replace empl = . if empl <= 0 // not included above because not nominal variable



rename oppl ebit

* Labor Share


gen labor_share = staf/av
replace labor_share = 0 if labor_share < 0 & !mi(labor_share)
replace labor_share = 1 if labor_share > 1 & !mi(labor_share)
gen capital_share = 1 - labor_share

* Ratios
foreach var in opre toas {
	gen ebta_`var' = ebta/`var'
	gen pl_`var' = pl/`var'
	gen ebit_`var' = ebit/`var'
	gen av_`var'  = av/`var'
}
* per employee
foreach var in av fias opre tfas {
	gen `var'_per_empl = `var'/empl
}

* log
foreach outcome in av av_per_empl empl fias fias_per_empl opre tfas opre_per_empl tfas_per_empl av_opre az_ges_bhp az_ft_ges{
	gen log_`outcome' = log(`outcome')
}

* TFP
*-----------------
preserve
keep idnr jahr nace_d* staf av fias tfas
keep if jahr >= 2006 & jahr <= 2014
keep if nace_d2 != .
gen include = 0
replace include = 1 if staf > 0 & av > 0 & staf != . & av != . // include only firms for which we observe staf and av simultaneously
foreach var of varlist staf av {
	bysort jahr nace_d2 include: gegen sum_`var' = sum(`var')
	replace sum_`var' = . if include == 0
}
gen alpha_jt = sum_staf / sum_av

*dealing with extreme values : max value by sector

gen indicator_geq1 = 0 if include == 1

replace indicator_geq1 = 1 if alpha_jt >= 1

bysort nace_d2 indicator_geq1: gegen m_alpha_jt = max(alpha_jt)

bysort nace_d2: gegen max_alpha_jt = min(m_alpha_jt)

replace alpha_jt = max_alpha_jt if alpha_jt >= 1 & alpha_jt != .

replace alpha_jt = 0.9999 if alpha_jt >= 1 & alpha_jt != . // intended to deal with a single obs in nace 4d industry

*create alpha_j (time invariant industry alpha)
collapse (mean) alpha_j = alpha_jt, by(nace_d2) fast
tempfile alpha

save `alpha'
restore

merge m:1 nace_d2 using `alpha', nogen keep(1 3)
foreach var of varlist fias tfas {
	gen log_TFPr_`var' = log_av - (alpha_j)*log_empl - (1-alpha_j)*log_`var'
	label variable log_TFPr_`var' "TFPr using `var' and 2-digit NACE labor shares"
}
erase `alpha'


* BvD >500 indicator
* -----------------------------------------------------------------------------
gen empl500plus = (empl > 500 & empl  != .)
label variable empl500plus "1(Firm larger than 500 employees) BVD"



* Load and merge detailed dateinc variable from BvD
*-------------------------------------------------------------------------------

preserve

	use "$orig\bvd_gruendungsdatum_v1.dta", clear


	* Keep only one bvdid observation corresponding to earliest incorporation date
	*-------------------------------------------------------------------------------

	* Keep the earliest incorporation date in case of multiple entries per bvd-id
	drop if dateinc==.
	drop if ydate==1  // ydate is indicator for observations where the dateinc variable was corrected to 01.01.
	bysort bvdid (dateinc): keep if _n==1

	keep bvdid dateinc

	tempfile dateinc

	save `dateinc'

restore

merge m:1 bvdid using `dateinc', nogenerate keep(1 3) // merge information on incorporation date (rather than year)


* Merge information to drop IDs
*-------------------------------------------------------------------------------
merge m:1 bvdid using $orig\003_BvD_sample_for_IAB.dta , nogenerate keep(1 3) // merge information to drop IDs



* Clean exact incorporation date, pick earliest, gen running variable relative to reform (d_rel)
*-------------------------------------------------------------------------------
gen min_bvd_dateinc = min(dateinc,_e_dateinc)
replace min_bvd_dateinc = _d_dateinc if _d_dateinc!=.&abs(min_bvd_dateinc-_d_dateinc)<=365
drop _e_dateinc _d_dateinc dateinc
rename min_bvd_dateinc dateinc
format %td dateinc

gen d_rel = dateinc - mdy(08,10,1994) // The reform abolished codet. only for corporations incorporated *on* or after August 10, 1994
gen prereformcohort = (d_rel<0)&(d_rel!=.) // Old cohorts where codetermination was locked in in stock corporations


* Set sample restrictions
********************************************************************************

* Restrict to sample of firms incorporated with five years of reform
keep if dateinc>=mdy(08,10,1989)&dateinc<=mdy(08,10,1999)

* Restrict sample to West Germany
drop if federal_state >= 11 | federal_state == .

* Restrict years to year after incorporation to avoid weird comparisons
keep if jahr>year(dateinc)


* Drop BvD IDs (e keep firms with missing variable drop_from_BvD_sample, i.e. unmatched firms.)
drop if drop_from_BvD_sample==1
drop drop_from_BvD_sample


gen dropid_industry_test = inrange(nace_d5,35000,38999) // // Energieversorgung, Wasserversorgung, Abwasserentsorgung, Sammlung, Behandlung und Beseitigung von Abfällen; Rückgewinnung
replace dropid_industry_test = inrange(nace_d5,94000,94999) if dropid_industry_test == 0 // Interessenvertretungen sowie kirchliche und sonstige religiöse Vereinigungen (ohne Sozialwesen und Sport)
replace dropid_industry_test = inrange(nace_d5,97000,98999) if dropid_industry_test == 0 // Private Haushalte mit Hauspersonal, Herstellung von Waren und Erbringung von Dienstleistungen durch private Haushalte
replace dropid_industry_test = inrange(nace_d5,84000,84999) if dropid_industry_test == 0 // Öffentliche Verwaltung, Verteidigung; Sozialversicherung
replace dropid_industry_test = inrange(nace_d5,99000,99999) if dropid_industry_test == 0 // Exterritoriale Organisationen und Körperschaften
replace dropid_industry_test = inrange(nace_d5,49000,49299) if dropid_industry_test == 0 // Bahnen
replace dropid_industry_test = inrange(nace_d5,58130,58139) if dropid_industry_test == 0 // Publishing
replace dropid_industry_test = inrange(nace_d5,60000,60999) if dropid_industry_test == 0 // Broadcasters
replace dropid_industry_test = inrange(nace_d5,72000,72999) if dropid_industry_test == 0 // Education
replace dropid_industry_test = inrange(nace_d5,85000,85520) if dropid_industry_test == 0 // Education excluding driving and flying schools
replace dropid_industry_test = inrange(nace_d5,85591,85600) if dropid_industry_test == 0 // Education excluding driving and flying schools
replace dropid_industry_test = inrange(nace_d5,87000,88990) if dropid_industry_test == 0 // Charities

drop if dropid_industry_test==1
drop dropid_industry_test


* Assign earliest legal form and keep AGs and GmbHs
gen AG = legalfrm == 4
gen GmbH  = legalfrm == 3

replace AG = _earliest_AG if yr_of_AG<2007&_earliest_AG!=.
replace GmbH = (1-_earliest_AG) if yr_of_AG<2007&_earliest_AG!=.

keep if AG==1|GmbH==1

drop yr_of_AG _earliest_AG

* Keep only observations from firms with at least ten full-time employees
keep if az_ft_ges >= 10 & az_ft_ges!=.


* Take consolidated data if there are two observations in a firm-year
duplicates tag idnr jahr, gen(tag)
sum tag if AG==1
sum tag if GmbH==1
keep if tag == 0 | tag == 1
drop tag


* 3. Create additional variables
*===============================================================================

* Create dummy variable for entities with more than 500 workers (az_ges500plus)

gen az_ges_bhp500plus = (az_ges_bhp > 500 & az_ges_bhp != .)
label variable az_ges_bhp500plus "1(Firm larger than 500 employees)"

gen log_ten_ges = log(tenure)

* 4. Add worker and firm effect
*===============================================================================

merge 1:1 idnr jahr using "${data}/akm.dta"
drop if _merge == 2
drop _merge
replace pers_fe = . if jahr<year(dateinc)+${akm_radius_in_years}+1 // keep only AKM estimates for which observations post incorporation year were used
replace akm_firm_fe = . if jahr<year(dateinc)+${akm_radius_in_years}+1  // keep only AKM estimates for which observations post incorporation year were used




* 5. Create per-employee and log rank outcomes
*===============================================================================


* Create per-employee outcomes
*-------------------------------------------------------------------------------


foreach var in az_ft_ges az_ft_azubi  az_ft_f fscl  {
		gen `var'_per_empl = `var'/az_ft_ges
		label variable `var'_per_empl "`: var label `var'' per Employee"

		} // var

gen az_ft_zens_p_empl = az_ft_zens/az_ft_ges
label variable az_ft_zens_p_empl "az_ft_zens per Employee"
gen separation_p_empl = separation/az_ft_ges
label variable separation_p_empl "separation per Employee"

foreach var of varlist az_ft_gq az_ft_mq az_ft_hq {

	gen `var'_per_empl = `var'/(az_ft_gq + az_ft_mq + az_ft_hq)
	label variable `var'_per_empl "`: var label `var'' per Employee"

	}

	rename az_ft_gq_per_empl az_gq_per_empl

	rename az_ft_mq_per_empl az_mq_per_empl

	rename az_ft_hq_per_empl az_hq_per_empl



* 6. Save
*===============================================================================

label data "IAB Wage Analysis Dataset `c(current_date)'"
save "${data}/iab_wage_analysis.dta", replace


cap log close

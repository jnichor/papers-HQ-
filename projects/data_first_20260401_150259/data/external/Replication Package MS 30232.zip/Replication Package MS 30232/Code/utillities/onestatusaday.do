***
*** Bei Überlappungen werden gemäss Prioritätenreihenfolge untergeordnete Spells gelöscht oder in kleinere Stücke geschnitten. 
***

* Überlappende oder aneinandergereihte Spells desselben Status dürfen in den zu Grunde liegenden Files nicht mehr existieren, 
* sonst werden fehlerhafte Einträge produziert. 
* D.h. normspell pro Status mit gap mindestens = 1 ist Pflicht.


args id vdat bdat statvar statprior 

set more off


if "`1'" == "" | "`2'" == "" | "`3'" == "" | "`4'"=="" | "`5'"=="" {
noisily dis in red "missing parameters; nothing was done"
exit
}


local counter = 0
local allok = 1
foreach stat of local statprior {
local counter = `counter' + 1
qui count if `statvar' == `stat'
local allok = `allok'*r(N)!=0
}
if `allok' == 0 {
noisily dis in red "inexistant value(s) in statvar; nothing was done"
exit
}
bysort `statvar': g byte idcount = _n == 1
qui count if idcount
if r(N) != `counter' {
noisily dis in red "please indicate all states in statvar; nothing was done"
exit
}
drop idcount



local count = 0
preserve

foreach stat of local statprior {
restore, preserve
local count = `count'+1
keep if `statvar' == `stat'
g priorder = `count'
save stat`count'.tmp, replace
}

restore, not



local cm1 = `count'-1
forv file = 1(1)`cm1' {

local fp1 = `file'+1
forv corrf = `fp1'(1)`count' {

use stat`file'.tmp, clear
append using stat`corrf'.tmp

g byte authority = priorder == `file'
g byte nauthority = priorder != `file'



qui count if nauthority
local N0 = r(N)
qui count if authority
local NA = r(N)

noisily dis ""
noisily dis "priority `file', non-priority `corrf': priority spells at t=0 = `NA' (will not change anymore)"
noisily dis "priority `file', non-priority `corrf': non-priority spells at t=0 = `N0'"



*** step 1: exclusion of full overlaps of non-priority by priority spells

sort `id' `vdat' nauthority 

local N0 = _N

local N1 = 0
local N2 = 1
while `N1' != `N2' {
local N1 = _N
by `id': drop if inrange(`vdat',`vdat'[_n-1],`bdat'[_n-1]) & inrange(`bdat',`vdat'[_n-1],`bdat'[_n-1]) & nauthority & _n > 1
local N2 = _N
}

local NZ = `N0'-_N

noisily dis "priority `file', non-priority `corrf': non-priority spells dropped (non-priority spells enclosed by priority spells) = `NZ'"



*** step 2: adjustment of full overlaps of priority by non-priority spells

local N0 = _N

local N1 = 0
local N2 = 1
while `N1' != `N2' {
local N1 = _N

sort `id' `vdat' authority

g int vdat2 = `vdat'
g int bdat2 = `bdat'
by `id': g byte umschl = inrange(`vdat'[_n+1],`vdat',`bdat') & inrange(`bdat'[_n+1],`vdat',`bdat') & nauthority & _n < _N
replace vdat2 = `bdat'[_n+1]+1 if umschl == 1
replace bdat2 = `vdat'[_n+1]-1 if umschl == 1

expand 2 if umschl
replace `bdat' = bdat2 if _n <= `N1' & umschl == 1
replace `vdat' = vdat2 if _n > `N1' & umschl == 1
drop if `bdat' < `vdat'

drop umschl vdat2 bdat2

local N2 = _N
}


local NZ = -(`N0'-_N)

noisily dis "priority `file', non-priority `corrf': non-priority spells created (non-priority spells enclose priority spells) = `NZ'"



*** step 3: adjustment of overlaps

sort `id' `vdat' nauthority
by `id': replace `vdat' = `bdat'[_n-1]+1 if `vdat' <= `bdat'[_n-1] & nauthority & _n > 1
by `id': replace `bdat' = `vdat'[_n+1]-1 if `bdat' >= `vdat'[_n+1] & nauthority & _n < _N



keep if nauthority
drop *authority

local NN = _N
noisily dis "priority `file', non-priority `corrf': current non-priority spells = `NN'"

save stat`corrf'.tmp, replace

}
}

use stat1.tmp, clear
erase stat1.tmp
forv i = 2(1)`count' {
append using stat`i'.tmp
erase stat`i'.tmp
}
drop priorder

*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================


cap log close

log using "$log/101_Build_SIAB_prep.txt", replace text


********************************************************************************
*
*
*	 		101 Prepare Worker level data
*
*
********************************************************************************

foreach jahr of numlist $bhpminyear/$bhpmaxyear {

* 1. Load worker level data
*===============================================================================

	use persnr quelle frau gebjahr betnr begorig endorig erwstat grund tentgelt ///
		spell teilzeit beruf beruf2010_4 beruf2010_3 schule ausbildung nation niveau ///
		using $orig\SIAB_7514_v1_`jahr'.dta if quelle == 1, clear

	drop quelle

	gen jahr = `jahr'


* 2. Merge ao_bula from establishment level data
*===============================================================================

	merge m:1 betnr using "$orig/bhp_7514_m06_v1_`jahr'.dta", keepusing(ao_bula az_ges)
	drop _merge

	bys betnr: replace az_ges = . if _n!=1 // only keep one az_ges observation, otherwise will sum too many because it's individual-level information at the collapse at firm level (with sum)


* 3. Merge crosswalk (BvD_Schluessel_fertig) to restrict sample to workers only at BvD only firms
*===============================================================================


	merge m:1 betnr using $orig\BvD_Schluessel_fertig.dta, keepusing(BVDID) // BvD_Schluessel_fertig.dta has crosswalk between bvdid and betnr (unique match)
	keep if _merge == 3
	drop _merge

	rename *, lower

	gen idnr = substr(bvdid,3,10)
	destring idnr, force replace

	compress

	drop if idnr==.


* 4. Restrict the data
*===============================================================================

	drop if grund == 54 // one-time

	drop if tentgelt < 1

	duplicates drop persnr betnr begorig endorig, force

	*define age and trim on age;

	gen age= year(begorig) - gebjahr

	keep if age>=20 & age<=60

	*drop part-time jobs;
	drop if teilzeit == 1


* 5. Define a set of variables
*===============================================================================


	* all workes
	gen _ges = 1

	* define regular workers
	gen _reg = inlist(erwstat,101,140,143)

	* define trainees
	gen _azubi = inlist(erwstat,102,121,122,141,144)


	* define marignal workers
	gen _gf = inlist(erwstat,109,209)

	* define Altersteilzeit
	gen _atz = inlist(erwstat,103,142)


	* define niveau

	foreach i of numlist 1/4 {

		gen _niv`i' = niveau == `i'

		}

	* define education
	gen edgroup = 1 /* missing, ohne abgeschlossene Berufsausbildung*/
	replace edgroup = 2 if inlist(schule,1,4,6,8) & ausbildung == 2 /*mit Berufsausbildung*/
	replace edgroup = 3 if inlist(ausbildung,11,12) /*college (FH/Uni) values 5 and 6 are missing */

	gen _gq = inlist(schule,1,4,6,8) | ausbildung == 1

	gen _mq = inlist(schule,1,4,6,8) & ausbildung == 2

	gen _hq = inlist(ausbildung,11,12)

	replace _gq = 0 if _mq ==1 | _hq == 1

	replace _mq = 0 if _hq == 1

	gen _uq = 1 if _gq == 0 & _mq == 0 & _hq == 0

	* Create education-potential experience interactions for Mincer residualization and AKM estimation
	forvalues edu = 1/3 {
	forvalues p = 0/3 {
		gen edu_exp_`edu'_`p' = (edgroup==`edu')*age^(`p')
	}
}



* 6. Wages - code censororing - use ssmax from SIAB*/
*===============================================================================

	gen double _censor = 0
	replace _censor = 1 if tentgelt >=	47.06*0.98	&	jahr ==	1975	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	51.97*0.98	&	jahr ==	1976	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	57.15*0.98	&	jahr ==	1977	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	62.19*0.98	&	jahr ==	1978	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	67.24*0.98	&	jahr ==	1979	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	70.4*0.98	&	jahr ==	1980	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	73.96*0.98	&	jahr ==	1981	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	79*0.98		&	jahr ==	1982	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	84.05*0.98	&	jahr ==	1983	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	87.17*0.98	&	jahr ==	1984	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	90.77*0.98	&	jahr ==	1985	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	94.13*0.98	&	jahr ==	1986	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	95.82*0.98	&	jahr ==	1987	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	100.58*0.98	&	jahr ==	1988	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	102.54*0.98	&	jahr ==	1989	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	105.9*0.98	&	jahr ==	1990	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	109.26*0.98	&	jahr ==	1991	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	113.99*0.98	&	jahr ==	1992	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	121.03*0.98	&	jahr ==	1993	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	127.75*0.98	&	jahr ==	1994	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	131.12*0.98	&	jahr ==	1995	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	134.11*0.98	&	jahr ==	1996	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	137.84*0.98	&	jahr ==	1997	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	141.2*0.98	&	jahr ==	1998	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	142.88*0.98	&	jahr ==	1999	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	144.17*0.98	&	jahr ==	2000	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	146.24*0.98	&	jahr ==	2001	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	147.95*0.98	&	jahr ==	2002	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	167.67*0.98	&	jahr ==	2003	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	168.85*0.98	&	jahr ==	2004	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	170.96*0.98	&	jahr ==	2005	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	172.6*0.98	&	jahr ==	2006	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	172.6*0.98	&	jahr ==	2007	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	173.77*0.98	&	jahr ==	2008	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	177.53*0.98	&	jahr ==	2009	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	180.82*0.98	&	jahr ==	2010	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	180.82*0.98	&	jahr ==	2011	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	183.61*0.98	&	jahr ==	2012	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	190.68*0.98	&	jahr ==	2013	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	195.62*0.98	&	jahr ==	2014	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	198.9*0.98	&	jahr ==	2015	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	203.28*0.98	&	jahr ==	2016	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	208.77*0.98	&	jahr ==	2017	&	inrange(ao_bula,1,11)
	replace _censor = 1 if tentgelt >=	213.7*0.98	&	jahr ==	2018	&	inrange(ao_bula,1,11)

	replace _censor = 1 if tentgelt >=	45.39*0.98	&	jahr ==	1990	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	50.43*0.98	&	jahr ==	1991	&	endorig <= mdy(6,30,1991)		&	inrange(ao_bula,12,16)
	*replace _censor = 1 if tentgelt >=	57.15*0.98	&	jahr ==	1991	&	begorig >= mdy(7,17,1991)		&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	57.15*0.98	&	jahr ==	1991	&	begorig >= mdy(7,1,1991)		&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	80.47*0.98	&	jahr ==	1992	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	89.09*0.98	&	jahr ==	1993	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	99.18*0.98	&	jahr ==	1994	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	107.58*0.98	&	jahr ==	1995	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	113.99*0.98	&	jahr ==	1996	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	119.35*0.98	&	jahr ==	1997	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	117.67*0.98	&	jahr ==	1998	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	121.03*0.98	&	jahr ==	1999	&	inrange(ao_bula,12,16)

	replace _censor = 1 if tentgelt >=	119.02*0.98	&	jahr ==	2000	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	122.71*0.98	&	jahr ==	2001	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	123.29*0.98	&	jahr ==	2002	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	139.73*0.98	&	jahr ==	2003	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	142.62*0.98	&	jahr ==	2004	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	144.66*0.98	&	jahr ==	2005	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	144.66*0.98	&	jahr ==	2006	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	149.59*0.98	&	jahr ==	2007	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	147.54*0.98	&	jahr ==	2008	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	149.59*0.98	&	jahr ==	2009	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	152.88*0.98	&	jahr ==	2010	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	157.8*0.98	&	jahr ==	2011	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	157.38*0.98	&	jahr ==	2012	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	161.1*0.98	&	jahr ==	2013	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	164.38*0.98	&	jahr ==	2014	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	170.96*0.98	&	jahr ==	2015	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	177.05*0.98	&	jahr ==	2016	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	187.4*0.98	&	jahr ==	2017	&	inrange(ao_bula,12,16)
	replace _censor = 1 if tentgelt >=	190.68*0.98	&	jahr ==	2018	&	inrange(ao_bula,12,16)

	replace tentgelt = 	47.06*0.98	if  tentgelt>=	47.06*0.98	&	jahr ==	1975	&	inrange(ao_bula,1,11)
	replace tentgelt = 	51.97*0.98	if  tentgelt>=	51.97*0.98	&	jahr ==	1976	&	inrange(ao_bula,1,11)
	replace tentgelt = 	57.15*0.98	if  tentgelt>=	57.15*0.98	&	jahr ==	1977	&	inrange(ao_bula,1,11)
	replace tentgelt = 	62.19*0.98	if  tentgelt>=	62.19*0.98	&	jahr ==	1978	&	inrange(ao_bula,1,11)
	replace tentgelt = 	67.24*0.98	if  tentgelt>=	67.24*0.98	&	jahr ==	1979	&	inrange(ao_bula,1,11)
	replace tentgelt = 	70.4*0.98	if  tentgelt>=	70.4*0.98	&	jahr ==	1980	&	inrange(ao_bula,1,11)
	replace tentgelt = 	73.96*0.98	if  tentgelt>=	73.96*0.98	&	jahr ==	1981	&	inrange(ao_bula,1,11)
	replace tentgelt = 	79	*0.98	if  tentgelt>=	79*0.98		&	jahr ==	1982	&	inrange(ao_bula,1,11)
	replace tentgelt = 	84.05*0.98	if  tentgelt>=	84.05*0.98	&	jahr ==	1983	&	inrange(ao_bula,1,11)
	replace tentgelt = 	87.17*0.98	if  tentgelt>=	87.17*0.98	&	jahr ==	1984	&	inrange(ao_bula,1,11)
	replace tentgelt = 	90.77*0.98	if  tentgelt>=	90.77*0.98	&	jahr ==	1985	&	inrange(ao_bula,1,11)
	replace tentgelt = 	94.13*0.98	if  tentgelt>=	94.13*0.98	&	jahr ==	1986	&	inrange(ao_bula,1,11)
	replace tentgelt = 	95.82*0.98	if  tentgelt>=	95.82*0.98	&	jahr ==	1987	&	inrange(ao_bula,1,11)
	replace tentgelt = 	100.58*0.98	if  tentgelt>=	100.58*0.98	&	jahr ==	1988	&	inrange(ao_bula,1,11)
	replace tentgelt = 	102.54*0.98	if  tentgelt>=	102.54*0.98	&	jahr ==	1989	&	inrange(ao_bula,1,11)
	replace tentgelt = 	105.9*0.98	if  tentgelt>=	105.9*0.98	&	jahr ==	1990	&	inrange(ao_bula,1,11)
	replace tentgelt = 	109.26*0.98	if  tentgelt>=	109.26*0.98	&	jahr ==	1991	&	inrange(ao_bula,1,11)
	replace tentgelt = 	113.99*0.98	if  tentgelt>=	113.99*0.98	&	jahr ==	1992	&	inrange(ao_bula,1,11)
	replace tentgelt = 	121.03*0.98	if  tentgelt>=	121.03*0.98	&	jahr ==	1993	&	inrange(ao_bula,1,11)
	replace tentgelt = 	127.75*0.98	if  tentgelt>=	127.75*0.98	&	jahr ==	1994	&	inrange(ao_bula,1,11)
	replace tentgelt = 	131.12*0.98	if  tentgelt>=	131.12*0.98	&	jahr ==	1995	&	inrange(ao_bula,1,11)
	replace tentgelt = 	134.11*0.98	if  tentgelt>=	134.11*0.98	&	jahr ==	1996	&	inrange(ao_bula,1,11)
	replace tentgelt = 	137.84*0.98	if  tentgelt>=	137.84*0.98	&	jahr ==	1997	&	inrange(ao_bula,1,11)
	replace tentgelt = 	141.2*0.98	if  tentgelt>=	141.2*0.98	&	jahr ==	1998	&	inrange(ao_bula,1,11)
	replace tentgelt = 	142.88*0.98	if  tentgelt>=	142.88*0.98	&	jahr ==	1999	&	inrange(ao_bula,1,11)
	replace tentgelt = 	144.17*0.98	if  tentgelt>=	144.17*0.98	&	jahr ==	2000	&	inrange(ao_bula,1,11)
	replace tentgelt = 	146.24*0.98	if  tentgelt>=	146.24*0.98	&	jahr ==	2001	&	inrange(ao_bula,1,11)
	replace tentgelt = 	147.95*0.98	if  tentgelt>=	147.95*0.98	&	jahr ==	2002	&	inrange(ao_bula,1,11)
	replace tentgelt = 	167.67*0.98	if  tentgelt>=	167.67*0.98	&	jahr ==	2003	&	inrange(ao_bula,1,11)
	replace tentgelt = 	168.85*0.98	if  tentgelt>=	168.85*0.98	&	jahr ==	2004	&	inrange(ao_bula,1,11)
	replace tentgelt = 	170.96*0.98	if  tentgelt>=	170.96*0.98	&	jahr ==	2005	&	inrange(ao_bula,1,11)
	replace tentgelt = 	172.6*0.98	if  tentgelt>=	172.6*0.98	&	jahr ==	2006	&	inrange(ao_bula,1,11)
	replace tentgelt = 	172.6*0.98	if  tentgelt>=	172.6*0.98	&	jahr ==	2007	&	inrange(ao_bula,1,11)
	replace tentgelt = 	173.77*0.98	if  tentgelt>=	173.77*0.98	&	jahr ==	2008	&	inrange(ao_bula,1,11)
	replace tentgelt = 	177.53*0.98	if  tentgelt>=	177.53*0.98	&	jahr ==	2009	&	inrange(ao_bula,1,11)
	replace tentgelt = 	180.82*0.98	if  tentgelt>=	180.82*0.98	&	jahr ==	2010	&	inrange(ao_bula,1,11)
	replace tentgelt = 	180.82*0.98	if  tentgelt>=	180.82*0.98	&	jahr ==	2011	&	inrange(ao_bula,1,11)
	replace tentgelt = 	183.61*0.98	if  tentgelt>=	183.61*0.98	&	jahr ==	2012	&	inrange(ao_bula,1,11)
	replace tentgelt = 	190.68*0.98	if  tentgelt>=	190.68*0.98	&	jahr ==	2013	&	inrange(ao_bula,1,11)
	replace tentgelt = 	195.62*0.98	if  tentgelt>=	195.62*0.98	&	jahr ==	2014	&	inrange(ao_bula,1,11)
	replace tentgelt = 	198.9*0.98	if  tentgelt>=	198.9*0.98	&	jahr ==	2015	&	inrange(ao_bula,1,11)
	replace tentgelt = 	203.28*0.98	if  tentgelt>=	203.28*0.98	&	jahr ==	2016	&	inrange(ao_bula,1,11)
	replace tentgelt = 	208.77*0.98	if  tentgelt>=	208.77*0.98	&	jahr ==	2017	&	inrange(ao_bula,1,11)
	replace tentgelt = 	213.7*0.98	if  tentgelt>=	213.7*0.98	&	jahr ==	2018	&	inrange(ao_bula,1,11)

	replace tentgelt = 	45.39*0.98	if  tentgelt>=	45.39*0.98	&	jahr ==	1990	&	inrange(ao_bula,12,16)
	replace tentgelt = 	50.43*0.98	if  tentgelt>=	50.43*0.98	&	jahr ==	1991	&	endorig <= mdy(6,30,1991)
	replace tentgelt = 	57.15*0.98	if  tentgelt>=	57.15*0.98	&	jahr ==	1991	&	begorig >= mdy(7,17,1991)
	replace tentgelt = 	80.47*0.98	if  tentgelt>=	80.47*0.98	&	jahr ==	1992	&	inrange(ao_bula,12,16)
	replace tentgelt = 	89.09*0.98	if  tentgelt>=	89.09*0.98	&	jahr ==	1993	&	inrange(ao_bula,12,16)
	replace tentgelt = 	99.18*0.98	if  tentgelt>=	99.18*0.98	&	jahr ==	1994	&	inrange(ao_bula,12,16)
	replace tentgelt = 	107.58*0.98	if  tentgelt>=	107.58*0.98	&	jahr ==	1995	&	inrange(ao_bula,12,16)
	replace tentgelt = 	113.99*0.98	if  tentgelt>=	113.99*0.98	&	jahr ==	1996	&	inrange(ao_bula,12,16)
	replace tentgelt = 	119.35*0.98	if  tentgelt>=	119.35*0.98	&	jahr ==	1997	&	inrange(ao_bula,12,16)
	replace tentgelt = 	117.67*0.98	if  tentgelt>=	117.67*0.98	&	jahr ==	1998	&	inrange(ao_bula,12,16)
	replace tentgelt = 	121.03*0.98	if  tentgelt>=	121.03*0.98	&	jahr ==	1999	&	inrange(ao_bula,12,16)

	replace tentgelt = 	119.02*0.98	if  tentgelt>=	119.02*0.98	&	jahr ==	2000	&	inrange(ao_bula,12,16)
	replace tentgelt = 	122.71*0.98	if  tentgelt>=	122.71*0.98	&	jahr ==	2001	&	inrange(ao_bula,12,16)
	replace tentgelt = 	123.29*0.98	if  tentgelt>=	123.29*0.98	&	jahr ==	2002	&	inrange(ao_bula,12,16)
	replace tentgelt = 	139.73*0.98	if  tentgelt>=	139.73*0.98	&	jahr ==	2003	&	inrange(ao_bula,12,16)
	replace tentgelt = 	142.62*0.98	if  tentgelt>=	142.62*0.98	&	jahr ==	2004	&	inrange(ao_bula,12,16)
	replace tentgelt = 	144.66*0.98	if  tentgelt>=	144.66*0.98	&	jahr ==	2005	&	inrange(ao_bula,12,16)
	replace tentgelt = 	144.66*0.98	if  tentgelt>=	144.66*0.98	&	jahr ==	2006	&	inrange(ao_bula,12,16)
	replace tentgelt = 	149.59*0.98	if  tentgelt>=	149.59*0.98	&	jahr ==	2007	&	inrange(ao_bula,12,16)
	replace tentgelt = 	147.54*0.98	if  tentgelt>=	147.54*0.98	&	jahr ==	2008	&	inrange(ao_bula,12,16)
	replace tentgelt = 	149.59*0.98	if  tentgelt>=	149.59*0.98	&	jahr ==	2019	&	inrange(ao_bula,12,16)
	replace tentgelt = 	152.88*0.98	if  tentgelt>=	152.88*0.98	&	jahr ==	2010	&	inrange(ao_bula,12,16)
	replace tentgelt = 	157.8*0.98	if  tentgelt>=	157.8*0.98	&	jahr ==	2011	&	inrange(ao_bula,12,16)
	replace tentgelt = 	157.38*0.98	if  tentgelt>=	157.38*0.98	&	jahr ==	2012	&	inrange(ao_bula,12,16)
	replace tentgelt = 	161.1*0.98	if  tentgelt>=	161.1*0.98	&	jahr ==	2013	&	inrange(ao_bula,12,16)
	replace tentgelt = 	164.38*0.98	if  tentgelt>=	164.38*0.98	&	jahr ==	2014	&	inrange(ao_bula,12,16)
	replace tentgelt = 	170.96*0.98	if  tentgelt>=	170.96*0.98	&	jahr ==	2015	&	inrange(ao_bula,12,16)
	replace tentgelt = 	177.05*0.98	if  tentgelt>=	177.05*0.98	&	jahr ==	2016	&	inrange(ao_bula,12,16)
	replace tentgelt = 	187.4*0.98	if  tentgelt>=	187.4*0.98	&	jahr ==	2017	&	inrange(ao_bula,12,16)
	replace tentgelt = 	190.68*0.98	if  tentgelt>=	190.68*0.98	&	jahr ==	2018	&	inrange(ao_bula,12,16)


	* deflate daily wage to 2015 CPI
	* source: annual averages from https://fred.stlouisfed.org/series/DEUCPIALLMINMEI#0

	foreach var in tentgelt {
	replace `var' = 100*`var'/62.9436768006212	if jahr == 1990
	replace `var' = 100*`var'/65.4910288078316	if jahr == 1991
	replace `var' = 100*`var'/68.8028970737547	if jahr == 1992
	replace `var' = 100*`var'/71.8815351801058	if jahr == 1993
	replace `var' = 100*`var'/73.8173455045538	if jahr == 1994
	replace `var' = 100*`var'/75.0767883662429	if jahr == 1995
	replace `var' = 100*`var'/76.1651957775791	if jahr == 1996
	replace `var' = 100*`var'/77.6423201215354	if jahr == 1997
	replace `var' = 100*`var'/78.349784938904	if jahr == 1998
	replace `var' = 100*`var'/78.8084709193957	if jahr == 1999
	replace `var' = 100*`var'/79.9435243626463	if jahr == 2000
	replace `var' = 100*`var'/81.5294894477363	if jahr == 2001
	replace `var' = 100*`var'/82.6878659069441	if jahr == 2002
	replace `var' = 100*`var'/83.5430431587083	if jahr == 2003
	replace `var' = 100*`var'/84.9346497774882	if jahr == 2004
	replace `var' = 100*`var'/86.248513009744	if jahr == 2005
	replace `var' = 100*`var'/87.6090222739143	if jahr == 2006
	replace `var' = 100*`var'/89.6225759848864	if jahr == 2007
	replace `var' = 100*`var'/91.9782005965641	if jahr == 2008
	replace `var' = 100*`var'/92.265851126703	if jahr == 2009
	replace `var' = 100*`var'/93.2842894901676	if jahr == 2010
	replace `var' = 100*`var'/95.2200998146156	if jahr == 2011
	replace `var' = 100*`var'/97.1325871231064	if jahr == 2012
	replace `var' = 100*`var'/98.5941627897579	if jahr == 2013
	replace `var' = 100*`var'/99.4882117347841	if jahr == 2014
	replace `var' = 100*`var'/100				if jahr == 2015
	replace `var' = 100*`var'/100.491748624771	if jahr == 2016
	replace `var' = 100*`var'/102.008668111352	if jahr == 2017
	replace `var' = 100*`var'/103.775629271545	if jahr == 2018
	replace `var' = 100*`var'/105.275879313219	if jahr == 2019
}

	* define spell duration and earnings

	gen duration = endorig - begorig + 1

	rename tentgelt dailywage

	gen spellearn = duration * dailywage
	gen logdailywage = log(dailywage)
	winsor2 logdailywage, cut(1 99) replace


* Define FSCL occupations
*-------------------------------------------------------------------------------

	gen _food = (beruf==911) | (beruf==912) | (beruf==913) | (beruf==411) | (beruf==412)

	gen _cleaning = (beruf== 923) | (beruf== 933) | (beruf== 934) | (beruf== 936) | (beruf== 937)

	gen _security = (beruf== 791) | (beruf== 792) | (beruf== 793)

	gen _logistics = (beruf== 714) | (beruf== 741) | (beruf== 742) | (beruf== 743) | (beruf== 744)

	gen _fscl = (_food==1)|(_cleaning==1)|(_security==1)|(_logistics==1)

	drop _food _cleaning _security _logistics


* 8. Keep only highest paid spell if multiple spells per person
*===============================================================================

	* Now select highest earning wfy as wy observation

	bysort persnr: egen _maxtotearn = max(spellearn)
	keep if spellearn == _maxtotearn

	drop duration spellearn grund beruf2010_3 nation gebjahr

	bys persnr jahr: keep if _n == 1



* 9. Save
*===============================================================================

	save "$data/siab_bvdid_clean_`jahr'.dta", replace



* 10. Clean for AKM estimations
*===============================================================================

	* only keep regular employment
	*drop marginal jobs for comparability over time;
	keep if inlist(erwstat,101,140,143)

	* drop person-year obs if daily wage < 5th percentile
	sum dailywage, detail
	drop if dailywage<r(p5)


* 11. Save
*===============================================================================

	save "$data/siab_bvdid_clean_AKM_`jahr'.dta", replace

} //jahr

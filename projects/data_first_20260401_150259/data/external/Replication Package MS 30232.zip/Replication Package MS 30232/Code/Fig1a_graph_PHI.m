
close all

figure1 = figure;

  tau_100=1
  tau_20=0.2
  tau_10=0.104
  tau_5=0.05
  tau_3=0.03
  
  phi=0 :0.01:1

  dwdb_100= (1-phi)*1./(1+phi*(1./tau_100 -1))
  dwdb_20 = (1-phi)*1./(1+phi*(1./tau_20 -1))
  dwdb_10  = (1-phi)*1./(1+phi*(1./tau_10 -1))
  dwdb_5  = (1-phi)*1./(1+phi*(1./tau_5 -1))
  dwdb_3 = (1-phi)*1./(1+phi*(1./tau_3 -1))

p = plot(phi,dwdb_3,':',phi,dwdb_5,'-',phi,dwdb_10,'-',phi,dwdb_20,'-.',phi,dwdb_100,'--');
p(1).LineWidth = 4;
p(2).LineWidth = 2;
p(3).LineWidth = 4;
p(4).LineWidth = 4;
p(5).LineWidth = 4;
xlabel('Worker Bargaining Power \phi','fontsize',12)
ylabel('Wage-Benefit Sensitivity','fontsize',12)
% set(findall(gca, 'Type', 'Line'),'LineWidth',4);
legend('\tau = 3 %', '\tau = 5 %', '\tau = 10 %', '\tau = 20 %', '\tau = 100 %','Location','northeast');
xticks([0 .2 .4 .6 .8 1])
set(gca,'FontSize',12)

% Creating horizontal and vertical lines 
annotation(figure1,'line',[0.208 0.208],[0.13 .51]);
annotation(figure1,'line',[0.208 0.13], [.51 .51]);

set(figure1, 'PaperPosition', [0 0 5 4]); 
set(figure1, 'PaperSize', [5 4]); %Keep the same paper size

% Saving 
file_path = 'C:\Users\sammy\Dropbox\Documents\MIT\Work\SimonJaegerWork\Est_BargainingPower\SY_Revision\Code\TwoState_MatlabFigures';
saveas(figure1, fullfile(file_path, 'graph_PHI'),'pdf')




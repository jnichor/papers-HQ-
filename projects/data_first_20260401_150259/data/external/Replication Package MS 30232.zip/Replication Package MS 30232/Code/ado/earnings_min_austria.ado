* ado file creating earnings minima by year
* source: Zweimueller et al 2009, ASSD description
* The laws prescribe a monthly maximum, since Austrian wages are paid out in
* 1 rather than 12 installments, we need to scale up the monthly maximum
* by 1/12 to arrive at monthly maxima corresponding to monthly 
* earnings measures of yearly_earnings/12.
* Before 1965, wages were paid out in 13 installments, so the maxima are scaled
* by 13/12 for 1957 through 1964.
* Zweimueller et al (2009) only gives values in Euro (1 EUR = 13.7603 ATS). To convert 
* back to nominal ATS, we multiply by 13.7603. 

program earnings_min_austria
	syntax, new_monthly_earn_min(string) year_t(varname)
	
	// Social security earnings maximum
	cap drop `new_monthly_earn_min'
	gen `new_monthly_earn_min' = .
	replace `new_monthly_earn_min' =	1/12*13.7603*661	if `year_t'==	1972
	replace `new_monthly_earn_min' =	1/12*13.7603*661	if `year_t'==	1973
	replace `new_monthly_earn_min' =	1/12*13.7603*926	if `year_t'==	1974
	replace `new_monthly_earn_min' =	1/12*13.7603*1058	if `year_t'==	1975
	replace `new_monthly_earn_min' = 	1/12*13.7603*1058	if `year_t'==	1976
	replace `new_monthly_earn_min' = 	1/12*13.7603*1526	if `year_t'==	1977
	replace `new_monthly_earn_min' = 	1/12*13.7603*1632	if `year_t'==	1978
	replace `new_monthly_earn_min' = 	1/12*13.7603*1738	if `year_t'==	1979
	replace `new_monthly_earn_min' = 	1/12*13.7603*1835	if `year_t'==	1980
	replace `new_monthly_earn_min' = 	1/12*13.7603*1929	if `year_t'==	1981
	replace `new_monthly_earn_min' = 	1/12*13.7603*2030	if `year_t'==	1982
	replace `new_monthly_earn_min' = 	1/12*13.7603*2142	if `year_t'==	1983
	replace `new_monthly_earn_min' = 	1/12*13.7603*2227	if `year_t'==	1984
	replace `new_monthly_earn_min' = 	1/12*13.7603*2300	if `year_t'==	1985
	replace `new_monthly_earn_min' = 	1/12*13.7603*2395	if `year_t'==	1986
	replace `new_monthly_earn_min' = 	1/12*13.7603*2494	if `year_t'==	1987
	replace `new_monthly_earn_min' = 	1/12*13.7603*2571	if `year_t'==	1988
	replace `new_monthly_earn_min' = 	1/12*13.7603*2638	if `year_t'==	1989
	replace `new_monthly_earn_min' = 	1/12*13.7603*2704	if `year_t'==	1990
	replace `new_monthly_earn_min' = 	1/12*13.7603*2820	if `year_t'==	1991
	replace `new_monthly_earn_min' = 	1/12*13.7603*2975	if `year_t'==	1992
	replace `new_monthly_earn_min' = 	1/12*13.7603*3156	if `year_t'==	1993
	replace `new_monthly_earn_min' = 	1/12*13.7603*3345	if `year_t'==	1994
	replace `new_monthly_earn_min' = 	1/12*13.7603*3512	if `year_t'==	1995
	replace `new_monthly_earn_min' = 	1/12*13.7603*3663	if `year_t'==	1996
	replace `new_monthly_earn_min' = 	1/12*13.7603*3805	if `year_t'==	1997
	replace `new_monthly_earn_min' = 	1/12*13.7603*3897	if `year_t'==	1998
	replace `new_monthly_earn_min' = 	1/12*13.7603*3967	if `year_t'==	1999
	replace `new_monthly_earn_min' = 	1/12*13.7603*4046	if `year_t'==	2000
	replace `new_monthly_earn_min' = 	1/12*13.7603*4147	if `year_t'==	2001
	replace `new_monthly_earn_min' = 	1/12*13.7603*4222	if `year_t'==	2002
	replace `new_monthly_earn_min' = 	1/12*13.7603*4331	if `year_t'==	2003
	replace `new_monthly_earn_min' = 	1/12*13.7603*4427	if `year_t'==	2004
	replace `new_monthly_earn_min' = 	1/12*13.7603*4528	if `year_t'==	2005
	replace `new_monthly_earn_min' = 	1/12*13.7603*4664	if `year_t'==	2006
	replace `new_monthly_earn_min' = 	1/12*13.7603*4776	if `year_t'==	2007



	
end	

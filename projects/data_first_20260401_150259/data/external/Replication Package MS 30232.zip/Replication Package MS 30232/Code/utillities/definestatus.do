
/* This do-file creates a status variable based on quals (sstaubli/bmask/00_dofiles/Aufbereitung/status_*)

   Authors: Andreas Haller, Stefan Staubli, Andreas Steinhauer, Dominik Egloff, and previous versions' authors


   The main objective here is to learn about the labor market activity on a given day. We discard any spells
   that are there purely for insurance / pension purposes.

*/


/* This version creates the following stati:


Status:                                            Notes:

1:  dependent employment
2:  self-employment
3:  civil servants                                 as far as observed
4:  minor employment
5:  old-age part time                              need extra files to get this (Simon Buechi's Altersteilzeit)
6:  military and civil service
7:  maternity insurance
8:  minor self-employment
9:  quasi-employment                               employment to calculate daily earnings, otherwise not employed
10: sick
11: unemployment
12: retired
13: retired on disability 
14: parental leave
15: special pension (damaged/injured)
16: recovery/training benefit for sick/disabled
17: on leave to care for family members
18: widower pension
19: receiving social assistance



To define employment:

  always include status 1-4
  depending on objective also include status 5-9

*/



cap g byte status = .

/* Status 1: Dependent employment / Unselbständige Beschäftigung */ 

/* Alle (potentiellen) Vollzeitbeschäftigungen ohne Selbständige und Beamte */ 
/* Ohne geringfügig Beschäftigte, ausser wenn mit Vollversicherung */ 
/* Auch ohne Erntehelfer und ohne "nur in Arbeitslosenversicherung versicherungspflichtig" */ 

#d ;
replace status = 1 if 

qual == "10" |	/* PV-Pflichtversicherung nach dem ASVG - Arbeiter */
qual == "11" |	/* PV-Pflichtversicherung nach dem ASVG (knappschaftl. PV, Arb. mit wesentlich bergmännische Tätigkeit) */
qual == "12" |	/* PV-Pflichtversicherung nach dem ASVG (knappschaftl. PV, Arb. + Gewinnhauertätigkeit) */
qual == "14" |	/* PV-Pflichtversicherung nach dem ASVG - Angestellter */
qual == "15" |	/* PV-Pflichtversicherung nach dem ASVG - Angestellter mit wesentlicher bergmännischer Tätigkeit */
qual == "16" |	/* PV-Pflichtversicherung nach dem ASVG - Angestellter mit Gewinnhauertätigkeit */
qual == "1E" |	/* PV-Pflichtversicherung (Notariatskandidaten) - UB */
qual == "A5" |	/* Teilversicherung gem. § 471 f - h ASVG */
qual == "A6" |	/* Teilversicherung gem. § 471 f - h ASVG */
qual == "B1" |	/* Pflichtversicherung nach dem ASVG - Lehrlinge (Arb.) */
qual == "B2" |	/* Pflichtversicherung nach dem ASVG - Lehrlinge (Arb.) mit wesentlich bergmännischer Tätigkeit */
qual == "B3" |	/* Pflichtversicherung nach dem ASVG/NSchG - Lehrlinger (Arbeiter) */
qual == "B4" |	/* Pflichtversicherung nach dem ASVG - Lehrlinge (Ang.) */
qual == "B5" |	/* Pflichtversicherung nach dem ASVG/NSchG - Lehrlinger (Angestellte) */
qual == "B8" |	/* Vollversicherung aufgrund mehrfacher geringfügiger Beschäftigung - Arbeiter */
qual == "B9" |	/* Vollversicherung aufgrund mehrfacher geringfügiger Beschäftigung - Angestellter */
qual == "BD" |	/* Vollversicherung aufgrund mehrfacher geringfügiger Beschäftigung - Dienstleistungsscheck (DLS) */
qual == "BE" |	/* Pflichtversicherung in der PV aufgrund eines Dienstleistungsschecks (DLS) */
qual == "C1" |	/* PV-Pflichtversicherung nach dem ASVG - Hausgehilfen */
qual == "C4" |	/* PV-Pflichtversicherung nach dem ASVG - Hausangestellte */
qual == "C6" |	/* PV-Pflichtversicherung nach dem ASVG (Arbeiter und knappschaftliche PV) */
qual == "C7" |	/* PV-Pflichtversicherung nach dem ASVG (Angestellte und knappschaftliche PV) */
qual == "D1" |	/* PV-Pflichtversicherung nach dem ASVG - Hausbesorger */
qual == "E4" |	/* Pflichtversicherung nach dem ASVG - Entwicklungshelfer */
qual == "G1" |	/* PV-Pflichtversicherung nach dem ASVG/NSchG (Arb. und knappschaft. PV) */
qual == "G2" |	/* PV-Pflichtversicherung nach dem ASVG/NSchG (knappschaft. PV, Arb. mit wesentlich bergmännischer Tätigkeit) */
qual == "G3" |	/* PV-Pflichtversicherung nach dem ASVG/NSchG (knappschaft. PV, Arb. mit Gewinnhauertätigkeit) */
qual == "G4" |	/* PV-Pflichtversicherung nach dem ASVG/NSchG (Ang. und knappschaftl. PV) */
qual == "G5" |	/* PV-Pflichtversicherung nach dem ASVG/NSchG (knappschaft. PV, Ang. mit wesentlich bergmännischer Tätigkeit) */
qual == "G6" |	/* PV-Pflichtversicherung nach dem ASVG/NSchG (knappschaft. PV, Ang. mit Gewinnhauertätigkeit) */
qual == "G7" |	/* KrankenpflegeschülerInnen */
qual == "JY" |	/* Vertragsbedienstete Arbeiter bei ASVG Pensionsversichert (Kranken-Unfall bei BKUVG vormals als 10 gefuehrt) */
qual == "JZ" |	/* Vertragsbedienstete Angestellte bei ASVG Pensionsversichert (Kranken-Unfall bei BKUVG vormals als 14 gefuehrt) */
qual == "P1" |	/* Pflichtversicherung Werkvertrag gem. § 4 Abs. 5 ASVG - Arbeiter */
qual == "P2" |	/* Pflichtversicherung Werkvertrag gem. § 4 Abs. 5 ASVG - Angestellter */
qual == "P3" |	/* Pflichtversicherung Werkvertrag gem. § 4 Abs. 4 ASVG - Arbeiter */
qual == "P4" |	/* Pflichtversicherung Werkvertrag gem. § 4 Abs. 4 ASVG - Angestellter */
qual == "Y1" |	/* PV-Pflichtversicherung nach dem ASVG (Arbeiter in der knappschaftl. PV) */
qual == "Y4" |	/* PV-Pflichtversicherung als Angestellter (ASVG/NSchG) im knappschaftl. PV-Zweig */
qual == "Z1" |	/* PV-Pflichtversicherung nach dem ASVG -Lehrlinge (Arb. in der knappschaftl. PV) */
qual == "Z4" |	/* PV-Pflichtversicherung nach dem ASVG - Lehrlinge (Ang., knappschaftl. PV) */
qual == "ZC" |	/* PV-Pflichtversicherung nach dem ASVG/NSchG (Arb., knappschaftl. PV) */
qual == "ZD" |	/* PV-Pflichtversicherung nach dem ASVG/NSchG (Ang., knappschaftl. PV) */
qual == "ZJ" |	/* Pflichtversicherung Werkvertrag gem. § 4 Abs. 4 ASVG -Angestellter (knappschaftl. PV) */
qual == "BA" |  /* Pflichtversicherung nach dem ASVG/NSchG – Lehrlinge (Arbeiter) mit wesentlich bergmännischer Tätigkeit */ 
qual == "EM" |  /* Pflichtversicherung nach dem ASVG - Entwicklungshelfer (neue Rechtslage) */ 
qual == "GY" |  /* Pflichtversicherung als Arbeiter in der Pensionsversicherung nach dem ASVG/NSchG */ 
qual == "GZ" ;  /* Pflichtversicherung als Angestellter in der Pensionsversicherung nach dem ASVG/NSchG */ 

#d cr




/* Status 2: Self-employment / Selbständigkeit */ 

#d ;

replace status = 2 if 

qual == "17" |	/* Zeit einer Beitragsvorschreibung zur Pflichtversicherung nach dem GSVG / FSVG / BSVG */
qual == "18" |	/* Pflichtversicherung nach dem GSVG */
qual == "19" |	/* Pflichtversicherung nach dem BSVG (Betriebsführer) */
qual == "1D" |	/* PV-Pflichtversicherung nach BSVG (GesellschafterIn) */
qual == "1F" |	/* PV-Pflichtversicherung (Notariatskandidaten) - SB */
qual == "20" |	/* Pflichtversicherung nach dem BSVG (Angehöriger) */
qual == "64" |	/* PV-Pflichtversicherung nach dem BSVG-Betriebsführer (halber Versicherungswert) */
qual == "96" |	/* PV-Pflichtversicherung nach dem BSVG - Ehepartner */
qual == "97" |	/* PV-Pflichtversicherung nach dem BSVG - Ehepartner (halber Versicherungswert) */
qual == "99" |	/* PV-Pflichtversicherung nach den BSVG (Angehöriger bei Doppelbeschäftigung) */
qual == "A8" |	/* PV-Pflichtversicherung nach dem BSVG - (Schwieger-)Kind */
qual == "A9" |	/* PV-Pflichtversicherung nach dem BSVG - (Schwieger-)Kind bei Doppelbeschäftigung */
qual == "F1" |	/* Pflichtversicherung nach dem FSVG - freiberuflich selbständige Erwerbstätigkeit */
qual == "F2" |	/* Pflichtversicherung nach dem GSVG - mit gleichzeitiger Pflichtversicherung aufgrund freiberuflich sebständiger Erwerbstätigkeit (FSVG) */
qual == "F3" |	/* Pflichtversicherung gem. § 2 Abs.1 Z.4 GSVG */
qual == "F4" |	/* Pflichtversicherung gem. § 2 Abs.1 Z 4 GSVG mit gleichzeitiger Pflichtversicherung aufgrund freiberuflich selbständiger Erwerbstätigkeit (FSVG) */ 
qual == "M8" |	/* Hauptberuflich beschäftigte Eltern im Rahmen des BSVG */ 
qual == "FY" |  /* FSVG – freiwillige Versicherung als Ziviltechniker(in) bis 2012 */ 
qual == "FZ" |  /* FSVG – Pflichtversicherung als Ziviltechniker(in) bis 2012 */ 
/* regular self-employed */ 
qual == "FX" |  /* PV-Pflichtversicherung für Tierärzte und Wirtschaftstreuhänder nach dem GSVG/FSVG */
/* self-employed doctors  */ 
qual == "GI" ;  /* Ausübung einer freiberuflichen Erwerbstätigkeit (§2 Abs. 2 FSVG) ohne FSVG-Pflichtversicherung */ 

#d cr




/* Status 3: Civil servants as far as observed / Öffentlich Bedienstete soweit verfolgbar*/ 

#d ;

replace status = 3 if 

qual == "BB" |	/* Vollversicherung aufgrund mehrfacher geringfügiger Beschäftigung nach dem B-KUVG - Beamter/in bzw. Mandatar/in */
qual == "J1" |	/* Pflichtversicherung als öffentlich Bediensteter */
qual == "J8" |	/* Pflichtversicherte nach dem B-KUVG - § 4 Versicherte */
qual == "J9" |	/* Pflichtversicherung nach dem B-KUVG, §1/1/8 - 11 B-KUVG ('Politiker') */
qual == "JA" |	/* PV-Pflichtversicherung als Bundesbeamter/in */
qual == "JB" |	/* PV-Pflichtversicherung als Landeslehrer/in */
qual == "JC" |	/* PV-Pflichtversicherung als Beamter/in bei der Post AG */
qual == "JD" |	/* PV-Pflichtversicherung als Beamter/in bei der Telekom Austria AG */
qual == "JE" |	/* PV-Pflichtversicherung als Beamter/in bei der Postbus AG */
qual == "JF" |	/* PV-Pflichtversicherung aufgrund einer Beschäftigung beiim Bundestheaterverband */
qual == "JH" |	/* PV-Pflichtversicherung als Landesbeamter/in */
qual == "JN" |	/* PV-Pflichtversicherung als Beamter/in bei den ÖBB */
qual == "JQ" |	/* PV-Pflichtversicherung aufgrund einer Beschäftigung als Oberstes Organ */
qual == "JP" |	/* PV-Pflichtversicherung wegen Beschaeftigung bei einer EU-Koerperschaft */
qual == "JV" |	/* PV-Pflichtversicherung als Antragsbeamter(in) des Bundes gem. §136 b BDG */
qual == "JI" ;  /* PV-Pflichtversicherung als Gemeindebeamter/in */ 

#d cr




/* Status 4: Minor employment / Geringfuegige Beschaeftigung */ 

#d ;

replace status = 4 if 

qual == "60" |	/* Ausländische Beschäftigungszeit */
qual == "G8" |	/* Geringfügige Beschäftigung als Arbeiter(in) */
qual == "G9" |	/* Geringfügige Beschäftigung als Angesteller(r) */
qual == "GD" |	/* Geringfügige Beschäftigung - DLS */
qual == "GT" |	/* Geringfügige Beschäftigung nach dem B-KUVG als Beamter/in oder Mandatar/in */
qual == "J3" |  /* Vertragsbedienstete nach B-KUVG, Einkommen unter der Geringfügigkeitsgrenze gem. § 5/2 ASVG */
qual == "Q9" ;	/* Erntehelfer */

#d cr




/* Status 5: Old-age part time / Altersteilzeit */ 

/* note: this needs additional data to work (Simon Buechi Altersteilzeitdaten (ca. bis 2008))
replace status = 5 if substr(qual,1,2) == "at" 
*/ 




/* status 6: military and civil service / Militaer-/Zivildienst */ 

#d;

replace status = 6 if

qual == "33" | /* Präsenzdienstleistung im Datenergänzungsverfahren*/ 
qual == "3A" | /* Präsenzdienst- bzw. Ausbildungsdienst beim österr. Bundesheer*/ 
qual == "3B" | /* Zeitsoldat beim österreichischen Bundesheer*/ 
qual == "53" | /* Zivildienst*/ 
qual == "3C" ; /* teilpflichtversicherungszeit: Ausbildungsdienstleistende beim österreichischen Bundesheer (ab dem 13. Monat des Ausbildungsdienstes) aus pensionsversicherungsrechtlicher Sicht*/ 

#d cr



/* status 7: maternity insurance (wochengeld) */ 

#d;

replace status = 7 if

qual == "34" | /* Wochengeldbezug (auf Dienstgeberkontonummer bezogen) */ 
qual == "35" | /* Wochengeldbezug (Sonderfälle) */ 
qual == "JO" ; /* Wochengeld für weibliche ÖBB-Beamte */ 

#d cr




/* status 8: minor self-employment, some of them still have (low) contributions in the BG files */

#d;

replace status = 8 if

/* we checked the gsvg: minor self-employed / some have beitragsgrundlagen */
qual == "GE" | /* Ausübung einer selbständigen Erwerbstätigkeit (§2 Abs. 1 Z4 GSVG) ohne Pflichtversicherung in der GSVG-PV */
qual == "GF" | /* Ausübung einer selbständigen Erwerbstätigkeit (§2 Abs. 1 Z4 GSVG) ohne Pflichtversicherung in der GSVG-KV */
qual == "GG" | /* Ausübung einer selbständigen Erwerbstätigkeit (§2 Abs. 1 Z1 GSVG) ohne Pflichtversicherung in der GSVG-PV */
qual == "GH" | /* Ausübung einer selbständigen Erwerbstätigkeit (§2 Abs. 1 Z1 GSVG) ohne Pflichtversicherung in der GSVG-KV */
qual == "I9" | /* Krankenversicherung bei Erwerbstätigkeit nach dem BSVG */
/* we think freie dienstnehmer are self-employed */
qual == "GU" | /* Geringfügig beschäftigte(r) Arbeiter(in) mit kürzer als ein Monat vereinbarter Beschäftigung */
qual == "GV" | /* Geringfügig beschäftigte(r) Angestellte(r) mit kürzer als ein Monat vereinbarter Beschäftigung */
qual == "GW" | /* Geringfügig beschäftigte(r) Arbeiter(in) mit freiem Dienstvertrag und kürzer als ein Monat vereinbarter Beschäftigung */
qual == "GX" | /* Geringfügig beschäftigte(r) Angestellte(r) mit freiem Dienstvertrag und kürzer als ein Monat vereinbarter Beschäftigung */
qual == "P7" | /* Freie Dienstverträge gem. § 4 Abs. 4 ASVG - geringfügig beschäftigt - Arbeiter */
qual == "P8" ; /* Freie Dienstverträge gem. § 4 Abs. 4 ASVG - geringfügig beschäftigt - Angestellter */

#d cr




/* status 9: quasi-employment, i.e. employment to calculate daily earnings, otherwise not employed */

#d ;
replace status = 9 if

qual == "D3" | /* Pflichtversicherung aufgrund einer Kündigungsentschädigung */
qual == "D4" | /* Pflichtversicherung aufgrund einer Winterfeiertagsentschädigung */
qual == "D2" | /* Pflichtversicherung aufgrund einer Urlaubsabfindung oder -entschädigung */ 
qual == "56" ; /* Ersatzzeit aufgrund des Ruhens eines Arbeitslosengeldes wegen Urlaubsabfindung/-entschädigung */

#d cr





/* Status 10: Sick / Krankengeldbezug */

#d ;
replace status = 10 if 

qual == "36" |	/* Krankengeldbezug (auf Dienstgeberkontonummer bezogen) */
qual == "37" |	/* Krankengeldbezug (Sonderfälle) */
qual == "3V" |	/* Krankengeldbezug (auf Dienstgeberkontonummer bezogen) einer Antragsbeamtin des Bundes gem. § 136b */
qual == "3W" |	/* Krankengeldbezug (auf Dienstgeberkontonummer bezogen) von Antragsbeamten des Bundes gem. § 136b */
qual == "86" |	/* Neutrale Zeit infolge Krankheit */
qual == "3S" |  /* Sachleistungsanspruch in der KV bei Versagung des Krankengeldes (Sickness pay gets cut when there's a criminal conviction and that's indicated by this qual) */ 
qual == "3G" ;	/* Beitragsgrundlagen aufgrund einen Krankengeldbezuges */

#d cr




/* Status 11: Unemployment / Arbeitslosigkeit */

#d ;
replace status = 11 if 

qual == "38" |	/* Bezug von Arbeitslosengeld (Bezugszeiten) */
qual == "39" |	/* Vorgemerkte Arbeitssuche */
qual == "40" | 	/* Bezug eines Pensionsvorschusses */
qual == "48" | 	/* Bezug einer Sonderunterstützung */
qual == "81" |	/* Sondernotstandshilfe */
qual == "C5" ;	/* Bezug von Notstands- oder Überbrückungshilfe */

#d cr




/* Status 12: Retired / Pensioniert - Alterspension */ 

/* Alterspensionen aller Art, inkl. Ruhegelder für öffentlich Bedienstete, Sonderruhegeld (NSchG) und Sonderunterstützung (SUG) */ 

#d ;
replace status = 12 if 

qual == "05" |	/* Bezug eines Sonderruhegeldes nach dem NSchG */
qual == "09" |	/* Bezug einer Alterspension / Knappschaftsalterspension */
qual == "D5" |	/* Bezug von vorzeitiger Alterspension bei langer Versicherungsdauer */
qual == "D6" |	/* Bezug einer vorzeitiger Alterspension bei Arbeitslosigkeit */
qual == "D8" |	/* Bezug einer Teilpension */
qual == "D9" |	/* Bezug einer Gleitpension */
qual == "J5" |	/* Ruhegenuss aufgrund einer Beschäftigung als öffentlich Bediensteter */
qual == "N9" |	/* Bezug einer Gleitpension (300 Versicherungsmonate) */
qual == "Y5" | 	/* Bezug eines Sonderruhegeldes nach dem NSchG (knappschaftl. PV) */
qual == "Y6" |	/* Bezug einer vorzeitigen Alterspension bei Arbeitslosigkeit aus der knappschaftl. PV */
qual == "Y8" |	/* Bezug von vorzeitiger Alterspension bei langer Versicherungsdauer aus der knappschaftl. PV */
qual == "Y9" |	/* Bezug einer Knappschaftsalterspension */
qual == "Z3" ;	/* Bezug einer Gleitpension aus der knappschaftl. PV */

#d cr




/* Status 13: Retired on disability / Pensioniert - Invaliditätspension */ 

#d ;
replace status = 13 if 

qual == "07" |	/* Bezug einer Invaliditäts- / Berufsunfähigkeits- / Knappschaftsvollpension */
qual == "08" |	/* Bezug einer Erwerbsunfähigkeits- / Knappschaftspension */
qual == "7A" |	/* Bezug einer Berufsunfaehigkeitspension */
qual == "D7" |	/* Bezug einer vorzeitiger Alterspension wegen geminderter Erwerbsfähigkeit */
qual == "Y7" |	/* Bezug einer Knappschaftsvollpension */
qual == "ZM" |	/* Bezug einer vorzeitigen Alterspension wegen geminderter Erwerbsfähigkeit aus der knappschaftl. PV */
qual == "FE" ;  /* Bezug einer besonderen Pensionsleistung als Erwerbsunfähigkeitspension (FSVG) */ 

#d cr





/* status 14: parental leave (karenzurlaub/kinderbetreuungsgeld)*/ 

#d;
replace status = 14 if

qual == "41" | /* Karenz(urlaubs)geldbezug */ 
qual == "43" | /* Karenzurlaubsgeldbezug bei Annahme eines Kindes an Kindes statt */ 
qual == "J2" | /* Karenzurlaub mit Beitragszahlung */ 
qual == "I5" | /* Bezug von Kinderbetreuungsgeld */ 
qual == "IE" ; /* Bezug von einkommensabhängigem Kinderbetreuungsgeld (income-dependent parental leave benefits) */ 

#d cr




/* status 15: a special type of pension for the 'damaged/injured/disabled' */ 

/* Versehrtenrente is probably 50% between sick and disabled. could count it as either of them or create a new status
   some of these spells can be very long (10+ years) */ 
#d;
replace status = 15 if

qual == "42" | /* Bezug von Versehrtenrente aufgrund von mindestens 50 % Erwerbsfähigkeitseinbuße */ 
qual == "N1" | /* Bezug einer Versehrtenrente aufgrund von weniger als 50 % Erwerbsunfähigkeitseinbuße */ 
qual == "N2" ; /* Bezug einer Vollrente gem. § 205 Abs. 2 Z 1 ASVG bzw. § 103 Abs. 2 Z 1 B-KUVG */

#d cr




/* status 16: reha/umschulung, a special type of recovery/training benefit for the sick/disabled, see paper Haller, Staubli, Zweimueller */

#d;
replace status = 16 if

qual == "6R" | /* Bezug von Rehabilitationsgeld */
qual == "69" | /* Pflichtversicherung nach dem BSVG/GSVG (Rehabilitation) */
qual == "68" | /* Rehabilitationszeit */
qual == "6U" | /* Bezug von Umschulungsgeld (Introduced with IPNeu reform, "SRAEG 2012", see paper Haller, Staubli, Zweimueller). */
qual == "66" | /* Bezug eines Übergangsgeldes */
qual == "6A" | /* Bezug eines Übergangsgeldes in der PV-Pflichtversicherung der „Angestellten“ */
qual == "NU" | /* Weiterbildungsgeld nach dem ALVG 1977 vor dem 45. Lebensjahr */
qual == "NW" | /* Weiterbildungsgeld nach dem ALVG 1977 */
qual == "N4" | /* Weiterbildungsgeld nach dem ALVG 1977 ab dem 45. Lebensjahr */
qual == "DU" ; /* Überbrückungsgeldbezug gem. § 13l BUAG */

#d cr




/* status 17: "on leave" from work to care for family members; the job is protected */

#d;
replace status = 17 if

qual == "O8" | /* Familienhospizkarenz */
qual == "O9" | /* Familienhospizkarenz - nur PV-Schutz */
qual == "OA" | /* Familienhospizteilzeitkarenz gem. §§ 14a oder 14b AVRAG – nur PV-Schutz */
qual == "OB" | /* Familienhospizvollzeitkarenz bzw. Familienhospizteilzeitkarenz mit Entgelt gleich/unter der Geringfügigkeitsgrenze – nur KV-Schutz */
qual == "OC" | /* Familienhospizvollzeitkarenz bzw. Familienhospizteilzeitkarenz mit Entgelt gleich/unter der Geringfügigkeitsgrenze – nur PV-Schutz */
qual == "OJ" | /* Familienhospizkarenz - nur KV-Schutz */
qual == "OX" | /* Pflegeteilzeitkarenz gem. §14d AVRAG - nur PV-Schutz */
qual == "OY" | /* Pflegevollzeitkarenz gem. §14c AVRAG bzw. Pflegteilzeitkarenz mit Entgelt gleich/unter der Geringfügigkeitsgrenze – nur KV-Schutz */
qual == "OZ" ; /* Pflegevollzeitkarenz gem. §14c AVRAG bzw. Pflegteilzeitkarenz mit Entgelt gleich/unter der Geringfügigkeitsgrenze – nur PV-Schutz */

#d cr





/* status 18: widower's pension */

#d;
replace status = 18 if

qual == "63" | /* Bezug einer Witwen(Witwer)pension */
qual == "65" | /* Bezug von Waisenpension */
qual == "J6" | /* Versorgungsgenuss - Witwe/Witwer */
qual == "J7" | /* Versorgungsgenuss - Waise */
qual == "N3" ; /* Bezug einer Hinterbliebenenrente aus der gesetzlichen Unfallversicherung */

#d cr





/* status 19: receiving social assistance */

#d;
replace status = 19 if

qual == "SH" ; /* KV-Pflichtversicherung für Sozialhilfeempfänger */

#d cr






/* status 98: other/not status relevant, mostly relevant for insurance/pension purposes */

#d;
replace status = 98 if

qual == "06" | /* Bezug von Knappschaftssold */
qual == "80" | /* Dentistenausbildung (dentist apprentice; there should be an accompanying work spell) */
qual == "BK" | /* Bezug von Kombilohn (Bezugszeiten) */

/* The following could be relevant to calculate pension stuff; see Stefan Staubli's dofiles for details on that
   In this dofile the focus is on economically relevant labor market status */
qual == "25" | /* Freiwillige Weiterversicherung nach dem ASVG (Arb. und knappschaftliche PV) */
qual == "26" | /* Freiwillige Weiterversicherung nach dem ASVG (Ang. Und knappschaftliche PV) */
qual == "2D" | /* Überweisungsbetrag vom Dienstgeber für Versicherungszeiten im PV-Zweig der „Angestellten“; important from an insurance point of view, should have an accompanying employment spell */
qual == "2F" | /* Freiwillige Weiterversicherung nach dem ASVG (OMV-Mitarbeiter als Arbeiter(in)) */
qual == "2G" | /* Freiwillige Weiterversicherung nach dem ASVG (OMV-Mitarbeiter als Angestellter(in)) */
qual == "52" | /* Überweisungsbetrages vom Dienstgeber - Rückzahlung */
qual == "A7" | /* Überweisungsbetrag vom Dienstgeber gemäß §§ 564 und 314a ASVG */
qual == "27" | /* Freiwillige Weiterversicherung nach dem GSVG oder FSVG */
qual == "28" | /* Freiwillige Weiterversicherung nach dem BSVG (Betriebsführer) */
qual == "29" | /* Freiwillige Weiterversicherung nach dem BSVG (Angehöriger) */
qual == "F6" | /* Freiwillige Weiterversicherung nach dem BSVG - Angehöriger mit halber Mindestbeitragsgrundlage */
qual == "F7" | /* Freiwillige Weiterversicherung nach dem BSVG - Ehegatte (halbe Mindestbeitragsgrundlage) */
qual == "F8" | /* Freiwillige Weiterversicherung nach dem BSVG - Betriebsführer (halbe Mindestbeitragsgrundlage) */
qual == "F9" | /* Freiwillige Weiterversicherung nach dem BSVG - Ehegatte */
qual == "K6" | /* Freiwillige Weiterversicherung nach dem GSVG - Beitragszahlung der Dienstgeberanteile aus Mitteln des Bundes gemäß § 33 Abs. 9 GSVG */
qual == "K7" | /* Freiwillige Weiterversicherung nach dem BSVG - Beitragszahlung der Dienstgeberanteile aus Mitteln des Bundes gemäß § 28 Abs. 6 BSVG */
qual == "K8" | /* Weiterversicherung in der Krankenversicherung (§ 8 GSVG) */
qual == "K9" | /* Weiterversicherung in der Krankenversicherung (§ 8 BSVG) */
qual == "K4" | /* Freiwillige Weiterversicherung nach dem ASVG - Beitragszahlung der Dienstgeberanteile aus Mitteln des Bundes gemäß § 77 Abs. 6 ASVG (Arb. + knappschaftl. PV) */
qual == "K5" | /* Freiwillige Weiterversicherung nach dem ASVG - Beitragszahlung der Dienstgeberanteile aus Mitteln des Bundes gemäß § 77 Abs. 6 ASVG (Ang. + knappschaftl. PV) */
qual == "Z5" | /* Freiwillige Weiterversicherung nach dem ASVG (Arb., knappschaftl. PV) */
qual == "Z6" | /* Freiwillige Weiterversicherung nach dem ASVG (Ang. in knappschaftl. PV) */
qual == "ZE" | /* Freiwillige Weiterversicherung nach dem ASVG - Beitragszahlung der Dienstgeberanteile aus Mitteln des Bundes gem. § 77 Abs. 6 ASVG (Arb. in knappschaftl. PV) */
qual == "QC" | /* Freiwillige Weiterversicherung in der Krankenversicherung bei der KFA Wien */
qual == "E6" | /* Freiwillige Weiterversicherung für Zeiten der Kindererziehung -(pflege) (Arb. und knappschaftl. PV) */
qual == "E7" | /* Freiwillige Weiterversicherung für Zeiten der Kindererziehung -(pflege) (Ang. und knappschaftl. PV) */
qual == "CA" | /* Beitragsrückerstattung gemäß § 70 Abs. 4 ASVG in der PVPflichtversicherung der „Angestellten“ */
/* self-insurance if a person is not insured by the ASVG due to their employment (should also have an employment spell) */
qual == "E1" | /* Selbstversicherung gemäß § 18a ASVG */
qual == "E2" | /* Selbstversicherung gemäß § 16a ASVG */
qual == "EA" | /* Selbstversicherung gemäß § 18a ASVG in der knappschaftl. PV */
qual == "EB" | /* Selbstversicherung gemäß § 18b ASVG bei Anspruch des Angehörigen auf Pflegegeld nach § 5 BPG */
qual == "EC" | /* Selbstversicherung gemäß § 18b ASVG bei Anspruch des Angehörigen auf Pflegegeld nach § 5 BPG in der knappschaftlichen PV */
qual == "ED" | /* Selbstversicherung gemäß § 18a ASVG in der PV-Pflichtversicherung der „Angestellten“ */
qual == "EE" | /* Selbstversicherung gemäß § 16a ASVG in der PV-Pflichtversicherung der „Angestellten“ */
qual == "EG" | /* Selbstversicherung gemäß § 18b ASVG in der PV-Pflichtversicherung der „Angestellten“ bei Anspruch des Angehörigen auf Pflegegeld nach § 5 BPG */
qual == "K2" | /* Selbstversicherung bei geringfügiger Beschäftigung gemäß § 19a ASVG - Arbeiter */
qual == "K3" | /* Selbstversicherung bei geringfügiger Beschäftigung gemäß § 19a ASVG – Angestellte(r) */
qual == "KA" | /* Selbstversicherung bei geringfügiger Beschäftigung gem. § 7a Abs. 2 Z 1 B-KUVG - Arbeiter */
qual == "KB" | /* Selbstversicherung bei geringfügiger Beschäftigung gem. § 7a Abs. 2 Z 1 B-KUVG - Angestellter */
qual == "EH" | /* Selbstversicherung in der PV für Zeiten des Besuches einer mittleren Schule */
qual == "EI" | /* Selbstversicherung in der PV für Zeiten des Besuches einer höheren Schule */
qual == "EJ" | /* Selbstversicherung in der PV für Zeiten des Besuches einer Hochschule */
qual == "EK" | /* Selbstversicherung in der PV für Zeiten einer Ausbildung nach einem Hochschulstudium */
qual == "KC" | /* Selbstversicherung bei geringfügiger Beschäftigung gem. § 7a Abs. 2 Z 2 B-KUVG - Beamter/in bzw. Mandatar/in */
/* completely voluntary self-insurance, no parallel employment spell; cannot infer what they're doing */
qual == "I1" | /* Selbstversicherung § 16/1 ASVG */
qual == "I2" | /* Selbstversicherung § 16/2 ASVG */
qual == "I3" | /* Selbstversicherung § 16 ASVG – Wartezeit */
/* indicate self-employed who are paying separately for unemployment insurance, should also have employment spell */
qual == "2P" | /* Selbstversicherung in der ALV gem. § 3 AIVG für GSVG PVpflichtversicherte Personen (1/4 der GSVG HBG, beitragspflichtig) */
qual == "2R" | /* Selbstversicherung in der ALV gem. § 3 AIVG für GSVG PVpflichtversicherte Personen (1/2 der GSVG HBG, beitragspflichtig) */
qual == "2T" | /* Selbstversicherung in der ALV gem. § 3 AIVG für GSVG PVpflichtversicherte Personen (3/4 der GSVG HBG, beitragspflichtig) */
qual == "K1" | /* Selbstversicherung in der Krankenversicherung (§ 16 ASVG) */
/* indicate voluntary self-insurance while taking care of young children */
qual == "E8" | /* Selbstversicherung nach dem ASVG für Zeiten der Kindererziehung (-pflege) (Arb. und knappschaftl. PV) */
qual == "E9" | /* Selbstversicherung nach dem ASVG für Zeiten der Kindererziehung (-pflege) (Ang. und knappschaftl. PV) */
/* we think these are just security deposits with the unemployment office */
qual == "N6" | /* Sicherungsbeitrag gem. § 5d AMPFG - ASVG-Versicherungsträger (keine Beitragszahlung) */
qual == "Q6" | /* Sicherungsbeitrag gem. § 5d AMPFG - Beitragszahlung bei ASVGVersicherungsträger */
qual == "Q7" | /* Sicherungsbeitrag gem. § 5d AMPFG - Beitragszahlung bei GSVGVersicherungsträger */
qual == "Q8" | /* Sicherungsbeitrag gem. § 5d AMPFG - Beitragszahlung bei BSVGVersicherungsträger */
/* see Stefan Staubli's do-file; relevant to calculate pensions. There should be an accompanying employment spell */
qual == "SA" | /* Festgestellte Schwerarbeitszeit gem. §1 Abs. 1 Z1 der Schwerarbeits- VO (BGBI. Nr. 104/2006) */
qual == "SB" | /* Festgestellte Schwerarbeitszeit gem. §1 Abs. 1 Z2 der Schwerarbeits- VO (BGBI. Nr. 104/2006) */
qual == "SC" | /* Festgestellte Schwerarbeitszeit gem. §1 Abs. 1 Z3 der Schwerarbeits- VO (BGBI Nr. 104/2006 */
qual == "SD" | /* Festgestellte Schwerarbeitszeit gem. §1 Abs. 1 Z4 der Schwerarbeits- VO (BGBI Nr. 104/2006 */
qual == "SE" | /* Festgestellte Schwerarbeitszeit gem. §1 Abs. 1 Z5 der Schwerarbeits- VO (BGBI Nr. 104/2006 */
qual == "SF" | /* Festgestellte Schwerarbeitszeit gem. §1 Abs. 1 Z6 der Schwerarbeits- VO (BGBI Nr. 104/2006 */
qual == "BV" | /* BUAK-Beschäftigungszeiten im Sinne der Schwerarbeitsverordnung 201/203 */
qual == "V1" | /* Vorläufige Schwerarbeitszeit gem. §1 Abs. 1 Z1 der Schwerarbeitsverordnung (BGBI. Nr. 104/2006) */
qual == "V2" | /* Vorläufige Schwerarbeitszeit gem. §1 Abs. 1 Z2 der Schwerarbeitsverordnung (BGBI. Nr. 104/2006) */
qual == "V4" | /* Vorläufige Schwerarbeitszeit gem. §1 Abs. 1 Z4 der Schwerarbeitsverordnung (BGBI. Nr. 104/2006) */
qual == "V5" | /* Vorläufige Schwerarbeitszeit gem. §1 Abs. 1 Z5 der Schwerarbeitsverordnung (BGBI. Nr. 104/2006) */
qual == "V6" | /* Vorläufige Schwerarbeitszeit gem. §1 Abs. 1 Z6 der Schwerarbeitsverordnung (BGBI. Nr. 104/2006) */
qual == "VV" | /* Vorläufige Schwerarbeitszeit gem. § 1 Abs. 1 Z1 der Schwerarbeits- VO (BGBI. Nr. 104/2006) dienstgeberkontonummernpflichtig */
qual == "VW" | /* Vorläufige Schwerarbeitszeit gem. § 1 Abs. 1 Z2 der Schwerarbeits- VO (BGBI. Nr. 104/2006) dienstgeberkontonummernpflichtig */
qual == "VX" | /* Vorläufige Schwerarbeitszeit gem. § 1 Abs. 1 Z4 der Schwerarbeits- VO (BGBI. Nr. 104/2006) dienstgeberkontonummernpflichtig */
qual == "VY" | /* Vorläufige Schwerarbeitszeit gem. § 1 Abs. 1 Z5 der Schwerarbeits- VO (BGBI. Nr. 104/2006) dienstgeberkontonummernpflichtig */
qual == "VZ" | /* Vorläufige Schwerarbeitszeit gem. § 1 Abs. 1 Z6 der Schwerarbeits- VO (BGBI. Nr. 104/2006) dienstgeberkontonummernpflichtig */
qual == "VA" | /* Abgelehnte Schwerarbeitszeit gem. §1 Abs. 1 Z1 der Schwerarbeits- VO (BGBI. Nr. 104/2006) */
qual == "VB" | /* Abgelehnte Schwerarbeitszeit gem. §1 Abs. 1 Z2 der Schwerarbeits- VO (BGBI. Nr. 104/2006) */
qual == "VC" | /* Abgelehnte Schwerarbeitszeit gem. §1 Abs. 1 Z3 der Schwerarbeits- VO (BGBI. Nr. 104/2006) */
qual == "VD" | /* Abgelehnte Schwerarbeitszeit gem. §1 Abs. 1 Z4 der Schwerarbeits- VO (BGBI. Nr. 104/2006) */
qual == "VE" | /* Abgelehnte Schwerarbeitszeit gem. §1 Abs. 1 Z5 der Schwerarbeits- VO (BGBI. Nr. 104/2006) */
qual == "VF" | /* Abgelehnte Schwerarbeitszeit gem. §1 Abs. 1 Z6 der Schwerarbeits- VO (BGBI. Nr. 104/2006) */
/* special payments */
qual == "3J" | /* Beitragsgrundlagen aufgrund eines AMS-Geldleistungsbezuges; nur beitragsmeldung, duration ist immer 1 tag */
/* gemaess AMFG koennen sich arbeitende und arbeitslose fuer beihilfen bewerben; wir denken es sollte ein arbeitsspell, arbietslosigkeitsspell vorhanden sein */
qual == "A1" | /* PV-Pflichtversicherung -Bezug einer Beihilfe gemäß § 20 Abs. 2 lit.c AMFG - Arbeiter */
qual == "A2" | /* Pflichtversicherung nur in der Arbeitslosenversicherung */
qual == "A3" | /* Bezug einer Teilzeitbeihilfe */
qual == "A4" | /* PV-Pflichtversicherung - Bezug einer Beihilfe gemäß § 20 Ab. 2 lit.c AMFG - Angestellte */
/* GSVG=self-employed; have a separate pension spell; records health insurance eligibility */
qual == "4I" | /* KV-Pensionisten (GSVG) - Sachleistung */
qual == "4J" | /* KV-Pensionisten (GSVG) - Geldleistung */
/* and same for the non self-employed */
qual == "I4" | /* Krankenversicherung bei Pensionsbezug */
qual == "I8" | /* Krankenversicherung bei Pensionsbezug (auf Dienstnehmerkontonummer bezogen) */
qual == "AR" | /* Differenz-Krankenversicherungsbeitrag auf Grund einer Auslandspension und gleichzeitigem inländischen Pensionsbezug */
/* fsvg=self-employed; should overlap a regular pension spell */
qual == "FA" | /* Bezug einer besonderen Pensionsleistung als Alterspension (FSVG) */
qual == "FH" | /* Bezug einer besonderen Pensionsleistung als Witwen-/Witwerpension (FSVG) / could or couldn't be employed as well */
qual == "FK" | /* Bezug einer besonderen Pensionsleistung als Waisenpension (FSVG) */
/* self-employed; forgot to report pension contribution; duration always 1 day */
qual == "2A" | /* Verjährte Beitragsgrundlagenteile (GSVG) */
/* self-employed; should have parallel self-employment spell; indicates eligibility for health insurance */
qual == "4A" | /* KV-Pfl.Vers. § 2/1/1 - § 2/1/3 GSVG (Sachleistung) */
qual == "4B" | /* KV-Pfl.Vers. § 2/1/1 - § 2/1/3 GSVG (Geldleistung) */
qual == "4C" | /* KV-Pfl.Vers. § 2/1/4 GSVG (Sachleistung) */
qual == "4D" | /* KV-Pfl.Vers. § 2/1/4 GSVG (Geldleistung) */
qual == "4E" | /* KV-Pfl.Vers. §§ 14/A,14/B GSVG (Sachleistung) */
qual == "4F" | /* KV-Pfl.Vers. §§ 14/A,14/B GSVG (Geldleistung) */
qual == "4G" | /* KV-Weiterversicherung (GSVG) - Sachleistung */
qual == "4H" | /* KV-Weiterversicherung (GSVG) - Geldleistung */
qual == "4K" | /* KV-Pflichtversicherung (GSVG) - Sachleistung */
qual == "4L" | /* KV-Pflichtversicherung (GSVG) - Geldleistung */
qual == "4M" | /* KV-Pfl.Vers. § 2/1/4 GSVG ohne Leist.anspr. (Sachleistung) */
qual == "4N" | /* KV-Pfl.Vers. § 2/1/4 GSVG ohne Leist.anspr. (Geldleistung) */
qual == "4P" | /* KV-Pfl.Vers. §§14/A,14/B GSVG ohne Leist.anspr. (Sachleistung) */
qual == "4R" | /* KV-Pfl.Vers. §§14/A,14/B GSVG ohne Leist.anspr. (Geldleistung) */
qual == "4S" | /* KV-Pflichtversicherung (GSVG) – Sachleistung aufgrund einer vorläufigen Krankenversicherung */
qual == "4T" | /* KV-Pflichtversicherung (GSVG) – Geldleistung aufgrund einer vorläufigen Krankenversicherung */
qual == "IA" | /* KV-Pflichtversicherung - Sachleistung wegen KBG (GSVG) */
qual == "IB" | /* KV-Pflichtversicherung - Geldleistung wegen KBG (GSVG) */
qual == "IG" | /* KV-Pflichtversicherung nach dem BSVG auf Grund einer Gesellschaftertätigkeit */
/* indicate insurance in health insurance fund; dependent employed */
qual == "O3" | /* KV-Pflichtversicherung nach dem ASVG, Auslandsbetreute mit ständigem Wohnsitz in Österreich („De-facto-Versicherte“) */
qual == "O4" | /* KV-Pflichtversicherung nach dem ASVG, Asylwerber bzw. Flüchtlinge */
qual == "O5" | /* KV-Pflichtversicherung nach dem ASVG, Zugeteilte nach dem OFG */
qual == "O6" | /* KV-Pflichtversicherung nach dem ASVG, Kriegshinterbliebene */
qual == "O7" | /* Ruhen des KV-Anspruches für Hauptversicherten */
/* indicates health insurance coverage for 'special' civil servants; should also have employment spell */
qual == "J4" | /* Pflichtversicherung in der KV als Antragsbeamter(in) des Bundes gemäß § 136b BDG */
qual == "F5" | /* Nachträglicher Einkauf von Versicherungszeiten aufgrund freiberuflich selbständiger Erwerbstätigkeit (FSVG) */
/* indicates outstanding contributions for self-employed farmers */
qual == "L1" | /* Beiträge (noch) nicht bezahlt (BSVG) zu Pflichtversicherungszeiten QUAL 64 */
qual == "L2" | /* Beiträge (noch) nicht bezahlt (BSVG) zu Pflichtversicherungszeiten QUAL 96 */
qual == "L3" | /* Beiträge (noch) nicht bezahlt (BSVG) zu Pflichtversicherungszeiten QUAL 97 */
qual == "L4" | /* Beiträge (noch) nicht bezahlt (BSVG) zu Pflichtversicherungszeiten QUAL 20 */
qual == "L5" | /* Beiträge (noch) nicht bezahlt (BSVG) zu Pflichtversicherungszeiten QUAL 99 */
qual == "L6" | /* Beiträge (noch) nicht bezahlt (BSVG) zu Pflichtversicherungszeiten QUAL A8 */
qual == "L8" | /* Verjährung / Schuldenerlass im Rahmen des GSVG / FSVG */
qual == "M1" | /* Unwirksame Beitragszahlung (BSVG) zu Pflichtversicherungszeiten QUAL 65 */
qual == "M2" | /* Unwirksame Beitragszahlung (BSVG) zu Pflichtversicherungszeiten QUAL 96 */
qual == "M3" | /* Unwirksame Beitragszahlung (BSVG) zu Pflichtversicherungszeiten QUAL 97 */
qual == "M4" | /* Unwirksame Beitragszahlung (BSVG) zu Pflichtversicherungszeiten QUAL 20 */
/* various quals related to payments from/to social insurance */
qual == "C2" | /* Beitragserstattung Anrechnungsbetrag */
qual == "C3" | /* Rückerstattung von Krankenversicherungsbeiträgen */
qual == "C8" | /* Rückerstattung von Pensionsversicherungsbeiträgen */
qual == "C9" | /* Nicht vorgeschriebene Beiträge */
qual == "CS" | /* Beitragsgrundlage für eine übertragene Teilgutschrift (Überträger) */
qual == "CU" | /* Beitragsgrundlage für eine übertragene Teilgutschrift (Übernehmer) */
qual == "CX" | /* Rückerstattung von Arbeitslosenversicherungsbeiträgen */
qual == "4Z" | /* Verjährung / Schuldenerlass ( FSVG) */
qual == "50" | /* Nachträglicher Einkauf von Versicherungszeiten */
qual == "57" | /* Besondere Pensionsbeiträge */
qual == "61" | /* Begünstigung gem. § 506b ASVG */
qual == "62" | /* Überweisungsbetrag gem. § 308 Abs. 4 ASVG */
/* should also have employment spell */
qual == "N7" | /* Sicherungsbeitrag gem. § 5d AMPFG - GSVG-Versicherungsträger (keine Beitragszahlung) */
qual == "N8" | /* Sicherungsbeitrag gem. § 5d AMPFG - BSVG-Versicherungsträger (keine Beitragszahlung) */
qual == "O1" | /* Beitragspflichtige Mitversicherung in der Krankenversicherung */
qual == "O2" | /* Beitragspflichtige Mitversicherung in der Krankenversicherung (GSVG/BSVG) */
/* payments / eligibility spells related to maternity insurance/parental leave */
qual == "3E" | /* Beitragsgrundlagen aufgrund eines Wochengeldbezuges */
/* indicate health insurance coverage or other things; should have reqular maternity insurance / parental leave spell */
qual == "4U" | /* KV-Leistungsanspruch während GSVG-Wochengeldbezug (Sachleistung) */
qual == "4V" | /* KV-Leistungsanspruch während GSVG-Wochengeldbezug (Geldleistung) */
qual == "5W" | /* Teilpflichtversicherung in der GSVG-PV während eines GSVG-Wochengeldbezuges */
qual == "87" | /* Neutrale Zeit für Kindererziehung(-pflege) */
qual == "E3" | /* Versicherungszeit wegen Kindererziehung */
qual == "E5" | /* Nachträglicher Einkauf von Versicherungszeiten infolge von Kindererziehung (-pflege) nach dem ASVG */
qual == "EX" | /* Vorläufige Versicherungszeit wegen Kindererziehung */
qual == "I7" | /* Anspruch auf Kinderbetreuungsgeld */
qual == "51" | /* Ausschluss vom Anspruch auf Karenzurlaubs- bzw. Karenzgeld, weil dieses der Kindesvater bezieht bzw. Karenzgeldbezug bei Teilzeitbeschäftigung */
qual == "Q1" | /* Teilversicherung in der Krankenversicherung gem. § 43 Abs.1 bzw. Abs. 2 KGG */
/* live birth (women only) */
qual == "49" | /* Anzeige einer Lebendgeburt */
/* these are special years for young people / asylum seekers; kinda like an apprenticeship */
/* could count them as employed depending on the situation */
qual == "FI" | /* Freiwilliges Integrationsjahr */
qual == "FJ" | /* Freiwilliges Integrationsjahr bei bereits vorliegender Krankenversicherung */
qual == "FW" | /* Freiwilliges Sozialjahr */

qual == "H1" | /* Mittlere Schule - Beitragszahlung (Beamte) */
qual == "H2" | /* Höhere Schule - Beitragszahlung (Beamte) */
qual == "H3" | /* Hochschule - Beitragszahlung (Beamte) */
qual == "HB" | /* Höhere Schule - Beitragszahlung (Beamte) */
qual == "30" | /* Mittlere Schule */
qual == "31" | /* Höhere Schule */
qual == "32" | /* Hochschule */
qual == "JL" | /* Nachgekaufte angerechnete Zeiten im Beamtenbereich (7 spells in total) */
qual == "JM" | /* Geprüfte Beamtennullzeit */
qual == "3T" | /* Beitragsgrundlagen aufgrund von Teilentgelttagen; could be important for wage */
/* pay for full coverage */
qual == "BX" | /* Pauschalbetrag bei Vollversicherung und geringfügiger Beschäftigung - Arbeiter */
qual == "BY" | /* Pauschalbetrag bei Vollversicherung und geringfügiger Beschäftigung - Angestellter */






qual == "01" | /* Bestätigte Nullzeit */

qual == "83" | /* Versicherungszeit aufgrund Gewährung einer strafrechtlichen Entschädigung */

qual == "85" | /* Strittige Versicherungszeit */
qual == "AP" | /* Krankenversicherungsbeitrag auf Grund einer Auslandspension und gleichzeitiger inländischer Beschäftigung */
qual == "AQ" | /* Krankenversicherungsbeitrag auf Grund einer Auslandspension und gleichzeitigem inländischen Pensionsbezug */
qual == "H4" | /* Ausbildungszeit nach einem Hochschulstudium – Beitragszahlung */
qual == "M9" | /* Beitragserstattung gem. § 70 Abs.5 ASVG */
qual == "79" | /* Beschäftigung vor Versicherungspflicht */
/* should also have unemployment spell */
qual == "1C" | /* Zeiten, in denen mangels Notlage kein Anspruch auf Notstandshilfe besteht (§ 34/1 AIVG) – PV-pflichtig */
qual == "1G" | /* Zeiten, in denen mangels Notlage kein Anspruch auf Notstandshilfe besteht (§ 34/1 AIVG) – KV- und PV-pflichtig (für Personen die vor dem 1.1.1955 geboren sind) */

qual == "21" | /* Überweisungsbetrag an den Dienstgeber */
qual == "22" | /* Überweisungsbetrag vom Dienstgeber für Versicherungszeiten im PV-Zweig der „Arbeiter“ */

qual == "23" | /* Beitragszeit aufgrund Gewährung von strafrechtlicher Entschädigung */
qual == "3D" | /* Beitragszeit aufgrund Gewährung von strafrechtlicher Entschädigung im PV-Zweig der „Angestellten“ */

qual == "24" | /* Unwirksame Beitragszeit */
qual == "2B" | /* Stichtagsunwirksame Beitragszeit */

qual == "45" | /* Untersuchungshaft mit Verfahrenseinstellung oder Freispruch */
qual == "46" | /* Straferlass kraft neuer Gesetzeslage */

qual == "70" | /* Ausbildungszeit nach einem Hochschulstudium */

qual == "78" | /* Beschäftigung als Ordensangehöriger (a few spells in 1971/1972) */
qual == "PC" | /* Überweisungsbetrag für Ordensangehörige gemäß § 314 in der PVPflichtversicherung der „Arbeiter“ */
qual == "PD" | /* Überweisungsbetrag für Ordensangehörige gemäß § 314 in der PVPflichtversicherung der „Angestellten“ */

qual == "BT" | /* Bezug von Bildungsteilzeitgeld */

qual == "L9" | /* Nicht vorgeschriebene Krankenversicherungsbeitragsgrundlage */

qual == "OK" | /* Kein KV-Anspruch mit österreichischer EKVK */
qual == "P5" | /* Anrechnungsbetrag gem. § 13 Bundesbezügegesetz */
qual == "P6" | /* Überweisungsbetrag gem. § 49h Abs. 3 des Bezügegesetzes */
qual == "P9" | /* Beiträge nicht bezahlt */

qual == "PA" | /* Anrechnungsbetrag gemäß § 13 Bundesbezügegesetz in der PVPflichtversicherung der „Angestellten“ */

qual == "Q4" | /* Kein Leistungsanspruch in der Krankenversicherung */
qual == "Q5" | /* Selbstversicherung in der Krankenversicherung gem. §16 ASVG “Wartezeit“ - Übergangslösung */
qual == "QA" | /* Vormerkung zur Kranken- und Pensionsversicherung nach dem ASVG */
qual == "Q2" | /* Pflichtversicherung in der Krankenversicherung nach dem ASVG (auf DG-Kontonummer bezogen) */
qual == "Q3" | /* Pflichtversicherung in der Krankenversicherung nach dem ASVG */
qual == "QE" | /* Pflichtversicherung in der Krankenversicherung bei der KFA Wien */

qual == "ZK" | /* Anrechnungsbetrag gemäß § 13 Bundesbezügegesetz (knappschaftl. PV) */

qual == "13" ; /* Ersatzzeit für die Zeit, in der mangels Notlage kein Anspruch auf Notstandshilfe besteht (§ 34/1 AIVG) - KV- und PV-pflichtig */ 

#d cr




/* status 99: unknown; we have no idea */

#d;
replace status = 99 if

qual == "44"  | /* Unentgeltliche Berufsausbildung eines Beschädigten nach dem KOVG(=kriegsopferversorgungsgesetz) */
qual == "47"  | /* Beschädigtenrente nach dem KOVG */
qual == "54"  | /* Ausgedinge (BSVG); something about farmers renting our their farms */
qual == "XYX" | /* vx */
qual == "XOO" | /* yv */
qual == "55"  | /* Beschäftigung bei internationaler Vereinigung und andere neutrale Zeiten */
qual == "JK"  | /* Anerkannte Teilpflichtversicherungszeiten im Beamtenbereich (3 spells in total) */
qual == "BF"  | /* Vollversicherung aufgrund der besonderen Formalversicherung nach § 471g ASVG - Arbeiter */
qual == "BG"  | /* Vollversicherung aufgrund der besonderen Formalversicherung nach § 471g ASVG - Angestellter */
qual == "02"  | /* Ersatzzeit - Ohne Verschulden des Versicherten zu Unrecht bezogene Leistung aus der Arbeitslosenversicherung */
qual == "OR"  | /* Ruhen von Krankengeld wegen Bezug eines Übergangsgeldes */
qual == "QB"  | /* Pflichtversicherung in der Kranken-, Unfall- und Arbeitslosenversicherung */
qual == "QD"  ; /* Schutzfristanspruch bei AMS-Sperre gem. § 10 AIVG */

#d cr



cap label drop status

label define status 1  "1. dependent employment"
label define status 2  "2. self-employment", add
label define status 3  "3. civil servants", add
label define status 4  "4. minor employment", add
label define status 5  "5. old-age part time", add
label define status 6  "6. military and civil service", add
label define status 7  "7. maternity insurance", add
label define status 8  "8. minor self-employment", add
label define status 9  "9. quasi-employment", add
label define status 10 "10. sick", add
label define status 11 "11. unemployment", add
label define status 12 "12. retired", add
label define status 13 "13. retired on disability", add
label define status 14 "14. parental leave", add
label define status 15 "15. special pension (damaged/injured)", add
label define status 16 "16. recovery/training benefit for sick/disabled", add
label define status 17 "17. on leave to care for family members", add
label define status 18 "18. widower pension", add
label define status 19 "19. receiving social assistance", add

label define status 98 "98. other", add
label define status 99 "99. unknown", add

cap label values status status






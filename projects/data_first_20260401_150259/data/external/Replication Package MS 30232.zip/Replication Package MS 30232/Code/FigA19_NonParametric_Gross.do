/*******************************************************************************

	DESCRIPTION: Figure A.19 nonparametric gross



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
clear all
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA19_NonParametric_Gross`curr_date'", replace

local counter = 0
local color1 sea
local color2 sky

local xrange_2001 10000 28000
local xrange_1989 5000 15000
local xrange_1985 10000 25000
local xrange_1976 2000 4500

local xtick_2001 10000(2500)28000
local xtick_1989 5000(5000)15000
local xtick_1985 10000(5000)25000
local xtick_1976 2000(500)4500

********************************************************************************
***** Nonparametric figures for each reform
********************************************************************************
foreach reform in $reforms {
	local counter = `counter' + 1
	local letter = word("a b c d", `counter')

	use  ${temp}/03a_Nonparametric_DTAFiles/03a_NonParametric_Sample_Reform`reform'_gross.dta if in_sample_`reform'  == 1 , replace

	if `reform' == 1985 {
		su earn_pct_bin if treatment_`reform' > 0 & !mi(treatment_`reform')
		local relPct = r(min)
	}
	else if `reform' == 1976 {
		local relPct = 7
	}
	else if `reform' == 2001 {
		local relPct = 29
	}
	else {
		su earn_pct_bin if treatment_`reform' > 0  & !mi(treatment_`reform')
		local relPct = r(max)
	}
	su adj_earnings if earn_pct_bin == `relPct'
	local zeroEarn = r(mean)

	**** Creating sequence of figures that progressivly adds lines
	tw (connected diff_w_pbo1 adj_earnings, lcolor(sea) mcolor(sea) msymbol(S) msize(medium)) ///
			(connected diff_w_pbo2 adj_earnings, lcolor(sky) mcolor(sky) msymbol(Oh) msize(medium)) ///
			(line RRdiff_f1_RRiBY_BRiBY adj_earnings, lcolor(green%90) lwidth(thick) lpattern(solid) ) ///
			(line PredWgGrth1 adj_earnings, lcolor(dkorange) lpattern(dash) lwidth(medthick) ///
			ytitle("Change (Pct Pts)", size(medium)) ///
			xtitle("Nom. Earnings in Base Year", size(medium)) ///
			yline(0,lpattern(dash) lcolor(gray)) ///
			xline(`zeroEarn', lpattern(dash) lcolor(black)) ///
			xsc(r(`xrange_`reform'')) ///
			xlab(`xtick_`reform'', labsize(medium)) ylab(, labsize(medium)) ///
			legend(label(1 "One-Year Effects (dw/w)") ///
			label(2 "Two-Year Effects (dw/w)") ///
			label(3 "Benefit Change (db/w)" ) ///
			label(4 "Predicted Wage Effects" ) ///
			order(3 4 1 2) on pos(6) col(2)) ///
			note("`note1'" "`note2'") )
	graph export "${figures}/FigA19`letter'_NonParametric_Gross.pdf", replace
}

log close

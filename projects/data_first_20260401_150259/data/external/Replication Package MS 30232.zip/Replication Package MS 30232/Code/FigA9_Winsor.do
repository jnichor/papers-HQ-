/*******************************************************************************

	DESCRIPTION: Figure A.9 Robustness Check: Outcome Variable Winsorization



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA9_Winsor`curr_date'", replace

********************************************************************************

local outcome earn_Diff_f1
local ytitle = "One-Year Earnings Change"
local with "With76"
local controlname ctrls
local suffix earn_pct

local x = 1
foreach wins in 0 1 5 {
	use "${resDat}/DiD_1_earn_pct_`outcome'_w`wins'_Winsor`with'_stable_`wins'_Spec`controlname'.dta", clear
	gen wins = "`wins'"
	gen spec = `x'
	local x = `x' + 1
	tempfile f`wins'
	save `f`wins''
}

clear
set obs 1
gen filler = 1
foreach wins in 0 1 5 {
	append using "`f`wins''"
}

qui su spec
local max = r(max) + 1
qui su year
local yearmin = r(min)
gen n = (year - `yearmin' + 1) + (spec/`max')

local colors "gray sea gray"
local shapes "C S T"
local statement
local legend
local order
local xlabels
local lab1 "No Winsorization"
local lab2 "Winsor at 1st Pct"
local lab3 "Winsor at 5th Pct"
forval x = 1/3 {

	local color = word("`colors'",`x')
	local shape = word("`shapes'",`x')

	if `x' < 3 {
	local statement `statement' (rcap ctrls_LB ctrls_UB n if spec == `x', lcolor(`color')) ///
	(scatter ctrls_coeff n if spec == `x', mcolor(`color') msymbol(`shape') msize(medlarge))
	}

	if `x' == 3 {
	local statement `statement' (rcap ctrls_LB ctrls_UB n if spec == `x', lcolor(`color')) ///
	(scatter ctrls_coeff n if spec == `x', mcolor(`color') msymbol(`shape') msize(medlarge)
	}

	local y = 2*`x'
	local legend `legend' label(`y' "`lab`x''")
	local order `order' `y'

	local x = `x' + 1


}

levelsof year, local(years)
foreach year in `years' {
	local midpoint = (`year' - `yearmin' + 1) + 0.5
	local xlabels `xlabels' `midpoint' "`year'"
}

qui su n
local maxn = r(max)

tw `statement' legend(`legend' order(`order') r(1)) xtick(1(1)`maxn') xlab(`xlabels', notick) ///
yline(0, lpattern(shortdash) lcolor(gray%80)) ytitle("Wage-Benefit Sensitivity", size(medium)) xtitle("Year Rel. to Treatment", size(medium)) ///
legend(col(2) pos(6) size(medium)) )

graph export "${figures}/FigA9_Winsor.pdf", replace

log close

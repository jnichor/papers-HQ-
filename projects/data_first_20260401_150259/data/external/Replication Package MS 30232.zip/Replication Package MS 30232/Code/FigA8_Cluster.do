/*******************************************************************************

	DESCRIPTION: Figure A.8 Robustness Check: Different Levels of Clustering



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA8_Cluster`curr_date'", replace

********************************************************************************

local outcome earn_Diff_f1
local samplename With76_stable
local controlname ctrls
local suffix earn_pct

clear
set obs 1
gen clusternumber = .
foreach clusternumber in 1 2 3 4 5 6 7 {
	append using "${resDat}/DiD_1_`suffix'_`outcome'_clustergroup`clusternumber'`samplename'_Spec`controlname'.dta", gen(ind)
	replace clusternumber = `clusternumber' if ind == 1
	drop ind
}

drop if clusternumber == .
duplicates drop
qui su clusternumber
local max = r(max)
qui su year
local yearmin = r(min)
gen n = (year - `yearmin' + 1) + (clusternumber/`max')

local colors "sea gray gray gray gray gray gray"
local shapes "S O T D Sh Oh Th"
local statement
local legend
local order
local xlabels
forval x = 1/`max' {

	if `x' == 1 {
	local lab "Eighths of a Percentile"
	}
	if `x' == 2 {
	local lab "Percentile"
	}
	if `x' == 3 {
	local lab "Individual-Percentile"
	}
	if `x' == 4 {
	local lab "Firm-Percentile"
	}
	if `x' == 5 {
	local lab "Reform-Percentile"
	}
	if `x' == 6 {
	local lab "Reform-Percentile-Firm"
	}
	if `x' == 7 {
	local lab "Reform-Percentile-Individual"
	}

	local color = word("`colors'",`x')
	local shape = word("`shapes'",`x')
	if `x' < `max' {
	local statement `statement' (rcap ctrls_LB ctrls_UB n if clusternumber == `x', lcolor(`color')) ///
	(scatter ctrls_coeff n if clusternumber == `x', mcolor(`color') msymbol(`shape') msize(medlarge))

	}

	if `x' == `max' {
	local statement `statement' (rcap ctrls_LB ctrls_UB n if clusternumber == `x', lcolor(`color')) ///
	(scatter ctrls_coeff n if clusternumber == `x', mcolor(`color') msymbol(`shape') msize(medlarge)

	}

	local y = 2*`x'
	local legend `legend' label(`y' "`lab'")

	local order `order' `y'

}

levelsof year, local(years)
foreach year in `years' {
	local midpoint = (`year' - `yearmin' + 1) + 0.5
	local xlabels `xlabels' `midpoint' "`year'"
}

qui su n
local maxn = r(max)

tw `statement' legend(`legend' order(`order') )  ///
 xtick(1.5(1)`maxn') xlab(`xlabels') yline(0, lpattern(shortdash) lcolor(gray%80)) ///
 ytitle("Wage-Benefit Sensitivity", size(medium)) xtitle("Year", size(medium)) legend(col(2) pos(6) size(medium)) )

graph display, xsize(14) ysize(8)
graph export "${figures}/FigA8_Cluster.pdf", replace

log close

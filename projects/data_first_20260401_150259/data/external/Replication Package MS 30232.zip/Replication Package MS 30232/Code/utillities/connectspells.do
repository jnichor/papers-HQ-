args byvar begin end gap

if "`1'" == "" | "`2'" == "" | "`3'" == "" | "`4'"=="" {
	noi di in red "missing parameters"
	exit
}

set more off

sort `byvar' `begin' `end'

count
local number = r(N)

qui by `byvar': gen byte todrop = (_n > 1) & (`begin' >= `begin'[_n-1] & `begin' <= `end'[_n-1] +`gap' & `end' > `end'[_n-1])

drop if todrop == 1 & todrop[_n+1] == 1

count if (_n < _N) & (todrop[_n+1] == 1)
local adjusted = r(N)

qui by `byvar': replace `end' = `end'[_n+1] if (_n < _N) & (todrop[_n+1] == 1)

drop if todrop == 1

count
local onumber 	= `number'
local number 	= r(N)
local deleted 	= `deleted' + `onumber' - `number'

* make sure `end' is missing again
replace `end' = . if `end'==mdy(1,1,3000)

drop todrop

noisily display "number of records:" `number'
noisily display "deleted          :" `deleted'
noisily display "adjusted         :" `adjusted'

/*******************************************************************************

	DESCRIPTION: Non-parametric analysis of each reform

*******************************************************************************/



********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/03a_Analysis_NonParametric`curr_date'", replace

local placeboruns 0 1 2
local suffix earn_pct
local types " stable  gross "




****************************************************************************
* Run on different placebo ranges and on differnt types
****************************************************************************
***** Different specifications
	* placeboruns -- which "placebo specs" to run -- ex. lagging the treatment and control years
	* types -- treatment specifications (ex. stable earnings + the gross earnings specification)
	* reform -- reforms to loop over
foreach placeborun in `placeboruns' {
foreach type in `types' {
foreach reform in $reforms {




	****************************************************************************
	* Setting up data for analysis
	****************************************************************************
	if `placeborun' == 0 {
		local range inrange(year, `reform'-3, `reform' - 1 )
		local yrsFwd 1 2
		local pboind
	}
	if `placeborun' == 1  {
		local range inrange(year, `reform'-4, `reform' - 2)
		local yrsFwd 1
		local pboind _pbo`placeborun'
	}
	if `placeborun' == 2 {
		local range inrange(year, `reform'-5, `reform' - 3)
		local yrsFwd 2
		local pboind _pbo`placeborun'
	}

	if `reform' == 1976 & `placeborun' == 2 {
		di "There cannot be a two-year placebo for 1976."
	}

	else {


	***** Loading data + shortening the sample
	use ${temp}/02b_Reform`reform'.dta if `range' , clear

	foreach i in `yrsFwd' {
		replace earn_Diff_f`i' = (earn_Diff_f`i'/100) + 1
		bys year: gegen avg_earn_Diff_f`i' = mean(earn_Diff_f`i')
	}

	if $shorten76and89 == 1 {
		*Shorten 1976 and 1989 by 1 pct
		if inlist(`reform', 1976, 1989) {
			su earn_pct if treatment_`reform' == 1
			local min = r(min)
			su earn_pct if control_`reform' == 1
			local max = r(max)
			local new_min = `min' + 1
			local new_max = `max' - 1
			drop if  earn_pct <= `new_min' & !mi(earn_pct)
			drop if earn_pct >= `new_max' & !mi(earn_pct)
		}
	}


	***** Type restriction ->
	if "`type'" == "stable" | "`type'" == "gross" {
		keep if mth_emp == 12
	}


	***** Year Summary Statistics
	bys year: gen N = _N
	qui su year
	local maxyr = `r(max)'





	****************************************************************************
	* Collapsing plot variables in the placebo and treated years + generate wage growth diffs
	****************************************************************************
	tempfile temp
	save `temp'


	***** Collapsing the following variables in the "control/placebo" years and the treated year
		* RRdiff_f1_RRiBY_BRiBY -- One-year RR instrument
		* RRdiff_f`i'_RRRY_BRRY --
			* Actual future replacement rate  RR(RY)
			* MINUS
			* Current schedule but with realized future income. BR(RY)
		* wage_grwth`i' -- earnings growth measure
		* avg_wage_grwth`i' -- average wage growth in the entire sample
		* netoftaxrate -- net-of-tax rate

	***** "control/placebo" years
	foreach i in `yrsFwd' {
		use "`temp'" if year == `maxyr' - `i', clear
		fcollapse RRdiff_f1_RRiBY_BRiBY RRdiff_f`i'_RRRY_BRRY wage_grwth`i' avg_wage_grwth`i' earn_Diff_f`i' avg_earn_Diff_f`i' netoftaxrate, by(earn_pct_bin)
		if "`type'" == "gross" {
			replace RRdiff_f1_RRiBY_BRiBY  = RRdiff_f1_RRiBY_BRiBY / netoftaxrate
		}
		rename * pbo_*
		rename pbo_earn_pct_bin earn_pct_bin
		rename pbo_RRdiff_f1_RRiBY_BRiBY pbo`i'_RRdiff_f1_RRiBY_BRiBY
		tempfile placebo`i'
		save `placebo`i'', replace
	}


	***** Treated year
	use "`temp'" , clear
	erase `temp'

	keep if year == `maxyr'

	ds adj_earnings wage_* infl* netoftaxrate RRdiff_f*_RRRY_BRRY RRdiff_f*_RRiBY_BRiBY treatment_`reform' control_`reform' in_sample_`reform' avg_wage_grwth* earn_Diff_f* avg_earn_Diff_f* N

	fcollapse `r(varlist)', by(earn_pct_bin)

	if "`type'" == "gross" {
		replace RRdiff_f1_RRiBY_BRiBY  = RRdiff_f1_RRiBY_BRiBY / netoftaxrate
	}


	***** Merging together concurrent and placebo measures
		* diff_w_pbo -- percentile diff minus overall mean difference
		* Note the overall mean difference shouldn't matter because we later normalize one percentile to zero
	foreach i in `yrsFwd' {
		merge 1:1 earn_pct_bin using "`placebo`i''", nogen
		gen PredWgGrth`i' = RRdiff_f1_RRiBY_BRiBY * $wageBen

		foreach v in earn_Diff_f wage_grwth {
			gen diff_w_pbo_`v'`i' = 100*(`v'`i' - pbo_`v'`i' - avg_`v'`i' + pbo_avg_`v'`i')
			replace `v'`i' = 100*(`v'`i' - 1)
			replace pbo_`v'`i' = 100*(pbo_`v'`i' - 1)
		}
	}


	***** Normalizing one percentile to zero for each reform
		* Closest control percentile to the treatment region
	if `reform' == 1985 {
		su earn_pct_bin if treatment_`reform' > 0 & !mi(treatment_`reform')
		local relPct = r(min)
	}
	else if `reform' == 1976 {
		local relPct = 7
	}
	else if `reform' == 2001 {
		local relPct = 29
	}
	else {
		su earn_pct_bin if treatment_`reform' > 0  & !mi(treatment_`reform')
		local relPct = r(max)
	}

	foreach i in `yrsFwd' {
	foreach v in earn_Diff_f wage_grwth {
		su diff_w_pbo_`v'`i' if earn_pct_bin == `relPct'
		replace diff_w_pbo_`v'`i' = diff_w_pbo_`v'`i' - r(mean)
	}

		gen diff_w_pbo`i' = diff_w_pbo_earn_Diff_f`i'
	}

	***** Sample restriction + saving
	keep if in_sample_`reform' == 1
	gen reform = `reform'
	save ${temp}/03a_Nonparametric_DTAFiles/03a_NonParametric_Sample_Reform`reform'_`type'`pboind'.dta, replace

	} // Else not 1976 and not two-year placebo
	} // Reforms

	* Pooled scatterplot figure. The percentile points are weighted by the
	* sample size of each reform in calculating the slope.

	foreach yr in `yrsFwd' {

		clear
		set obs 1
		foreach reform in 1976 1985 1989 2001 {
			if `placeborun' == 2 & `yr' == 2 & `reform' == 1976 {
			}
			else {
				append using ${temp}/03a_Nonparametric_DTAFiles/03a_NonParametric_Sample_Reform`reform'_`type'`pboind'.dta
			}
		}
		rename RRdiff_f1_RRiBY_BRiBY mean

		save ${temp}/03a_Nonparametric_DTAFiles/03a_NonParametric_GroupedScatter`pboind'_`suffix'_yrFwd`yr'_`type'.dta, replace

	} //Years forward

} //Sample: Stayer, Mover, etc.
} //Placebo sample

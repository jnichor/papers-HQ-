*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================


* Generates stock selection regression table
* --------------- --------------- --------------- ---------------  -------------


* generate locals to save estimates and latex code
* -----------------------------------------------------------------------------
local incorporationdate_b "Incorporation Date"
local incorporationdate_se
local incorporationdate_var y



local prereformcohort_b "$\mathbb{1}$(Pre-Reform)"
local prereformcohort_se
local prereformcohort_var pre

local interaction_b "Inc. Date $\times$ $\mathbb{1}$(Pre-Reform)"
local interaction_se
local interaction_var


local ns      "\textit{N}, Stock Cs"
local ns_var Nag
local nllc   "\textit{N},  LLCs"
local nllc_var   Ngmbh
local r2      "Adj. $ R^2 $"
local r2_var Radjusted

local estimates incorporationdate prereformcohort interaction
local statistics ns nllc  /*r2*/

foreach row in `estimates'  {
  qui foreach spec in 1 2  {
    use "${iab}/208/Incorporation_spec`spec'.dta", clear

    local b
    local starp
    local se
    * coefficient
    * ------------
    sum b``row'_var'
    local b : di %5.3f `r(mean)'
    * stars
    * ------------
    sum p``row'_var'

    if `r(mean)'==.{
      local starp
    }


    if `r(mean)'>0{
      local starp "\sym{***}"
    }

    if `r(mean)'>0.01{
      local starp "\sym{**}"
    }
    if `r(mean)'>0.05{
      local starp "\sym{*}"
    }

    if `r(mean)'>0.1{
      local starp
    }

    * store in local
    local `row'_b  ``row'_b' & `b' `starp'

    * standard error
    * ----------------
    sum s``row'_var'
    local s : di %5.3f `r(mean)'
    * store in local
    local `row'_se  ``row'_se' & (`s')
  } // specifications

} // rows

foreach row in `statistics'  {
  qui foreach spec in 1 2 {
    use "${iab}/208/Incorporation_spec`spec'.dta", clear
    * oops
    replace Nag = N - Ngmbh


    sum ``row'_var'

    local b : di %9.0fc `r(mean)'

    if "`row'" == "r2" {
        local b : di %5.3f `r(mean)'
    }

    local `row' ``row'' & `b'

  } // statistics
  di "``row''"
} // row



local columns l c c c
local colnumber_line  "& (1) & (2) "
*local columnnames  "& $\mathbb{1}$(Incorporated as AG) & $\mathbb{1}$(Incorporated as AG)  & $\mathbb{1}$(Incorporated as AG)"
local blank_line " "



* write latex code
* -----------------------------------------------------------------------------

file open fh using "${tables}/TableA1.tex", write replace

* header
file write fh "\begin{tabular}{`columns'}" _n ///
              "\toprule \toprule" _n ///
              "\addlinespace " _n ///
							"& \multicolumn{2}{c}{$\mathbb{1}$(Inc. as Stock Corp.)} \\ " _n ///
 							"\cmidrule(lr){2-3} " _n   ///
              "`colnumber_line' \\ " _n ///
              "\midrule \addlinespace" _n ///
              "[1em]" _n

foreach row in `estimates' {
  file write fh "``row'_b' \\" _n ///
                "``row'_se' \\" _n ///
                "[1em]" _n
}
file write fh "\midrule " _n
*file write fh " Year FE &   &   X   &   \\" _n
file write fh " Industry FE &    &   X \\ " _n
file write fh "\hline " _n
foreach row in `statistics' {
  file write fh "``row'' \\" _n ///
                "[1em]" _n
}


file write fh "" ///
              "%" _n ///
              "%" _n ///
              "\bottomrule \bottomrule" _n ///
              "%" _n ///
              "\end{tabular}"

file close fh

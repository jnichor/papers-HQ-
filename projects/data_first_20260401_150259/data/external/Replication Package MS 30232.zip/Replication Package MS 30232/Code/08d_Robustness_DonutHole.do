/*******************************************************************************

	DESCRIPTION: Analyze the sensitivity of the main results to the choice
		of donut hole size.

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/08d_Robustness_DonutHole`curr_date'", replace

********************************************************************************
***** Outcome variables + instrument aggregations + sample restrictions
********************************************************************************


***** Outcomes for the main and alternative analysis
	* Don't add yrFwd here -- automatically added from $earnF
local main_outcomes earn_Diff_f /*realizedRRChange_f*/
local alt_outcomes /*mover_f recalled_f ENE_f EUE_f mth_non_emp_f mth_UE_f mth_sick_f  UIdur_f_NE  takeup_f UIdur_f*/


***** Level of instrument aggregation
local aggregations earn_pct /*benr indocc*/


***** Sample restrictions to run
local types _stable /*_stayer _mover _recalled _ENE  _EE _EUE _nonEUE */ // "" "_shortENE" "_longENE"


***** Including or dropping the 1976 reform
	* 0 -> drop 1976 reform and extend the pre-period
	* 1 -> include the 1976 reform w/ limited pre-period
local include1976 1

* Set of hole sizes to loop over
local holes 1 2 5 10 15 20 25

********************************************************************************
***** Specifying which controls to include
********************************************************************************

***** Specific controls for each instrument aggregation
local control_num_list_earn_pct 4 // only interested in main spec for robustness checks
local control_num_list_benr 1 2 3 4
local control_num_list_indocc 9 10 11 12 15 16


***** Directly included controls for the different specifications
local controls1 reform#year##c.lnearnings reform#year#REBPcontrol

local controls2 reform#year##c.(exp25 exp25_sq exp25_cub tenure tenure_sq tenure_cub refage refage_sq refage_cub lnearnings)  reform#year#frau reform#year#REBPcontrol

local controls3 `controls1'

local controls4 `controls2'

local controls5 `controls1'

local controls6 `controls2'



local controls9 `controls1'

local controls10 `controls2'

local controls11 `controls1'

local controls12 `controls1'

local controls13 `controls2'

local controls14 `controls2'

local controls15 `controls1'

local controls16 `controls2'


***** Directly included controls for the different specifications
local FE_controls1 earn_pct_bin#reform const
local FE_controls2 `FE_controls1'
local FE_controls3 `FE_controls1' nace08#whitecoll#reform#year
local FE_controls4 `FE_controls3'
local FE_controls5 `FE_controls1' benr#year#reform
local FE_controls6 `FE_controls3' benr#year#reform
local FE_controls7 `FE_controls1' nace08d3_grp#reform#year
local FE_controls8 `FE_controls1' nace08d3_grp#reform#year

local FE_controls9 earn_pct_bin#reform const
local FE_controls10 `FE_controls9'
local FE_controls11 `FE_controls9' ind_grp#year#reform
local FE_controls12 `FE_controls9' whitecoll#year#reform
local FE_controls13 `FE_controls11'
local FE_controls14 `FE_controls12'
local FE_controls15 `FE_controls9' ind_grp#year#reform whitecoll#year#reform
local FE_controls16 `FE_controls15'


***** Naming different control specifications
local controlname1 none
local controlname2 mincer
local controlname3 indocc
local controlname4 ctrls
local controlname5 firmyr
local controlname6 ctrlsfirmyr
local controlname7 ind3dig
local controlname8 ctrlsind3dig

local controlname9 none
local controlname10 mincer
local controlname11 indyr
local controlname12 occyr
local controlname13 minc_indyr
local controlname14 minc_occyr
local controlname15 indyroccyr
local controlname16 minc_indyroccyr

****************************************************************************
* Pooled Analysis with different donut hole
****************************************************************************

foreach type in `types' {

foreach yrFwd in $earnF {

foreach group in `include1976' {

	***** Adding the yrFwd suffixes to each outcomes variable
	local main_outcomes_mod ""
	local alt_outcomes_mod ""
	foreach outcome in `main_outcomes' {
		local main_outcomes_mod `main_outcomes_mod' `outcome'`yrFwd'
	}
	foreach outcome in `alt_outcomes' {
		local alt_outcomes_mod `main_outcomes_mod' `outcome'`yrFwd'
	}

	local outcomes `main_outcomes_mod' `alt_outcomes_mod'


	***** Sample restrictions whether or not the 1976 reform is included
	if `group' == 0 { // 6 Years back
		local grprestriction inlist(reform, 1985, 1989, 2001)
		local samplename ""
		local coefflist1 l5 l4 l3 l2 l0
		local coefflist2 l5 l4 l3 l0
		local coefflist3 l5 l4 l0
	}

	if `group' == 1  { // 4 years Back
		local grprestriction inlist(reform, 1976, 1985, 1989, 2001) & inlist(yr_l5,.,0) & inlist(yr_l4,.,0)
		local samplename With76
		local coefflist1 l3 l2 l0
		local coefflist2 l3 l0
		local coefflist3 l0
	}


	***** Defining instrument aggregations
	foreach suffix in `aggregations' {

		***** Specifying cluster variables
		if "`suffix'" == "earn_pct" {
			local cluster svnr earn_pct_bin
		}
		else {
			local cluster `suffix' svnr
		}

		***** Loading pooled reform data for each hole
		foreach cut in percentile nominal {
		foreach hole in `holes' {

		use ${temp}/02c_PooledReforms_yrFwd`yrFwd'.dta if `grprestriction', clear

		* Asserting that we only have four years for each reform
		if `group' == 1 {
			assert inrange(year, reform - 4, reform - 1)
		}


		***** Sample restrictions + specific variable definitions
		if "`suffix'" == "indocc" {
			drop if mi(whitecoll)
			encode nace08d3, gen(ind_grp)
		}

		foreach x in shtreat_pct_indocc treat_pct_indocc {
			replace `x' = round(`x', 5)
			replace `x' = 1 if `x' == 0
		}


		***** Indicator for REBP eligibility
			* rebp -- indicate REBP geographic eligibility
			* eREBP -- indicates age and experience eligibility
			*
		gen REBPcontrol = rebp != 0 & eREBP == 1 & reform == 1989 & year >= 1987

		* Winsorize earnings outcomes
		winsor2 earn_Diff_f`yrFwd', replace cut(1 99) by(reform year)

		* Keep if employed in December
		keep if status == 3


		***** Dropping the bottom earnings percentile from each reform
		if $shorten76and89 == 1 {
			foreach reform in 1976 1989 {
				su earn_pct if treatment_`reform' == 1
				local min = r(min)
				su earn_pct if control_`reform' == 1
				local max = r(max)
				local new_min = `min' + 1
				local new_max = `max' - 1
				drop if reform == `reform' & earn_pct <= `new_min' & !mi(earn_pct)
				drop if reform == `reform' & earn_pct >= `new_max' & !mi(earn_pct)
			} // Looping through 1976 and 1989 code blocks
		} // Shorten 76 and 89 code block


		***** Displaying the final earnings ranges for each reform
		foreach reform in $reforms {

			di "Treatment for `reform' Reform"
			su adj_earnings if treatment_`reform' == 1 & year == `reform' - 1 & reform == `reform'
			su earn_pct if treatment_`reform' == 1

			di "Control for `reform' Reform"
			su adj_earnings if control_`reform' == 1 & year == `reform' - 1 & reform == `reform'
			su earn_pct if control_`reform' == 1

		}

		gen const = 1

		***** Type-specific sample restrictions
		if "`type'" == "_stable" {
			keep if mth_emp == 12
		}

		local short = substr("`type'",2,.)

		if inlist("`type'", "_stayer", "_mover", "_recalled") {
			keep if `short'_f`yrFwd' == 1 & mth_emp == 12
		}

		if inlist("`type'", "_ENE", "_EE", "_EUE") {
			keep if mover_f`yrFwd' == 1 & `short'_f`yrFwd'  == 1 & mth_emp == 12
		}

		if inlist("`type'", "_nonEUE") {
			keep if mover_f`yrFwd' == 1 & EUE_f`yrFwd' == 0 & ENE_f`yrFwd' == 1 & mth_emp == 12
		}

		if inlist("`type'", "_shortENE") {
			keep if mover_f`yrFwd' == 1 & ENE_f`yrFwd' == 1 & len_NE_premove_f`yrFwd' == 1 & mth_emp == 12
		}

		if inlist("`type'", "_longENE") {
			keep if mover_f`yrFwd' == 1 & ENE_f`yrFwd' == 1 & len_NE_premove_f`yrFwd' > 1 & !mi(len_NE_premove_f`yrFwd')  & mth_emp == 12
		}

		if `group' == 1  {
			drop *_l4_f`yrFwd' *_l5_f`yrFwd' yr_l5 yr_l4
		}

		local extravars
		if inlist("`suffix'", "benr", "indocc") {
			local extravars reform#shtreat_pct_`suffix' reform#treat_pct_`suffix'
		}


		***** Generating numeric version of benr -> used as FE
		rename benr benr_str
		gegen benr = group(benr_str)

		* Cut the hole
		if "`cut'" == "percentile" {
			local var earn_pct

			foreach reform in $reforms {
				qui su `var' if treatment_`reform' == 1
				local tmax = r(max)
				local tmin = r(min)
				qui su `var' if control_`reform' == 1
				local cmax = r(max)
				local cmin = r(min)

				if `reform' != 1985 {
					drop if reform == `reform' & ///
					inrange(`var', `tmax' - ((`hole'/100)*(`tmax'-`tmin')), ///
					`cmin' + ((`hole'/100)*(`cmax'-`cmin')))
				}

				if `reform' == 1985 {
					drop if reform == `reform' & ///
					inrange(`var', `cmax' - ((`hole'/100)*(`cmax'-`cmin')), ///
					`tmin' + ((`hole'/100)*(`tmax'-`tmin')))
				}
			} // reforms
		} // cuts

		if "`cut'" == "nominal" {
			local var adj_earnings
			foreach reform in $reforms {
				flevelsof year if reform == `reform', local(years)
				foreach y in `years' {
					qui su `var' if year == `y' ///
					& reform == `reform' & treatment_`reform' == 1
					local tmin = r(min)
					local tmax = r(max)

					qui su `var' if year == `y' ///
					& reform == `reform' & control_`reform' == 1
					local cmin = r(min)
					local cmax = r(max)

					if `reform' != 1985 {
						drop if reform == `reform' & ///
						inrange(`var', `tmax' - ((`hole'/100)*(`tmax'-`tmin')), ///
						`cmin' + ((`hole'/100)*(`cmax'-`cmin')))
					}

					if `reform' == 1985 {
						drop if reform == `reform' & ///
						inrange(`var', `cmax' - ((`hole'/100)*(`cmax'-`cmin')), ///
						`tmin' + ((`hole'/100)*(`tmax'-`tmin')))
					}
				} // years
			}	// reforms
		} // cuts

		if `yrFwd' == 3 & `group' == 2 {
			di "We do not run specifications on the sample with 1976 and three-year outcomes because we have no placebos."
		}

		else {
			* Run specification program
			foreach cnt_grp in `control_num_list_`suffix'' {
				cap program drop run_specification
				run_specification, outcomes(`outcomes') ///
					instr_aggreg(`suffix') ///
					controlname(`controlname`cnt_grp'') ///
					instr_yrFwd(1) ///
					regvars(" " ) ///
					absorbvars(`controls`cnt_grp'' `FE_controls`cnt_grp'') ///
					coefflist(`coefflist`yrFwd'') ///
					aux_info(coeff SE R N F avg) ///
					cluster(`cluster') ///
					yrFwd(`yrFwd') ///
					samplename(`samplename'`type'_Hole_`cut'_`hole'pt)

			} // Specifications
		} // If not 3-year horizon and with 1976
	} // Hole size
	} // cut type
	} // Instrument aggregation
} // With or Without 1976
} // Years forward
} // Type

log close

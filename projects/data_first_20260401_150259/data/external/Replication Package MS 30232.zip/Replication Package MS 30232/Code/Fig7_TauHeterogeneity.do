/*******************************************************************************

	DESCRIPTION: Figure 7: tau heterogeneity.

*******************************************************************************/

*===============================================================================
* PREFIX

* prefix
set more off
clear all

local curr_date = c(current_date)
log using "${logs}/Fig7_TauHetergeneity`curr_date'", replace

* settings
local bins		= 10				// 5, 10, 20
local lab		= "Deciles"			// "Quintiles", "Deciles", "Ventiles"
local sublab		= "highlow2" 			// high1, low1, highlow1, high2, low2, highlow2
local figname		= "oldctrls"			// oldctrls, adjctrls
local Jensen		= 0				// 0, 1

*===============================================================================

***** Looping through the counting cutoffs + reemployment conditions
foreach tracking in $tausamples_hetAnal {
foreach reemployment in $conditions_hetAnal {


* load data
use "${temp}/09d_TauHeterogeneity_With76_stable_`reemployment'_`tracking'_earn_Diff_f1_tau_U_qrt_K_`bins'_`sublab'.dta", clear


* drop missing tau^U
drop if tau_U_qrt==.

local suffix
local name
if `Jensen' == 0 {
	local suffix _tilde
	local name _notRespJensen
}

* generate figure of empirical and predicted wage-benefit sensitivity by quintile of predicted tau^U
tw 	(connected 	ctrls_intcoeff 		tau_U_hat, lc(sea%40) lp(solid) mc(sea) m(S) msize(medium)) ///
	(rcap 		ctrls_intUB ctrls_intLB 	tau_U_hat, lc(sea) lp(solid) lwidth(medthick)) ///
	(connected 	sensitivity_hat`suffix'	tau_U_hat, lc(dkorange) lp(dash) mc(dkorange) m(none)), ///
	legend(size(medium) order(1 "Empirical Estimate" 3 "Predicted") r(1) pos(6) region(style(none))) ///
	yline(0, lpattern(shortdash) lcolor(gray)) ylab(-0.2(0.2)0.6) xlab(0(0.05)0.2) ///
	ylab(,labsize(medium)) xlab(,labsize(medium)) ///
	ytitle("Wage-Benefit Sensitivity", m(r=2)) xtitle("Predicted Fraction of Post-Separation Time on UI ({&tau})", m(t=2))


graph export "${figures}/Fig7_TauHeterogeneity.pdf", replace


} // Counting cutoffs
} // Reemployment conditions

log close

/*******************************************************************************

	DESCRIPTION: Creates dataset of predicted replacement rate
		(UIB/net income) from the 2006 Eurobarometer survey
		in Austria and the actual distribution from the AMS
		data.

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/04b_Diagnostic_Eurobarometer`curr_date'", replace

********************************************************************************
* Generating the AMS dataset
********************************************************************************

	**** Loading data

	use ${ams}/daten/ams_leistungen.dta if inlist(year(lstg_vdat), ${eurobar_year}) ///
	& inlist(lstg_art, ${eurobar_type}) ///
	& !mi(penr), clear

	**** Converting start and end of spell dates to stata dates
	format lstg_vdat %td
	format lstg_bdat %td

	gen start_month = month(lstg_vdat)
	gen year = year(lstg_vdat)

	* Take average UIB received per person. Differs slightly
	fcollapse tagsatzleist, by(penr year) fast

	**** Converting UIB payments to nominal Austrian Shillings from daily 2000 Euros
		* Multiply by 13.7603 to get from Euros to Shillings
		* Multiply by the number of days per year/months
		* Incorporate leap years https://kalender-365.de/leap-years.php
		* Multilying by the CPI deflator to get to nominal Shillings
	fmerge m:1 year using "${data}/CPI_AUT.dta", assert(match using) keep(match) nogen

	* Leap years
	gen leap_year = inlist(year, 1972, 1976, 1980, 1984, 1988, 1992, 1996, 2000, 2004, 2008, 2012, 2016)
	gen day_per_year = cond(leap_year == 1, 366, 365)

	* Daily UIB payments in EUR
	gen adj_UIB = tagsatzleist*(CPI_2000/100)

	keep penr adj_UIB

	tempfile ams
	save `ams', replace


********************************************************************************
* Generating the ASSD
********************************************************************************

	* Append monthly fies together, pulling annual earnings variables
	forval m = 1/12 {
		use penr dearnings ///
			using ${data}/0010_panelBal_year${eurobar_year}_month`m'.dta, clear
		gen byte month = `m'
		tempfile month`m'
		save `month`m'', replace
	}
	clear

	set obs 1
	forval m = 1/12 {
		append using "`month`m''"
		erase "`month`m''"
	}

	* Take average of assigned base income and special payments values across year
	fcollapse dearnings, by(penr) fast

	* Generate net income with Weber tax calculator (2006 tax schedule)
	gen day = 1
	gen month = 1
	gen year = $eurobar_year
	gen date = mdy(month,day,year)
	fmerge m:1 year using "${data}/CPI_AUT.dta", assert(match using) keep(match) nogen
	* Leap years
	gen leap_year = inlist(year, 1972, 1976, 1980, 1984, 1988, 1992, 1996, 2000, 2004, 2008, 2012, 2016)
	gen day_per_year = cond(leap_year == 1, 366, 365)

	* Merge actual UIB from AMS data
	fmerge 1:1 penr using "`ams'"
	erase "`ams'"
	keep if _m == 3
	drop _merge

	gen grossincome = dearnings*day_per_year*(CPI_2000/100)
	cap pr drop getnetwage
	getnetwage grossincome date
	gen net_dearnings = netwage / day_per_year


	winsor2 adj_UIB, cut(1 99)

	winsor2 net_dearnings, cut(1 99)

	* Generate actual replacement rates. This will be missing for anyone
	* who did not receive UIB.

	gen const = 1

	foreach suffix in "" "_w" {
		gen actualRR`suffix' = adj_UIB`suffix' / net_dearnings`suffix'

		if "`suffix'" == "_w" {
			winsor2 actualRR`suffix', replace cut(5 95)
		}

		su net_dearnings`suffix', d
		global cap`suffix' = r(max)

		* Find mean of actual RR in 2006.
		su actualRR`suffix', d
		global meanRR`suffix' = 100*r(mean)

		reg actualRR`suffix' const
		predict meanactualRR`suffix', xb
		predict seactualRR`suffix', stdp
		qui su meanactualRR`suffix'
		global meanactualRR`suffix' = r(mean)
		qui su seactualRR`suffix'
		global seactualRR`suffix' = r(mean)

	}

	gen meanactualRR_w_ = round((100*${meanactualRR_w}),.01) if _n==1

	save ${temp}/04b_Eurobarometer.dta, replace

********************************************************************************
* Eurobarometer Analysis
********************************************************************************

	* Pull Austrian data from survey. The Austrian code is 18.
	use ${eurob_data}/ZA4507_v1-1-0.dta if v6 == 18, clear

	* Rename variables
	rename v418 predRR // 5 ordinal categories

	* Generate bounds of interval for intreg
	gen lb = .
	replace lb = 91 if predRR == 1
	replace lb = 71 if predRR == 2
	replace lb = 51 if predRR == 3
	replace lb = 31 if predRR == 4
	replace lb = 0 if predRR == 5

	gen ub = .
	replace ub = 100 if predRR == 1
	replace ub = 90 if predRR == 2
	replace ub = 70 if predRR == 3
	replace ub = 50 if predRR == 4
	replace ub = 30 if predRR == 5

	gen mdpt = .
	replace mdpt = 95 if predRR == 1
	replace mdpt = 80 if predRR == 2
	replace mdpt = 60 if predRR == 3
	replace mdpt = 40 if predRR == 4
	replace mdpt = 15 if predRR == 5

	* Generate children variable
	gen children = v661 + v663
	drop if children > 2

	gen const = 1
	qui intreg lb ub const
	predict meanpredRR, xb
	predict sepredRR, stdp
	qui su meanpredRR
	global meanpredRR = r(mean)
	qui su sepredRR
	global sepredRR = r(mean)

	gen meanpredRR_ = round(${meanpredRR},.01) if _n==1
	gen sepredRR_ = round(${sepredRR},.01) if _n==1

	foreach var in children v410 v458 v442 v443 {
		preserve
			intreg lb ub i.`var', vce(robust)
			predict pred, xb
			predict se, stdp
			gen predub = pred + 1.96*se
			gen predlb = pred - 1.96*se
			bys `var': gen ind = _n == 1
		restore
	}

	save ${temp}/04b_Eurobarometer_Survey.dta, replace

log close

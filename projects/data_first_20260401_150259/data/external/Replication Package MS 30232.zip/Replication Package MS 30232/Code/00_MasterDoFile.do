/*******************************************************************************


  WAGES AND THE VALUE OF NON-EMPLOYMENT

  By Simon Jäger, Benjamin Schoefer, Samuel Young, and Josef Zweimüller

  DESCRIPTION: Master Do-File

  April 24th, 2020


*******************************************************************************/




********************************************************************************
***** Global contain the home folder
* Note -- the ChangePermissions Bash script requires manual changes
* Clear globals here
********************************************************************************
macro drop _all
global home = "Q:/MarginalJobs/UIFirms/BargParam/Replication"




********************************************************************************
* Running individual .do files
********************************************************************************

***** Main Data Construction Files
do "${home}/dofiles/00a_SetPaths.do"
do "${dofiles}/00b_SetGlobals.do"
// do "${dofiles}/01a_Build_MonthlyPanel.do"
// do "${dofiles}/01c_Build_SpellVariables.do"
// do "${dofiles}/01d_Build_StayerMovers.do"
// do "${dofiles}/01e_Build_AnnualPanel.do"
// do "${dofiles}/02a_Build_RegressionVariables.do"
// do "${dofiles}/02b_Build_ReformSamples.do"
//  do "${dofiles}/02c_Build_PooledSample.do"


***** Nonparametric and DiD Data Analysis
// do "${dofiles}/03a_Analysis_NonParametric.do"
// do "${dofiles}/03b_Analysis_DiD_Pooled.do"
// do "${dofiles}/03c_Analysis_IV_Pooled.do"
// do "${dofiles}/03d_Analysis_DiD_Pooled_NetTax.do"


**** Diagnostics
// do "${dofiles}/04a_Diagnostic_BenefitChangeByPercentile.do"
// do "${dofiles}/04b_Diagnostic_Eurobarometer.do"
// do "${dofiles}/04c_Diagnostic_Takeup.do"
// do "${dofiles}/04d_Diagnostic_WagePrediction.do"


**** Potential Benefit Duration
// do "${dofiles}/05a_PBDExtension_Build.do"
// do "${dofiles}/05b_PBDExtension_Analysis_NonParametric.do"
// do "${dofiles}/05c_PBDExtension_Analysis_DiD.do"


***** Heterogeneity analysis
// do "${dofiles}/06a_Heterogeneity_Build_LocalUnempRate.do"
// do "${dofiles}/06b_Heterogeneity_Build_AKMFirmEffects.do"
// do "${dofiles}/06c_Heterogeneity_Build_FirmCharacteristics.do"
// do "${dofiles}/06d_Heterogeneity_Build_IndOccUnempRate.do"
// do "${dofiles}/06e_Heterogeneity_Build_IndustryGrowthRate.do"
// do "${dofiles}/07a_Heterogeneity_Build_Panel.do"
// do "${dofiles}/07b_Heterogeneity_Analysis.do"


***** Robustness
// do "${dofiles}/08a_Robustness_Cluster.do"
// do "${dofiles}/08b_Robustness_Controls.do"
// do "${dofiles}/08c_Robustness_Winsor.do"
// do "${dofiles}/08d_Robustness_DonutHole.do"


***** Tau Analysis
// do "${dofiles}/09_TauMaster.do"
// do "${dofiles}/00b_SetGlobals.do" // restore globals for rest of the analysis


***** In-text Calculations
// do "${dofiles}/10a_Rent_Sharing_Austria_BvD.do" // Rent-sharing in Austria
// do "${dofiles}/10b_ValidationExcluding2001.do" // Validation Excluding 2001


***** Tables
* main text
// do "${dofiles}/Tab1_Tau.do"
// do "${dofiles}/Tab2_SumStats.do"
// do "${dofiles}/Tab3_6_7_DiD.do"
// do "${dofiles}/Tab4_Transition.do"
// do "${dofiles}/Tab5_Heterogeneity.do"

* appendix
// do  "${dofiles}/TabA1_Takeup.do"
// do  "${dofiles}/TabA2_DiD_Takeup.do"
// do "${dofiles}/TabA3_Validation.do"
** Table A.4. (IV) is produced in 03c_Analysis_IV_Pooled
// do "${dofiles}/TabA5_Tau_Actual.do"
// do "${dofiles}/TabA6_PredWageChanges.do"
// do "${dofiles}/TabA7_DiD_Gross.do"


***** Figures
* main text
// do "${dofiles}/Fig2_MetaStudy.do"
// do "${dofiles}/Fig3_BenefitSchedules.do"
// do "${dofiles}/Fig4_NonParametric.do"
// do "${dofiles}/Fig5_Scatter.do"
// do "${dofiles}/Fig6-A6_BinScatter.do"
// do "${dofiles}/Fig7_TauHetergeneity.do"

* appendix
// do "${dofiles}/FigA1_Eurobarometer.do"
// do "${dofiles}/FigA2-5_Additional_NonParametric.do"
// do "${dofiles}/FigA7_Distribution_IndOccInstrument.do"
// do "${dofiles}/FigA8_Cluster.do"
// do "${dofiles}/FigA9_Winsor.do"
// do "${dofiles}/FigA10_Control.do"
// do "${dofiles}/FigA11_DonutHole.do"
// do "${dofiles}/FigA12_AlternateOutcomes.do"
// do "${dofiles}/FigA13_ImpliedSigma.do"
// do "${dofiles}/FigA14_UI_rule_validation"
// do "${dofiles}/FigA15_Quality_WagePrediction.do"
// do "${dofiles}/FigA16_PBD_Reform.do"
// do "${dofiles}/FigA17_PBD_NonParametric.do"
// do "${dofiles}/FigA18_PBD_DiD.do"
// do "${dofiles}/FigA19_NonParametric_Gross.do"
// do "${dofiles}/FigB1-4_RR_Schedule_Flipbook.do"

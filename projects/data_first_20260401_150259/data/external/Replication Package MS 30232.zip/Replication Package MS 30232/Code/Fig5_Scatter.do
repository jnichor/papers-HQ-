/*******************************************************************************

	DESCRIPTION: Figure 5: Scatter Plots of Wage Growth and Unemployment Benefit Changes



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
clear all
cap log close
local curr_date = c(current_date)
log using "${logs}/Fig5_Scatter`curr_date'", replace

********************************************************************************

local h1
local h2 h

local transp1 30
local transp2 80

foreach yr in $earnF {

	local letter = word("a b", `yr')

	use ${temp}/03a_Nonparametric_DTAFiles/03a_NonParametric_GroupedScatter_earn_pct_yrFwd`yr'_stable.dta, clear

	local counter = 1
	local scatterline`yr'
	local scatterline_1stStage`yr'
	local labels`yr'
	local orders`yr'

	local color1 sea
	local color2 sky
	foreach reform in 1976 1985 1989 2001 {

		local color = word("red blue green ananas", `counter')
		local shape = word("O S D T O",`counter')

		local scatterline`yr' `scatterline`yr'' ///
		(scatter diff_w_pbo`yr' mean if reform == `reform', ///
		mcolor(`color`yr''%`transp`yr'') msymbol("`shape'`h`yr''"))

		local counter = `counter' + 1
		local othercounter = 1 + `counter'
		local labels`yr' `labels`yr'' label(`othercounter' "`reform'")
		local orders`yr' `orders`yr'' `othercounter'


	}
	local othercounter = `othercounter' + 1


	qui reg PredWgGrth1 mean [pweight=N]
	local oneminusphi = round(_b[mean],0.001)

	foreach outcome in diff_w_pbo`yr' RRdiff_f`yr'_RRRY_BRRY  {
		qui reg `outcome' mean [pweight=N]
		local slope_`outcome' = round(_b[mean],0.001)
		local se_`outcome' = round(_se[mean],0.0001)
	}

	tw (lfitci diff_w_pbo`yr' mean  [pweight=N], lcolor(`color`yr'') acolor(`color`yr''%40) ) ///
		`scatterline`yr'' ///
		/*(scatter PredWgGrth1 mean, mcolor(dkorange) msymbol(X))*/ ///
		(lfit PredWgGrth1 mean  [pweight=N] , lpattern(dash) ///
		lcolor(dkorange) xtitle("Unemployment Benefit Change (db/w)", size(medium)) ///
		ytitle("Wage Growth (dw/w)", size(medium))  ///
		xlab(,labsize(medium)) ylab(,labsize(medium)) ///
		legend(`labels`yr'' label(`othercounter' "Predicted") ///
		order(`orders`yr'' `othercounter') r(1) pos(6) size(medium)) ///
		note("Estimated Wage Sensitivity {&sigma}: `slope_diff_w_pbo`yr'' (SE: `se_diff_w_pbo`yr'') " ///
		"Predicted Semi-Elasticity: `oneminusphi'"))

	graph export "${figures}/Fig5`letter'_Scatter.pdf", replace

}

log close

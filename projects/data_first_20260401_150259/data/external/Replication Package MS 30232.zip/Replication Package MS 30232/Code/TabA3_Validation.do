/*******************************************************************************

	DESCRIPTION: Table A2: Validation Exercise: Difference-in-Differences Regression Design

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
cap file close fh
local curr_date = c(current_date)
log using "${logs}/Table_Validation`curr_date'", replace

****************************************************************************

local group = 2
local with2 With76
local coefflist1 l3 l2 l0
local coefflist2 l3 l0


* Choose which of controls below to use
local control_num_list_earn_pct 1 4 6
local control_num_list_benr 1 2 3 4
local control_num_list_nace08 1 2 7 8
local control_num_list_horserace 1 4 6

local xlist_earn_pct 2 3 5
local xlist_benr 2 3
local xlist_nace08 2 7 8

local controlname1 none
local controlname2 mincer
local controlname3 indocc
local controlname4 ctrls
local controlname5 firmyr
local controlname6 ctrlsfirmyr
local controlname7 ind2digocc
local controlname8 ctrlsind2digocc

forval j = 1/8 {
	local `controlname1'_ind`j' "X"
	if inlist(`j', 2, 4, 6, 8) {
		local `controlname2'_ind`j' "X"
	}
	if inlist(`j', 3, 4, 6, 8) {
		local `controlname3'_ind`j' "X"
		local `controlname4'_ind`j' "X"
	}
	if inlist(`j', 5, 6) {
		local `controlname5'_ind`j' "X"
		local `controlname6'_ind`j' "X"
	}
	if inlist(`j', 7, 8) {
		local `controlname7'_ind`j' "X"
		local `controlname8'_ind`j' "X"
	}
}


* Aggregations
local aggregations earn_pct //  benr nace08

foreach x in `aggregations' horserace {
	local number_specs_`x' = 0
	foreach i in `control_num_list_`x'' {
		local number_specs_`x' = `number_specs_`x'' + 1
	}
}



foreach x in earn_pct benr horserace {
	local number_specs_`x' = 0
	foreach i in `control_num_list_`x'' {
		local number_specs_`x' = `number_specs_`x'' + 1
	}
}

cap file close fh

foreach suffix in earn_pct  {


	if "`suffix'" == "earn_pct" {
		local earningsoutcomes earn_Diff_f`yrFwd'
		local name_earningsoutcomes earningsoutcomes_`yrFwd'
		local coefflist `coefflist`yrFwd''

	}

	if inlist("`suffix'", "benr", "nace08") {
		local earningsoutcomes earn_Diff_f1 earn_Diff_f2
		local name_earningsoutcomes earningsoutcomes
		local coefflist `coefflist1'
		local tablename Table4
	}

	local realizedRRoutcomes realizedRRChange_f1 realizedRRChange_f2
	local name_realizedRRoutcomes realizedRRoutcomes

	local tables realizedRRoutcomes

	foreach results in `tables' {

		file open fh using "$tables/TabA3_Validation.tex", write replace

			* Need one column for every outcome-specification pair
			local collist
			forval i = 1/`number_specs_`suffix'' {
				foreach outcome in ``results'' {
					local collist `collist' c
				}
			}
			file write fh "\begin{tabular}{l `collist'}" _n "\hline \hline" _n
			local outc_name_row
			foreach outcome in ``results'' {


				if "`outcome'" == "earn_Diff_f`yrFwd'" {
					local lab`outcome' = "`yrFwd'-Year Earnings Effects"
				}

				if "`outcome'" == "RRChange_f`yrFwd'" {
					local lab`outcome'  = "Pred. `yrFwd'-Year RR Change"
				}

				if "`outcome'" == "realizedRRChange_f1" {
					local lab`outcome'  = "1-Year Realized RR Effects"
				}

				if "`outcome'" == "realizedRRChange_f2" {
					local lab`outcome'  = "2-Year Realized RR Effects"
				}

				local outc_name_row "`outc_name_row' & \multicolumn{`number_specs_`suffix''}{c}{`lab`outcome''}"

				local short = substr("`suffix'",1,1)

				foreach i in `control_num_list_`suffix'' {

				if "`suffix'" == "earn_pct" {
				use "${resDat}/DiD_${instrumentF}_`suffix'_`outcome'_`with`group''_stable_Spec`controlname`i''.dta", clear
				}
				if "`suffix'" == "benr" {
				use "${resDat}/DiD_${instrumentF}_`suffix'_`outcome'_`with`group''_stable_Spec`controlname`i''.dta", clear
				}
					foreach yr in l3 l2 l0 {

						local x = substr("`yr'", -1, 1)

						if substr("`yr'", 1, 1) == "l" {
							local n = 0 - `x'
						}

						if substr("`yr'", 1, 1) == "f" {
							local n = 0 + `x'
						}
						if "`outcome'" == "realizedRRChange_f2" & "`yr'" == "l2" {
						}
						else {
						qui su `controlname`i''_coeff if year == `n'
						global b`group'_`outcome'_`yr'_`short'`i': di %4.3f `r(mean)'
						qui su `controlname`i''_SE if year == `n'
						local temp: di %4.3f `r(mean)'
						global se`group'_`outcome'_`yr'_`short'`i' = "(" + string(`temp') + ")"


						}
					}

					qui su `controlname`i''_R
					global R`group'_`outcome'_`short'`i': di %4.3f `r(mean)'
					qui su `controlname`i''_N
					global N`group'_`outcome'_`short'`i' = round(`r(mean)' / 1000,1)
					qui su `controlname`i''_F
					global F`group'_`outcome'_`short'`i': di %4.3f `r(mean)'
					qui su `controlname`i''_avg
					global avg`group'_`outcome'_`short'`i' = round(`r(mean)',0.001)
				}

			}

			local spec_num_row
			local cmidrule_row
			local startofline = 2
			foreach outcome in ``results'' {
				local number = 1
				foreach cnt_grp in `control_num_list_`suffix'' {
					local spec_num_row "`spec_num_row' & (`number')"
					local number = `number' + 1
				}
				local endofline = `startofline' + `number_specs_`suffix'' - 1
				local cmidrule_row "`cmidrule_row' \cmidrule(lr){`startofline'-`endofline'}"
				local startofline = `startofline' + `number_specs_`suffix''
			}
			file write fh "`outc_name_row' \\ `cmidrule_row'" _n "`spec_num_row' \\" _n  "\hline" _n

				local n = 1
				foreach yr in l3 l2 {
					local x = substr("`yr'", -1, 1)
					local coeffline`n' " Placebo: `x' Yr Lag"
					local seline`n' ""
					local n = `n' + 1
				}
				local treatcoeffline "\textbf{Treatment Year}"
				local treatseline ""
				local blankline ""
				local avgline "Base-Year Average"
				local Fline "Pre-p F-test p-val"
				local rline "\textit{R}$^{2}$"
				local nline "\textit{N} (1000s)"

			* Groups of columns of outcomes
			foreach outcome in ``results'' {

				* Columns of control groups
				foreach cnt_grp in `control_num_list_`suffix'' {
						* Rows of yearly coefficients
						local n = 1
						foreach yr in l3 l2 {
							local coeffline`n' "`coeffline`n'' & ${b`group'_`outcome'_`yr'_`short'`cnt_grp'}"
							local seline`n' "`seline`n'' & ${se`group'_`outcome'_`yr'_`short'`cnt_grp'}"
							local n = `n' + 1
						}	//Year coefficients
					local treatcoeffline "`treatcoeffline' & \textbf{ ${b`group'_`outcome'_l0_`short'`cnt_grp'}}"
					local treatseline "`treatseline' & \textbf{ ${se`group'_`outcome'_l0_`short'`cnt_grp'}} "
					local blankline "`blankline' & "
					local avgline "`avgline' & ${avg`group'_`outcome'_`short'`cnt_grp'}"
					local Fline "`Fline' & ${F`group'_`outcome'_`short'`cnt_grp'} "
					local rline "`rline' & ${R`group'_`outcome'_`short'`cnt_grp'} "
					local nline "`nline' & ${N`group'_`outcome'_`short'`cnt_grp'} "

				} //Columns of controls
			} // Groups of columns of outcomes

			* Write up subsection
			file write fh "`blankline' \\" _n
			local n = 1
			foreach yr in l3 l2 {
				file write fh "`coeffline`n'' \\" _n "`seline`n'' \\" _n
				local n = `n' + 1
			}
			file write fh "\vspace{-.3cm} \\" _n "`treatcoeffline' \\" _n "`treatseline' \\" _n ///
			 "\vspace{-.2cm} \\" _n "\hline" _n "`avgline' \\" _n "`Fline' \\" _n ///
			"\vspace{-.3cm} \\" _n "`rline' \\" _n "`nline' \\" _n

			* Control indicators
			file write fh "\hline" _n
			local specline2 "Mincerian Ctrls"
			local specline3 "4-Digit Ind.-Occ. FEs"
			local specline5 "Firm-Year FEs"
			local specline7 "2-Digit Ind.-Occ. FEs"

			foreach outcome in ``results'' {
				foreach i in `xlist_`suffix'' {
					foreach j in `control_num_list_`suffix'' {
						local specline`i' "`specline`i'' & ``controlname`i''_ind`j'' "
					}
				}
			}
			foreach i in `xlist_`suffix'' {
				file write fh "`specline`i'' \\" _n
			}
			file write fh "\hline \hline" _n "\end{tabular}" _n

			file close fh

		} // Different Tables
		} // Instrument Aggregation

log close

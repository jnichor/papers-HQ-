

**********************************************************************************************
/*

Last updated: October 29, 2018

 This runs the specification and creates the figure. It partials out the outcome and instrument
	values according to the controls and runs all regressions on this saved cache.

 One must define the following:

	1) outcomes: the list of outcome variables. Note that one should do all the time horizons at
		once due to the saved cache. 
	2) instr_aggreg: the aggregations of the instrument (percentile-, firm-, or industry-level)
	3) controlname: the name of the specification that you want to to give
	4) instr_yrFwd: the time horizon of the instrument (almost always 1)
	5) absorbvars: the list of control variables. Normally we define this varlist as a local,.
		e.g. controls1,. controls2, etc., and loop over them.
	6) coefflist: the list of interactions to include in event time, e.g. l3 l2 l0. 
	7) aux_info: the regression output to keep. OPTIONS:
		- RRcoeff: 
		- RRSE: 
		- intcoeff: the coefficient estimate 
		- intSE: the standard error estimate
		- R: the R-squared value 
		- N: the number of observations
		- F: the F test of the pre-period placebo treatment estimates
		- avg: the average value of the outcome in the base year e = 0. 
		- For horse race, we should also have Fbenr, Fpct, and Wald 
		- For heterogeneity, we include a Wald test of all interactions being the same
	8) cluster: the cluster variable
	9) samplename: the name you wish to give in the saved dta file and figure 
	10) yrsFwd: time horizon of the outcome
	11) hetergroup: heterogeneity group 
	12) heterlabel: label of heterogeneity group
*/
**********************************************************************************************


* must define names of specifications beforehand, i.e. controlname and control variables 
* string can include: 
program run_specification_hetcuts
	syntax, outcomes(varlist) ///
	instr_aggreg(string) ///
	controlname(string) ///
	instr_yrFwd(string) ///
	regvars(string) ///
	absorbvars(string) ///
	coefflist(string) ///
	aux_info(string) ///
	cluster(string) ///
	samplename(string) ///
	yrFwd(string) ///
	hetergroup(string) ///
	heterlabel(string) 
	
	
	preserve

	***** Adding auxiliary information for matrix column names
	local number_aux_info = 0
	foreach x in `aux_info' {
		local number_aux_info = `number_aux_info' + 1 	
		if inlist("`x'", "intcoeff", "intSE") {
			local control_name_list `control_name_list' `controlname'_`x' 
		}
	}
				
	* Number of rows to include for storing estimates
	local number_rows = 1 //Start with 1 because we need the excluded year
	foreach i in `coefflist' {
		local number_rows = `number_rows' + 1
	}
	
	local short = substr("`instr_aggreg'",1,1) 			

	* Adding heterogeneity-group specific auxiliary information 
	levelsof `hetergroup', local(levels)
	foreach level in `levels' {
		foreach x in `aux_info' {
			local hetgroup_name_list `hetgroup_name_list' `controlname'_lev`level'`x' 
		}
	}
				
	* Indicators for each heterogeneity group interacted with baseline treatment + baseline treatment X event-time
	foreach level in `levels' {
		gen `hetergroup'`level' = `hetergroup' == `level' 
		ds RRinstrument_`instr_aggreg'_f`instr_yrFwd' interaction_`instr_aggreg'_*_f`yrFwd'
		foreach var in `r(varlist)' {
			gen double Het`level'`var' = `hetergroup'`level' * `var'
		} 
	}

	* Regression variables included -- 			
	local reg_vars Het* `regvars'
	
	**** Stats to store in regression and for testing placebo years
	local test_str test
	
	foreach level in `levels' {
		local test_str `test_str' Het`level'interaction_`instr_aggreg'_l0_f`yrFwd' =
	}
	
	local test_str `test_str' 0

	***** Looping through outcome variables + running regression + saving
	foreach outcome in `outcomes' {
		
		qui su `hetergroup'
		local hetero_end = r(max)
	
		* Matrix to store estimates across all heterogeneity groups 
		local shortname = subinstr("`hetergroup'", "_grp","",.)

		matrix T`instr_aggreg'`shortname' = J(`hetero_end', 3 , .)
		matrix colnames T`instr_aggreg'`shortname' = heteroGrp `control_name_list'

		
		* Matrix to store estimated treatment - control for DiD figures
		* 2 RR coeff and se, 2 interaction and se = 4 
		* 2 RR coeff and se, 2 intearction and se het interactions = 4 * no. levels
		* 1 for year column
		matrix `outcome'`instr_aggreg'`group' = J(`number_rows',(`number_aux_info'*`hetero_end')+ 1,.)
					
		matrix colnames `outcome'`instr_aggreg'`group' = year `hetgroup_name_list'

		local col_counter = 2
	
		* Running regressions
		noi reghdfe `outcome' `reg_vars',  ///
		absorb(`absorbvars') ///
		vce(cluster `cluster') ///
		/*cache(use)*/ ///
		verbose(0) ///
		/*poolsize(12)*/ ///
		nosample

		estimates store `controlname'

		* Testing the equality of the placebo effects
		`test_str'
		global F`group'_`outcome'_`short' = r(p)

		* Saving the estimated coeff diffs in the table and for the figure
		local row_counter = 1

		foreach yr in `coefflist' {
		
			local x = substr("`yr'", -1, 1) 

			if substr("`yr'", 1, 1) == "l" {
				local n = 0 - `x'
			}
			
			if substr("`yr'", 1, 1) == "f" {
				local n = 0 + `x'
			}
		
			if `col_counter' == 2 {
				mat `outcome'`instr_aggreg'`group'[`row_counter',1] = `n'	
			}
			local i = 0 
			foreach level in `levels' {
				mat T`instr_aggreg'`shortname'[`level', 1] = `level'

				foreach x in `aux_info' {
					if "`x'" == "RRcoeff" { 
						mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = _b[Het`level'RRinstrument_`instr_aggreg'_f`instr_yrFwd'] 						
					}
					
					if "`x'" == "RRSE" {
						mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = _se[Het`level'RRinstrument_`instr_aggreg'_f`instr_yrFwd'] 

					}
					
					if "`x'" == "intcoeff" { 
						mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = _b[Het`level'interaction_`instr_aggreg'_`yr'_f`yrFwd'] 
					}
					
					if "`x'" == "intSE" {
						mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = _se[Het`level'interaction_`instr_aggreg'_`yr'_f`yrFwd'] 
					}
					
					if "`x'" == "R" {
						mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = e(r2)
					} 
					
					if "`x'" == "N" {
						mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = e(N)
					}
					
					if "`x'" == "avg" {
						qui su `outcome' if yr_l0 == 1
						mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = r(mean)
					}
					
					if "`x'" == "F" { 
						mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] =  ${F`group'_`outcome'_`short'}
					}

					local i = `i' + 1 				
				} // Levels of the treatment variable 
				
				mat T`instr_aggreg'`shortname'[`level', `col_counter'] = _b[Het`level'interaction_`instr_aggreg'_l0_f`yrFwd']
				mat T`instr_aggreg'`shortname'[`level', `col_counter' + 1] = _se[Het`level'interaction_`instr_aggreg'_l0_f`yrFwd']						

			}
			
			
			local row_counter = `row_counter' + 1 
		
		} //Rows of matrix-- (yr in coefflist )
	} //Outcomes 

	****************************************************************************
	* Exporting coefficients
	****************************************************************************
	foreach outcome in `outcomes' {		
		**** 
		* Matrix to dataset
	    clear
	    svmat `outcome'`instr_aggreg'`group', names(col)

	    * Creating confidence intervals for each estimates
		* Estimates are for no controls, controls, and firm fixed effects
		foreach x in RR int {
			foreach level in `levels' {
				gen `controlname'_lev`level'`x'UB = `controlname'_lev`level'`x'coeff + 1.96*`controlname'_lev`level'`x'SE
				gen `controlname'_lev`level'`x'LB = `controlname'_lev`level'`x'coeff - 1.96*`controlname'_lev`level'`x'SE
			}
		}


		* generating zero values for excluded year - not estimated but extra row included for it
		replace year = 0 - `yrFwd'  if mi(year)
				
		foreach x in RR int {
			foreach type in coeff UB LB {
				foreach level in `levels' {
						replace `controlname'_lev`level'`x'`type' = 0 if year == 0 - `yrFwd'
				}
			}
		}

	    **** Saving dataset with the estimated coefficients
	    save "${resDat}/Heterogeneity_`outcome'_`instr_aggreg'_`samplename'_Spec`controlname'`hetergroup'`level'.dta", replace

			  			    
		} // Outcome	    	
				
restore
end 
				
				
				

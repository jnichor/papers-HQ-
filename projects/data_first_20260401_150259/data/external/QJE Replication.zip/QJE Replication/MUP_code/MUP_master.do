*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						
*===============================================================================


	clear
	set more off
	cap log close
	
*	PLEASE SET LOCATION OF THIS MASTER .DO FILE: 

global home "z:/Archiv-IOEK/FDZ/SETUSERNAME"
cd home

global dta_name "mup_status"


* Set Paths

global dofiles ${home}/Code
global data ${home}/Data
global temp ${data}/Temp
global log ${home}/Logs
global fig ${home}/Figures
global results ${home}/Results
global tables ${home}/Tables
	

adopath ++ "${dofiles}"
adopath ++ "${dofiles}/ado"

graph set window fontface "Verdana"

cd "${dofiles}"
set scheme KMA

* Set Globals
global end_year = 2017
global start_year = 1992
global time_horizon = 20
global bw_standard = 2*365
global min_incorporation = 1990
global max_incorporation = 1999


* Survival Analysis
do MUP_Prepare_Survival.do
do MUP_Analysis_Survival.do


* McCrary Test 
do MUP_Analysis_Mccrary.do


* Industry Composition
do MUP_Analysis_IndustryComposition



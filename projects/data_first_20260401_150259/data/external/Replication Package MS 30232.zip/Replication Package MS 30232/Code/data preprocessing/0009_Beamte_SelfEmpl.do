********************************************************************************
* 0009_Beamte_SelfEmpl.do 
* cleans stammdaten
* identifies beamte (civil servants), self-employed to later exclude
* Input: Austria Stammdaten, Qual-Files
* Output: stammdaten.dta, 0009_Beamte_SelfEmpl.dta (keep Beamte)
********************************************************************************


//// set globals
global ASSD /home/data/group_zweim/daten/Austria/ASSD2016
global REV /home/data/group_zweim/daten/Austria/REV2008
global UIF /home/data/group_zweim/pruh/Projekte/UIFirms
global dofiles $UIF/dofiles
global data $UIF/data
global temp $UIF/temp
global script /home/data/group_zweim/pruh/daten/utilities
cd $temp


//// prepare individual data
use $ASSD/stammdaten/stammdaten.dta, clear
bysort svnr (gueltig_von): keep if _n==_N
save $temp/stammdaten.dta, replace


//// identify beamte and self-employed
clear
g svnr = .
save $data/0009_Beamte_SelfEmpl.dta, replace
set more off
forvalues q = 1/40 {

	global q = `q'
	use $ASSD/qualifikation/qual_$q.dta, clear
	
	* keep beamte
	#d ;
	keep if 
	qual == "BB" |	/* Vollversicherung aufgrund mehrfacher geringfügiger Beschäftigung nach dem B-KUVG - Beamter/in bzw. Mandatar/in */
	qual == "J1" |	/* Pflichtversicherung als öffentlich Bediensteter */
	qual == "J8" |	/* Pflichtversicherte nach dem B-KUVG - § 4 Versicherte */
	qual == "J9" |	/* Pflichtversicherung nach dem B-KUVG, §1/1/8 - 11 B-KUVG ('Politiker') */
	qual == "JA" |	/* PV-Pflichtversicherung als Bundesbeamter/in */
	qual == "JN" |	/* PV-Pflichtversicherung als Beamter/in bei den ÖBB */

	/* neue qual */
	qual == "J4" | /* Pflichtversicherung in der Krankenversicherung als Antragsbeamter(in) des Bundes gem. ¤136 b BDG */
	qual == "JB" | /* PV-Pflichtversicherung als Landeslehrer/in */
	qual == "JC" | /* PV-Pflichtversicherung als Beamter/in bei der Post AG */
	qual == "JD" | /* PV-Pflichtversicherung als Beamter/in bei der Telekom Austria AG */
	qual == "JE" | /* PV-Pflichtversicherung als Beamter/in bei der Postbus AG */
	qual == "JF" | /* PV-Pflichtversicherung aufgrund einer Beschäftigung beim Bundestheaterverband */
	qual == "JH" | /* PV-Pflichtversicherung als Landesbeamter/in */
	qual == "JV" ; /* PV-Pflichtversicherung als Antragsbeamter(in) des Bundes gem. ¤136 b BDG */
	#d cr
	
	bysort svnr: keep if _n==1
	keep svnr svnrklasse
	
	compress
	
	append using $data/0009_Beamte_SelfEmpl.dta
	save $data/0009_Beamte_SelfEmpl.dta, replace

}

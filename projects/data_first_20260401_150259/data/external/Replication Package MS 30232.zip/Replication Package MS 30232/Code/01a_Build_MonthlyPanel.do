
/*******************************************************************************


	DESCRIPTION: Creates worker-month panel from month files built out of the ASSD qual files.
		Creates variables for which all 12 months are needed but order is not important
		Then saves a "spell data file" of all worker-months from 1972 to 2015 but fewer
		variables, which is used to construct variables in subsequent files.
		Code is run on each gender separately.


*******************************************************************************/




********************************************************************************
***** Preliminaries
********************************************************************************
set more off

***** Logging
cap log close
local curr_date = c(current_date)
log using "${logs}/01a_Build_MonthlyPanel`curr_date'", replace




********************************************************************************
***** Looping over males and females separately -- avoids memory issues
********************************************************************************
foreach sex_sample in $sexSamples {


***** Sex indicators
if "`sex_sample'" == "male" {
	local frau_ind = 0
}
else {
	local frau_ind = 1
}



****************************************************************************
* Looping over different year subsets -- avoids memory issues
****************************************************************************
foreach yr_range in $yrRanges {

	local year_st = ${start`yr_range'}
	local year_end = ${end`yr_range'}




	****************************************************************************
	* Loading and appending monthly files
	****************************************************************************
	***** loop over points in time, select sample and collect in one file
	forvalues y = `year_st'/`year_end' {
		forvalues m = $month_start/$month_end {

			**** loading panel
			display("Preparing data for year `y', month `m'")
			use svnr benr status frau refage whitecoll tenure exp10 exp25 ///
				year dearnings eREBP bg_euro sz_euro ///
				using ${data}/0010_panelBal_year`y'_month`m'.dta ///
				if frau == `frau_ind' & inrange(refage, ${start_age}, ${end_age}), clear

			gen byte month = `m'
			replace year = `y' if mi(year) // Individuals with status = 20 are missing the year variable.

			* Timesetting the data
			gen date = mdy(month,1,year)
			gen m_date = mofd(date)
			drop date month
			format m_date %tm


			*labelling the Variables
			label define status 3 "employed" 2 "sick" 1 "unemployed" 4 "retired: old-age" 5 "retired: disability" ///
		 										6 "self-employed" 7 "civil servants" 8 "parental leave" 9 "other" ///
												10 "minor employment" 20 "missing status", replace

			label var frau "1 if female"
			label var refage "reference age in days (current date minus birthdate)/(365.25)"

			***** Loading on individual-location -- only used for REBP residence
			if inrange(`y',1987,2010) { // Only have the ams_gkz files after 1987

				* get location of residence
				fmerge 1:1 svnr using ${data}/ams_gkz_`y'_`m'.dta, keep(1 3) nogen keepusing(gkz)

				* define rebp region
				replace gkz = 90001 if gkz>=90000 & gkz<.
				fmerge m:1 gkz using ${data}/rebp_gkzunique2.dta, keepusing(kr_arba) keep(1 3) nogen
				drop gkz
				rename kr_arba rebp_residence
			}

			compress
			save "$temp/01_tempMonthData_`y'_`m'.dta", replace
		} // m
	} // y


	***** Append all monthly files together
	clear
	set obs 1
	gen byte filler = 1

	forvalues y = `year_st'/`year_end' {
		forvalues m = $month_start/$month_end { // Every month of the year
			display("Appending data for year `y', month `m'")
			append using $temp/01_tempMonthData_`y'_`m'.dta
			erase $temp/01_tempMonthData_`y'_`m'.dta
		}
	}

	drop if filler == 1
	drop filler




	****************************************************************************
	* Merging on firm-level variables
	****************************************************************************

	* determine REBP-elegibility by geography from place of work. Use last place of work if not employed
	fmerge m:1 benr using ${data}/0012_dg.dta, keepusing(gkz rebp industry_15 nace08) keep(1 3) nogen
	if `year_end' >= 1987 {
		replace rebp = rebp_residence if rebp==.
		drop rebp_residence
	}

	* Rename to make sure we don't confuse the residence variable with the place of work variable
	rename gkz gkz_work




	****************************************************************************
	* Defining variables that depend on all 12 observations per year
	****************************************************************************


	***** Generating indicators for employed the whole year and part of the year
	bysort svnr year: gegen mth_emp = sum(status == 3)
	assert !mi(mth_emp)

	***** Generating the number of months each year sick, unemployed, and nonemployed
	* Sick leave
	gen byte sick = status == 2
	bysort svnr year: gegen mth_sick = sum(sick)

	* unemployment
	gen byte UE = status == 1
	bysort svnr year: gegen mth_UE = sum(UE)

	* non-employment
	gen byte non_emp = status != 3
	bysort svnr year: gegen mth_non_emp = sum(non_emp)

	drop sick UE non_emp



	***** Variables related to the earnings concepts
	* Get duration (number of days employed at each spell)
	gen duration = (bg_euro + sz_euro)/dearnings

	* Daily measures of bg and sz payments
	gen dbg_euro = bg_euro / duration
	gen dsz_euro = sz_euro / duration

	* Generating average earnings over the year
	bysort svnr year: gegen avg_dearnings = mean(dearnings)
	bysort svnr year: gegen avg_dbg_euro = mean(dbg_euro)
	bysort svnr year: gegen avg_dsz_euro = mean(dsz_euro)


	**** Some earnings checks
	assert abs(dbg_euro + dsz_euro - dearnings) < 1 if !mi(duration)
	assert mi(dearnings) if mi(bg_euro) | mi(sz_euro)
	assert dearnings == 0 if bg_euro == 0 & sz_euro == 0


	* Replace any firm ID to missing when non-employed
	gen benr_temp = benr
	replace benr_temp = "" if status != 3

	compress
	save ${temp}/01_Temp_MonthFiles_`sex_sample'_`year_st'_`year_end'.dta, replace

} // Different year ranges




****************************************************************************
* Pull variables needed to make employment spell variables in next section
****************************************************************************
foreach yr_range in $yrRanges {
	use svnr m_date status benr_temp dearnings using $temp/01_Temp_MonthFiles_`sex_sample'_${start`yr_range'}_${end`yr_range'}.dta, clear
	tempfile forspell_${start`yr_range'}_${end`yr_range'}
	save `forspell_${start`yr_range'}_${end`yr_range'}', replace
}


***** Appending together files with just the spell variables
clear
set obs 1
gen filler = 1

foreach yr_range in $yrRanges {
	append using "`forspell_${start`yr_range'}_${end`yr_range'}'"
	erase "`forspell_${start`yr_range'}_${end`yr_range'}'"
}

drop if filler == 1
drop filler




****************************************************************************
* Splitting data into two subsamples and spell-level analysis
****************************************************************************


***** Splitting dataset into two subsets by svnr to deal with memory issues
su svnr, d
local medianperson = r(p50)
gen byte group = svnr < `medianperson'

tempfile bigfile
save `bigfile', replace


***** Looping through two subsets of the data
foreach group in 1 2 {

	if `group' == 1 {
		local grprestriction group == 1
	}
	if `group' == 2 {
		local grprestriction group == 0
	}

	use svnr m_date status benr_temp group dearnings using "`bigfile'" if `grprestriction', clear
	drop group

	xtset svnr m_date


	***** Replacing one month of sickness surrounded by employment as employed
	bysort svnr (m_date): replace benr_temp = benr_temp[_n - 1]  if ///
	/* Currently sick */ status == 2 ///
	/* Employed in the previous and next month */ & status[_n - 1] == 3 & status[_n + 1] == 3 ///
	/* Same emp in the previous and next month */ & benr_temp[_n - 1] == benr_temp[_n + 1]

	* Replacing one month of being sick surrounded by employment at the same employer as employment
	gen byte status_temp = status
	bysort svnr (m_date): replace status_temp = 3 if ///
	/* Currently sick */ status_temp == 2 ///
	/* Employed in the previous and next month */ & status_temp[_n - 1] == 3 & status_temp[_n + 1] == 3 ///
	/* Same emp in the previous and next month */ & benr_temp[_n - 1] == benr_temp[_n + 1]


	***** Replace firm of employment if on parental leave and return to old firm.
	bys svnr (m_date): carryforward benr_temp, gen(lastfirm)
	gen negdate = -m_date
	bys svnr (negdate): carryforward benr_temp, gen(nextfirm)
	drop negdate

	replace benr_temp = lastfirm if ///
	/* Currently on parental leave */ status == 8 & ///
	/* Employed in same firm before and after */ lastfirm == nextfirm

	replace status_temp = 3 if ///
	/* Currently on parental leave */ status_temp == 8 & ///
	/* Employed in same firm before and after */ lastfirm == nextfirm

	***** balancing the panel -- Note this only balances the spell data
		* The December files used below are not balanced
		* This same balancing is introduced 01e when we merge these together
	tsfill
	replace status = 20 if status == .
	replace status_temp = 20 if status_temp == .




	compress
	save ${temp}/01_SpellData_`sex_sample'_Group`group'.dta, replace

}




****************************************************************************
* Saving subsets of data that only include the observations from December each year
****************************************************************************
foreach yr_range in $yrRanges {
	use $temp/01_Temp_MonthFiles_`sex_sample'_${start`yr_range'}_${end`yr_range'}.dta if month(dofm(m_date)) == 12, clear
	compress
	save ${temp}/01_December_`sex_sample'_${start`yr_range'}_${end`yr_range'}.dta, replace
	erase $temp/01_Temp_MonthFiles_`sex_sample'_${start`yr_range'}_${end`yr_range'}.dta
}

} // Sex samples


log close

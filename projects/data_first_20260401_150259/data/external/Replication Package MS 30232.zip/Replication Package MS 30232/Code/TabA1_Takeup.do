/*******************************************************************************

	DESCRIPTION: Table A.1

*******************************************************************************/


********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
cap file close fh
local curr_date = c(current_date)
log using "${logs}/Table_Takeup`curr_date'", replace

********************************************************************************

global days 1

	use $temp/04c_Takeup_Days${days}.dta if inrange(year,1972,2000), clear


	*Drop UI spells. We know if the spell had UI because of the UI variable above.
	drop if status == 11

	* missing UI only if last spell OR if go from E spell into O spell
	drop if mi(UI)

	* missing Ndur only if last spell in the data (i.e. if you never are observed going back to employment)
	drop if mi(Ndur)

	* Drop if no nonemployment spells
	drop if Ndur == 0

	* BASE SAMPLE: prime age, employed at least a year, not recalled
	keep if inrange(refage,25,54) & ///
	recalled == 0 & ///
	Edur >= 365

	* Total count
	count
	local total : di %15.0fc r(N)

	* All spells
	qui su UI
	local mean1 : di %5.3f `r(mean)'
	local diff1 : di %15.0fc r(N)
	local lab1 "All Spells"

	* Spells shorter than 2 years
	qui su UI if Ndur <= 2*365
	local mean2 : di %5.3f `r(mean)'
	local diff2 : di %15.0fc r(N)
	local lab2 "2 Years or Shorter"

	* Spells longer than 2 days
	qui su UI if Ndur >= 2
	local mean3 : di %5.3f `r(mean)'
	local diff3 : di %15.0fc r(N)
	local lab3 "2 Days or Longer"

	* Spells >= 28 days
	qui su UI if Ndur >= 28
	local mean4 : di %5.3f `r(mean)'
	local diff4 : di %15.0fc r(N)
	local lab4 "28 Days or Longer"

	* Spells between 28 days and 2 years
	qui su UI if inrange(Ndur, 28, 2*365)
	local mean5 : di %5.3f `r(mean)'
	local diff5 : di %15.0fc r(N)
	local lab5 "Between 28 Days and 2 Years"

	* Men
	qui su UI if frau == 0
	local mean6 : di %5.3f `r(mean)'
	local diff6 : di %15.0fc r(N)
	local lab6 "Men"

	* Women
	qui su UI if frau == 1
	local mean7 : di %5.3f `r(mean)'
	local diff7 : di %15.0fc r(N)
	local lab7 "Women"

	* Blue Collar
	qui su UI if whitecoll == 0
	local mean8 : di %5.3f `r(mean)'
	local diff8 : di %15.0fc r(N)
	local lab8 "Blue Collar"

	* White Collar
	qui su UI if whitecoll == 1
	local mean9 : di %5.3f `r(mean)'
	local diff9 : di %15.0fc r(N)
	local lab9 "White Collar"

	* Prime Age
	qui su UI if inrange(refage, 25, 49)
	local mean10 : di %5.3f `r(mean)'
	local diff10 : di %15.0fc r(N)
	local lab10 "Excluding Ages 50-54"

	* Recalled
	qui su UI if recalled == 1
	local mean11 : di %5.3f `r(mean)'
	local diff11 : di %15.0fc r(N)
	local lab11 "Recalled"

	* Not Recalled
	qui su UI if recalled == 0
	local mean12 : di %5.3f `r(mean)'
	local diff12 : di %15.0fc r(N)
	local lab12 "Not Recalled"

	* Employed for at least 2 years
	qui su UI if Edur >= 365
	local mean14 : di %5.3f `r(mean)'
	local diff14 : di %15.0fc r(N)
	local lab14 "Employed At Least 1 Year"

	* Employed for at least 2 years
	qui su UI if Edur >= 2*(365)
	local mean15 : di %5.3f `r(mean)'
	local diff15 : di %15.0fc r(N)
	local lab15 "Employed At Least 2 Years"

	* Employed for at least 2 years, NE spell between 28 days and 2 years
	qui su UI if Edur >= 365 & inrange(Ndur, 28, 2*365)
	local mean16 : di %5.3f `r(mean)'
	local diff16 : di %15.0fc r(N)
	local lab16 "Employed $\geq$ 1 Yr"

	* Employed for at least 2 years, NE spell between 28 days and 2 years
	qui su UI if Edur >= 2*(365) & inrange(Ndur, 28, 2*365)
	local mean17 : di %5.3f `r(mean)'
	local diff17 : di %15.0fc r(N)
	local lab17 "Employed At Least 2 Years"

	* Recalled, NE spell between 28 days and 2 years
	qui su UI if recalled == 1 & inrange(Ndur, 28, 2*365)
	local mean18 : di %5.3f `r(mean)'
	local diff18 : di %15.0fc r(N)
	local lab18 "Recalled"

	* Not Recalled
	qui su UI if recalled == 0 & inrange(Ndur, 28, 2*365)
	local mean19 : di %5.3f `r(mean)'
	local diff19 : di %15.0fc r(N)
	local lab19 "Not Recalled"

	* Prime Age
	qui su UI if inrange(refage, 25, 49) & inrange(Ndur, 28, 2*365)
	local mean20 : di %5.3f `r(mean)'
	local diff20 =  r(N)
	local lab20 "Excluding Ages 50-54"

	* Prime Age
	qui su UI if inrange(refage, 25, 54) & Edur >= 2*(365) & inrange(Ndur, 28, 2*365)
	local mean21 : di %5.3f `r(mean)'
	local diff21 : di %15.0fc r(N)
	local lab21 "Prime Age, E $\geq$ 2 Yrs"

	* Prime Age
	qui su UI if frau == 0  & inrange(Ndur, 28, 2*365)
	local mean22 : di %5.3f `r(mean)'
	local diff22 : di %15.0fc r(N)
	local lab22 "Male"

	* Prime Age
	qui su UI if frau == 0  & inrange(Ndur, 28, 2*365) & inrange(refage, 25,49)
	local mean23 : di %5.3f `r(mean)'
	local diff23 : di %15.0fc r(N)
	local lab23 "Male Under 50"

	* Not Recalled, Emp > 2 Yrs, Not recalled
	qui su UI if frau == 1  & inrange(Ndur, 28, 2*365)
	local mean24 : di %5.3f `r(mean)'
	local diff24 : di %15.0fc r(N)
	local lab24 "Female"

	* Not Recalled, Emp > 2 Yrs, Not recalled
	qui su UI if frau == 1  & inrange(Ndur, 28, 2*365) & inrange(refage, 25,49)
	local mean25 : di %5.3f `r(mean)'
	local diff25 : di %15.0fc r(N)
	local lab25 "Female Under 50"

	* Only count formal employment into NE
	qui su UI if Ndur >= 14
	local mean27 : di %5.3f `r(mean)'
	local diff27 : di %15.0fc r(N)
	local lab27 "14 Days or Longer"

	* Only count formal employment into NE
	qui su UI if inrange(Ndur,28,2*365) & whitecoll == 0
	local mean28: di %5.3f `r(mean)'
	local diff28 : di %15.0fc r(N)
	local lab28 "Blue Collar"

	* Only count formal employment into NE
	qui su UI if inrange(Ndur,28,2*365) & whitecoll == 1
	local mean29: di %5.3f `r(mean)'
	local diff29 : di %15.0fc r(N)
	local lab29 "White Collar"

	file open fh using $tables/TabA1_Takeup.tex, write replace
	file write fh "\begin{tabular}{l c c }" _n "\hline\hline" _n " & & \\" _n " & Prop. of NE Spells & No. Spells\\" _n "\hline" _n " & & \\" _n
	foreach i in 1 2 3 27 4 5 6 7 8 9 10 15 {
		file write fh "`lab`i'' & `mean`i'' & `diff`i'' \\" _n
	}
	file write fh " & & \\" _n "\textbf{Spells between 28 Days and 2 Years} & \\" _n
	foreach i in 22 23 24 25 28 29 20 17 {
		file write fh "\hspace{0.5cm} `lab`i'' & `mean`i'' & `diff`i'' \\" _n
	}
	file write fh " & & \\" _n "\hline\hline" _n "\end{tabular}" _n
	file close fh

log close

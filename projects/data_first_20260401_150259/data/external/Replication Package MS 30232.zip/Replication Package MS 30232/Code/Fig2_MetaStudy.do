/*******************************************************************************

	DESCRIPTION: Creates figure 2: the meta study on worker bargaining power

*******************************************************************************/

import excel "${userData}/meta_study.xlsx", sheet("Table 1") firstrow clear

gen ci_lo = beta - 1.96*se
gen ci_hi = beta + 1.96*se
replace ci_hi = 1 if position>=31&ci_hi>1
replace beta = 1 if beta>1&beta!=.&Category=="Outside Options"


replace position = 0 if mi(position)

gen beta_divided_variance = beta/(se)^2
gen variance = 1/se^2
sum beta_divided_variance if Category=="Firm-Level Profit and Indiv. Wage"&(ProfitMeasure==0)
global mean_beta_divided_variance = r(mean)
sum variance if Category=="Firm-Level Profit and Indiv. Wage"&(ProfitMeasure==0)
global mean_variance = r(mean)

gen micro_study_mean = ${mean_beta_divided_variance}/${mean_variance}
global micro_study_mean = round(${mean_beta_divided_variance}/${mean_variance},0.001)
sum micro_study_mean


/// Mean of studies with persistent effects

sum beta_divided_variance if paper=="Card, Cardoso, Heining and Kline (2018), AKM specification"|paper=="Cardoso and Portela (2009), permanent"|paper=="Guiso, Pistaferri, Schivardi (2005)"|paper=="Jäger, Schoefer and Heinig (2019)"
global mean_beta_divided_variance2 = r(mean)
sum variance if paper=="Card, Cardoso, Heining and Kline (2018), AKM specification"|paper=="Cardoso and Portela (2009), permanent"|paper=="Guiso, Pistaferri, Schivardi (2005)"|paper=="Jäger, Schoefer and Heinig (2019)"
global mean_variance2 = r(mean)

gen persistent_study_mean = ${mean_beta_divided_variance2}/${mean_variance2}
global persistent_study_mean = round(${mean_beta_divided_variance2}/${mean_variance2},0.001)
sum persistent_study_mean

///



graph twoway ///
(line micro_study_mean position if Category=="Firm-Level Profit and Indiv. Wage", lcolor(red)  lpattern(dash) lwidth(thin)) ///
(scatter beta position if position<31, msize(small) mcolor(navy) msymbol(o))    ///
(scatter beta position if position>=31, msize(small) mcolor(green) msymbol(o) )   ///
(rcap ci_lo ci_hi position if position>=-1&position < 31, lcolor(navy)), ///
xlabel(-8 "Shimer (2005)" ///
-7 "Hagedorn and Manovskii (2008)" ///
-6 "Chodorow-Reich et al. (2017)" ///
-5 "Christian, Eichenbaum and Trabandt (2017)" ///
-4 "Gertler and Trigari (2009)" ///
-3 "Pissarides (2009)" ///
-1 "Christofides and Oswald (1992)" ///
0 "Blanchflower, Oswald, Sanfey (1996)" ///
1 "Estevao and Tevlin (2003): profits" ///
2 "Estevao and Tevlin (2003): value-added" ///
4 "Our Study: Rent-Sharing Austria" ///
5 "Abowd and Lemieux (1993)" ///
6 "Van Reenen (1996)" ///
7 "Hildreth and Oswald (1997)" ///
8 "Hildreth (1998)" ///
9 "Barth, Davis and Freeman (2014)" ///
11 "Margolis and Salvanes (2001), France" ///
12 "Margolis and Salvanes (2001), Norway" ///
13 "Arai (2003)" ///
14 "Guiso, Pistaferri, Schivardi (2005), permanent" ///
15 "Fakhfakf and FitzRoy (2004)" ///
16 "Caju, Rycx and Tojerow (2009)" ///
17 "Martins (2009)" ///
18 "Guertzgen (2009)" ///
19 "Cardoso and Portela (2009), permanent" ///
20 "Card, Cardoso, Heining and Kline (2018), AKM specification" ///
21 "Arai and Hayman (2009)" ///
22 "Card, Devicienti and Maida (2014)" ///
23 "Carlsson, Messina and Skans (2014)" ///
24 "Carlsson, Messina and Skans (2014)" ///
25 "Card, Cardoso, Kline (2014), Between Firm" ///
26 "Card, Cardoso, Kline (2014), Stayers" ///
27 "Bagger, Christensen Mortensen (2014), Mfg" ///
28 "Kline, Petkova, Williams and Zidar (2019)" ///
29 "Garin and Silverio (2018)" ///
30 "Jäger, Schoefer and Heining (2019)" ///
32 "Our Study: No Controls, One-Year Horizon" ///
33 "Our Study: Full Controls, One-Year Horizon" ///
34 "Our Study: No Controls, Two-Year Horizon" ///
35 "Our Study: Full Controls, Two-Year Horizon", ///
angle(30) labsize(tiny)) ///
aspect(.33) ///
xtitle("") ytitle("Rent-Sharing Estimates and" "Implied Worker Bargaining Power {&phi}", size(small)) ///
yscale(range(0 1)) ylabel(0(0.2)1) ///
xscale(range(-11 33)) ///
legend(off) ///
graphregion(color(white)) ///
text(1.2 -6 "Macro" "Calibrations", size(vsmall) angle(90)) ///
text(1.2 0.5 "Industry-Level" "Specifications", size(vsmall) angle(90)) ///
text(1.2 6.5 "Firm-Level" "Specifications", size(vsmall) angle(90)) ///
text(1.2 20 "Worker-Level" "Specifications", size(vsmall) angle(90))  ///
text(1.2 33.4 "Bargaining with" "Nonemployment" "Outside Option", color(green) size(vsmall) angle(90)) ///
text(0.3 20 "Average: 0${micro_study_mean}", size(vsmall) color(red) angle(90))

graph export "${figures}/Fig2_meta_study.pdf", replace



graph twoway ///
(line micro_study_mean position if Category=="Firm-Level Profit and Indiv. Wage", lcolor(red)  lpattern(dash) lwidth(thin)) ///
(scatter beta position if position<31, msize(small) mcolor(navy) msymbol(o))    ///
(rcap ci_lo ci_hi position if position>=-1&position<31, lcolor(navy)), ///
xlabel(-8 "Shimer (2005)" ///
-7 "Hagedorn and Manovskii (2008)" ///
-6 "Chodorow-Reich et al. (2017)" ///
-5 "Christian, Eichenbaum and Trabandt (2017)" ///
-4 "Gertler and Trigari (2009)" ///
-3 "Pissarides (2009)" ///
-1 "Christofides and Oswald (1992)" ///
0 "Blanchflower, Oswald, Sanfey (1996)" ///
1 "Estevao and Tevlin (2003): profits" ///
2 "Estevao and Tevlin (2003): value-added" ///
4 "Our Study: Rent-Sharing Austria" ///
5 "Abowd and Lemieux (1993)" ///
6 "Van Reenen (1996)" ///
7 "Hildreth and Oswald (1997)" ///
8 "Hildreth (1998)" ///
9 "Barth, Davis and Freeman (2014)" ///
11 "Margolis and Salvanes (2001), France" ///
12 "Margolis and Salvanes (2001), Norway" ///
13 "Arai (2003)" ///
14 "Guiso, Pistaferri, Schivardi (2005), permanent" ///
15 "Fakhfakf and FitzRoy (2004)" ///
16 "Caju, Rycx and Tojerow (2009)" ///
17 "Martins (2009)" ///
18 "Guertzgen (2009)" ///
19 "Cardoso and Portela (2009), permanent" ///
20 "Card, Cardoso, Heining and Kline (2018), AKM specification" ///
21 "Arai and Hayman (2009)" ///
22 "Card, Divincienti and Maida (2014)" ///
23 "Carlsson, Messina and Skans (2014)" ///
24 "Carlsson, Messina and Skans (2014)" ///
25 "Card, Cardoso, Kline (2014), Between Firm" ///
26 "Card, Cardoso, Kline (2014), Stayers" ///
27 "Bagger, Christensen Mortensen (2014), Mfg" ///
28 "Kline, Petkova, Williams and Zidar (2017)" ///
29 "Garin and Silverio (2018)" ///
30 "Jäger, Schoefer and Heining (2019)", ///
angle(30) labsize(tiny)) ///
aspect(.33) ///
xtitle("") ytitle("Rent-Sharing Estimates and" "Implied Worker Bargaining Power {&phi}", size(small)) ///
yscale(range(0 1)) ylabel(0(0.2)1) ///
xscale(range(-11 33)) ///
legend(off) ///
graphregion(color(white)) ///
text(1.2 -6 "Macro" "Calibrations", size(vsmall) angle(90)) ///
text(1.2 0.5 "Industry-Level" "Specifications", size(vsmall) angle(90)) ///
text(1.2 6.5 "Firm-Level" "Specifications", size(vsmall) angle(90)) ///
text(1.2 20 "Worker-Level" "Specifications", size(vsmall) angle(90))  ///
text(0.3 20 "Avg.: 0${micro_study_mean}", size(vsmall) color(red) angle(90))

graph export "${figures}/meta_study_omitting_our_estimates.pdf", replace

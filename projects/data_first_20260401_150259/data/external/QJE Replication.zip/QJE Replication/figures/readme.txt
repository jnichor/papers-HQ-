*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*							2020-20-08
*===============================================================================

This folder will contain the figures in the paper after running  the
'exhibits' do files.

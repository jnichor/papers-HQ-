/*******************************************************************************

	DESCRIPTION: Construct worker-year panel of workers based on ages
		and years for the PBD extension reform in 1989.



*******************************************************************************/

****************************************************************************
***** Preliminaries
****************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/05a_PBDExtension_Build`curr_date'", replace


****************************************************************************
* Treatment and control parameters
****************************************************************************
* Control start and end ages
local cnt_start = 35
local cnt_end = 38

* Treatment start and end ages
local treat_start = 39
local treat_end = 42

* Weeks of experience in the past 10 years required to be eligible for
local exp_weeks = 312

* Year to normalize treatment efect equal to zero for
local excld_yr = 1987

* Starting and ending years
local start_yr = 1983
local end_yr = 1989


****************************************************************************
* Loading data, defining treatment, and sample restrictions
****************************************************************************

	use ${temp}/02b_Reform1989.dta if inrange(year, `start_yr', `end_yr'), clear

	gen age_round = floor(refage)
	replace exp10 = exp10/365 // exp10 from days to years

	**** Sample restrictions
	keep if inrange(age_round, `cnt_start', `treat_end') // Only keeping treat + cont
	keep if exp10>=312/52 //Eligible for the experience requirement
	drop if inlist(rebp, 1, 2) // Dropping REBP regions
	keep if mth_emp == 12 // Keeping the stable worker sample

	**** Defining the REBP control
	gen REBPcontrol = rebp != 0 & eREBP == 1 & year >= 1988

	**** Treatment definitions
	gen PBD_treated = inrange(age_round, `treat_start', `treat_end')

	compress
	save ${temp}/05a_DataSet.dta, replace

log close

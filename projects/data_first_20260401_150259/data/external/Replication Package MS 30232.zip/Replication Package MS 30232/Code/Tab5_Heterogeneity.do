/*******************************************************************************

	DESCRIPTION: Table 5 Heterogeneity

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/Table_Heterogeneity`curr_date'", replace

clear all
cap file close fh

**** Number of years to plot
local yrFwdLst 1 2

**** Different groups of heterogeneity cut variables to plot
local groupsTab ueFiller /*indocc_mth_UE_grp*/ indocc_unemp_grp UE_grp UI_grp nonemp_grp ///
	            firmFiller lom_ind_growth_grp AKMfirm_grp  wage_growth_SD_grp  CBA_residuals_SD_grp firmshNonemp_grp ///
	            indFiller tenure_grp age_grp gender_grp occ_grp

****************************************************************************
* Heterogeneity Sets
****************************************************************************
qui foreach hetergroup in `groupsTab' {

	**** Filler categories to separate the heterogeneity sets
		* All load the same empty dataset
	if substr("`hetergroup'",1,4) == "fill"  | inlist("`hetergroup'", "indFiller", "firmFiller", "switchFiller","ueFiller") {
		local D`hetergroup' FillerData_grp
	}

	else {
		local D`hetergroup' `hetergroup'
	}
}

****************************************************************************
* Pulling in the heterogeneity results datasets
****************************************************************************

clear
set obs 1
gen filler = 1

qui foreach yrFwd in `yrFwdLst' {

	* Currently set up so the one-year forward results pulls the with 76 results
	* and the two-year forward results don't include 76
	if `yrFwd' == 1 {
		local string76 With76
	}
	else {
		local string76 With76
	}

	* Resetting parameters and locals for each figure
	local labels ""
	local statement ""
	local ylines_dashed ""
	local ylines_solid ""
	local order ""


	****************************************************************************
	* Defining n - location of plotted datapoints and separating lines
		* Most groups only plot main label
		* job to job plot three different labels
		* gender and occupation - plot two labels
	****************************************************************************

	foreach hetergroup in `groupsTab' {

	if inlist("`hetergroup'", "indFiller", "firmFiller", "switchFiller","ueFiller") {
	}
	else {
			noi append using "$resDat/Heterogeneity_earn_Diff_f`yrFwd'_earn_pct_`string76'_stable_Specctrls`D`hetergroup''.dta", gen(`hetergroup'_`yrFwd')
			noi di "$resDat/Heterogeneity_earn_Diff_f`yrFwd'_earn_pct_`string76'_stable_Specctrls`D`hetergroup''.dta"
		}

	}
} // Years Forward List

drop if filler == 1
drop filler

gen n = 0
local n
local i = 0
qui foreach yrFwd in `yrFwdLst' {
foreach hetergroup in `groupsTab' {

if inlist("`hetergroup'", "indFiller", "firmFiller", "switchFiller","ueFiller") {
}
else {
	local ++i
	replace n = `i' if `hetergroup'_`yrFwd' == 1
	local n `n' `i' `"`hetergroup'_`yrFwd'"'
}
}
}

label define n `n'
label values n n

drop *grp*

local suffix RRcoeff RRSE intcoeff intSE R N F avg RRUB RRLB intUB intLB
local long
foreach suff in `suffix' {
	local long `long' ctrls_lev@`suff'
}

reshape long `long'  , i(year n) j(heteroGrp)

dec n, gen(n_str)
flevelsof n_str, local(hetgroups)
foreach het in `hetgroups' {
	gen `het' = n_str == "`het'"
}

keep if year == 0

rename (*UB *LB) (*_1 *_2)

drop if heteroGrp > 2 & (strpos(n_str,"gender_grp") > 0 | strpos(n_str,"occ_grp") > 0)
drop if heteroGrp > 4 & (strpos(n_str,"UE_grp") > 0 & strpos(n_str,"indocc") == 0)

****************************************************************************
* Writing tex file
****************************************************************************
file open fh using "$tables/Tab5_Heterogeneity.tex", write replace

**** Writing preamble
file write fh "\begin{tabular}{l c c c c}" _n
file write fh "\hline \hline" _n
file write fh "\textit{Horizon} & \multicolumn{2}{c}{1-Year Effects} & \multicolumn{2}{c}{2-Year Effects} \\  \cmidrule(lr){2-3} \cmidrule(lr){4-5}" _n
 file write fh "\textit{Quintile} & $1^{st}$ (Lowest) & $5^{th}$ (Highest) & $1^{st}$ (Lowest) & $5^{th}$ (Highest) \\" _n
file write fh "\hline" _n
file write fh " &  &  &  & \\" _n

**** Writing het group specific results
qui foreach hetergroup in `groupsTab' {

	* Writing code for filler rows
	if strpos("`hetergroup'","Filler") {
		if "`hetergroup'" == "ueFiller" {
			local boldTxt "Unemployment Risk"
		}
		else if "`hetergroup'" == "firmFiller" {
			local boldTxt = "Firm Characteristics"
		}
		else if "`hetergroup'" == "indFiller" {
			local boldTxt = "Worker Characteristics"
		}

		if "`boldTxt'" == "Unemployment Risk" {
			file write fh "\vspace{-.7cm} \\" _n
			file write fh "\vspace{5pt} \textbf{`boldTxt'} & &  &  & \\" _n
		}
		else {
			file write fh "\hline \\" _n
			file write fh "\vspace{-.7cm} \\" _n
			file write fh "\vspace{5pt} \textbf{`boldTxt'} & &  &  & \\" _n
		}
	}
	* Writing code for the results rows
	else {

		* Category Labels
		if "`hetergroup'" == "indocc_mth_UE_grp" {
			local catLab "Industry Months UE"
		}
		else if "`hetergroup'" == "indocc_unemp_grp" {
			local catLab "Industry EU Transition Rate"
		}
		else if "`hetergroup'" == "UE_grp" {
			local catLab "Local Unemployment Rate"
		}
		else if "`hetergroup'" == "UI_grp"  {
			local catLab "Months since UI Receipt"
		}
		else if "`hetergroup'" == "nonemp_grp"  {
			local catLab "Months since Non-Emp."
		}
		else if "`hetergroup'" == "lom_ind_growth_grp" {
			local catLab "Industry Growth Rate"
		}
		else if "`hetergroup'" == "AKMfirm_grp" {
			local catLab "Wage Premium (AKM FE)"
		}
		else if "`hetergroup'" == "wage_growth_SD_grp" {
			local catLab "SD of Earnings Growth"
		}
		else if "`hetergroup'" == "CBA_residuals_SD_grp" {
			local catLab "Wage Distance from CBA Floor (Proxy)"
		}
		else if "`hetergroup'" == "firmshNonemp_grp"  {
			local catLab "Share Non-Emp Last 2 Yrs"
		}
		else if "`hetergroup'" == "tenure_grp" {
			local catLab "Tenure"
		}
		else if "`hetergroup'" == "gender_grp" {
			local catLab "Gender: Male (left) / Female (right)"
		}
		else if "`hetergroup'" == "age_grp" {
			local catLab "Age"
		}
		else if "`hetergroup'" == "occ_grp" {
			local catLab "Occupation: Blue (left) / White Collar (right)"
		}

		*file write fh "\underline{`catLab'} &  &  &  &  \\" _n

		**** Number of categories for each het group
		su heteroGrp if `hetergroup'_1 == 1
		local numGrps = r(max)

		if "`hetergroup'" == "gender_grp" {
			local lab1 "Male"
			local lab2 "Female"
		}
		else if "`hetergroup'" == "occ_grp" {
			local lab1 "Blue"
			local lab2 "White"
		}
		else {
			if `numGrps' == 4 {
				local lab1 "First Quartile"
				local lab2 "Fourth Quartile"
			}
			else if `numGrps' == 5 {
				local lab1 "First Quintile"
				local lab2 "Fifth Quintile"
			}
		}

		local display %5.3f

		**** One-year lowest category
		foreach yrFwd in $earnF {
		su ctrls_levintcoeff if `hetergroup'_`yrFwd' == 1 & heteroGrp == 1
		local value = round(r(mean), .001)
		local `yrFwd'yr_1stEst_C : di %5.3f `value'

		su ctrls_levintSE if `hetergroup'_`yrFwd' == 1 & heteroGrp == 1
		local value = round(r(mean), .001)
		local `yrFwd'yr_1stEst_SE : di %5.3f `value'


		su ctrls_levintcoeff if `hetergroup'_`yrFwd' == 1 & heteroGrp == `numGrps'
		local value = round(r(mean), .001)
		local `yrFwd'yr_`numGrps'thEst_C : di %5.3f `value'

		su ctrls_levintSE if `hetergroup'_`yrFwd' == 1 & heteroGrp == `numGrps'
		local value = round(r(mean), .001)
		local `yrFwd'yr_`numGrps'thEst_SE : di %5.3f `value'

		}

		file write fh "`catLab' & `1yr_1stEst_C' \; \; (`1yr_1stEst_SE') & `1yr_`numGrps'thEst_C' \; \; (`1yr_`numGrps'thEst_SE') & `2yr_1stEst_C' \; \; (`2yr_1stEst_SE') & `2yr_`numGrps'thEst_C' \; \; (`2yr_`numGrps'thEst_SE') \\" _n
		file write fh " \vspace{-.3cm} \\" _n

	}
}


**** Writing end of table lines
file write fh "\hline \hline" _n
file write fh "\end{tabular}" _n


file close fh

log close

/*******************************************************************************

	DESCRIPTION: Figure 6 and Figure A.6: Residualized binscatter Plots
	             of Wage Growth and Unemployment Benefit Changes



*******************************************************************************/

********************************************************************************
* Preliminaries
********************************************************************************

set more off
cap log close
set scheme wagebarg, permanently

local curr_date = c(current_date)
log using "${logs}/Fig6-A6_BinScatter`curr_date'", replace

local aggregations earn_pct /*benr nace08*/
local types /*_all*/ _stable /*_stayer _mover _recalled _ENE  _EE _EUE _nonEUE  _shortENE _longENE*/
local include1976 1

********************************************************************************
* Pooled Analysis
********************************************************************************


foreach type in `types' {

	foreach yrFwd in 1 {

	foreach group in `include1976' {

	local main_outcomes earn_Diff_f`yrFwd' /*realizedRRChange_f`yrFwd'*/
	/*local alt_outcomes  mover_f`yrFwd' recalled_f`yrFwd' ENE_f`yrFwd' EUE_f`yrFwd'   ///
	mth_non_emp_f`yrFwd' mth_UE_f`yrFwd' mth_sick_f`yrFwd' */

	local outcomes `main_outcomes' `alt_outcomes'

	if `group' == 0 { // 6 Years back
		local grprestriction inlist(reform, 1985, 1989, 2001)

	}

	if `group' == 1  { // 4 years Back
		local grprestriction inlist(reform, 1976, 1985, 1989, 2001) & inlist(yr_l5,.,0) & inlist(yr_l4,.,0)
		local samplename With76
	}


	foreach suffix in `aggregations' {

		if "`suffix'" == "earn_pct" {
			local cluster svnr earn_pct_bin
		}
		else {
			local cluster `suffix'
		}

		use ${temp}/02c_PooledReforms_yrFwd`yrFwd'.dta if `grprestriction', clear

	* Indicator for REBP eligibility
		gen REBPcontrol = rebp != 0 & eREBP == 1 & reform == 1989 & year >= 1987

		* Generating constant to include in fixed effect regression
		gen const = 1

		* Winsorize earnings outcomes
		winsor2 earn_Diff_f`yrFwd', replace cut(1 99) by(reform year)

		* Keep if employed in December
		keep if status == 3

		if $shorten76and89== 1 {
			*Shorten 1976 and 1989 by 1 pct
			foreach r in 1976 1989 {
				su earn_pct if treatment_`r' == 1
				local min = r(min)
				su earn_pct if control_`r' == 1
				local max = r(max)
				local new_min = `min' + 1
				local new_max = `max' - 1
				drop if reform == `r' & earn_pct <= `new_min' & !mi(earn_pct)
				drop if reform == `r' & earn_pct >= `new_max' & !mi(earn_pct)
			}
		}


		if "`type'" == "_stable" {
			keep if mth_emp == 12
		}

		local short = substr("`type'",2,.)

		if inlist("`type'", "_stayer", "_mover", "_recalled") {
			keep if `short'_f`yrFwd' == 1 & mth_emp == 12
		}

		if inlist("`type'", "_ENE", "_EE", "_EUE") {
			keep if mover_f`yrFwd' == 1 & `short'_f`yrFwd'  == 1 & mth_emp == 12
		}

		if inlist("`type'", "_nonEUE") {
			keep if mover_f`yrFwd' == 1 & EUE_f`yrFwd' == 0 & ENE_f`yrFwd' == 1 & mth_emp == 12
		}

		if inlist("`type'", "_shortENE") {
			keep if mover_f`yrFwd' == 1 & ENE_f`yrFwd' == 1 & len_NE_premove_f`yrFwd' == 1 & mth_emp == 12
		}

		if inlist("`type'", "_longENE") {
			keep if mover_f`yrFwd' == 1 & ENE_f`yrFwd' == 1 & len_NE_premove_f`yrFwd' > 1 & !mi(len_NE_premove_f`yrFwd')  & mth_emp == 12
		}

		if `group' == 1  {
			drop *_l4_f`yrFwd' *_l5_f`yrFwd' yr_l5 yr_l4
		}


		* Run three specifications

		noi reghdfe earn_Diff_f`yrFwd' RRinstrument_`suffix'_f1 interaction_`suffix'_l*_f`yrFwd', ///
		absorb(reform#year const reform#year#REBPcontrol) vce(cluster svnr earn_pct_bin) // i.year

		foreach k in 0 2 3 {
			local b_spec1_l`k': di %5.3f _b[interaction_`suffix'_l`k'_f`yrFwd']
			local s_spec1_l`k': di %5.3f _se[interaction_`suffix'_l`k'_f`yrFwd']
		}

		noi reghdfe earn_Diff_f`yrFwd' RRinstrument_`suffix'_f1 interaction_`suffix'_l*_f`yrFwd', ///
		absorb(reform#earn_pct_bin reform#year const reform#year#REBPcontrol) vce(cluster svnr earn_pct_bin) // i.reform##i.earn_pct_bin i.year

		foreach k in 0 2 3 {
			local b_spec2_l`k': di %5.3f _b[interaction_`suffix'_l`k'_f`yrFwd']
			local s_spec2_l`k': di %5.3f _se[interaction_`suffix'_l`k'_f`yrFwd']
		}

		noi reghdfe earn_Diff_f`yrFwd' RRinstrument_`suffix'_f1 interaction_`suffix'_l*_f`yrFwd', ///
		absorb(earn_pct_bin#reform const reform#year#REBPcontrol reform#year##c.lnearnings) ///
		 vce(cluster svnr earn_pct_bin) // earn_pct_bin#reform const reform#year#REBPcontrol reform#year##c.lnearnings

		foreach k in 0 2 3 {
			local b_spec3_l`k': di %5.3f _b[interaction_`suffix'_l`k'_f`yrFwd']
			local s_spec3_l`k': di %5.3f _se[interaction_`suffix'_l`k'_f`yrFwd']
		}

		* Create binned scatterplots of each event year

		foreach k in 0 2 3 {

		if `k' == 0 {
			local row 3
		}

		if `k' == 2 {
			local row 2
		}

		if `k' == 3 {
			local row 1
		}

		gen PredWgGrth = interaction_`suffix'_l`k'_f`yrFwd'  * $wageBen

		foreach var in earn_Diff_f`yrFwd' interaction_`suffix'_l`k'_f`yrFwd' PredWgGrth {
			local list
			foreach j in 0 2 3 {
				if `j' == `k' {
				}
				if `j' != `k' {
				local list `list' interaction_`suffix'_l`j'_f`yrFwd'
				}
			}
			reghdfe `var' RRinstrument_`suffix'_f1 `list', ///
			absorb( reform#year const reform#year#REBPcontrol ) resid(r_`var')
		}

		binscatter r_earn_Diff_f`yrFwd' r_PredWgGrth r_interaction_`suffix'_l`k'_f`yrFwd' ///
		if yr_l`k' == 1, reportreg ///
		savegraph(${figures}/Temp.gph) replace ///
		xtitle("Residual: Unemployment Benefit Change (db/w)") ///
		ytitle("Residual: Earnings Change (dw/w)")  ///
		mcolor(sea dkorange) ///
		lcolor(sea dkorange) ///
		msymbol(S none) ///
		ylab(,labsize(medium)) xlab(,labsize(medium)) ///
		legend(order(1 4) size(medium) label(1 "Actual") label(4 "Predicted") pos(6) col(2))

		graph combine ${figures}/Temp.gph, ///
		note("Slope: `b_spec1_l`k'' (`s_spec1_l`k'')")

		local graphname BinScatter_earn_Diff_f`yrFwd'_Yr_L`k'
		if "`graphname'" == "BinScatter_earn_Diff_f1_Yr_L0" {
			local graphname Fig6a_BinScatter
		}
		else if "`graphname'" == "BinScatter_earn_Diff_f1_Yr_L2" {
			local graphname FigA6a_BinScatter
		}
		else if "`graphname'" == "BinScatter_earn_Diff_f1_Yr_L3" {
			local graphname FigA6b_BinScatter
		}
		graph export ${figures}/`graphname'.pdf, replace

		drop r_*

		foreach var in earn_Diff_f`yrFwd' interaction_`suffix'_l`k'_f`yrFwd' PredWgGrth {
			local list
			foreach j in 0 2 3 {
				if `j' == `k' {
				}
				if `j' != `k' {
				local list `list' interaction_`suffix'_l`j'_f`yrFwd'
				}
			}
			reghdfe `var' RRinstrument_`suffix'_f1 `list', ///
			absorb(reform#earn_pct_bin reform#year const reform#year#REBPcontrol ) resid(r_`var')
		}

		binscatter r_earn_Diff_f`yrFwd' r_PredWgGrth r_interaction_`suffix'_l`k'_f`yrFwd' ///
		if yr_l`k' == 1, reportreg ///
		savegraph(${figures}/Temp.gph) replace ///
		xtitle("Residual: Unemployment Benefit Change (db/w)") ///
		ytitle("Residual: Earnings Change (dw/w)")  ///
		mcolor(sea dkorange) ///
		lcolor(sea dkorange) ///
		msymbol(S none) ///
		ylab(,labsize(medium)) xlab(,labsize(medium)) ///
		legend(order(1 4) size(medium) label(1 "Actual") label(4 "Predicted") pos(6) col(2))

		graph combine ${figures}/Temp.gph, ///
		note("Slope: `b_spec2_l`k'' (`s_spec2_l`k'')")

		local graphname BinScatter_earn_Diff_f`yrFwd'_Pct_L`k'
		if "`graphname'" == "BinScatter_earn_Diff_f1_Pct_L0" {
			local graphname Fig6b_BinScatter
		}
		else if "`graphname'" == "BinScatter_earn_Diff_f1_Pct_L2" {
			local graphname FigA6c_BinScatter
		}
		else if "`graphname'" == "BinScatter_earn_Diff_f1_Pct_L3" {
			local graphname FigA6d_BinScatter
		}
		graph export ${figures}/`graphname'.pdf, replace

		drop r_*

		foreach var in earn_Diff_f`yrFwd' interaction_`suffix'_l`k'_f`yrFwd' PredWgGrth {
			local list
			foreach j in 0 2 3 {
				if `j' == `k' {
				}
				if `j' != `k' {
				local list `list' interaction_`suffix'_l`j'_f`yrFwd'
				}
			}
			reghdfe `var' RRinstrument_`suffix'_f1 `list', ///
			absorb(earn_pct_bin#reform const reform#year#REBPcontrol reform#year##c.lnearnings) resid(r_`var')
		}

		binscatter r_earn_Diff_f`yrFwd' r_PredWgGrth r_interaction_`suffix'_l`k'_f`yrFwd' ///
		if yr_l`k' == 1, reportreg ///
		savegraph(${figures}/Temp.gph) replace ///
		xtitle("Residual: Unemployment Benefit Change (db/w)") ///
		ytitle("Residual: Earnings Change (dw/w)")  ///
		mcolor(sea dkorange) ///
		lcolor(sea dkorange) ///
		msymbol(S none) ///
		ylab(,labsize(medium)) xlab(,labsize(medium)) ///
		legend(order(1 4) size(medium) label(1 "Actual") label(4 "Predicted") pos(6) col(2))

		graph combine ${figures}/Temp.gph, ///
		note("Slope: `b_spec3_l`k'' (`s_spec3_l`k''), {bf: See Table III, column (1), Row `row'}")


		local graphname BinScatter_earn_Diff_f`yrFwd'_LnEarn_Pct_L`k'
		if "`graphname'" == "BinScatter_earn_Diff_f1_LnEarn_Pct_L0" {
			local graphname Fig6c_BinScatter
		}
		else if "`graphname'" == "BinScatter_earn_Diff_f1_LnEarn_Pct_L2" {
			local graphname FigA6e_BinScatter
		}
		else if "`graphname'" == "BinScatter_earn_Diff_f1_LnEarn_Pct_L3" {
			local graphname FigA6f_BinScatter
		}
		graph export ${figures}/`graphname'.pdf, replace

		drop r_*

		drop PredWgGrth

		} // Event year (e = 0, -2, -3)

	} // Instrument aggregation
} // With or without 1976
} // Horizon
} // Sample

log close

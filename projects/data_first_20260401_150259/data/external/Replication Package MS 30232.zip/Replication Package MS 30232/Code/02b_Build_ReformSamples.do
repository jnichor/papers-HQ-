/*******************************************************************************

	DESCRIPTION: Creates reform samples, i.e. isolates specific parts of
		the income distribution from the worker-year panels.
		Also creates actual db/w instruments at the percentile, firm,
		and industry level.

*******************************************************************************/




********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/02b_Build_ReformSamples`curr_date'", replace



****************************************************************************
* Looping through the four reforms
****************************************************************************
foreach reform in $reforms {

	***** Loading data
	use ${temp}/02a_Reform`reform'.dta, clear


	***** Unique industry/white collar indicator
	gen temp = string(industry_15) + "_" + string(whitecoll)
	gegen wikl_occ = group(temp)
	drop temp



	****************************************************************************
	* Create and assign instruments by percentile, firm, and industry
	****************************************************************************
	foreach yrFwd in $instrumentF {

		preserve

			***** Sample restrictions
				* For the yrFwd == 1 -> pick two years
					* reform - 1 is the year we actually use to define RR instruments across all years
					* reform - 4 is just used to calculate the difference between RR instruments in the treatment year and lagged three year value
						* We use this difference to define treatment in the cap adjustment reforms
				* Only including individuals with non-missing outcomes for the averaging
			if `yrFwd' == 1 {
				keep if !mi(earn_Diff_f`yrFwd') & inlist(year,`reform' - 4, `reform' - 1)
			}
			else {
				keep if !mi(earn_Diff_f`yrFwd') & year == `reform' - 1
			}


			***** Collapsing down the average RR instrument by earnings percentiles
			fcollapse RRdiff_f`yrFwd'_RRiBY_BRiBY, by(earn_pct year)

			rename RRdiff_f`yrFwd'_RRiBY_BRiBY RRdiff_f`yrFwd'_`reform'_earn_pct


			***** Net of tax rate average instrument

			fmerge m:1 earn_pct year using ${temp}/02a_NetofTaxRate_Reform`reform'.dta, nogen keep(3) keepusing(netoftaxrate)

			gen RRdiff_f`yrFwd'_`reform'_earn_pct_nettax = RRdiff_f`yrFwd'_`reform'_earn_pct / netoftaxrate


			***** Difference between current instrument and instrument from three years prior
				* Used for defining treatment in the cap extension reforms
				* Only keeping treated year observations
			if `yrFwd' == 1 {
				xtset earn_pct year
				gen tempdiff`reform' = RRdiff_f1_`reform'_earn_pct - l3.RRdiff_f1_`reform'_earn_pct
				drop if year == `reform' - 4
			}

			drop year

			tempfile RRChng_earn_pct_`reform'_f`yrFwd'
			save `RRChng_earn_pct_`reform'_f`yrFwd'', replace

		restore

		fmerge m:1 earn_pct using `RRChng_earn_pct_`reform'_f`yrFwd'', nogen
		erase `RRChng_earn_pct_`reform'_f`yrFwd''


	} // Years forward

	***** some asserts
	bysort earn_pct: assert RRdiff_f1_`reform'_earn_pct == RRdiff_f1_`reform'_earn_pct[_n - 1] if !mi(RRdiff_f1_`reform'_earn_pct ) & !mi(RRdiff_f1_`reform'_earn_pct[_n - 1])




	****************************************************************************
	* Create treatment and control region in order to create sample
	****************************************************************************

	***** 2001 Reform
		* The treatment range is hard coded between 10000 and 20500 shillings each month
		* The control region starts at the treatment ub an spans the same number of percentiles
		* The lower bound is only 10,000 ATS because the accuracy of our benefit calculation was off for these lower earnings.
	if `reform' == 2001 {

		qui su earn_pct if adj_earnings >= $treat_lb_2001 & year == `reform' - 1
		local treatment_lb = r(min)

		qui su earn_pct if adj_earnings <= $treat_ub_2001 & year == `reform' - 1
		local treatment_ub = r(max)

		local treatment_range = `treatment_ub' - `treatment_lb'

		local control_lb = `treatment_ub'
		local control_ub = `treatment_ub' + `treatment_range' - (1/8)
	}


	***** 1989 reform
		* Treatment range is the percentile range with a positive instrument values
		*  There is a small fall in the dRR right before the minimum, so we take as a minimum the smallest dRR > 6.
	if `reform' == 1989 {

		qui su earn_pct if RRdiff_f1_`reform'_earn_pct > 6 & year == `reform' - 1 & !mi(RRdiff_f1_`reform'_earn_pct) & earn_pct > 1
		local treatment_lb = r(min)

		qui su earn_pct if RRdiff_f1_`reform'_earn_pct > 0 & year == `reform' - 1 & !mi(RRdiff_f1_`reform'_earn_pct) & earn_pct < 50
		local treatment_ub = r(max)

		local treatment_range = `treatment_ub' - `treatment_lb'

		local control_lb = `treatment_ub'
		local control_ub = `treatment_ub' + `treatment_range' - (1/8)

	}


	***** 1985 Reform
		* Treatment range is the percentile range with a positive instrument value in year r - 1, up to the sample cap based on the ASSD
        * Control region is the percentile range of equal size to treatment that has not been treated in the last 3 years.
        * One can see that if a percentile has zero excess db/w between 3 years before the base year and the base year, then it also has zero excess db/w 2 years and a year before before the base year.

	if `reform' == 1985 {

		su earn_pct if RRdiff_f1_`reform'_earn_pct > 0.5 & year == `reform' - 1
		local treatment_lb = r(min)

		* Treatment ends three percentiles below the earning cap
		su earn_pct if at_earnCap == 1 & year == `reform' - 1
		local treatment_ub = r(max) - ${samplecap}

		local treatment_range = `treatment_ub' - `treatment_lb'

		su earn_pct if tempdiff`reform' == 0 & year == `reform' - 1 & earn_pct < 50
		local control_ub = r(max)
		local control_lb = `control_ub' - `treatment_range'

		drop tempdiff`reform'
	}


	***** 1976 reform
		* Treatment range is the percentile range with an instrument > 1, with a lower bound at the ASSD minimum and ignoring the cap extension region which begins around the 30th percentile (we use the 12th as the max but it wouldn't hit any higher than there).

	if `reform' == 1976 {

		qui su earn_pct if adj_earnings >= x_earn_min & year == `reform' - 1
		local treatment_lb = r(min)

		qui su earn_pct if RRdiff_f1_`reform'_earn_pct >= 2 & year == `reform' - 1 & earn_pct <= 12
		local treatment_ub = r(max)

		local treatment_range = `treatment_ub' - `treatment_lb'

		local control_lb = `treatment_ub'
		local control_ub = `treatment_ub' + `treatment_range' - (1/8)

	}





	display "**********************************************" _n ///
	 	"Earnings Percentiles for the `reform' Reform" _n ///
		"**********************************************" _n ///
		"Treatment Region - [`treatment_lb',`treatment_ub']" _n ///
		"Control Region - [`control_lb',`control_ub']" _n ///
		"**********************************************" _n


	*** some asserts
	assert (`treatment_ub' <= 100) & (`treatment_lb' >= 0) & (`control_ub' <= 100) &  (`control_lb' >= 0)
	assert (`treatment_ub' != .) & (`treatment_lb' != .) & (`control_ub' != .) &  (`control_lb' != .)

	***** Defining treatment, control, and in sample groups

	* Treatment and control groups
	gen byte treatment_`reform' = inrange(earn_pct, `treatment_lb', `treatment_ub')
	gen byte control_`reform' = inrange(earn_pct, `control_lb', `control_ub')

	***** In-sample variable.
		* For 1985, this will include the ``donut-hole'' individuals

	* For 1985, treatment is above control
	if `reform' == 1985 {
		gen byte in_sample_`reform' = inrange(earn_pct, `control_lb', `treatment_ub')
	}

	* For other reforms, treatment is below control
	else {
		gen byte in_sample_`reform' = inrange(earn_pct, `treatment_lb', `control_ub')
	}

	ds RRdiff*

	foreach var in `r(varlist)' {

		su `var' if treatment_`reform' == 1
		local treat_avg = r(mean)
		su `var' if control_`reform' == 1
		local cont_avg = r(mean)

		display "**********************************************" _n ///
			"Average `var' for the `reform' Reform by `x', `sex_sample'" _n ///
			"**********************************************" _n ///
			"Treatment Region: `treat_avg' " _n ///
			"Control Region: `cont_avg' "_n ///
			"**********************************************" _n
	}




	****************************************************************************
	* Firm- and industry-level treatment
	***************************************************************************

	count if mi(benr) & status == 3
	local mi_benr = r(N)
	count if mi(whitecoll) & status == 3
	local mi_whitecoll = r(N)
	count if mi(nace08) & status == 3
	local mi_nace08 = r(N)

	di "Number of missing observations for reform -- `reform': benr -- `mi_benr', whitecoll -- `mi_whitecoll', and nace08 -- `mi_nace08'"

	foreach yrFwd in $instrumentF {
		foreach x in benr indocc {

			***** Generating the
			if "`x'" == "indocc" {
				gen nace08str = string(nace08)
				replace nace08str = "0" + nace08str if length(nace08str) == 3
				gen nace08d3 = substr(nace08str, 1, 3)
				gen indocc_str = nace08d3 + "_" + string(whitecoll)
				gegen indocc = group(indocc_str)
			}

			preserve

				* Only keeping individuals with earnings growth defined (sample for analysis)
				keep if !mi(earn_Diff_f`yrFwd')

				* Winsorize percentile level instrument
				* Note this uses the already percentile aggregated instrument
				gstats winsor RRdiff_f`yrFwd'_`reform'_earn_pct, replace cut(1 99) by(year)

				* Firm or industry-level averages
				collapse RRdiff_f`yrFwd'_`reform'_earn_pct RRdiff_f`yrFwd'_`reform'_earn_pct_nettax RRdiff_f1_RRRY_BRRY treatment_`reform', by(`x' year)

				* Quantiles of average treatment values and the share treated
				gquantiles treat_pct_`x' = RRdiff_f`yrFwd'_`reform'_earn_pct, xtile by(year) nquantiles(100)
				gquantiles shtreat_pct_`x' = treatment_`reform', xtile by(year) nquantiles(100)

				* Renaming and saving
				rename (treatment_`reform' RRdiff_f`yrFwd'_`reform'_earn_pct ///
				 RRdiff_f`yrFwd'_`reform'_earn_pct_nettax RRdiff_f1_RRRY_BRRY) ///
				 (shtreat_`x' RRdiff_f`yrFwd'_`reform'_`x' ///
				 RRdiff_f`yrFwd'_`reform'_`x'_nettax ///
				 realizedRR_`x')

				tempfile RRChng_`x'_`reform'_f`yrFwd'
				save `RRChng_`x'_`reform'_f`yrFwd'', replace

			restore

			merge m:1 `x' year using `RRChng_`x'_`reform'_f`yrFwd'', nogen
			erase `RRChng_`x'_`reform'_f`yrFwd''

		} // Firm- and industry-level aggregations
	}




	****************************************************************************
	* Adjusting the earnings change variables for movers
		* Note -- could be implemented in 02a or 02b
		* The difference only affects who is dropped during the instrument construction
	***************************************************************************
	foreach yrFwd in $earnF {

		***** Change earnings outcomes for recalled/movers
		gen old_earn_Diff_f`yrFwd' = earn_Diff_f`yrFwd'

		replace earn_Diff_f`yrFwd' = 100*((adj_earnings_afterchange_f`yrFwd' - adj_earnings) / adj_earnings) if mover_f`yrFwd' == 1 | recalled_f`yrFwd' == 1


		* Change transition types at the two-year horizon.
		if `yrFwd' == 2 {
			foreach var in stayer mover recalled EE EUE ENE {
				* If you are a non-stayer in t+1, you get your t+1 type in t+2.
				* If you are a stayer in t+1, you get your t+2 type in t+2.
				replace `var'_f2 = `var'_f1 if stayer_f1 == 0
			}
			replace earn_Diff_f`yrFwd' = old_earn_Diff_f`yrFwd'
			replace earn_Diff_f`yrFwd' = 100*((adj_earnings_afterchange_f`yrFwd' - adj_earnings) / adj_earnings) ///
			if (mover_f`yrFwd' == 1 | recalled_f`yrFwd' == 1) & ///
			stayer_f1 == 1
		}

	} // Year forward adjustments

	save ${temp}/02b_Reform`reform'.dta, replace

} // Different reforms

log close

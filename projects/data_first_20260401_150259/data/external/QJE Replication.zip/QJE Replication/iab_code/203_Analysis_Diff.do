*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/203/$today"
local output $log/203/$today

log using "`output'/203_Analysis_Diff.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*		203 Analysis Difference
*
********************************************************************************

foreach robust in 1 2 3 {

	foreach w in $winsor_values {
		noi di "Winsorization `w' %"

		use "$data\iab_wage_analysis_winsor`w'.dta" if abs(d_rel) <= ${bw_standard} & AG==1 ${robust`robust'}, clear

		 foreach i in $specifications {


			timer on 2
			noi di "Specification `i'"


			foreach outcome in $outcomes  {


				timer on 2
				noi di "	Outcome: `outcome'"

						timer on 3

				* Simple difference regression
				reghdfe `outcome' i.prereformcohort, ///
					a(${controls`i'}) vce(cluster cluster_variable)

				global b`outcome'`w'`i' = _b[1.prereformcohort]
				global s`outcome'`w'`i' = _se[1.prereformcohort]
				global p`outcome'`w'`i' = (2 * ttail(e(df_r), abs(_b[1.prereformcohort ]/_se[1.prereformcohort])))


				global N`outcome'`w'`i' = `e(N)'

				* Number of AGs
				gdistinct idnr if e(sample) == 1
				global Nag1`outcome'`w'`i' = `r(ndistinct)'

				gstats su `outcome' if d_rel >= 0
				global cmag1`outcome'`w'`i' = `r(mean)'


				timer off 3
				qui timer list 3
				noi di "		Time for regression: `r(t3)' seconds"
				timer clear 3

			} // Outcomes

			timer off 2
			qui timer list 2
			noi di "	Time for outcome: `r(t2)' seconds"
			timer clear 2

		} // Specifications

	} //  Winsor values


	foreach i in $specifications {

		qui foreach outcome in $outcomes {

			foreach w in $winsor_values {

				* Save data
				clear
				set obs 1
				gen spec = `i'
				gen outcome = "`outcome'"
				gen winsor = `w'
				gen bandwidth = $bw_standard
				gen N = ${N`outcome'`w'`i'}
				gen b = ${b`outcome'`w'`i'}
				gen s = ${s`outcome'`w'`i'}
				gen p = ${p`outcome'`w'`i'}
				gen controlmean_AG = ${cmag1`outcome'`w'`i'}
				gen N_AG = ${Nag1`outcome'`w'`i'}


				save "`output'/Diff_`outcome'_Winsor`w'_spec`i'${robustness`robust'}.dta", replace


			} // Winsor values
		} // Outcome
	} // Specification
} // Robustness


log close

/*

	generate time-invariant variables on firm-level:
	industry15, nace08 --> steel
	beot --> gkz --> rebp
	
*/

//// set globals
global ASSD /home/data/group_zweim/daten/Austria/ASSD2016
global REV /home/data/group_zweim/daten/Austria/REV2008
global UIF /home/data/group_zweim/pruh/Projekte/UIFirms
global dofiles $UIF/dofiles
global data $UIF/data
global temp $UIF/temp
global script /home/data/group_zweim/pruh/daten/utilities
cd $temp


use $ASSD/dienstgeber/dg.dta, clear
bysort benr (gueltig_von): keep if _n==_N
drop gueltig* data_delivery vstr onace origin wikl_25 wikl_59

* define steel sector
g steel = nace08==2454 | nace08==2453 | nace08==729 | nace08==3311 | nace08==4674 | nace08==2511 | nace08==4752 | nace08==4672 | nace08==2599 | nace08==2891 | nace08==2512 | nace08==2441 | nace08==2841 | nace08==4612 | nace08==2399 | nace08==2445 | nace08==2572 | nace08==2571 | nace08==2529 | nace08==2591 | nace08==2592 | nace08==4615 | nace08==2550

* map beot to gkz
rename beot beot5
merge m:1 beot5 using $script/gkz_beot_eindeutig.dta, keepusing(gkz5) keep(1 3) nogen
rename gkz5 gkz
rename beot5 beot

// define REBP and get gkz
preserve
use $ASSD/../ASSD2007/REBP/gkz_beot_kr_arba.dta, clear
drop if gkz==.
collapse (mean) kr_arba, by(gkz)
assert kr==0 | kr==1 | kr==2
save $temp/rebp_gkzunique2.dta, replace
restore

merge m:1 gkz using $temp/rebp_gkzunique2.dta, keepusing(kr_arba) keep(1 3) nogen
rename kr_arba rebp
label define rebp 0 "no rebp region" 1 "rebp until 1991" 2 "rebp until 1993"
label values rebp rebp


compress
save $data/0012_dg.dta, replace

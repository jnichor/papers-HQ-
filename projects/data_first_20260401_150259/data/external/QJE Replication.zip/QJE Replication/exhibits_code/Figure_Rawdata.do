*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================




* Generates the Raw Data Cohort Graphs (DiD/RD)
* --------------- --------------- --------------- ---------------  -------------

* --------------- --------------- --------------- ---------------  -------------
* Outcomes to run
* --------------- --------------- --------------- ---------------  -------------
local outcomes log_te_mw  log_av_per_empl log_fias log_fias_per_empl

* --------------- --------------- --------------- ---------------  -------------
* Graphical Settings
* --------------- --------------- --------------- ---------------  -------------

set scheme plotplainblind
graph set window fontface "Verdana"
* output folder

local fontsize 3.8
local fontsizellc 4.5
local msize 2.5
local lwidth 0.75
local clwidth 0.3

local youngstockcolor maroon
local oldstockcolor navy
local youngllccolor maroon
local oldllccolor navy

local youngstocksymbol msymbol(circle_hollow) lp(solid)
local oldstocksymbol msymbol(circle)
local youngllcsymbol msymbol(triangle_hollow)
local oldllcsymbol msymbol(triangle)

local youngstocklp lp(dash)
local oldstocklp lp(solid)
local youngllclp lp(dash)
local oldllclp lp(solid)

local txtoldstocklog_te_mw 4.65 -1050
local txtyoungstocklog_te_mw 4.65 -1050
local txtoldstocklog_te_mw 4.65 -1050
local txtyoungstocklog_te_mw 4.65 -1050

* in quarters
local quarters  -1825 "-20" -1460 "-16" -1095 "-12" -730 "-8" -365 "-4" 0 "0" ///
1825 "20" 1460 "16" 1095 "12" 730 "8" 365 "4"

* set scale axes
local ylab_log_te_mw 4.2(0.2)5
local ylab_log_fias 11.5(1)15.5
local ylab_log_av_per_empl 10.5(0.5)12
local ylab_log_fias_per_empl 8.5(1)11.5

local xlab_log_te_mw 1994(4)2016
local xlab_log_fias 2006(2)2014
local xlab_av_per_empl 2006(2)2014


local file_log_fias_DiD "fig7c"
local file_log_fias_per_empl_DiD "fig7e"
local file_log_av_per_empl_DiD "fig7a"
local file_log_fias_RD "figA6c"
local file_log_fias_per_empl_RD "figA6e"
local file_log_av_per_empl_RD "figA6a"
local file_log_te_mw_DiD "fig4a"
local file_akm_firm_fe_DiD "fig5a"
local file_log_te_mw_RD "fig4b"
local file_akm_firm_fe_RD "fig5b"



* --------------- --------------- --------------- ---------------  -------------
* Load Estimate Results to Global for RD plots
* --------------- --------------- --------------- ---------------  -------------
foreach outcome in log_te_mw akm_firm_fe{
use "${iab}/201/RD_`outcome'_Winsor1_spec3_AG", clear
	qui sum b
	global RDestimate_`outcome': di %5.3f `r(mean)'
	qui sum s
	global RDse_`outcome': di %5.3f `r(mean)'
}

* print text on graph
# delimit ;

local text_log_te_mw	text(5 -890  "Old Stock Corps (Shared Gov.)", size(`fontsize'))
						text(5  960 "Young Stock Corps (Shared Gov.)", size(`fontsize'))
						text( 4.25 -1540 "Old LLCs", size(`fontsizellc'))
						text(4.25 1350   "Young LLCs", size(`fontsizellc')) 
				        text( 4.85 1250 "RD: ${RDestimate_log_te_mw} (SE ${RDse_log_te_mw})", size(`fontsize')) ;

local text_akm_firm_fe	text(.1 -1000   "Old Stock Corps (Shared Gov.)", size(`fontsize'))
						text(.1  960 "Young Stock Corps (Shared Gov.)", size(`fontsize'))
						text( -.1 -1540 "Old LLCs", size(`fontsizellc'))
						text(-.1 1350   "Young LLCs", size(`fontsizellc')) 
						text( .07 1250 "RD: ${RDestimate_akm_firm_fe} (SE ${RDse_akm_firm_fe})", size(`fontsize')) ;

local text_log_fias		text(16.2 -1000   "Old Stock Corps (Shared Gov.)", size(`fontsize'))
						text(16.2  960 "Young Stock Corps (Shared Gov.)", size(`fontsize'))
						text(11.8 -1540 "Old LLCs", size(`fontsizellc'))
						text(11.8 1350   "Young LLCs", size(`fontsizellc')) ;

local text_log_av_per_empl	text(12.25 -1000   "Old Stock Corps (Shared Gov.)", size(`fontsize'))
						text(12.25  960 "Young Stock Corps (Shared Gov.)", size(`fontsize'))
						text(10.55 -1540 "Old LLCs", size(`fontsizellc'))
						text(10.55 1350   "Young LLCs", size(`fontsizellc')) ;

local text_log_fias_per_empl		text(13 -1000   "Old Stock Corps (Shared Gov.)", size(`fontsize'))
						text(13  960 "Young Stock Corps (Shared Gov.)", size(`fontsize'))
						text(9 -1540 "Old LLCs", size(`fontsizellc'))
						text(9 1350   "Young LLCs", size(`fontsizellc')) ;

# delimit cr

* --------------- --------------- --------------- ---------------  -------------
* Cohort graphs (DiD)
* Legends are overlaid on the graphs using Latex
* --------------- --------------- --------------- ---------------  -------------

* for outcomes EXCEPT normalised AKM
foreach outcome in `outcomes' {


	* By Calendar year
	use "${iab}/204/spec1/Figure_DIDyear_`outcome'_Winsor1.dta", clear
	drop if n==0 // drop empty bins

	separate `outcome', by (AG_prereformcohort)
	keep if jahr>=1994

	twoway ///
	(scatter `outcome'0 jahr, c(l) lp(dash)  msymbol(triangle_hollow) msize(`msize')  color(maroon )) ///
	(scatter `outcome'1 jahr, c(l) lp(solid) msymbol(triangle) msize(`msize')  color(navy) ) ///
	(scatter `outcome'10 jahr, c(l) lp(dash) msymbol(circle_hollow) msize(`msize')  color(maroon)  ) ///
	(scatter `outcome'11 jahr, c(l) lp(solid) msymbol(circle) msize(`msize')  color(navy) ), ///
	xlab(`xlab_`outcome'', labsize(`fontsize')) ylab(`ylab_`outcome'', labsize(`fontsize')) ///
	xtitle("Year",size(`fontsize')) ///
	ytitle("")  ///
	legend(off)

	graph export "${figures}/`file_`outcome'_DiD'.pdf", replace


} // outcome


* Normalise AKM firm fixed effects using mean log wage
* -----------------------------------------------------------------------------


use "${iab}/204/spec1/Figure_DIDyear_log_te_mw_Winsor1.dta", clear

merge 1:1 jahr AG_prereformcohort using "${iab}/204/spec1/Figure_DIDyear_akm_firm_fe_Winsor1.dta"

gen akm_oldstock = akm_firm_fe if AG_prereformcohort == 11
bysort jahr (AG_prereformcohort): replace akm_oldstock = akm_oldstock[4] if mi(akm_oldstock)

gen wage_oldstock = log_te_mw if AG_prereformcohort == 11
bysort jahr (AG_prereformcohort): replace wage_oldstock = wage_oldstock[4] if mi(wage_oldstock)

gen akm_norm = wage_oldstock + akm_firm_fe - akm_oldstock

drop if jahr<1996
drop if jahr >2012
separate akm_norm, by (AG_prereformcohort)


twoway ///
(scatter akm_norm0 jahr, c(l) lp(dash)  msymbol(triangle_hollow) msize(`msize')  color(maroon )) ///
(scatter akm_norm1 jahr, c(l) lp(solid) msymbol(triangle) msize(`msize')  color(navy) ) ///
(scatter akm_norm10 jahr, c(l) lp(dash) msymbol(circle_hollow) msize(`msize')  color(maroon)  ) ///
(scatter akm_norm11 jahr, c(l) lp(solid) msymbol(circle) msize(`msize')  color(navy) ), ///
xlab(1996(4)2012, labsize(`fontsize')) ylab(4.45(0.1)4.75, labsize(`fontsize')) ///
xtitle("Year",size(`fontsize')) ///
ytitle("")  ///
legend(off)


graph export "${figures}/fig5a.pdf", replace


*  Generate legends to be overlaid on the previous graphs
*  Crop out the legends  manually after generating
* -----------------------------------------------------------------------------

* load a generic dataset
local outcome log_te_mw

use "${iab}/204/spec1/Figure_DIDyear_`outcome'_Winsor1.dta", clear
drop if n==0


separate `outcome', by (AG_prereformcohort)
keep if jahr>=1994

local legendstock order(4 "Old Stock Corps (Shared Gov.)" 3 "Young Stock Corps (No Shared Gov.)" ) pos(11)
local legendllc order( 2 "Old LLCs" 1 "Young LLCs") pos(5) ring(0)

twoway ///
(scatter `outcome'0 jahr, c(l) lp(dash)  msymbol(triangle_hollow) msize(`msize')  color(maroon )) ///
(scatter `outcome'1 jahr, c(l) lp(solid) msymbol(triangle) msize(`msize')  color(navy) ) ///
(scatter `outcome'10 jahr, c(l) lp(dash) msymbol(circle_hollow) msize(`msize')  color(maroon)  ) ///
(scatter `outcome'11 jahr, c(l) lp(solid) msymbol(circle) msize(`msize')  color(navy) ), ///
      legend(`legendstock') yscale(off) xscale(off)


graph export "${figures}/legendstock.pdf", replace

twoway ///
(scatter `outcome'0 jahr, c(l) lp(dash)  msymbol(triangle_hollow) msize(`msize')  color(maroon )) ///
(scatter `outcome'1 jahr, c(l) lp(solid) msymbol(triangle) msize(`msize')  color(navy) ) ///
(scatter `outcome'10 jahr, c(l) lp(dash) msymbol(circle_hollow) msize(`msize')  color(maroon)  ) ///
(scatter `outcome'11 jahr, c(l) lp(solid) msymbol(circle) msize(`msize')  color(navy) ), ///
      legend(`legendllc') yscale(off) xscale(off)


graph export "${figures}/legendllc.pdf", replace



* --------------- --------------- --------------- ---------------  -------------
* RD plots using local polynomial for fitted line
* On all outcomes (and non-normalise AKM)
* --------------- --------------- --------------- ---------------  -------------

foreach outcome in `outcomes' akm_firm_fe {

	use "${iab}/204/spec1/Figure_RD_bins_`outcome'_Winsor1", clear
	separate `outcome', by (AG_prereformcohort)

	append using "${iab}/204/spec1/Figure_RD_lpoly_firmlevel_`outcome'_Winsor1.dta"

	foreach cohort in 0 1 10 11 {
		gen ub`cohort' = yhat`cohort' + 1.96*sehat`cohort'
		gen lb`cohort' = yhat`cohort' - 1.96*sehat`cohort'
	} // cohort


	twoway ///
	(scatter `outcome'0  d_rel, mcolor(`youngllccolor') lcolor(`youngllccolor') msize(`msize')   `youngllcsymbol')   ///
	(line yhat0  xhat0, lcolor(`youngllccolor') `youngllclp' lwidth(`lwidth')) ///
	(line ub0  xhat0, lcolor(`youngllccolor') `youngllclp' lwidth(`clwidth')) ///
	(line lb0  xhat0, lcolor(`youngllccolor') `youngllclp' lwidth(`clwidth')) ///
	(scatter `outcome'1 d_rel, mcolor(`oldllccolor') lcolor(`oldllccolor')   msize(`msize') `oldllcsymbol')  ///
	(line yhat1  xhat1, lcolor(`oldllccolor') `oldllclp' lwidth(`lwidth')) ///
	(line ub1  xhat1, lcolor(`oldllccolor') `oldllclp' lwidth(`cwidth')) ///
	(line lb1  xhat1, lcolor(`oldllccolor') `oldllclp' lwidth(`cwidth')) ///
	(scatter `outcome'10 d_rel, mcolor(`youngstockcolor') lcolor(`youngstockcolor') msize(`msize') `youngstocksymbol') ///
	(line yhat10  xhat10, lcolor(`youngstockcolor') `youngstocklp' lwidth(`lwidth')) ///
	(line ub10  xhat10, lcolor(`youngstockcolor') `youngstocklp' lwidth(`clwidth')) ///
	(line lb10  xhat10, lcolor(`youngstockcolor') `youngstocklp' lwidth(`clwidth')) ///
	(scatter  `outcome'11 d_rel, mcolor(`oldstockcolor') lcolor(`oldstockcolor') msize(`msize')  `oldstocksymbol')  ///
	(line yhat11  xhat11, lcolor(`oldstockcolor') `oldstocklp' lwidth(`lwidth')) ///
	(line ub11  xhat11, lcolor(`oldstockcolor') `oldstocklp' lwidth(`clwidth')) ///
	(line lb11  xhat11, lcolor(`oldstockcolor') `oldstocklp' lwidth(`clwidth')) ///
	, graphregion(fcolor(white)) ///
	ytitle("")  	xtitle("Incorporation Date Relative To August 10, 1994 (Quarters)", size(`fontsize')) ///
	xline(0, lp(dash) lc(gs6)) ///
	legend( off  ) 	ylab(, labsize(`fontsize'))  xlab(`quarters', labsize(`fontsize')) ///
	`text_`outcome''


	graph export "${figures}/`file_`outcome'_RD'.pdf", replace


} // outcomes

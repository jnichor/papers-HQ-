*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================




********************************************************************************
*
*
*			 12 Set Outcomes to Run
*
*
********************************************************************************

#delimit ;




/* Wage Outcomes*/

global wage_outcomes

										log_te_mw
										akm_firm_fe
										pers_fe
										log_te_p7525
										log_te_p25
										log_te_p75
										log_te_p10
										log_te_p20
										log_te_p30
										log_te_p40
										log_te_p50
										log_te_p60
										log_te_p70
										log_te_p80
										log_te_p90
										az_ft_zens
										log_ten_ges
										tenure
										fscl
										az_gq_per_empl
										az_hq_per_empl
										az_mq_per_empl
										separation
										separation_p_empl
										ln_m_residuals
										az_ft_zens_p_empl
										log_az_ft_ges
										log_az_ges_bhp
										fscl_per_empl

;
/* BvD Outcomes*/
global bvd_outcomes

										log_av_per_empl
										log_av
										log_empl
										log_fias
										log_fias_per_empl
										capital_share
										av_opre
										log_opre
										log_tfas
										log_opre_per_empl
										log_tfas_per_empl
										log_TFPr_fias
										ebta_opre
										ebit_opre
										pl_opre
										ebta_toas
										ebit_toas
										pl_toas


;

/* Indicator outcomes not to be winsorized*/
global nonwins_outcomes
										az_ges_bhp500plus
										empl500plus

;

/* Outcomes for heterogeneity analysis*/
global heterogeneity_outcomes

										akm_firm_fe
										log_te_mw
;

/* Heterogeneity categories*/

global hetgroups

										CBA_coverage
										binding_CBA_coverage
										works_council
										akm_sd
										industry_akm
										ln_av_empl
										separation_rate
										tenure

;

# delimit cr

* set main outcomes
global outcomes  $nonwins_outcomes $bvd_outcomes $wage_outcomes

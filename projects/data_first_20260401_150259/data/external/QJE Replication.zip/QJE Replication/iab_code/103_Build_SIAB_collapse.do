*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================

cap log close

log using $log\103_Build_SIAB_Collapse.txt, replace text


********************************************************************************
*
*
*			103 Collapse Worker Data
*
*
********************************************************************************

use  $data\bvd_siab.dta, clear

keep az_ges _ges _reg frau _gq _mq _hq _fscl _censor dailywage _azubi separation tenure dailywage logdailywage ln_m_residuals d_lnwage_l1 d_lnwage_l2 d_lnwage_l3 age idnr jahr

compress

* 1. Collapse to firm level
*===============================================================================

		collapse ///
		(sum)	az_ges_bhp = az_ges ///
				az_ft_ges=_ges ///
				az_ft_reg=_reg ///
				az_ft_f=frau ///
				az_ft_gq=_gq ///
				az_ft_mq=_mq ///
				az_ft_hq=_hq ///
				fscl=_fscl ///
				az_ft_zens=_censor ///
				wagebill=dailywage ///
				az_ft_azubi=_azubi ///
				separation ///
		(mean)  tenure ///
				te_mw=dailywage ///
				log_te_mw=logdailywage ///
				ln_m_residuals  ///
				d_lnwage_l1 ///
				d_lnwage_l2 ///
				d_lnwage_l3 ///
				alter_mw=age ///
		(p10)	log_te_p10 = logdailywage ///
		(p20)	log_te_p20 = logdailywage ///
		(p30)	log_te_p30 = logdailywage ///
		(p40)	log_te_p40 = logdailywage ///
		(p60)	log_te_p60 = logdailywage ///
		(p70)	log_te_p70 = logdailywage ///
		(p80)	log_te_p80 = logdailywage ///
		(p90)	log_te_p90 = logdailywage ///
		(p25)	te_p25=dailywage ///
				log_te_p25 =logdailywage ///
		(p50) 	te_med=dailywage ///
				log_te_p50 =logdailywage ///
		(p75) 	te_p75=dailywage ///
				log_te_p75  =logdailywage ///
				, by(idnr jahr) fast

gen te_p7525 = te_p75/te_p25

gen log_te_p7525 = log(te_p7525)

save $data\idnr_jahr_collapsed_siab.dta, replace

log close

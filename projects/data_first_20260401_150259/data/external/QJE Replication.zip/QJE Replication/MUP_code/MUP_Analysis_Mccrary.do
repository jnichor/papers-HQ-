*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						
*===============================================================================


********************************************************************************
*
*		Test for bunching at policy discontinuity 
*
********************************************************************************

cap log close
log using "${log}/MUP_Analysis_Bunching.log", replace


foreach variable in dateinc {
	use "${temp}/MUP_survival.dta", clear
	duplicates drop crefo, force 
	
	if "`variable'"=="dateinc" {
		global run_var d_rel
	}
	
	

	* McCrary test


	keep if abs(${run_var}) <= ${bw_standard}

	bys crefo: keep if _n == 1

	gen month_rel = ${run_var}/30

	cap drop Yj_ag Xj_ag r0_ag fhat_ag se_fhat_ag Xj_all Yj_all r0_all fhat_all se_fhat_all

	discard

	DCdensity_withnote month_rel, breakpoint(0)  ///
	generate(Xj_all Yj_all r0_all fhat_all se_fhat_all)
	graph export "${fig}/MUP_`variable'_McCrary_all.pdf", replace
	
	keep if AG == 1
	DCdensity_withnote month_rel if AG == 1, breakpoint(0) ///
	generate(Xj_ag Yj_ag r0_ag fhat_ag se_fhat_ag)
	graph export "${fig}/MUP_`variable'_McCrary_AG.pdf", replace



}

log close


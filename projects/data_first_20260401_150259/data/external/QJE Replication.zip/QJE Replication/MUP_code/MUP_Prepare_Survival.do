*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						
*===============================================================================


set more off
set matsize 11000
timer clear 
est clear

********************************************************************************
*
*		Survival analysis - Prepare
*
********************************************************************************

*prepare survival.dta. 

/*
use ${temp}/oh_cleaned.dta, clear

gen one=1
tostring closdate_year, gen(closdate_year_str)
bysort crefo : gegen first_year_obs=min(closdate_year)
bysort crefo : gegen last_year_obs=max(closdate_year)

save ${temp}/oh_cleaned.dta, replace
*/

****************************************
*expanding database
****************************************

use crefo refo exit using "${data}/${dta_name}.dta", clear

gen AG = (refo==11)
gen GmbH = (refo==9|refo==10)
keep if AG==1|GmbH==1
drop AG GmbH

gen bankruptcy = (exit==2)
drop exit

global expand_horizon = ${end_year}-${start_year}+1
duplicates drop crefo, force
expand ${expand_horizon}
bys crefo: gen closdate_year = ${start_year} + _n -1

merge m:1 crefo using "${data}/${dta_name}.dta", ///
	keepusing(exit refo gruenddat hreintrag exit_datum wzdig) nogen
	
gen AG = (refo==11)
gen GmbH = (refo==9|refo==10)
keep if AG==1|GmbH==1

replace hreintrag = . if hreintrag==0

foreach variable in hreintrag gruenddat {
	replace `variable' = . if `variable'==0

	gen `variable'_year = floor(`variable'/10000)
	tab `variable'_year
	keep if `variable'_year>=${min_incorporation}&`variable'_year<=${max_incorporation}
	gen `variable'_month = floor((`variable'-`variable'_year*10000)/100)
	tab `variable'_month
	keep if `variable'_month>=1&`variable'_month<=12
	gen `variable'_day = mod(`variable',100)
	tab `variable'_day
	keep if `variable'_day>=1&`variable'_day<=31
	drop `variable' 
	gen `variable' = mdy(`variable'_month,`variable'_day,`variable'_year)
	drop `variable'_month `variable'_day `variable'_year
}

tab exit_datum
replace exit_datum = 9999 if exit_datum<1980

gen dateinc = gruenddat
replace dateinc = hreintrag if abs(gruenddat-hreintrag)>365
gen dateinc_year = year(dateinc)

gen d_rel = dateinc-mdy(8,10,1994)	
replace d_rel = hreintrag if abs(gruenddat-hreintrag)>365

gen yrs_Incorporation = closdate_year-dateinc_year
tab yrs_Incorporation, gen(yrs_since_inc_cat)
 
gen first_observed = dateinc_year
gen last_observed = year(exit_datum)

gen nace_d5 = wzdig

gen id_observed = closdate_year<exit_datum & closdate_year>=dateinc_year
gen bankruptcy_prob = (id_observed==0)&(bankruptcy==1)

*years since incorp. variable
gen yrs_since_inc = closdate_year - dateinc_year

/*
*years since `year' variable
forvalues j=$start_year/$end_year {
	gen yrs_`j' = closdate_year - `j'
}
*/

* Regressors
gen pre_reform_inc = d_rel <0
label define pre_reform_inc 0 "Post" 1 "Pre" 
label values pre_reform_inc pre_reform_inc



gen firm = AG
label define firm 0 "GmbH" 1 "AG" 
label values firm firm

gen firm_reform_category = .
	replace firm_reform_category = 1 if AG==1 & pre_reform_inc == 1
	replace firm_reform_category = 2 if AG==1 & pre_reform_inc == 0
	replace firm_reform_category = 3 if GmbH==1 & pre_reform_inc == 1
	replace firm_reform_category = 4 if GmbH==1 & pre_reform_inc == 0
label define firm_reform_category 1 "AG; pre" 2 "AG; post" 3 "GmbH; pre" 4 "GmbH; post"
label values firm_reform_category firm_reform_category

format dateinc %td

**************************************
* hazard rates
**************************************

gen hazard_rate = .
replace hazard_rate = 1 if id_observed==1

bys crefo (closdate): replace hazard_rate = 0 if id_observed==0 & id_observed[_n-1]==1 
bys crefo (closdate): replace hazard_rate = . if id_observed[_n-1]==0 
gen exit_hazard = 1-hazard_rate
gen exit_hazard_bankruptcy = (exit_hazard==1) & (bankruptcy==1)

gen _nace_d4 = floor(wzdig/10)
drop if _nace_d4 == . 
drop if inrange(_nace_d4,3500,3899) // Energie etc.
drop if inrange(_nace_d4,4900,4929) // Bahnen
drop if inrange(_nace_d4,8400,8499) // Oeffentliche Verwaltung etc.
drop if inrange(_nace_d4,9400,9499) // Interessenvertr.
drop if inrange(_nace_d4,9700,9899) // Private Haushalte
drop if inrange(_nace_d4,9900,9999) // Exterritoriale Organisationen und Koerperschaften

drop _* 

save "${temp}/MUP_survival.dta", replace

keep crefo
duplicates drop crefo, force
save "${temp}/MUP_sample_crefo.dta", replace

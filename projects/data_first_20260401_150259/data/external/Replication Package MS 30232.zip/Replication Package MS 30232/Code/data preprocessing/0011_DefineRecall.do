/*

	define recall
	idea:
	Step 1
	- loop over all quarters from beginning to end
	- for every Empl - UI transition, store benr_E (related to E)
	- trace forward benr_E until new employment is found and compare benr
	
	- define variable: recalled = 1 in the quarter we observe that the firms are the same

	Step 2
	- loop over all quarters BACKWARDS.
	- define variable recall = 1 for every quarter back to the "initial" Empl
	
	Step 3
	- save dataset containing svnr ref recall recalled (can be merged to the main dataset afterwards)

*/

//// set globals
global yearvon = 1983
global yearbis = 1998


global root /home/data/group_zweim // Linux
*global root \\econzagreus\group_zweim // Windows


global ASSD $root/daten/Austria/ASSD2016
global REV $root/daten/Austria/REV2008
global UIF $root/projekte/UIFirms
global dofiles $UIF/dofiles
global data $UIF/data
global temp $UIF/temp
global script $root/pruh/daten/utilities

****
clear
g benr =""
save $data/0011_ref_Recalls.dta, replace
save $data/0011_ref_Recalls_backw.dta, replace

* open first quarter
use $data/0010_panel_year${yearvon}_month2.dta, clear

keep svnr ref status benr
keep if status == 3

g benr_E = benr
g recalled = .
g recall = .
g recall_point =.
g firing_recall =.

save $temp/0011_temp_ref_Recalls.dta, replace

// loop for first year
forvalues m = 5(3)11 {
noi di `m'

set more off
	global y = $yearvon
	global m = `m'
	
	use $temp/0011_temp_ref_Recalls.dta, clear
	global refp = mdy($m,15,$y)
	
	append using $data/0010_panel_year${y}_month${m}.dta
	keep svnr ref status benr recalled recall_point recall benr_E firing_recall status
	
	sort svnr ref
	
	bysort svnr (ref): replace recall_point = 1 if status==3 & status[_n-1]!=3 & benr_E[_n-1]==benr & ref == $refp //recall now 1st time
	replace recalled = 1 if recall_point == 1
	bysort svnr (ref): replace recalled = 1 if status==3 & benr_E[_n-1]==benr & recalled[_n-1] ==1 & ref == $refp //on-going recall
	bysort svnr (ref): replace benr_E = benr if status == 3 & ref == $refp //employee
	bysort svnr (ref): replace benr_E = benr_E[_n-1] if status != 3 & ref == $refp // now no work, carryforward old benr_E
	
		keep if ref == $refp
		save $temp/0011_temp_ref_Recalls.dta, replace

keep if recalled == 1
keep svnr benr ref recalled recall recall_point firing_recall status
append using $data/0011_ref_Recalls.dta
save $data/0011_ref_Recalls.dta, replace
}

// loop over years and quarters to define potential recalls
global yr1 = ($yearvon + 1)


forvalues y = $yr1(1)$yearbis {
forvalues m = 2(3)11 {
noi di "`m' in `y'"

set more off
	global y = `y'
	global m = `m'
	
	*global ref = mdy($m,15,$y)
	*append using $temp/0010_recalls${ref}.dta
	use $temp/0011_temp_ref_Recalls.dta, clear
	global refp = mdy($m,15,$y)
		
	append using $data/0010_panel_year${y}_month${m}.dta
	keep svnr ref status benr recalled recall_point recall benr_E firing_recall status
	
	sort svnr ref
	
	bysort svnr (ref): replace recall_point = 1 if status==3 & status[_n-1]!=3 & benr_E[_n-1]==benr & ref == $refp //recall now 1st time
	replace recalled = 1 if recall_point == 1
	bysort svnr (ref): replace recalled = 1 if status==3 & benr_E[_n-1]==benr & recalled[_n-1] ==1 & ref == $refp //on-going recall
	bysort svnr (ref): replace benr_E = benr if status == 3 & ref == $refp //employee
	bysort svnr (ref): replace benr_E = benr_E[_n-1] if status != 3 & ref == $refp // now no work, carryforward old benr_E
	
		keep if ref == $refp
		save $temp/0011_temp_ref_Recalls.dta, replace

keep if recalled == 1
keep svnr benr ref recalled recall recall_point firing_recall status
append using $data/0011_ref_Recalls.dta
save $data/0011_ref_Recalls.dta, replace
		
		*ARE THERE GAPS OVER TIME WITHIN INDIVIDUAL? EVENTUALLY WE DO NOT WANT THIS?
		*WHAT IS THE AVERAGE AND MEDIAN LENGTH BETWEEN TWO EMPLOYMENT SPELLS INVOLVING A RECALL?
		

	} // m
} // y
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
erase $temp/0011_temp_ref_Recalls.dta








// loop backwards over years to define effective recalls

* open last quarter
use $data/0010_panel_year${yearbis}_month11.dta, clear
keep svnr ref status benr

merge m:1 svnr ref using $data/0011_ref_Recalls.dta, nogen keepusing(recall_point) keep(3)
keep if recall_point == 1

g recalled = .
g recall = .
g firing_recall =.

save $temp/0011_temp_ref_Recalls.dta, replace

// loop backwards, last year
forvalues m = 8(-3)2 {
noi di `m'

set more off
	global y = $yearbis
	global m = `m'
	
	use $temp/0011_temp_ref_Recalls.dta, clear
	global refp = mdy($m,15,$y)
	
	drop recall_point //for merge
	merge m:1 svnr ref using $data/0011_ref_Recalls.dta, nogen keepusing(recall_point) keep (1 3)
	keep if recall_point == 1 | recall == 1
	
	append using $data/0010_panel_year${y}_month${m}.dta
	keep svnr ref status benr recalled recall_point recall firing_recall status
	
	sort svnr ref
		
		bysort svnr (ref): replace recall = 1 if recall_point[_n+1] == 1 & ref == $refp //last obs recall
		bysort svnr (ref): replace recall = 1 if recall[_n+1] == 1 & status !=3 & ref == $refp //on-going recall
		bysort svnr (ref): replace firing_recall = 1 if recall[_n+1] == 1 & status == 3 & ref == $refp //firing, first obs recall
		
		
		keep if ref == $refp
		save $temp/0011_temp_ref_Recalls.dta, replace

keep if recall == 1 | firing_recall == 1
keep svnr benr ref recalled recall recall_point firing_recall status
append using $data/0011_ref_Recalls_backw.dta
save $data/0011_ref_Recalls_backw.dta, replace
	
}

// loop backwards
global yrlast = ($yearbis -1)

forvalues y = $yrlast(-1)$yearvon {
forvalues m = 11(-3)2 {
noi di "`m' in `y'"

set more off
	global y = `y'
	global m = `m'
	
	
	use $temp/0011_temp_ref_Recalls.dta, clear
	global refp = mdy($m,15,$y)
	
	drop recall_point //for merge
	merge m:1 svnr ref using $data/0011_ref_Recalls.dta, nogen keepusing(recall_point) keep (1 3)
	keep if recall_point == 1 | recall == 1
	
	append using $data/0010_panel_year${y}_month${m}.dta
	keep svnr ref status benr recalled recall_point recall firing_recall status
	
	sort svnr ref
		
		bysort svnr (ref): replace recall = 1 if recall_point[_n+1] == 1 & ref == $refp //last obs recall
		bysort svnr (ref): replace recall = 1 if recall[_n+1] == 1 & status !=3 & ref == $refp //on-going recall
		bysort svnr (ref): replace firing_recall = 1 if recall[_n+1] == 1 & status == 3 & ref == $refp //firing, first obs recall
		
		
		keep if ref == $refp
		save $temp/0011_temp_ref_Recalls.dta, replace

keep if recall == 1 | firing_recall == 1
keep svnr benr ref recalled recall recall_point firing_recall status
append using $data/0011_ref_Recalls_backw.dta
save $data/0011_ref_Recalls_backw.dta, replace
	
	} // m
} // y

erase $temp/0011_temp_ref_Recalls.dta


***append backw and forward
use $data/0011_ref_Recalls.dta, clear
append using $data/0011_ref_Recalls_backw.dta

collapse (sum) recalled recall recall_point firing_recall, by(svnr ref benr) 

sort svnr ref
isid svnr ref

replace benr = benr[_n-1] if recall == 1 //benr for recall, last benr is when firing_recall == 1, eliminating fake firms

save $data/0011_ref_Recalls.dta, replace
erase $data/0011_ref_Recalls_backw.dta

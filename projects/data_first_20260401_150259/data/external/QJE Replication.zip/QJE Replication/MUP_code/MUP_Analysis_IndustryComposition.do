*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						
*===============================================================================


set more off
set matsize 11000
timer clear 
est clear

cap log close
log using "${log}/MUP_Analysis_IndustryComposition2.log", replace

timer on 1

********************************************************************************
*
*		Measure industry composition changes (DiD)
*
********************************************************************************

		
use "${temp}/MUP_survival.dta" if abs(d_rel) <= ${bw_standard}, clear
	bys crefo (closdate_year): gen _n_obs = _n
	keep if _n_obs==1
	
	estimates drop _all
	* Create the number of the observation within firm ID for board composition variables
	bys crefo: gen i = _n
	
	* Create 
	gen const = 1
	
	gen cohort = qofd(dateinc)
	format %tq cohort
	* Create indicator for codetermination
	gen ind = d_rel < 0 

	* Create quadratic term in the running variable
	gen d2 = d_rel^2
	
	gen wzdig2 = floor(wzdig5/1000)

	gen i_nace_1 = inrange(wzdig2,1,3)
	gen i_nace_2 = inrange(wzdig2,5,9)
	gen i_nace_3 = inrange(wzdig2,10,33)
	gen i_nace_4 = inrange(wzdig2,35,35)
	gen i_nace_5 = inrange(wzdig2,36,39)
	gen i_nace_6 = inrange(wzdig2,41,43)
	gen i_nace_7 = inrange(wzdig2,45,47)
	gen i_nace_8 = inrange(wzdig2,49,53)
	gen i_nace_9 = inrange(wzdig2,55,56)
	gen i_nace_10 = inrange(wzdig2,58,63)
	gen i_nace_11 = inrange(wzdig2,64,66)
	gen i_nace_12 = inrange(wzdig2,68,68)
	gen i_nace_13 = inrange(wzdig2,69,75)
	gen i_nace_14 = inrange(wzdig2,69,75)
	gen i_nace_15 = inrange(wzdig2,77,82)
	gen i_nace_16 = inrange(wzdig2,84,84)
	gen i_nace_17 = inrange(wzdig2,85,85)
	gen i_nace_18 = inrange(wzdig2,86,88)
	gen i_nace_19 = inrange(wzdig2,90,93)
	gen i_nace_20 = inrange(wzdig2,94,96)
	gen i_nace_21 = inrange(wzdig2,97,98)
	gen i_nace_22 = inrange(wzdig2,99,99)
	
	
	/*
	levelsof nace_d1, local(levels)
	foreach l in `levels' {
		gen i_nace_`l' = nace_d1 == `l'
		replace i_nace_`l' = . if mi(nace_d1)
	}
	*/
	
	
	ds i_nace_* 
	local nace_list `r(varlist)'


	local list `nace_list' 
	
	qui foreach i in 1 8 {
		foreach x in nace_list  {
			global test_`x'`i'
			foreach y in ``x'' {
				global nametest_`x'`i' `nametest_`x'`i'' `y'`i'
				*global test_`x'`i' `test_`x'`i'' ([`y'`i']_b[1.AG#1.${pre_reform_indicator}] = 0)
			}
		}
	}
	
	
foreach inc_date in bvd  {
		
		if "`inc_date'"=="bvd" {
			global pre_reform_indicator pre_reform_inc
			global date_var dateinc
			global run_var d_rel
		}
				
	
qui foreach i in 1 8 {

	estimates drop _all
	timer on 2

	noi di "Specification `i'" 	

foreach type in nace  {
foreach outcome in ``type'_list'  {
	timer on 2

	noi di "	Outcome: `outcome'" 
		

	noi reg `outcome' i.AG##i.${pre_reform_indicator} ${vars`i'} i.cohort, ///
			nocons
			
			estimates store `outcome'`i'
			global test_`type'`i' ${`test_`type'`i''} `outcome'`i'
						
			global c`outcome'`wname'`i' = _b[1.AG#1.${pre_reform_indicator}]
			global s`outcome'`wname'`i' = _se[1.AG#1.${pre_reform_indicator}]
			global p`outcome'`wname'`i' = (2 * ttail(e(df_r), abs(_b[1.AG#1.${pre_reform_indicator}]/_se[1.AG#1.${pre_reform_indicator}])))
			global cag`outcome'`wname'`i' = _b[1.AG]
			global sag`outcome'`wname'`i' = _se[1.AG]
			global pag`outcome'`wname'`i' = (2 * ttail(e(df_r), abs(_b[1.AG]/_se[1.AG])))
			global cind`outcome'`wname'`i' = _b[1.${pre_reform_indicator}]
			global sind`outcome'`wname'`i' = _se[1.${pre_reform_indicator}]
			global pind`outcome'`wname'`i' = (2 * ttail(e(df_r), abs(_b[1.${pre_reform_indicator}]/_se[1.${pre_reform_indicator}])))
			global N`outcome'`wname'`i' `e(N)'
			
			
			cap drop _n_count
			bys crefo: gen _n_count = _n
					
			count if e(sample) == 1 & _n_count==1
			global Nf`outcome'`wname'`i' = `r(N)'
			
			count if e(sample) == 1 & AG == 1
			global Nag1`outcome'`wname'`i' = `r(N)'
			
			count if e(sample) == 1 & AG == 0
			global Nag0`outcome'`wname'`i' = `r(N)'
			
			* Control group mean at the discontinuity, i.e. in the first 30 days of the reform
			sum `outcome' if inrange(d_rel,0,90) & AG == 0
			global cmag0`outcome'`wname'`i' = `r(mean)' 

			sum `outcome' if inrange(d_rel,0,90) & AG == 1
			global cmag1`outcome'`wname'`i' = `r(mean)' 

		timer off 2 
		qui timer list 2
		noi di "	Time for outcome: `r(t2)' seconds" 
		timer clear 2
} // Outcomes 

suest i_`type'_*
noi test 1.AG#1.${pre_reform_indicator}

global chi_`type'`i' = r(chi2)
global p_`type'`i' = r(p)

noi di "	p-value for `sample' `famowner' `type'`i' : ${p_`type'`i'}"

} // Industry 
	
} // Specifications	


foreach i in 1 8 {

foreach type in nace {
foreach outcome in ``type'_list'  {

			local wname = subinstr("`w'",".","",.)

			* Save data from regressions
			clear 
			set obs 1
			gen spec = `i'
			gen outcome = "`outcome'"
			gen winsor = 0
			gen bandwidth = $bw_standard
			gen N = ${N`outcome'`wname'`i'}
			gen b = ${c`outcome'`wname'`i'}
			gen s = ${s`outcome'`wname'`i'}
			gen p = ${p`outcome'`wname'`i'}
			gen bag = ${cag`outcome'`wname'`i'}
			gen sag = ${sag`outcome'`wname'`i'}
			gen pag = ${pag`outcome'`wname'`i'}
			gen bind = ${cind`outcome'`wname'`i'}
			gen sind = ${sind`outcome'`wname'`i'}
			gen pind = ${pind`outcome'`wname'`i'}
			gen controlmean_AG = ${cmag1`outcome'`wname'`i'}
			gen controlmean_nonAG = ${cmag0`outcome'`wname'`i'}
			gen Nfirms = ${Nf`outcome'`wname'`i'}
			gen N_AG = ${Nag1`outcome'`wname'`i'}
			gen N_nonAG = ${Nag0`outcome'`wname'`i'}
			gen chi_jointtest = ${chi_`type'`i'}
			gen p_jointtest = ${p_`type'`i'}
			
			save "${temp}/MUP_DiD_`outcome'_Winsor`wname'_spec`i'_`sample'_`famowner'.dta", replace
			

		} // Outcome
		} // Industry 
} // Specification 


}	


log close	






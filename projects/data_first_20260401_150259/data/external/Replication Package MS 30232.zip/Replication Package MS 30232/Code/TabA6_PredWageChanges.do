/*******************************************************************************

	DESCRIPTION: Table A6

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/TabA6_PredWageChanges`curr_date'", replace

local sex_sample _all
local sample _fullSample
local yrFwd 1

	* load sample
	use ${temp}/02c_PooledReforms_yrFwd`yrFwd'.dta if inlist(reform, 1976, 1985, 1989, 2001) & inlist(yr_l5,.,0) & inlist(yr_l4,.,0) & reform-year == 1, clear

		* Indicator for REBP eligibility
		gen REBPcontrol = rebp != 0 & eREBP == 1 & reform == 1989 & year >= 1988

		* Winsorize earnings outcomes
		winsor2 earn_Diff_f`yrFwd', replace cut(1 99) by(reform year)

		* Keep if employed in December
		keep if status == 3


		*Shorten 1976 and 1989 by 1 pct
			foreach reform in 1976 1989 {
				su earn_pct if treatment_`reform' == 1
				local min = r(min)
				su earn_pct if control_`reform' == 1
				local max = r(max)
				local new_min = `min' + 1
				local new_max = `max' - 1
				drop if reform == `reform' & earn_pct <= `new_min' & !mi(earn_pct)
				drop if reform == `reform' & earn_pct >= `new_max' & !mi(earn_pct)
			} // Looping through 1976 and 1989 code blocks


			keep if mth_emp == 12
local list
foreach reform in 1976 1985 1989 2001 {

	qui count if treatment_`reform' == 1 & reform == `reform'
	global n_`reform' = `r(N)'
	qui gstats sum RRinstrument_earn_pct_f1 if treatment_`reform' == 1 & reform == `reform'
	foreach p in 25 50 75 90 95 {
		global p`p'_`reform': di %3.2f `r(p`p')'
	}
	global avg_`reform': di %3.2f `r(mean)'
	if `reform' != 1976 {
		local list `list' |
	}
	local list `list' (treatment_`reform' == 1 & reform == `reform')
}
	qui count if `list'
	global n_all = `r(N)'
	qui gstats sum RRinstrument_earn_pct_f1 if `list'
	foreach p in 25 50 75 90 95 {
		global p`p'_all: di %3.2f `r(p`p')'
	}
	global avg_all: di %3.2f `r(mean)'

foreach reform in 1976 1985 1989 2001 all {
	global frac_`reform': di %3.1f 100*(${n_`reform'}/${n_all})
	foreach var in p25 p50 p75 p90 p95 avg {
		global `var'_`reform'_m1: di %3.2f ${`var'_`reform'} * $wageBen_lo
		global `var'_`reform'_m2: di %3.2f ${`var'_`reform'} * $wageBen
	}
}

cap file close fh
file open fh using "${tables}/TabA6_PredWageChanges.tex", write replace

file write fh "\begin{tabular}{l c c c c c c c }" _n ///
"\hline \hline" _n ///
"Reform & Mean & P25 & Median & P75 & P90 & P95 & Fraction \\" _n ///
"\hline" _n ///
" & & & & & & & \\" _n
foreach reform in all 2001 1989 1985 1976 {
	if "`reform'" == "all" {
		local title Pooled
	}
	else {
		local title `reform'
	}
	file write fh "`title' & ${avg_`reform'_m1}/${avg_`reform'_m2} & ${p25_`reform'_m1}/${p25_`reform'_m2} & ${p50_`reform'_m1}/${p50_`reform'_m2} & ${p75_`reform'_m1}/${p75_`reform'_m2} & ${p90_`reform'_m1}/${p90_`reform'_m2} & ${p95_`reform'_m1}/${p95_`reform'_m2} & ${frac_`reform'}\% \\" _n ///
	" & \textit{${avg_`reform'}} & \textit{${p25_`reform'}} & \textit{${p50_`reform'}} & \textit{${p75_`reform'}} & \textit{${p90_`reform'}} & \textit{${p95_`reform'}} &  \\" _n ///
	" & & & & & & & \\" _n
}
file write fh "\hline \hline" _n "\end{tabular}" _n

file close fh

log close

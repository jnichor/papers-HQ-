*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
set more off
timer clear

set scheme plotplainblind

local ylabel_log_te_mw_Diff "-.2(.2).4"
local ylabel_akm_firm_fe_Diff "-.1(.1).2"
local ylabel_log_te_mw_DiD "-.2(.2).4"
local ylabel_akm_firm_fe_DiD "-.1(.1).2"
local ylabel_log_te_mw_RD "-.6(.2).4"
local ylabel_akm_firm_fe_RD "-.3(.1).3"
local ylabel_log_fias_Diff "-.5(1)4.5"
local ylabel_log_fias_per_empl_Diff "-.5(1)4.5"
local ylabel_log_av_per_empl_Diff "-.5(1)4.5"
local ylabel_log_fias_DiD "-.5(1)4.5"
local ylabel_log_fias_per_empl_DiD "-.5(0.5)2.5"
local ylabel_log_av_per_empl_DiD "-.5(0.5)2.5"

local posit_log_fias 5
local posit_log_fias_per_empl 5
local posit_log_av_per_empl 5
local posit_log_te_mw 6
local posit_akm_firm_fe 5
local gap_log_te_mw -40
local gap_akm_firm_fe -40
local gap_log_fias 0
local gap_log_fias_per_empl 0
local gap_log_av_per_empl 0


local file_log_fias_Diff "fig7d"
local file_log_fias_per_empl_Diff "fig7f"
local file_log_av_per_empl_Diff "fig7b"
local file_log_fias_DiD "figA6d"
local file_log_fias_per_empl_DiD "figA6f"
local file_log_av_per_empl_DiD "figA6b"
local file_log_te_mw_Diff "fig4c"
local file_akm_firm_fe_Diff "fig5c"
local file_log_te_mw_DiD "fig4d"
local file_akm_firm_fe_DiD "fig5d"
local file_log_te_mw_RD "figA4a"
local file_akm_firm_fe_RD "figA4c"


global outcomes  log_te_mw akm_firm_fe log_fias log_fias_per_empl log_av_per_empl
global winsor_values 1

global figname1_akm_firm_fe = "AKM Firm FE"
global figname1_log_te_mw  = "Log Wage, Mean"

global robustness1
global robustness2 "_robust_fias"
global robustness3 "_robust_av_per_empl"

timer on 1

global iabresults "$iab/205"


********************************************************************************

** Code for bandwidth

********************************************************************************

clear

foreach robust in 1 {

	foreach outcome in $outcomes {

		foreach i in 3 {

			clear

				foreach w in $winsor_values {

					use "${iabresults}/Bandwidth_`outcome'_Winsor`w'_spec`i'${robustness`robust'}.dta", replace

				}

				* keep specs >= 6 months
				keep if b >= 6

				local fontsize 5

				*--------------------------------------
				*--- DiD Spec
				*--------------------------------------

				* redenominate if in 1000 EUR

				qui sum c_did
				if `r(mean)' >= 1000 {
					foreach var in c_did ub_did lb_did s_did {
						replace `var' = `var'/1000
					}
				}

				qui sum c_did if b == 24
				global estimate : di %5.3f `r(mean)'
				qui sum s_did if b == 24
				global seestimate : di %5.3f `r(mean)'
				global graphtexty = $estimate + `posit_log_te_mw'*$seestimate

				tw connected c_did b , msymbol(Oh) mcolor(gray) msize(medium) || ///
					rarea ub_did lb_did b, color(gray%30) lwidth(medthick) || ///
					connected c_did b if b == 24, msymbol(S) mcolor(sea) msize(medium) || ///
					rcap ub_did lb_did b if b == 24, color(sea) lwidth(medthick) ///
					, ///
					text($graphtexty 24 "DiD: ${estimate} (SE ${seestimate})", size(`fontsize')) ///
					xtitle("Bandwidth (Months around August 10, 1994)", size(`fontsize')) ///
					ytitle("") ///
					yline(0, lcolor(red) lpattern(solid)) ///
					xlab(6(6)60, labsize(`fontsize')) ylab(`ylabel_`outcome'_DiD', labsize(`fontsize')) ///
					legend(off)
				graph export "${figures}/`file_`outcome'_DiD'.pdf", replace




				*--------------------------------------
				*--- Simple Difference Spec
				*--------------------------------------

				* redenominate if in 1000 EUR
				qui sum c_d
				if `r(mean)' >= 1000 {
					foreach var in c_d ub_d lb_d s_d {
						replace `var' = `var'/1000
					}
				}
				qui sum c_d if b == 24
				global estimate : di %5.3f `r(mean)'
				qui sum s_d if b == 24
				global seestimate : di %5.3f `r(mean)'
				global graphtexty = $estimate + `posit_`outcome''*$seestimate

				tw connected c_d b , msymbol(Oh) mcolor(gray) msize(medium) || ///
					rarea ub_d lb_d b, color(gray%30) lwidth(medthick) || ///
					connected c_d b if b == 24, msymbol(S) mcolor(sea) msize(medlarge) || ///
					rcap ub_d lb_d b if b == 24, color(sea) lwidth(medthick) ///
					, ///
					text($graphtexty 24 "Diff: ${estimate} (SE ${seestimate})", size(`fontsize')) ///
					xtitle("Bandwidth (Months around August 10, 1994)", size(`fontsize')) ///
					ytitle("") ///
					yline(0, lcolor(red) lpattern(solid)) ///
					xlab(6(6)60, labsize(`fontsize')) ylab(`ylabel_`outcome'_Diff', labsize(`fontsize')) ///
					legend(off)
				graph export "${figures}/`file_`outcome'_Diff'.pdf", replace


                if "`outcome'" == "log_te_mw" | "`outcome'" == "akm_firm_fe" {

				*--------------------------------------
				*--- RD Spec
				*--------------------------------------

				* redenominate if in 1000 EUR
				qui sum c_rd
				if `r(mean)' >= 1000 {
					foreach var in c_rd ub_rd lb_rd s_rd {
						replace `var' = `var'/1000
					}
				}

				qui sum c_rd if b == 24
				global estimate : di %5.3f `r(mean)'
				qui sum s_rd if b == 24
				global seestimate : di %5.3f `r(mean)'
				global graphtexty = $estimate - 5*$seestimate


				tw connected c_rd b , msymbol(Oh) mcolor(gray) msize(medium) || ///
					rarea ub_rd lb_rd b, color(gray%30) lwidth(medthick) || ///
					connected c_rd b if b == 24, msymbol(S) mcolor(sea) msize(medlarge) || ///
					rcap ub_rd lb_rd b if b == 24, color(sea) lwidth(medthick) ///
					, ///
					text($graphtexty 24 "RD: ${estimate} (SE ${seestimate})", size(`fontsize')) ///
					xtitle("Bandwidth (Months around August 10, 1994)", size(`fontsize')) ///
					ytitle("") ///
	                yscale(titlegap(*`gap_`outcome'')) ///
					yline(0, lcolor(red) lpattern(solid)) ///
					xlab(6(6)60, labsize(`fontsize')) ylab(`ylabel_`outcome'_RD', labsize(`fontsize')) ///
					legend(off)
				graph export "${figures}/`file_`outcome'_RD'.pdf", replace
           }

		}
	}
}

********************************************************************************
* 0007_benr_ktkz.do 
* cleans benr (establishment IDs)
* Input: Austria Qual-Files
* Output: benr_ktkz.dta
********************************************************************************

//// set globals
global ASSD /home/data/group_zweim/daten/Austria/ASSD2016
global REV /home/data/group_zweim/daten/Austria/REV2008
global UIF /home/data/group_zweim/projekte/UIFirms
global dofiles $UIF/dofiles
global data $UIF/data
global temp $UIF/temp
global script /home/data/group_zweim/pruh/daten/utilities
*cd $temp

clear

gen benr = "."
save $temp/benr_ktkz.dta, replace

forvalues a = 1/40 {
set more off
noi di `a'

use $ASSD/qualifikation/qual_`a'.dta, clear
keep benr ktkz

bysort benr ktkz: keep if _n==1

sort benr
replace ktkz = "x" if benr == benr[_n+1] //more than 1 different ktkt (benrs not unique over time)
replace ktkz = "x" if benr == benr[_n-1]

bysort benr ktkz: keep if _n==1

append using $temp/benr_ktkz.dta

bysort benr ktkz: keep if _n==1

sort benr
replace ktkz = "x" if benr == benr[_n+1] //more than 1 different ktkt (benrs not unique over time)
replace ktkz = "x" if benr == benr[_n-1]

bysort benr ktkz: keep if _n==1

isid benr
save $temp/benr_ktkz.dta, replace
}

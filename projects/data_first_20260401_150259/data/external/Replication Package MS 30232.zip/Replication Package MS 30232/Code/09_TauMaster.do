/*******************************************************************************

	DESCRIPTION: Tau master file. Contains globals used in the tau analysis.

*******************************************************************************/

clear all
set more off

********************************************************************************
* File directories
********************************************************************************
global home = "Q:/MarginalJobs/UIFirms"

global dofiles = "${home}/BargParam/Replication/dofiles"
global utilities "${home}/BargParam/Replication/dofiles/utilities"
adopath ++ "${home}/BargParam/Replication/dofiles/ado"

global qualData "${home}/BargParam/data/qualifikation"
global stamdattenData "${home}/data"
global temp "${home}/BargParam/Replication/temp"
global temp_qual "${home}/BargParam/Replication/temp/tauQualFiles"
global resDat = "${home}/BargParam/Replication/final/resultsData"
global table "${home}/BargParam/Replication/final/tables"
global figures "${home}/BargParam/Replication/final/figures"

global logs = "${home}/BargParam/replication/logs"


********************************************************************************
* Setting globals
********************************************************************************
global vyear	= 1972 		// 1972
global byear 	= 2018		// 2016
global vage 	= 25 		// 25
global bage		= 100 		// 54
global Edur		= 365		// 365
global Ndur		= .			// .
global EUdur	= 28		// 28
global day	 	1 	// 1 15 29 42

* set sample of analysis
global analysis = "lifecycle"	// "lifecycle" or "jobloss"

* Tau samples to calculate
global age_limit 70
global tau_samples Death${age_limit} DeathRet${age_limit}_PermEU DeathRetDis${age_limit}_PermEU

* Restrictions on returning to work XX years later
global returnWorkLim 4

* Set pre-reform years
global reforms 1976 1985 1989 2001


global prereformyears
foreach y in $reforms {
forvalues i = 3(-1)0 {
	global x = `y' - `i'
	global prereformyears $prereformyears $x
}
}

***** Globals for the 09c file

* Bargining power from meta-study
global phi .1

* Job stability restriction to include
global types = "_stable"

* Dropping percentiles from the 1976 and 1989 reforms
global Shorten76and89 = 1

***** Including or dropping the 1976 reform
	* 0 -> drop 1976 reform and extend the pre-period
	* 1 -> include the 1976 reform w/ limited pre-period
global include1976 1


* the sample for the summary stats table of the tau measures and whether prediction or actuals should be used
global prediction 	1	// 0=actual or 1=prediction
global age 	 	70 	// 54 or 70
global taumeasures 	E_frac N_frac O_frac UI_frac  UA_frac

* Note the order here matters for the table formatting
global tausamples  	 DeathRetDis${age}_PermEU DeathRet${age}_PermEU  Death${age}
global conditions	ENE4 EN



***** Globals for the tau heterogeneity file -- note some of the above ones are used too
global earnF 1
global aggregations earn_pct

* Differ from the above definitions
global tausamples_hetAnal DeathRetDis${age}_PermEU
global conditions_hetAnal ENE4



********************************************************************************
* Running .do files
********************************************************************************
**** Generating table (1) -- tau calculations under different assumptions
// do "${dofiles}/09a_Build_SpellData.do"
// do "${dofiles}/09b_Build_TauEstimates_Separators.do"
// do "${dofiles}/09c_Calculate_Mean_Tau_Separators.do"
// do "${dofiles}/Table1.do"


* Tau heterogeneity analysis
// do "${dofiles}/09d_Heterogeneity_Tau.do"
* figure
// do "${dofiles}/Fig7_TauHeterogeneity.do

// **** Generating table A.5
// do "${dofiles}/09b_Build_TauEstimates_FullSample.do"

// * Running the separators mean calculators without using the prediction -- for table A.5
// * We only need the EN restriction for the full sample

// global prediction 0
// global conditions EN
// do "${dofiles}/09c_Calculate_Mean_Tau_FullSample.do"

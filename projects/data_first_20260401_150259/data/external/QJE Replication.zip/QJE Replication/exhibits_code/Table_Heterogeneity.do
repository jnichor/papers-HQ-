*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
clear
set more off
set checksum off
set rmsg on
cap log close

set scheme plotplainblind
* Store Table Names in Globals
do "${code}/Set_Table_Names.do"

local cuts 0 1
local outcomes log_te_mw akm_firm_fe
**** Different groups of heterogeneity cut variables to plot
local hetgroups CBA_coverage ///
	binding_CBA_coverage ///
	akm_sd ///
	industry_akm ///
	works_council ///
	ln_av_empl ///
	tenure


local types  Diff DiD RD

local num : list sizeof local(hetgroups)
local wname 1
local control 3


foreach type in `types' {
	foreach outcome in `outcomes' {
		foreach cut in `cuts'{

			matrix beta_`cut'_`outcome'`type' = J(1,`num',.)

			matrix s_`cut'_`outcome'`type' = J(1,`num',.)

			matrix mh_`cut'_`outcome'`type' = J(1,`num',.)


		}
	}
}

foreach type in `types' {

	foreach outcome in `outcomes' {

		foreach cut in `cuts'{

			local i 0

			foreach hetergroup in `hetgroups' {

				local ++ i

				if "`type'" == "Diff" {
					use  "$iab/210/Heterogeneity_Diff_`outcome'_Winsor`wname'_spec`control'_`hetergroup'.dta", clear
				}
				else if "`type'" == "DiD" {
					use  "$iab/209/Heterogeneity_DiD_`outcome'_Winsor`wname'_spec`control'_`hetergroup'.dta", clear
				}
				else if "`type'" == "RD" {
					use  "$iab/211/Heterogeneity_RD_`outcome'_Winsor`wname'_spec`control'_`hetergroup'.dta", clear
				}
				matrix beta_`cut'_`outcome'`type'[1, `i'] = b[`cut'+1]

				matrix s_`cut'_`outcome'`type'[1, `i'] = s[`cut'+1]

				matrix mh_`cut'_`outcome'`type'[1, `i'] = mh[`cut'+1]

			}
		}
	}
}

local DiDtitle "Panel B:  Difference-in-Differences Design (Stock Corporations + LLC Control Group)"
local Difftitle "Panel A: Difference Design (Stock Corporations)"
local RDtitle "Panel C: Regression Discontinuity Design (Stock Corporations)"

****************************************************************************
* Writing tex file
****************************************************************************
cap file close fh
file open fh using "$tables/TableA11.tex", write replace
**** Writing preamble
file write fh "\begin{tabular}{l c c c c c c }" _n
file write fh "\hline \hline" _n
file write fh "\textit{Outcome} & \multicolumn{2}{c}{Control Means} & \multicolumn{2}{c}{Mean Log Wage} & \multicolumn{2}{c}{AKM Firm Fixed Effect} \\  \cmidrule(lr){2-3} \cmidrule(lr){4-5} \cmidrule(lr){6-7}" _n
file write fh "\textit{Cut} &  Below Median & Above Median &  Below Median & Above Median  & Below Median & Above Median  \\" _n

**** Writing het group specific results


qui foreach type in `types' {


	* Writing code for filler rows

	if "`type'" != "Diff" {
		file write fh "\vspace{0.1mm} \\" _n
	}

	file write fh "\hline" _n
	file write fh " \multicolumn{7}{l}{\textbf{``type'title'}} \\" _n "\hline" _n "\vspace{0.1mm} \\" _n



	qui foreach hetergroup in `hetgroups' {


	    * Writing code for the results rows

		* Category Labels
		if "`hetergroup'" == "CBA_coverage" {
			local catLab "CBA Coverage"
			local count 1
		}

		else if "`hetergroup'" == "binding_CBA_coverage" {
			local catLab "Binding CBA Coverage"
			local count 2
		}
		else if "`hetergroup'" == "works_council"  {
			local catLab "Works Council"
			local count 5
		}
		else if "`hetergroup'" == "akm_sd" {
			local catLab "AKM Pay Premia SD"
			local count 3
		}
		else if "`hetergroup'" == "industry_akm" {
			local catLab "Industry AKM"
			local count 4
		}
		else if "`hetergroup'" == "ln_av_empl" {
			local catLab "Log Value Added per Worker"
			local count 6
		}
		else if "`hetergroup'" == "tenure" {
			local catLab "Tenure"
			local count 7
		}

		local b_0_log_te_mw = beta_0_log_te_mw`type'[1, `count']
		local b_0_log_te_mw : di %5.3f `b_0_log_te_mw'
		local s_0_log_te_mw = s_0_log_te_mw`type'[1, `count']
		local s_0_log_te_mw : di %5.3f `s_0_log_te_mw'
		local mh_0_log_te_mw = mh_0_log_te_mw`type'[1, `count']
		local mh_0_log_te_mw : di %5.3f `mh_0_log_te_mw'


		local b_1_log_te_mw = beta_1_log_te_mw`type'[1, `count']
		local b_1_log_te_mw : di %5.3f `b_1_log_te_mw'
		local s_1_log_te_mw = s_1_log_te_mw`type'[1, `count']
		local s_1_log_te_mw : di %5.3f `s_1_log_te_mw'
		local mh_1_log_te_mw = mh_1_log_te_mw`type'[1, `count']
		local mh_1_log_te_mw : di %5.3f `mh_1_log_te_mw'

		local b_0_akm_firm_fe = beta_0_akm_firm_fe`type'[1, `count']
		local b_0_akm_firm_fe : di %5.3f `b_0_akm_firm_fe'
		local s_0_akm_firm_fe = s_0_akm_firm_fe`type'[1, `count']
		local s_0_akm_firm_fe : di %5.3f `s_0_akm_firm_fe'
		local mh_0_akm_firm_fe = mh_0_akm_firm_feDiff[1, `count']
		local mh_0_akm_firm_fe : di %5.3f `mh_0_akm_firm_fe'

		local b_1_akm_firm_fe = beta_1_akm_firm_fe`type'[1, `count']
		local b_1_akm_firm_fe : di %5.3f `b_1_akm_firm_fe'
		local s_1_akm_firm_fe = s_1_akm_firm_fe`type'[1, `count']
		local s_1_akm_firm_fe : di %5.3f `s_1_akm_firm_fe'
		local mh_1_akm_firm_fe = mh_1_akm_firm_feDiff[1, `count']
		local mh_1_akm_firm_fe : di %5.3f `mh_1_akm_firm_fe'

		file write fh "`catLab' &`mh_0_akm_firm_fe'  & `mh_1_akm_firm_fe' & `b_0_log_te_mw' \; \; (`s_0_log_te_mw')   & `b_1_log_te_mw' \; \; (`s_1_log_te_mw') & `b_0_akm_firm_fe'  \; \; (`s_0_akm_firm_fe') & `b_1_akm_firm_fe'  \; \; (`s_1_akm_firm_fe' )  \\" _n

	}
}

**** Writing end of table lines
file write fh " \vspace{-.3cm} \\" _n
file write fh "\hline \hline" _n
file write fh "\end{tabular}" _n
file close fh

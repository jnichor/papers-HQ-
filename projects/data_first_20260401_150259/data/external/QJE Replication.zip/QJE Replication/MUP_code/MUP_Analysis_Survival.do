*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						
*===============================================================================


set more off
set matsize 11000
timer clear 
est clear



********************************************************************************
*
*		Survival analysis
*
********************************************************************************

************************************************************************
/* SURVIVAL ANALYSIS



SETTINGS:
- You MUST choose a starting year (any year in [2004,2012])
- You MAY choose a placebo reform year (1992, 1993, 1996 or 1997). If you don't want a
	placebo year, write 0 in the placebo global. Figures that don't compare
	against a placebo will not run. */


cap log close
log using "${log}/MUP_Analysis_Survival1.log", replace


*CODE begins here:

global starting 2000
global placebo_year 0

global aug10_placebo = mdy(8,10,$placebo_year)




global id_observed_label "Probability of being observed"
global bankruptcy_prob "Probability of Bankruptcy"
global exit_hazard_label "Exit hazard rate"
global exit_hazard_bankruptcy_label "Bankruptcy hazard rate"

		

qui foreach outcome in id_observed bankruptcy_prob exit_hazard exit_hazard_bankruptcy {
	foreach suffix in "Incorporation" "$starting" {

	************************************
	*** whole sample
	************************************
		if $placebo_year == 0 {

			use "${temp}/MUP_survival.dta", clear
			gen yrs_${starting} = closdate_year - ${starting}
			
			if "`suffix'" == "$starting" {
				gen _keep=1 if id_observed == 1 & closdate == $starting
				bysort crefo: egen keep = min(_keep)
				keep if keep == 1
				replace exit_hazard=. if closdate == $starting
				replace id_observed = . if closdate_year - ${starting}>${time_horizon}
				keep if closdate_year <=  min(${end_year},$starting + ${time_horizon})
			}
			else {
				keep if closdate_year >= dateinc_year
				replace exit_hazard=. if yrs_Incorporation>${time_horizon}
				replace id_observed = . if yrs_Incorporation>${time_horizon}
			}

			
				keep if abs(d_rel) <= ${bw_standard}


				collapse (mean) `outcome', by(yrs_`suffix')
				keep if yrs>=0

				line `outcome' yrs_`suffix', ytitle("${`outcome'_label}", size(small)) ///
					xtitle("Years Relative to `suffix'", size(small)) ///
					
				graph export "${fig}/`outcome'whole_yrs_`suffix'.pdf", replace
			
		}

		
	****************************************************************
	*** by incorporation date (AGs only; pre_reform_inc=1 == pre reform)
	****************************************************************
	
	/*
		use "${temp}/MUP_survival.dta", clear
		gen yrs_${starting} = closdate_year - ${starting}
		
		keep if closdate_year <=  min(${end_year},$starting + ${time_horizon})
		
		
			if "`suffix'" == "$starting" {
				gen _keep=1 if id_observed == 1 & closdate == $starting
				bysort crefo: egen keep = min(_keep)
				keep if keep == 1
				replace exit_hazard=. if closdate == $starting
				replace id_observed = . if closdate_year - ${starting}>${time_horizon}
				keep if closdate_year <=  min(${end_year},$starting + ${time_horizon})
			}
			else {
				keep if closdate_year >= dateinc_year
				replace exit_hazard=. if yrs_Incorporation>${time_horizon}
				replace id_observed = . if yrs_Incorporation>${time_horizon}
			}


		if $placebo_year == 0 {

			keep if abs(d_rel) <= ${bw_standard}
			keep if firm == 1
			collapse (mean) `outcome', by(yrs_`suffix' pre_reform_inc)
			keep if yrs>=0

			tw (line `outcome' yrs_`suffix' if pre_reform_inc==1, ytitle("${`outcome'_label}", size(small)) ///
				xtitle("Years Relative to `suffix'", size(small))) ///
			(line `outcome' yrs_`suffix' if pre_reform_inc==0), ///
				legend(order(1 "Pre" 2 "Post") rows(1) pos(6)) note("Shareholder Corps only", size(small))
			graph export "${fig}/`outcome'prepost_yrs_`suffix'.pdf", replace

		}
		
		if $placebo_year != 0 {
			
			
			tempfile all
			save "`all'"
			
			*save temporary database with actual difference
			keep if abs(d_rel) <= ${bw_standard}
			keep if firm == 1

			collapse (mean) `outcome', by(yrs_`suffix' pre_reform_inc)
			reshape wide `outcome', i(yrs) j(pre_reform_inc)
			rename (`outcome'1 `outcome'0) (`outcome'_pre_actual `outcome'_post_actual)

			tempfile actual
			save "`actual'"
			
			
			*database with placebo differences
			use "`all'", clear
			
			gen d_rel_placebo = dateinc - $aug10_placebo
			gen pre_reform_inc_placebo = d_rel_placebo < 0
			keep if abs(d_rel_placebo) <= ${bw_standard}
			keep if firm == 1

			collapse (mean) `outcome', by(yrs_`suffix' pre_reform_inc_placebo)
			reshape wide `outcome', i(yrs) j(pre_reform_inc_placebo)
			rename (`outcome'1 `outcome'0) (`outcome'_pre_placebo `outcome'_post_placebo)

			merge 1:1 yrs using `actual', nogen keep(match)
			
			gen actual_diff = `outcome'_pre_actual- `outcome'_post_actual
			gen placebo_diff = `outcome'_pre_placebo- `outcome'_post_placebo
			keep if yrs>=0

			tw (line actual_diff yrs, ytitle("Difference in ${`outcome'_label}", size(small)) ///
				xtitle("Years Relative to `suffix'", size(small))) ///
			(line placebo_diff yrs), ///
				legend(order(1 "Actual" 2 "Placebo ($placebo_year)") rows(1) pos(6)) note("Shareholder Corps only", size(small))
			graph export "${fig}/`outcome'prepost_yrs_`suffix'_placebodiffs_${placebo}.pdf", replace
			
		}

		*/
		
	************************************
	*** by firm type and incorporation date
	************************************
		use "${temp}/MUP_survival.dta", clear
		gen yrs_${starting} = closdate_year - ${starting}
		
		keep if closdate_year <=  min(${end_year},$starting + ${time_horizon})
		replace id_observed = . if closdate_year - ${starting}>${time_horizon}

			if "`suffix'" == "$starting" {
				gen _keep=1 if id_observed == 1 & closdate == $starting
				bysort crefo: egen keep = min(_keep)
				keep if keep == 1
				replace exit_hazard=. if closdate == $starting
				replace id_observed = . if closdate_year - ${starting}>${time_horizon}
				keep if closdate_year <=  min(${end_year},$starting + ${time_horizon})
			}
			else {
				keep if closdate_year >= dateinc_year
				replace exit_hazard=. if yrs_Incorporation>${time_horizon}
				replace id_observed = . if yrs_Incorporation>${time_horizon}
			}


		if $placebo_year == 0 {

			keep if abs(d_rel) <= ${bw_standard}
			collapse (mean) `outcome', by(yrs_`suffix' pre_reform_inc firm)
			label values pre_reform_inc pre_reform_inc
			keep if yrs>=0

			tw (line `outcome' yrs_`suffix' if firm==1 & pre_reform_inc==1,  ///
				 ytitle("${`outcome'_label}", size(small)) ///
				xtitle("Years Relative to `suffix'", size(small))) ///
			(line `outcome' yrs_`suffix' if firm==1 & pre_reform_inc==0)  ///
			(line `outcome' yrs_`suffix' if firm==0 & pre_reform_inc==1)  ///
			(line `outcome' yrs_`suffix' if firm==0 & pre_reform_inc==0),  ///
			legend(order(1 "Old Shareholder Corp." 2 "New Shareholder Corp" 3 "Old Non-Shareholder Corp." 4 "New Non-Shareholder Corp.") cols(1) pos(6))
			graph export "${fig}/`outcome'allcomparisons_yrs_`suffix'.pdf", replace

		}

		if $placebo_year != 0 {
		
			tempfile all
			save "`all'"
			
			*save temporary database with actual difference
			keep if abs(d_rel) <= ${bw_standard}
			
			collapse (mean) `outcome', by(yrs_`suffix' pre_reform_inc firm)
			reshape wide `outcome', i(yrs firm) j(pre_reform_inc)
			rename (`outcome'1 `outcome'0) (`outcome'_pre_actual `outcome'_post_actual)
			reshape wide `outcome'*, i(yrs) j(firm)
			rename (`outcome'_pre_actual1 `outcome'_post_actual1 `outcome'_pre_actual0 `outcome'_post_actual0) ///
				   (`outcome'_pre_actual_ag `outcome'_post_actual_ag `outcome'_pre_actual_gmbh `outcome'_post_actual_gmbh)

			tempfile actual
			save "`actual'"
			
			
			*database with placebo differences
			use "`all'", clear
			
			gen d_rel_placebo = d_rel + mdy(8,10,1994) - $aug10_placebo
			gen pre_reform_inc_placebo = d_rel_placebo < 0
			keep if abs(d_rel_placebo) <= ${bw_standard}
			
			collapse (mean) `outcome', by(yrs_`suffix' pre_reform_inc_placebo firm)
			reshape wide `outcome', i(yrs firm) j(pre_reform_inc_placebo)
			rename (`outcome'1 `outcome'0) (`outcome'_pre_placebo `outcome'_post_placebo)
			reshape wide `outcome'*, i(yrs) j(firm)
			rename (`outcome'_pre_placebo1 `outcome'_post_placebo1 `outcome'_pre_placebo0 `outcome'_post_placebo0) ///
				   (`outcome'_pre_placebo_ag `outcome'_post_placebo_ag `outcome'_pre_placebo_gmbh `outcome'_post_placebo_gmbh)
			merge 1:1 yrs using `actual', nogen keep(match)
			
			gen actual_did = (`outcome'_pre_actual_ag - `outcome'_post_actual_ag) - (`outcome'_pre_actual_gmbh - `outcome'_post_actual_gmbh)
			gen placebo_did = (`outcome'_pre_placebo_ag - `outcome'_post_placebo_ag) - (`outcome'_pre_placebo_gmbh - `outcome'_post_placebo_gmbh)
			keep if yrs>=0

			tw (line actual_did yrs, ytitle("DiD of ${`outcome'_label}", size(small)) ///
				xtitle("Years Relative to `suffix'", size(small))) ///
			(line placebo_did yrs), legend(order(1 "Actual" 2 "Placebo ($placebo_year)") rows(1) pos(6))
			graph export "${fig}/`outcome'DiD_yrs_`suffix'_placebo_${placebo}.pdf", replace
			
		}
	} // years relative to ...
	} // outcome





	********************************************************************************
	*regressions

	*ad-hoc globals:

		global surv_specifications 1 2 6

		global surv_winsor_values 1
		
		global surv_controls1 const // No surv_controls
		global surv_controls2 i.closdate_year const // Year FEs
		global surv_controls3 i.nace_d2_grp const // Industry FEs
		global surv_controls4 i.nace_d2_grp#i.closdate_year const // Industry-Year FEs 
		global surv_controls5 i.yrs_Incorporation const // year-since-incorporation FEs 
		global surv_controls6 i.closdate_year i.yrs_Incorporation const // year and year-since-incorporation FEs
		global surv_controls7 i.closdate_year#i.AG const // AG-Specific Year FEs
		global surv_controls8 const // RD
		global surv_controls9 i.nace_d2_grp#i.closdate_year const // RD 
		global surv_controls10 i.closdate_year#i.AG const // RD 
		global surv_controls11 i.nace_d2_grp#i.closdate_year#i.cohort const // RD 
		global surv_controls12 i.nace_d2_grp const // RD 
		
		global surv_outcomes id_observed exit_hazard

			use "${temp}/MUP_survival.dta" if abs(d_rel) <= ${bw_standard} & closdate_year<=${end_year} & closdate_year>=dateinc_year, clear // run survival outcomes!
			gen yrs_${starting} = closdate_year - ${starting}
			
			replace exit_hazard=. if closdate == $starting

			gen const = 1
			egen cluster = group($default_cluster)
			gen nace_d2 = floor(wzdig5/1000)
			egen nace_d2_grp = group(nace_d2)
			gen ind = d_rel < 0

	qui foreach i in $surv_specifications {

	timer on 2

		noi di "Specification `i'" 	


	foreach outcome in $surv_outcomes {

		timer on 2
		noi di "	Outcome: `outcome'" 
		
		foreach w in $surv_winsor_values {
		
			noi di "		Winsor value: `w'%" 
			local wname = subinstr("`w'",".","",.)
		
		noi reg `outcome' i.AG##i.pre_reform_inc ${surv_controls`i'},  vce(cluster crefo)
			
				global c`outcome'`wname'`i' = _b[1.AG#1.ind]
				global s`outcome'`wname'`i' = _se[1.AG#1.ind]
				global p`outcome'`wname'`i' = (2 * ttail(e(df_r), abs(_b[1.AG#1.ind]/_se[1.AG#1.ind])))
				global cag`outcome'`wname'`i' = _b[1.AG]
				global sag`outcome'`wname'`i' = _se[1.AG]
				global pag`outcome'`wname'`i' = (2 * ttail(e(df_r), abs(_b[1.AG]/_se[1.AG])))
				global cind`outcome'`wname'`i' = _b[1.ind]
				global sind`outcome'`wname'`i' = _se[1.ind]
				global pind`outcome'`wname'`i' = (2 * ttail(e(df_r), abs(_b[1.ind]/_se[1.ind])))
				global N`outcome'`wname'`i' `e(N)'
				
				
				gdistinct crefo if e(sample) == 1
				global Nf`outcome'`wname'`i' = `r(ndistinct)'
				
				gdistinct crefo if e(sample) == 1 & AG == 1
				global Nag1`outcome'`wname'`i' = `r(ndistinct)'
				
				gdistinct crefo if e(sample) == 1 & AG == 0
				global Nag0`outcome'`wname'`i' = `r(ndistinct)'
				
				* Control group mean at the discontinuity, i.e. in the first 30 days of the reform
				gstats su `outcome' if inrange(d_rel,0,90) & AG == 0
				global cmag0`outcome'`wname'`i' = `r(mean)' 

				gstats su `outcome' if inrange(d_rel,0,90) & AG == 1
				global cmag1`outcome'`wname'`i' = `r(mean)' 

			} // Winsor values
			timer off 2 
			qui timer list 2
			noi di "	Time for outcome: `r(t2)' seconds" 
			timer clear 2
			
	} // Outcomes 

	} // Specifications

	}

	

foreach i in $surv_specifications {

qui foreach outcome in $surv_outcomes {

foreach w in $surv_winsor_values {

			local wname = subinstr("`w'",".","",.)

			 
			* Save data
			clear 
			set obs 1
			gen spec = `i'
			gen outcome = "`outcome'"
			gen winsor = `w'
			gen bandwidth = $bw_standard
			gen N = ${N`outcome'`wname'`i'}
			gen b = ${c`outcome'`wname'`i'}
			gen s = ${s`outcome'`wname'`i'}
			gen p = ${p`outcome'`wname'`i'}
			gen bag = ${cag`outcome'`wname'`i'}
			gen sag = ${sag`outcome'`wname'`i'}
			gen pag = ${pag`outcome'`wname'`i'}
			gen bind = ${cind`outcome'`wname'`i'}
			gen sind = ${sind`outcome'`wname'`i'}
			gen pind = ${pind`outcome'`wname'`i'}
			gen controlmean_AG = ${cmag1`outcome'`wname'`i'}
			gen controlmean_nonAG = ${cmag0`outcome'`wname'`i'}
			gen Nfirms = ${Nf`outcome'`wname'`i'}
			gen N_AG = ${Nag1`outcome'`wname'`i'}
			gen N_nonAG = ${Nag0`outcome'`wname'`i'}
			
			
			
			save "${temp}/MUP_`outcome'_Winsor`wname'_spec`i'.dta", replace
			
			} // Winsor values
		} // Outcome
} // Specification 

log close

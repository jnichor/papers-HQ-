/*******************************************************************************

	DESCRIPTION: Table A.2

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
cap file close fh
local curr_date = c(current_date)
log using "${logs}/Table_DiD_Takeup`curr_date'", replace

****************************************************************************

		local group = 2
			local with2 With76
			local coefflist1 l3 l2 l0
			local coefflist2 l3 l0

global instrumentF 1
* Choose which of controls below to use
local control_num_list_earn_pct 1 2 3 4 5 6
local control_num_list_benr 1 2 3 4
local control_num_list_nace08 1 2 7 8
local control_num_list_horserace 1 4 6
local control_num_list_cba_unit 9 10 11 12 15 16
local control_num_list_indocc 9 10 11 12 15 16

local xlist_earn_pct 2 3 5
local xlist_benr 2 3
local xlist_nace08 2 7
local xlist_cba_unit 2 9 11
local xlist_indocc 2 7 11


local controlname1 none
local controlname2 mincer
local controlname3 indocc
local controlname4 ctrls
local controlname5 firmyr
local controlname6 ctrlsfirmyr
local controlname7 ind3dig
local controlname8 ctrlsind3dig

local controlname9 none
local controlname10 mincer
local controlname11 indyr
local controlname12 occyr
local controlname13 minc_indyr
local controlname14 minc_occyr
local controlname15 indyroccyr
local controlname16 minc_indyroccyr

forval j = 1/16 {
	local `controlname1'_ind`j' "X"
	if inlist(`j', 2, 4, 6, 10, 13, 14, 16) {
		local `controlname2'_ind`j' "X"
	}
	if inlist(`j', 3, 4, 6) {
		local `controlname3'_ind`j' "X"
		local `controlname4'_ind`j' "X"
	}
	if inlist(`j', 5, 6) {
		local `controlname5'_ind`j' "X"
		local `controlname6'_ind`j' "X"
	}
	if inlist(`j', 7, 11, 13, 15, 16) {
		local `controlname7'_ind`j' "X"
		local `controlname8'_ind`j' "X"
	}
	if inlist(`j', 9,11, 13, 15, 16) {
		local `controlname9'_ind`j' "X"
	}
	if inlist(`j', 12, 14, 15, 16) {
		local `controlname11'_ind`j' "X"
	}
}


* Aggregations
local aggregations earn_pct

foreach x in `aggregations'  {
	local number_specs_`x' = 0
	foreach i in `control_num_list_`x'' {
		local number_specs_`x' = `number_specs_`x'' + 1
	}
}



foreach x in earn_pct benr cba_unit indocc {
	local number_specs_`x' = 0
	foreach i in `control_num_list_`x'' {
		local number_specs_`x' = `number_specs_`x'' + 1
	}
}

cap file close fh


		foreach suffix in `aggregations' {



			if "`suffix'" == "earn_pct" {
				local earningsoutcomes /*UIdur_f`yrFwd'_NE  UIdur_f`yrFwd'*/  takeup_f`yrFwd'
				local name_earningsoutcomes earningsoutcomes_`yrFwd'
				local coefflist `coefflist`yrFwd''
					local tablename /*Table_UIdur_mthUE*/ TabA2_Takeup_DiD


			}

			if inlist("`suffix'", "benr", "nace08", "cba_unit", "indocc", "TLI" ) {
				local name_earningsoutcomes earningsoutcomes
				local coefflist `coefflist1'
				local tablename Table_`suffix'
			}

				local realizedRRoutcomes realizedRRChange_f1 realizedRRChange_f2
				local name_realizedRRoutcomes realizedRRoutcomes
				local alternateoutcomes mover_f`yrFwd' recalled_f`yrFwd' ENE_f`yrFwd' EUE_f`yrFwd'  ///
				mth_non_emp_f`yrFwd' mth_UE_f`yrFwd' mth_sick_f`yrFwd'
				local name_alternateoutcomes alternateoutcomes_f`yrFwd'

			local tables earningsoutcomes //realizedRRoutcomes alternateoutcomes

			foreach results in `tables' {

			file open fh using "${tables}/`tablename'.tex", write replace

			* Need one column for every outcome-specification pair
			local collist
			forval i = 1/`number_specs_`suffix'' {
				foreach outcome in takeup_f1  {
					local collist `collist' c
				}
			}


			local spec_num_row
			local cmidrule_row
			local startofline = 2
				local number = 1
			foreach outcome in takeup_f1  {
				foreach cnt_grp in `control_num_list_`suffix'' {
					local spec_num_row "`spec_num_row' & (`number')"
					local number = `number' + 1
				}
				local endofline = `startofline' + `number_specs_`suffix'' - 1
				local cmidrule_row "`cmidrule_row' \cmidrule(lr){`startofline'-`endofline'}"
				local startofline = `startofline' + `number_specs_`suffix''
			}

			file write fh "\begin{tabular}{l `collist'}" _n "\hline \hline" _n  " & \multicolumn{`number_specs_`suffix''}{c}{Earnings Effects} \\" _n "`cmidrule_row' `spec_num_row' \\" _n

			foreach yrFwd in 1 2 {

			local letter1 A
			local letter2 B

			foreach outcome in  /*UIdur_f`yrFwd'_NE  UIdur_f`yrFwd'*/ takeup_f`yrFwd'  {


				if "`outcome'" == "earn_Diff_f`yrFwd'" {
					local lab`outcome' = "`yrFwd'-Year Horizon"
				}

				if "`outcome'" == "takeup_f`yrFwd'" {
					local lab`outcome' = "UI Takeup, `yrFwd' Year Ahead (100 * Indicator)"
				}
				if "`outcome'" == "UIdur_f`yrFwd'" {
					local lab`outcome' = "Months UI $|$ Takeup, `yrFwd' Year Ahead "
				}
				if "`outcome'" == "UIdur_f`yrFwd'_NE" {
					local lab`outcome' = "Months UI $|$ NE, `yrFwd' Year Ahead "
				}
				if "`outcome'" == "RRChange_f`yrFwd'" {
					local lab`outcome'  = "Pred. `yrFwd'-Year RR Change"
				}

				if "`outcome'" == "realizedRRChange_f`yrFwd'" {
					local lab`outcome'  = "`yrFwd'-Year Realized RR Effects"
				}

				if "`outcome'" == "mth_non_emp_f`yrFwd'" {
					local lab`outcome'  = "Pct Mths Non-Employed, `yrFwd' Yr Ahead"
				}

				if "`outcome'" == "mth_UE_f`yrFwd'" {
					local lab`outcome'  = "Pct Mths on UI, `yrFwd' Yr Ahead"
				}

				if "`outcome'" == "mth_sick_f`yrFwd'" {
					local lab`outcome'  = "Pct Mths Sick, `yrFwd' Yr Ahead"
				}

				if "`outcome'" == "mover_f`yrFwd'" {
					local lab`outcome'  = "Prob. Mover, `yrFwd' Yr Ahead"
				}

				if "`outcome'" == "mover_f`yrFwd'" {
					local lab`outcome'  = "Prob. Recalled, `yrFwd' Yr Ahead"
				}

				if "`outcome'" == "ENE_f`yrFwd'" {
					local lab`outcome'  = "Prob. of ENE Transition, `yrFwd' Yr Ahead"
				}

				if "`outcome'" == "mover_f`yrFwd'" {
					local lab`outcome'  = "Prob. of EUE Transition, `yrFwd' Yr Ahead"
				}

				local outc_name_row
				local outc_name_row "`outc_name_row' & \multicolumn{`number_specs_`suffix''}{c}{Panel `letter`yrFwd'': `lab`outcome''}"

				local short = substr("`suffix'",1,1)

				foreach i in `control_num_list_`suffix'' {

				if "`suffix'" == "earn_pct" {
				use "${resDat}/DiD_${instrumentF}_`suffix'_`outcome'_`with`group''_stable_Spec`controlname`i''.dta", clear
				}
				if "`suffix'" == "benr" {
				use "${resDat}/DiD_${instrumentF}_`suffix'_`outcome'_`with`group''_stable_Spec`controlname`i''.dta", clear
				}
				if "`suffix'" == "cba_unit" {
				use "${resDat}/DiD_${instrumentF}_`suffix'_`outcome'_`with`group''_stable_Spec`controlname`i''.dta", clear
				}
				if "`suffix'" == "indocc" {
				use "${resDat}/DiD_${instrumentF}_`suffix'_`outcome'_`with`group''_stable_Spec`controlname`i''.dta", clear
				}
					foreach yr in l3 l2 l0 {

						local x = substr("`yr'", -1, 1)

						if substr("`yr'", 1, 1) == "l" {
							local n = 0 - `x'
						}

						if substr("`yr'", 1, 1) == "f" {
							local n = 0 + `x'
						}
						if strpos("`outcome'", "_f2") > 0 & "`yr'" == "l2" {
						}
						else {
						qui su `controlname`i''_coeff if year == `n'
						global b`group'_`outcome'_`yr'_`short'`i': di %5.3f 100*`r(mean)'
						qui su `controlname`i''_SE if year == `n'
						local temp: di %5.3f 100*`r(mean)'
						global se`group'_`outcome'_`yr'_`short'`i' = "(" + "`temp'" + ")"


						}
					}

					qui su `controlname`i''_R
					global R`group'_`outcome'_`short'`i': di %5.3f `r(mean)'
					qui su `controlname`i''_N
					global N`group'_`outcome'_`short'`i' = round(`r(mean)' / 1000,1)
					qui su `controlname`i''_F
					global F`group'_`outcome'_`short'`i': di %5.3f `r(mean)'
					qui su `controlname`i''_avg
					global avg`group'_`outcome'_`short'`i': di %5.3f 100*`r(mean)'
				}

			}



			file write fh  "\hline" _n "`outc_name_row' \\" _n "\hline" _n

				local n = 1
				foreach yr in l3 l2 {
					local x = substr("`yr'", -1, 1)
					local coeffline`n' " Placebo: `x' Yr Lag"
					local seline`n' ""
					local n = `n' + 1
				}
				local treatcoeffline "\textbf{Treatment Year}"
				local treatseline ""
				local blankline ""
				local avgline "Base-Year Average"
				local Fline "Pre-p F-test p-val"
				local rline "\textit{R}$^{2}$"
				local nline "\textit{N} (1000s)"

			* Groups of columns of outcomes
			foreach outcome in /*UIdur_f`yrFwd'_NE   UIdur_f`yrFwd' */  takeup_f`yrFwd' {

				* Columns of control groups
				foreach cnt_grp in `control_num_list_`suffix'' {
						* Rows of yearly coefficients
						local n = 1
						foreach yr in l3 l2 {
							local coeffline`n' "`coeffline`n'' & ${b`group'_`outcome'_`yr'_`short'`cnt_grp'}"
							local seline`n' "`seline`n'' & ${se`group'_`outcome'_`yr'_`short'`cnt_grp'}"
							local n = `n' + 1
						}	//Year coefficients
					local treatcoeffline "`treatcoeffline' & \textbf{ ${b`group'_`outcome'_l0_`short'`cnt_grp'}}"
					local treatseline "`treatseline' & \textbf{ ${se`group'_`outcome'_l0_`short'`cnt_grp'}} "
					local blankline "`blankline' & "
					local avgline "`avgline' & ${avg`group'_`outcome'_`short'`cnt_grp'}"
					local Fline "`Fline' & ${F`group'_`outcome'_`short'`cnt_grp'} "
					local rline "`rline' & ${R`group'_`outcome'_`short'`cnt_grp'} "
					local nline "`nline' & ${N`group'_`outcome'_`short'`cnt_grp'} "

				} //Columns of controls
			} // Groups of columns of outcomes

			* Write up subsection
			file write fh "`blankline' \\" _n
			local n = 1
			foreach yr in l3 l2 {
				file write fh "`coeffline`n'' \\" _n "`seline`n'' \\" _n
				local n = `n' + 1
			}
			file write fh "\vspace{-.3cm} \\" _n "`treatcoeffline' \\" _n "`treatseline' \\" _n ///
			 "\vspace{-.2cm} \\" _n "\hline" _n "`avgline' \\" _n "`Fline' \\" _n ///
			"\vspace{-.3cm} \\" _n "`rline' \\" _n "`nline' \\" _n

			}
			* Control indicators
			file write fh "\hline" _n
			local specline2 "Mincerian Ctrls"
			local specline3 "4-Digit Ind.-Occ. FEs"
			local specline5 "Firm-Year FEs"
			local specline7 "3-Digit Ind. FEs"
			local specline9 "Ind. FEs"
			local specline11 "Occ. FEs"

			foreach outcome in /* UIdur_f`yrFwd'_NE   UIdur_f`yrFwd' */ takeup_f`yrFwd' {
				foreach i in `xlist_`suffix'' {
					foreach j in `control_num_list_`suffix'' {
						local specline`i' "`specline`i'' & ``controlname`i''_ind`j'' "
					}
				}
			}
			foreach i in `xlist_`suffix'' {
				file write fh "`specline`i'' \\" _n
			}
			file write fh "\hline \hline" _n "\end{tabular}" _n

			file close fh

		} // Instrument Aggregation
		} //Years Forward

log close

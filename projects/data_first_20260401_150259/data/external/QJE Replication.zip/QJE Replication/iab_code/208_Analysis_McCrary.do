*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/208/$today"
local output $log/208/$today

log using "`output'/208_McCrary.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*		208 Rent Sharing Analyis
*
********************************************************************************

* load sample
use "$data\iab_wage_analysis_winsor1.dta" if abs(d_rel) <= ${bw_standard} & (AG | GmbH) , clear

local months = 365/12
egen _bins = cut(d_rel), at(-1825(`months')1916.25)
egen months = group(_bins)
drop _bins
gen month_rel = d_rel/`months'
gen y_rel = d_rel / 365


*	Figure:  Selection Into Stock Corporation Status (proportion)
* ------------------------------------------------------------------------------

preserve
bys idnr: keep if _n == 1
collapse (mean) AG month_rel (sum) N=AG, by(months prereformcohort)
replace AG = 100*AG
lab var AG "proportion in percentage points"
lab var N "number of AGs"

save "`output'/proportion_stockselection.dta"

restore

preserve


bys idnr: keep if _n == 1
replace AG = 100*AG
foreach i in 1 2 {

  if `i' == 1 {
      reghdfe AG c.y_rel##i.prereformcohort, noabsorb  vce(cluster cluster_variable)
  }

  if `i' == 2 {
      reghdfe AG c.y_rel##i.prereformcohort, absorb(nace_d2_grp)  vce(cluster cluster_variable)
  }

  global b`i' = _b[c.y_rel#1.prereformcohort]
	global s`i' = _se[c.y_rel#1.prereformcohort]
	global p`i' = (2 * ttail(e(df_r), abs(_b[c.y_rel#1.prereformcohort]/_se[c.y_rel#1.prereformcohort])))

	global by`i' = _b[y_rel]
	global sy`i' = _se[y_rel]
	global py`i' = (2 * ttail(e(df_r), abs(_b[y_rel]/_se[y_rel])))

	global bpre`i' = _b[1.prereformcohort]
	global spre`i' = _se[1.prereformcohort]
	global ppre`i' = (2 * ttail(e(df_r), abs(_b[1.prereformcohort]/_se[1.prereformcohort])))

	global bcons`i' = _b[_cons]
	global scons`i' = _se[_cons]
	global pcons`i' = (2 * ttail(e(df_r), abs(_b[_cons]/_se[_cons])))

	global R`i' `e(r2_a_within)'

	* Number of AGs and GmbHs
  qui gstats su AG if e(sample)==1
	global N`i' = `r(N)'

  qui gstats su AG if e(sample)==1 & AG==100
  global Nag`i' = `r(N)'

  qui gstats su AG if e(sample)==1 & AG==0
  global Ngmbh`i' = `r(N)'

  qui gstats su AG if  e(sample)==1 & prereformcohort==0
  global cm`i' = `r(mean)'




}


foreach i in 1 2 {

	* Save data
	clear
	set obs 1
	gen spec = `i'
	gen bandwidth = $bw_standard
	gen b = ${b`i'}
	gen s = ${s`i'}
	gen p = ${p`i'}
	gen by = ${by`i'}
	gen sy = ${sy`i'}
	gen py = ${py`i'}
	gen bpre = ${bpre`i'}
	gen spre = ${spre`i'}
	gen ppre = ${ppre`i'}
	gen bcons = ${bcons`i'}
	gen scons = ${scons`i'}
	gen pcons = ${pcons`i'}

  gen cmean= ${cm`i'}
	gen N = ${N`i'}
	gen Nag = ${Nag`i'}
	gen Ngmbh = ${Ngmbh`i'}
	gen Radjusted = ${R`i'}

	save "`output'/Incorporation_spec`i'.dta", replace

}

restore


*	Figure:  Selection Into Stock Corporation Status (proportion)
* ------------------------------------------------------------------------------

preserve
bys idnr: keep if _n == 1
keep if AG == 1


DCdensity_withnote month_rel, breakpoint(0) ///
generate(Xj Yj r0 fhat se_fhat)  b(1)

keep if (Xj!=.) | (Yj!=.) | (r0!=.) | (fhat!=.) | (se_fhat!=.)
keep Xj Yj r0 fhat se_fhat theta*


save "`output'/McCrary_test.dta"
restore

log close

/*******************************************************************************

	DESCRIPTION: Difference-in-differences analysis of PBD extension
		reform.



*******************************************************************************/

****************************************************************************
***** Preliminaries
****************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/05c_PBDExtension_Analysis_DiD`curr_date'", replace

****************************************************************************
* Treatment and control parameters
****************************************************************************
* Control start and end ages
local cnt_start = 35
local cnt_end = 38

* Treatment start and end ages
local treat_start = 39
local treat_end = 42

* Weeks of experience in the past 10 years required to be eligible for
local exp_weeks = 312

* Year to normalize treatment efect equal to zero for
local excld_yr = 1987

* Starting and ending years
local start_yr = 1983
local end_yr = 1989


********************************************************************************
***** Specifying which controls to include
********************************************************************************


local cluster_var svnr nace08
local controls year##c.(exp25 exp25_sq exp25_cub tenure tenure_sq tenure_cub lnearnings)
local FE_controls age_round nace08#whitecoll#year year#earn_pct_bin year#frau year#REBPcontrol const

use ${temp}/05a_DataSet.dta, clear
gen const =1
	* Generating year dummies and year interacted with treatment
	forvalues yr = `start_yr'(1)`end_yr' {
		gen yr_`yr' = year == `yr'
		gen treat_`yr' = year == `yr' & PBD_treated == 1
	}

	foreach yrfwd in $earnF {

		if `yrfwd' == 1 {

			* Treated year and year excluded from estimation
			local excld_yr = 1987
			local treat_yr = 1988

			**** Defining lists of years to include in the regression
				* All years except the excluded year
			local yr_list 1983 1984 1985 1986 1988

			local DiD_Ests_numRow = 6
		}

		if `yrfwd' == 2 {

			* Treated year and year excluded from estimation
			local excld_yr = 1986
			local treat_yr = 1988

			**** Defining lists of years to include in the regression
				* All years except the excluded year
			local yr_list 1983 1984 1985 1988

			local DiD_Ests_numRow = 5

			drop if age_round == 38

		}

		* Defining regression variables
		local reg_vars
		foreach yr in `yr_list' {
			local reg_vars  `reg_vars' yr_`yr' treat_`yr'
		}

		* Running regression for each control group

			* Matrix to store estimated treatment - control for DiD figures
			matrix DiD_Ests = J(`DiD_Ests_numRow', 3,.)
			matrix colnames DiD_Ests = year coeff SE

			* Running regressions
			noi reghdfe earn_Diff_f`yrfwd' `reg_vars' `controls`cnt_grp'', absorb(`FE_controls`cnt_grp'') vce(cluster `cluster_var')

			* Saving the estimated coeff diffs in the matrix for plotting
			local row_counter = 1
			foreach yr in `yr_list' {

				mat DiD_Ests[`row_counter',1] = `yr'

				* Adding all estimated coefficients to the matrix
				mat DiD_Ests[`row_counter',2] = _b[treat_`yr']
				mat DiD_Ests[`row_counter',3] = _se[treat_`yr']
				local row_counter = `row_counter' + 1
			} // Years list

			* Plotting estimated coefficients and SEs
			preserve

				clear
				svmat DiD_Ests, names(col)

				**** Creating confidence interval variables
				gen UB = coeff + 1.96*SE
				gen LB = coeff - 1.96*SE

				**** generating zero values for excluded year
				replace year = `excld_yr' if mi(year)

				foreach var in coeff UB LB {
						replace `var' = 0 if year == `excld_yr'
				}

				* Saving estimated coeffs
				save "${resDat}/05c_Coeffs_YrFwd`yrfwd'_Controls.dta", replace
		restore
	}

log close

*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================


cap file close fh



* Store Table Names in Globals
do "${code}/Set_Table_Names.do"

global outcomes_wage ///
	log_te_mw  ///
	log_te_p50 ///
	az_ft_zens_p_empl ///
	ln_m_residuals  ///
	akm_firm_fe  ///
	pers_fe ///
	capital_share

global outcomes_profitability ///
	ebta_opre ///
	ebit_opre ///
	pl_opre ///
	ebta_toas ///
	ebit_toas ///
	pl_toas

global outcomes_skill ///
	az_gq_per_empl ///
	az_mq_per_empl ///
	az_hq_per_empl ///
	fscl_per_empl ///
    av_opre ///
	log_ten_ges ///
	tenure ///
	separation_p_empl



global groups  skill wage  profitability

global robustness1 ""
global robustness2 "_robust_fias"
global robustness3 "_robust_av_per_empl"


* IAB Outcomes
local pathDiff ${iab}/203
local pathDiD ${iab}/202
local pathRDTwoyear ${iab}/201
local pathRDFiveyear ${iab}/201

local file_wage_robustness1 "Table1"
local file_wage_robustness2 "TableA5"
local file_wage_robustness3 "TableA6"
local file_profitability_robustness1 "TableA8"
local file_skill_robustness1 "TableA10"


********************************************************************************
*
*		DiD and Diff Output Table - Orbis Historical Sample
*
********************************************************************************


*****************************************
*        Skill and Profitability Tables
*****************************************
foreach robust in 1  {
	foreach group in skill profitability {

		********** Diff **********
		local name1_upper "Year FE"
		local name1_lower ""
		local name2_upper "Industry-Year FE"
		local name2_lower ""
		local name3_upper ""
		local name3_lower " "
		********** DiD **********
		local name4_upper "Year FE"
		local name4_lower ""
		local name5_upper "Industry FE"
		local name5_lower ""
		local name6_upper "Industry-Year FE"
		local name6_lower ""
		**********     RD    **********
		local name7_upper "Year FE"
		local name7_lower ""
		local name8_upper "Industry-Year FE"
		local name8_lower ""
		local name9_upper "No Control"
		local name9_lower ""

		* fill in with specs you want to use
		local x1 2
		local x2 3
		local x3 3
		local x4 2
		local x5 3
		local x6 3
		local x7 2
		local x8 3
		local x9 1
		local x10 3

		local blocks 1 2 4 6 7 8 /*1 2 */ /* 1 2 3 4 5 6 7 8 */

		local Winsor Winsor

		local DiD DiD
		local bw_standard
        local west _west
		local sampsuffix

		if strpos("`group'", "ADIAB") > 0 {
			local Winsor winsor
			local OH_DiD oh_did
		}

		local blank_line " "

		local columns "l "

		local name1_line " "
		local name2_line " "
		local colnumber_line " "

		local lineNYag "\textit{N}, Firm-Years Stock Cs "
		local lineNYnag "\textit{N}, Firm-Years  LLCs "

		local controlmean_lineAG "Control Mean: Stock Cs "
		local controlmean_linenAG "Control Mean: LLCs "

		local lineNag "\textit{N}, Stock Cs "
		local lineNnag "\textit{N}, LLCs "

		local num_outcomes = 0
		foreach outcome in ${outcomes_`group'} {
			local num_outcomes = `num_outcomes' + 1
		}

		foreach block in `blocks' {
			local block`block'_lineB "\text{`name`block'_upper'}"
			local block`block'_lineSE " \text{`name`block'_lower'}"

			local colnumber = 0
			foreach outcome in ${outcomes_`group'} {

				if `block' == 1 {

					* Blank line
					local blank_line "`blank_line' & "

					* Number of columns
					local columns "`columns' c "

					* Name of outcome
					local name1_line "`name1_line' & ${name1_`outcome'}"
					local name2_line "`name2_line' & ${name2_`outcome'}"

					*Column number
					local colnumber = `colnumber' + 1
					local colnumber_line "`colnumber_line' & (`colnumber')"

				}

				* Panel A

				local RDtype

				* Use different result name for the simple differences
				if `block' <= 2 {

					local DiD Diff
					local path `pathDiff'
				}


				else if `block' == 7 | `block' == 8{

					local DiD RD
					local path `pathRDTwoyear'
                    local RDtype _AG



				}

				else if `block' == 9 | `block' == 10{

					local DiD RD
					local path `pathRDFiveyear'
				    local RDtype _AG

				}


				else {

					local DiD DiD
					local path `pathDiD'

				}

				use "`path'/`DiD'_`outcome'_`Winsor'1_spec`x`block''${robustness`robust'}`RDtype'.dta", clear

				cap rename Nf N_AG
				cap rename controlmean controlmean_AG

				cap foreach var in b s p controlmean_AG N_AG N_nonAG Nfirmyears_AG Nfirmyears_nonAG controlmean_nonAG {


					if inlist("`var'","p", "pag", "pind") {
						local display
					}
					else if inlist("`var'", "N", "Nfirms", "N_AG", "N_nonAG","Nfirmyears_AG", "Nfirmyears_nonAG") {
						local display %8.0fc
					}
					else if inlist("`var'", "controlmean_AG", "controlmean_nonAG") & "`outcome'" == "av" {
						local display %5.2f
					}
					else if inlist("`var'", "controlmean_AG", "controlmean_nonAG") & strpos("`group'", "RobGroup") > 0  {
						local display %9.2fc
					}
					else {
						qui su `var'
						if int(abs(r(mean))*1000)<1 {
							if int(abs(r(mean))*10000)<1 {
								if int(abs(r(mean))*10000)<1 {
									local display %5.3f
								}
								else {
									local display %5.3f
								}
							}
							else {
								local display %5.3f
							}
						}
						else {
							local display %5.3f
						}
					}

					if inlist("`var'", "p", "pag", "pind", "bag", "sag", "bind", "sind", "controlmean_nonAG", "N_nonAG") {
						replace `var' = 1 if `var' == .
					}
					qui su `var'



						local value = `r(mean)'


					if "`outcome'" == "ten_ges" & inlist("`var'", "b", "s", "controlmean_AG", "controlmean_nonAG") {
						local value = `value' / 365
					}

					 if "`outcome'" == "tenure" & inlist("`var'", "b", "s", "controlmean_AG", "controlmean_nonAG"){
					   local value = `value' * 365.25
					}

					if "`outcome'" == "capital_share" & inlist("`var'", "b"){
					   local value = (-1) *`value'
					}

					if "`outcome'" == "capital_share" & inlist("`var'", "controlmean_AG", "controlmean_nonAG"){
					   local value = 1 - `value'
					}

					local `var': di `display' `value'
				}


				local s "(`s')"

				foreach var in p {
					if ``var'' > .1 {
						local star_`var' ""
					}
					if inrange(``var'',.05,.1) {
						local star_`var' "$^{*}$"
					}
					if inrange(``var'',.01,.05) {
						local star_`var' "$^{**}$"
					}
					if ``var'' <= .01 {
						local star_`var' "$^{***}$"
					}
				}

				if `block' == 6 {


					local controlmean_lineAG "`controlmean_lineAG' & `controlmean_AG' "
					local controlmean_linenAG "`controlmean_linenAG' & `controlmean_nonAG' "
					local lineNag "`lineNag' & `N_AG'"
					local lineNnag "`lineNnag' & `N_nonAG'"
					local lineNYag "`lineNYag' & `Nfirmyears_AG'"
					local lineNYnag "`lineNYnag' & `Nfirmyears_nonAG'"

				}

				local block`block'_title "`block`block'_title' & "
				local block`block'_lineB "`block`block'_lineB' & `b'`star_p'"
				local block`block'_lineSE "`block`block'_lineSE' & `s'"

			} // Outcomes in Group
		} // Specification

		* Place all the locals into a table
		* open file
		local num_panel = `num_outcomes' + 1
		local blank_line " "
		local Diff_title_line "\multicolumn{`num_panel'}{l}{\textbf{Panel A: Difference Design (Stock Corporations)}}"
		local DiD_title_line1 "\multicolumn{`num_panel'}{l}{\textbf{Panel B:  Difference-in-Differences Design (Stock Corporations + LLC Control Group)}}"
		local RD_title_line "\multicolumn{`num_panel'}{l}{\textbf{Panel C: Regression Discontinuity Design (Stock Corporations)}}"

		file open fh using "${tables}/`file_`group'_robustness`robust''.tex", write replace

		* header
		file write fh "\begin{tabular}{`columns'}" _n ///
			"\hline \hline" _n ///
			"`blank_line' \\" _n ///
			"`name1_line' \\ " _n ///
			"`name2_line' \\ " _n ///
			"`colnumber_line' \\ " _n ///
			"\hline" _n ///


		* coefficients and SEs for different specs
		foreach block in `blocks' {

			if `block' == 1 {
				file write fh " `Diff_title_line' \\" _n "\hline" _n "`blank_line' \\" _n
			}

			if `block' == 4 {
				file write fh "\hline" _n  " `DiD_title_line1' \\" _n  "\hline" _n "`blank_line' \\" _n
			}

			if `block' == 7 {
				file write fh 	"\hline" _n " `RD_title_line'\\" _n "\hline" _n "`blank_line' \\" _n
			}

			file write fh "`block`block'_lineB' \\" _n ///
				"`block`block'_lineSE' \\" _n ///
				"`blank_line' \\" _n

		}

		* Regression data: control mean, N
		file write fh "\hline" _n ///
			"`blank_line' \\" _n ///
			"`controlmean_lineAG' \\" _n ///
			"`lineNag' \\" _n ///
			"`lineNYag' \\" _n ///
			"`blank_line' \\" _n ///
			"\hline" _n ///
			"`blank_line' \\" _n ///
			"`controlmean_linenAG' \\" _n ///
			/*"`blank_line' \\" _n*/ ///
			"`lineNnag' \\" _n ///
			"`lineNYnag' \\" _n ///
			"`blank_line' \\" _n

		* footer
		file write fh "\hline \hline" _n ///
			"\end{tabular}" _n

		file close fh

	} // Group of Outcomes
} // Robustness






*****************************************
*        Wage Tables
*****************************************
foreach robust in 1 2 3 {
	foreach group in wage {

		********** Diff **********
		local name1_upper "Year FE"
		local name1_lower ""
		local name2_upper "Industry-Year FE"
		local name2_lower ""
		local name3_upper ""
		local name3_lower " "
		********** DiD **********
		local name4_upper "Year FE"
		local name4_lower ""
		local name5_upper "Industry FE"
		local name5_lower ""
		local name6_upper "Industry-Year FE"
		local name6_lower ""
		**********     RD    **********
		local name7_upper "Year FE"
		local name7_lower ""
		local name8_upper "Industry-Year FE"
		local name8_lower ""
		local name9_upper "No Control"
		local name9_lower ""

		* fill in with specs you want to use
		local x1 2
		local x2 3
		local x3 3
		local x4 2
		local x5 3
		local x6 3
		local x7 2
		local x8 3
		local x9 1
		local x10 3

		local blocks 1 2 4 6 7 8 /*1 2 */ /* 1 2 3 4 5 6 7 8 */

		local Winsor Winsor

		local DiD DiD
		local bw_standard
        local west _west
		local sampsuffix

		if strpos("`group'", "ADIAB") > 0 {
			local Winsor winsor
			local OH_DiD oh_did
		}

		local blank_line " "

		local columns "l "

		local name1_line " "
		local name2_line " "
		local colnumber_line " "

		local lineNYag "\textit{N}, Firm-Years Stock Cs "
		local lineNYnag "\textit{N}, Firm-Years  LLCs "

		local controlmean_lineAG "Control Mean: Stock Cs "
		local controlmean_linenAG "Control Mean: LLCs "

		local lineNag "\textit{N}, Stock Cs "
		local lineNnag "\textit{N}, LLCs "

		local num_outcomes = 0
		foreach outcome in ${outcomes_`group'} {
			local num_outcomes = `num_outcomes' + 1
		}

		foreach block in `blocks' {
			local block`block'_lineB "\text{`name`block'_upper'}"
			local block`block'_lineSE " \text{`name`block'_lower'}"

			local colnumber = 0
			foreach outcome in ${outcomes_`group'} {

				if `block' == 1 {

					* Blank line
					local blank_line "`blank_line' & "

					* Number of columns
					local columns "`columns' c "

					* Name of outcome
					local name1_line "`name1_line' & ${name1_`outcome'}"
					local name2_line "`name2_line' & ${name2_`outcome'}"

					*Column number
					local colnumber = `colnumber' + 1
					local colnumber_line "`colnumber_line' & (`colnumber')"

				}

				* Panel A

				local RDtype

				* Use different result name for the simple differences
				if `block' <= 2 {

					local DiD Diff
					local path `pathDiff'
				}


				else if `block' == 7 | `block' == 8{

					local DiD RD
					local path `pathRDTwoyear'
                    local RDtype _AG



				}

				else if `block' == 9 | `block' == 10{

					local DiD RD
					local path `pathRDFiveyear'
				    local RDtype _AG

				}


				else {

					local DiD DiD
					local path `pathDiD'

				}

				use "`path'/`DiD'_`outcome'_`Winsor'1_spec`x`block''${robustness`robust'}`RDtype'.dta", clear

				cap rename Nf N_AG
				cap rename controlmean controlmean_AG

				cap foreach var in b s p controlmean_AG N_AG N_nonAG Nfirmyears_AG Nfirmyears_nonAG controlmean_nonAG {


					if inlist("`var'","p", "pag", "pind") {
						local display
					}
					else if inlist("`var'", "N", "Nfirms", "N_AG", "N_nonAG","Nfirmyears_AG", "Nfirmyears_nonAG") {
						local display %8.0fc
					}
					else if inlist("`var'", "controlmean_AG", "controlmean_nonAG") & "`outcome'" == "av" {
						local display %5.2f
					}
					else if inlist("`var'", "controlmean_AG", "controlmean_nonAG") & strpos("`group'", "RobGroup") > 0  {
						local display %9.2fc
					}
					else {
						qui su `var'
						if int(abs(r(mean))*1000)<1 {
							if int(abs(r(mean))*10000)<1 {
								if int(abs(r(mean))*10000)<1 {
									local display %5.3f
								}
								else {
									local display %5.3f
								}
							}
							else {
								local display %5.3f
							}
						}
						else {
							local display %5.3f
						}
					}

					if inlist("`var'", "p", "pag", "pind", "bag", "sag", "bind", "sind", "controlmean_nonAG", "N_nonAG") {
						replace `var' = 1 if `var' == .
					}
					qui su `var'



						local value = `r(mean)'


					if "`outcome'" == "ten_ges" & inlist("`var'", "b", "s", "controlmean_AG", "controlmean_nonAG") {
						local value = `value' / 365
					}

					 if "`outcome'" == "tenure" & inlist("`var'", "b", "s", "controlmean_AG", "controlmean_nonAG"){
					   local value = `value' * 365.25
					}

					if "`outcome'" == "capital_share" & inlist("`var'", "b"){
					   local value = (-1) *`value'
					}

					if "`outcome'" == "capital_share" & inlist("`var'", "controlmean_AG", "controlmean_nonAG"){
					   local value = 1 - `value'
					}

					local `var': di `display' `value'
				}


				local s "(`s')"

				foreach var in p {
					if ``var'' > .1 {
						local star_`var' ""
					}
					if inrange(``var'',.05,.1) {
						local star_`var' "$^{*}$"
					}
					if inrange(``var'',.01,.05) {
						local star_`var' "$^{**}$"
					}
					if ``var'' <= .01 {
						local star_`var' "$^{***}$"
					}
				}

				if `block' == 6 {


					local controlmean_lineAG "`controlmean_lineAG' & `controlmean_AG' "
					local controlmean_linenAG "`controlmean_linenAG' & `controlmean_nonAG' "
					local lineNag "`lineNag' & `N_AG'"
					local lineNnag "`lineNnag' & `N_nonAG'"
					local lineNYag "`lineNYag' & `Nfirmyears_AG'"
					local lineNYnag "`lineNYnag' & `Nfirmyears_nonAG'"

				}

				local block`block'_title "`block`block'_title' & "
				local block`block'_lineB "`block`block'_lineB' & `b'`star_p'"
				local block`block'_lineSE "`block`block'_lineSE' & `s'"

			} // Outcomes in Group
		} // Specification

		* Place all the locals into a table
		* open file
		local num_panel = `num_outcomes' + 1
		local blank_line " "
		local Diff_title_line "\multicolumn{`num_panel'}{l}{\textbf{Panel A: Difference Design (Stock Corporations)}}"
		local DiD_title_line1 "\multicolumn{`num_panel'}{l}{\textbf{Panel B:  Difference-in-Differences Design (Stock Corporations + LLC Control Group)}}"
		local RD_title_line "\multicolumn{`num_panel'}{l}{\textbf{Panel C: Regression Discontinuity Design (Stock Corporations)}}"

		file open fh using "${tables}/`file_`group'_robustness`robust''.tex", write replace

		* header
		file write fh "\begin{tabular}{`columns'}" _n ///
			"\hline \hline" _n ///
			"`blank_line' \\" _n ///
			"`name1_line' \\ " _n ///
			"`name2_line' \\ " _n ///
			"`colnumber_line' \\ " _n ///
			"\hline" _n ///


		* coefficients and SEs for different specs
		foreach block in `blocks' {

			if `block' == 1 {
				file write fh " `Diff_title_line' \\" _n "\hline" _n "`blank_line' \\" _n
			}

			if `block' == 4 {
				file write fh "\hline" _n  " `DiD_title_line1' \\" _n  "\hline" _n "`blank_line' \\" _n
			}

			if `block' == 7 {
				file write fh 	"\hline" _n " `RD_title_line'\\" _n "\hline" _n "`blank_line' \\" _n
			}

			file write fh "`block`block'_lineB' \\" _n ///
				"`block`block'_lineSE' \\" _n ///
				"`blank_line' \\" _n

		}

		* Regression data: control mean, N
		file write fh "\hline" _n ///
			"`blank_line' \\" _n ///
			"`controlmean_lineAG' \\" _n ///
			"`lineNag' \\" _n ///
			"`lineNYag' \\" _n ///
			"`blank_line' \\" _n ///
			"\hline" _n ///
			"`blank_line' \\" _n ///
			"`controlmean_linenAG' \\" _n ///
			/*"`blank_line' \\" _n*/ ///
			"`lineNnag' \\" _n ///
			"`lineNYnag' \\" _n ///
			"`blank_line' \\" _n

		* footer
		file write fh "\hline \hline" _n ///
			"\end{tabular}" _n

		file close fh

	} // Group of Outcomes
} // Robustness





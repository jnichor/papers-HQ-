/*******************************************************************************

	DESCRIPTION: Table 2 Summary Stats

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
cap file close fh
local curr_date = c(current_date)
log using "${logs}/Table_SumStats`curr_date'", replace

********************************************************************************

foreach reform in $reforms {

	di "year: `reform'"

		****************************************************************************
		* Summary Statistics Table
		****************************************************************************

			use $sumstat_table_vars year mth_emp earn_pct treatment_* control_*  ///
			using ${temp}/02b_Reform`reform'.dta ///
			if year == `reform' - 1 & mth_emp == 12, replace


			if $shorten76and89 == 1 {
				gen reform = `reform'
				if (`reform'== 1976) | (`reform'==1989) {
					su earn_pct if treatment_`reform' == 1
					local min = r(min)
					su earn_pct if control_`reform' == 1
					local max = r(max)
					local new_min = `min' + 1
					local new_max = `max' - 1
					drop if reform == `reform' & earn_pct <= `new_min' & !mi(earn_pct)
					drop if reform == `reform' & earn_pct >= `new_max' & !mi(earn_pct)
					drop reform
				} // check 1976 and 1989 code blocks
			} // Shorten 76 and 89 code block

drop earn_pct

		* Labels
				local labfrau "Proportion Women"

				local labrefage "Age"

				local labwhitecoll "White Collar"

				local labexp25 "Experience in last 25 Years"

				local labtenure "Tenure"

				local labadj_earnings "Avg. Monthly Earnings"

				local labmover_f1 "Separation Rate"

				local labrecalled_f1 "Recall Rate"

				local labENE_f1 "ENE Separation Rate"

				local labEUE_f1 "EUE Separation Rate"

				local labmth_non_emp_f1 "Porp. Months NE"

				local labmth_UE_f1 "Porp. Months on UI"

				local labmth_sick_f1 "Porp. Months on Sick Leave"

		* Values in reform samples

			foreach group in treatment control {
				foreach var in $sumstat_table_vars {

					qui su `var' if `group'_`reform' == 1

					if strpos("`var'", "earnings") > 0 {
						local `var'`reform'`group'm: di %15.0fc `r(mean)'
						local `var'`reform'`group's: di %15.0fc `r(sd)'
					}
					else {
						local count = length(string(round(`r(mean)',1))) + 9
						local `var'`reform'`group'm: di %`count'.3g `r(mean)'
						local count = length(string(round(`r(sd)',1))) + 3
						local `var'`reform'`group's: di %`count'.3f `r(sd)'
					}
				}
				qui count if `group'_`reform' == 1
				local N`reform'`group' : di %15.0fc r(N)
			}

			* Create sample to append to make pooled sample

			keep $sumstat_table_vars treatment_`reform' control_`reform'
			rename *_`reform' *
			tempfile file`reform'
			save `file`reform''

		} // Reforms

		* Pooled values
		clear
		set obs 1
		foreach reform in $reforms {
			append using "`file`reform''"
			erase `file`reform''
		}

		foreach group in treatment control {
			foreach var in $sumstat_table_vars {
				qui su `var' if `group' == 1

				if strpos("`var'", "earnings") > 0 {
					local `var'Pooled`group'm: di %15.0fc `r(mean)'
					local `var'Pooled`group's: di %15.0fc `r(sd)'
				}
				else {
					local count = length(string(round(`r(mean)',1))) + 3
					local `var'Pooled`group'm: di %`count'.3g `r(mean)'
					local count = length(string(round(`r(sd)',1))) + 3
					local `var'Pooled`group's: di %`count'.3f `r(sd)'
				}
			}
			qui count if `group'== 1
			local NPooled`group' : di %15.0fc r(N)
		}

		foreach reform in $reforms Pooled {
			local cols `cols' c c c
			local space `space' & & &
		}

		file open fh using "${tables}/Tab2_SumStats.tex", write replace

		file write fh "\begin{tabular}{l `cols'}" _n "\hline \hline" _n
		foreach reform in $reforms Pooled {
			local header1 "`header1' & \multicolumn{2}{c}{`reform' Reform} & "
			local header2 "`header2' & Control & Treatment & "
			foreach var in $sumstat_table_vars {
				local `var'line1 "``var'line1' & ``var'`reform'controlm' & ``var'`reform'treatmentm' & "
				local `var'line2 "``var'line2' & (``var'`reform'controls') & (``var'`reform'treatments') & "
			}
			local Nline "`Nline' & `N`reform'control' & `N`reform'treatment' & "
		}
		file write fh "`header1' \\" _n "`header2' \\" _n "\hline \hline" _n "`space' \\" _n
		foreach var in $sumstat_table_vars {
			file write fh "`lab`var'' ``var'line1' \\" _n " ``var'line2' \\"  _n "`space' \\" _n
		}
		file write fh "\hline" _n "Observations in Base Year `Nline' \\" _n ///
		"\hline \hline" _n "\end{tabular}" _n

		file close fh

log close

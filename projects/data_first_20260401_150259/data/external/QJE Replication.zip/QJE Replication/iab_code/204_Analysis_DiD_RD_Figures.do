*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/204/$today"
local output "$log/204/$today"

log using "`output'/204_Analysis_DiD_RD_Figures.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*		204 Raw Cohort Graphs, over calendar year and by incorporation date
*
********************************************************************************

*		DiD
********************************************************************************
foreach robust in 1 2 3 {
cap	mkdir "`output'/spec`robust'"

	foreach w in $winsor_values {

		use "$data\iab_wage_analysis_winsor`w'.dta" ///
		if abs(d_rel) <= ${bw_extensive} & (AG == 1 | GmbH == 1) ${robust`robust'}, clear


		cap bysort AG_prereformcohort: sum empl az_ges_bhp az_ft_ges
		keep if jahr - year(dateinc) >= 0


		foreach outcome in $outcomes {
			timer on 2

			noi di "	Outcome: `outcome'"


		   *** RD Plot
			 ************

			* Bins on firm-level
			preserve
			egen meanoutcome = mean(`outcome'), by(idnr)
			egen countoutcome = count(`outcome'), by(idnr)
			drop `outcome'
			gen `outcome' = meanoutcome
			egen _tag = tag(idnr) if !mi(`outcome')
			keep if _tag==1
			collapse `outcome'  d_rel  (sum) n = countoutcome, by(AG_prereformcohort  quarters)
			*data security reasons
			replace `outcome' =. if n<=20
			save "`output'/spec`robust'/Figure_RD_bins_firmlevel_`outcome'_Winsor`w'.dta", replace
			restore

			* Bins on firm-year-level
			preserve
			collapse `outcome'  d_rel  (count) n = `outcome', by(AG_prereformcohort  quarters)
			*data security reasons
			replace `outcome' =. if n<=20
			save "`output'/spec`robust'/Figure_RD_bins_`outcome'_Winsor`w'.dta", replace
			restore

			************ Local Polynomial
			* Firm level
			preserve
			local ngrid 100
			collapse `outcome'  d_rel (count) n_obs_firm = `outcome', by(AG_prereformcohort idnr)
			lpoly `outcome' d_rel if AG_prereformcohort ==0 [aweight=n_obs_firm], n(`ngrid') degree(1) kernel(rec)  bw(730) gen(xhat0 yhat0) se(sehat0) nograph
            lpoly `outcome' d_rel if AG_prereformcohort ==1 [aweight=n_obs_firm], n(`ngrid')  degree(1) kernel(rec) bw(730) gen(xhat1 yhat1) se(sehat1) nograph
            lpoly `outcome' d_rel if AG_prereformcohort ==10 [aweight=n_obs_firm], n(`ngrid')  degree(1) kernel(rec) bw(730) gen(xhat10 yhat10) se(sehat10) nograph
            lpoly `outcome' d_rel if AG_prereformcohort ==11 [aweight=n_obs_firm], n(`ngrid')  degree(1) kernel(rec) bw(730) gen(xhat11 yhat11) se(sehat11) nograph
			keep xhat0-sehat11
			save "`output'/spec`robust'/Figure_RD_lpoly_firmlevel_`outcome'_Winsor`w'.dta", replace
			restore



      preserve
			lpoly `outcome' d_rel if AG_prereformcohort ==0, n(`ngrid') degree(1) kernel(rec)  bw(730) gen(xhat0 yhat0) se(sehat0) nograph
            lpoly `outcome' d_rel if AG_prereformcohort ==1, n(`ngrid')  degree(1) kernel(rec) bw(730) gen(xhat1 yhat1) se(sehat1) nograph
            lpoly `outcome' d_rel if AG_prereformcohort ==10, n(`ngrid')  degree(1) kernel(rec) bw(730) gen(xhat10 yhat10) se(sehat10) nograph
            lpoly `outcome' d_rel if AG_prereformcohort ==11, n(`ngrid')  degree(1) kernel(rec) bw(730) gen(xhat11 yhat11) se(sehat11) nograph
			keep xhat0-sehat11
			save "`output'/spec`robust'/Figure_RD_lpoly_`outcome'_Winsor`w'.dta", replace
			restore

			** Year plot (graph locally)
			*main
			preserve
			keep if abs(d_rel) <= ${bw_standard}
			collapse (mean) `outcome' (count) n = `outcome' , by(jahr AG_prereformcohort)
			*data security reasons
			replace `outcome' =. if n<=20
			save "`output'/spec`robust'/Figure_DIDyear_`outcome'_Winsor`w'.dta", replace
			restore



			*********************************
			* Placebo
			*********************************

			foreach placeboyear in $placebo_reform_years {
				local placeboyear = `placeboyear'
				cap mkdir "`output'/spec`robust'/placebo`placeboyear'"


				cap drop placebo`placeboyear'_AG_prereformcohort d_rel_`placeboyear'
				gen placebo`placeboyear'_AG_prereformcohort = 10*AG + ((dateinc - mdy(08,10,`placeboyear'))<0)
				gen d_rel_`placeboyear' = dateinc - mdy(08,10,`placeboyear')

				preserve
				collapse `outcome'  d_rel_`placeboyear'  (count) n = `outcome', by(placebo`placeboyear'_AG_prereformcohort  quarters)
				*data security reasons
				replace `outcome' =. if n<=20
				save "`output'/spec`robust'/placebo`placeboyear'/Figure_RD_bins_`outcome'_Winsor`w'.dta", replace
				restore

				** Employee plot (graph locally)
				*main

				cap drop _bins
				cap drop employees
				egen _bins = cut(az_ges_bhp), at(0(25)1000)
				egen employees = group(_bins)
				preserve
				keep if abs(d_rel_`placeboyear') <= ${bw_standard}
				collapse (mean) `outcome' (count) n = `outcome' , by(employees placebo`placeboyear'_AG_prereformcohort)
				*data security reasons
				replace `outcome' =. if n<=20
				save "`output'/spec`robust'/placebo`placeboyear'/Figure_DIDempl_`outcome'_Winsor`w'.dta", replace
				restore
				** Year plot (graph locally)
				*main
				preserve
				keep if abs(d_rel_`placeboyear') <= ${bw_standard}
				collapse (mean) `outcome' (count) n = `outcome' , by(jahr placebo`placeboyear'_AG_prereformcohort )
				*data security reasons
				replace `outcome' =. if n<=20
				save "`output'/spec`robust'/placebo`placeboyear'/Figure_DIDyear_`outcome'_Winsor`w'.dta", replace
				restore
				** Age plot (graph locally)
				*main
				preserve
				keep if abs(d_rel_`placeboyear') <= ${bw_standard}
				collapse (mean) `outcome' (count) n = `outcome' , by(firm_age placebo`placeboyear'_AG_prereformcohort )
				*data security reasons
				replace `outcome' =. if n<=20
				save "`output'/spec`robust'/placebo`placeboyear'/Figure_DIDage_`outcome'_Winsor`w'.dta", replace
				restore
			} //placebo

		} // Outcomes

		timer off 2
		qui timer list 2
		noi di "	Time for outcome: `r(t2)' seconds"
		timer clear 2
	} //  Winsor values
} // robustness

log close

/*******************************************************************************

	DESCRIPTION: Figure A.10 Robustness Check: Different Parametric Earnings Control



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA10_Control`curr_date'", replace

********************************************************************************

local suffix earn_pct
local outcome earn_Diff_f1
local controlname ctrls
local coeffname ctrls
local ytitle "One-Year Earnings Change"
local with With76


local x = 1
foreach control in earn_pct adj_earnings lnearnings {
use "${resDat}/DiD_1_`suffix'_`outcome'_Control`control'`with'_stable_Spec`controlname'.dta", clear
gen wins = "`control'"
gen spec = `x'
local x = `x' + 1
tempfile f`control'
save `f`control''
}
clear
set obs 1
gen filler = 1
foreach control in earn_pct adj_earnings lnearnings {
	append using "`f`control''"
}
drop if filler == 1
drop filler

qui su spec
local max = r(max) + 1
qui su year
local yearmin = r(min)
gen n = (year - `yearmin' + 1) + (spec/`max')

local colors "gray gray sea"
local statement
local legend
local order
local xlabels
local lab1 "Log Earnings"
local lab2 "Linear Earnings"
local lab3 "Earnings Percentile"
forval x = 1/3 {

	local color = word("`colors'",`x')
	local shape = word("O T S", `x')

	if `x' < 3 {
	local statement `statement' (rcap `coeffname'_LB `coeffname'_UB n if spec == `x', lcolor(`color')) ///
	(scatter `coeffname'_coeff n if spec == `x', mcolor(`color') msymbol(`shape') msize(medlarge))
	}

	if `x' == 3 {
	local statement `statement' (rcap `coeffname'_LB `coeffname'_UB n if spec == `x', lcolor(`color')) ///
	(scatter `coeffname'_coeff n if spec == `x', mcolor(`color') msymbol(`shape') msize(medlarge)
	}

	local y = 2*`x'
	local legend `legend' label(`y' "`lab`x''")
	local order `order' `y'

	local x = `x' + 1


}

levelsof year, local(years)
foreach year in `years' {
	local midpoint = (`year' - `yearmin' + 1) + 0.5
	local xlabels `xlabels' `midpoint' "`year'"
}

qui su n
local maxn = r(max)

tw `statement' legend(`legend' order(`order') r(1)) xtick(1(1)`maxn') ///
xlab(`xlabels', notick) yline(0, lpattern(shortdash) lcolor(gray%80)) ///
ytitle("Wage-Benefit Sensitivity", size(medium)) xtitle("Year Rel. to Treatment", size(medium)) ///
legend(col(2) pos(6) size(medium)) )

graph display, xsize(14) ysize(8)
graph export "${figures}/FigA10_Controls.pdf", replace

log close

/*******************************************************************************

	DESCRIPTION: Create rent-sharing estimates using BvD data

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/10a_Rent_Sharing_Austria_BvD`curr_date'", replace



// Firm Characteristics
*AUSTRIA:
use "${userData}/BvD_Austria.dta", clear

tab closdate_year
drop if closdate_year < 2004
drop if closdate_year > 2016

global firm_variables_old fias toas ncli   culi turn gros oppl staf     av ebit ebta
global firm_variables empl

foreach var in $firm_variables_old {
	replace `var' = `var'/empl
	rename `var' `var'_per_empl
	global firm_variables $firm_variables `var'_per_empl
}

foreach var in $firm_variables {
	winsor `var', gen(`var'_new) p(0.01)
	replace `var' = `var'_new
	drop `var'_new
}


rename idnr sidnr
egen  idnr=group(sidnr)

// Rent-Sharing: Levels Specifications
global weight_var = "empl"





* No controls
reg staf_per_empl av_per_empl  [w=${weight_var}], vce(cluster idnr)
global rent_sharing_coef = round(_b[av_per_empl],0.001)
global rent_sharing_se = round(_se[av_per_empl],0.001)

binscatter staf_per_empl av_per_empl  [w=${weight_var}], xtitle("Value-Added per Employee") ytitle("Wage Costs per Employee") ///
	note("Rent-sharing coefficient (level-on-level specification): 0${rent_sharing_coef} (se 0${rent_sharing_se})")
graph export "${figures}/rent_sharing_Austria_no_controls.pdf", replace

cap gen ln_staf_per_empl = ln(staf_per_empl)
cap gen ln_av_per_empl = ln(av_per_empl)
reg ln_staf_per_empl ln_av_per_empl  [w=${weight_var}],  vce(cluster idnr)
global ln_rent_sharing_coef = round(_b[ln_av_per_empl],0.001)
global ln_rent_sharing_se = round(_se[ln_av_per_empl],0.001)
binscatter ln_staf_per_empl ln_av_per_empl  [w=${weight_var}], xtitle("Ln(Value-Added per Employee)") ytitle("Ln(Wage Costs per Employee)") ///
	note("Rent-sharing coefficients" "Level-on-level specification: 0${rent_sharing_coef} (se 0${rent_sharing_se})" "Log-log specification: 0${ln_rent_sharing_coef} (se 0${ln_rent_sharing_se})")
graph export "${figures}/ln_rent_sharing_Austria_no_controls.pdf", replace


* Panel: firm and year fixed effects
reghdfe staf_per_empl av_per_empl  [w=${weight_var}], absorb(idnr closdate_year) vce(cluster idnr)
global rent_sharing_coef = round(_b[av_per_empl],0.001)
global rent_sharing_se = round(_se[av_per_empl],0.001)

	* Residualize outcome and regressor
	cap drop av_per_empl_resid staf_per_empl
	quietly reghdfe av_per_empl  [w=${weight_var}], absorb(idnr closdate_year) residuals(av_per_empl_resid)
	quietly reghdfe staf_per_empl  [w=${weight_var}], absorb(idnr closdate_year) residuals(staf_per_empl_resid)
	binscatter staf_per_empl_resid av_per_empl_resid  [w=${weight_var}], xtitle("Value-Added per Employee") ytitle("Wage Costs per Employee") ///
	note("Rent-sharing coefficient (level-on-level specification): 0${rent_sharing_coef} (se 0${rent_sharing_se})")
	graph export "${figures}/rent_sharing_Austria_panel.pdf", replace

	* Ln panel
	cap drop ln_av_per_empl_resid ln_staf_per_empl_resid
	reghdfe ln_staf_per_empl ln_av_per_empl  [w=${weight_var}], absorb(idnr closdate_year)  vce(cluster idnr)
	global ln_rent_sharing_coef = round(_b[ln_av_per_empl],0.001)
	global ln_rent_sharing_se = round(_se[ln_av_per_empl],0.001)
	cap drop ln_av_per_empl_resid ln_staf_per_empl
	quietly reghdfe ln_av_per_empl  [w=${weight_var}], absorb(idnr closdate_year) residuals(ln_av_per_empl_resid)
	quietly reghdfe ln_staf_per_empl  [w=${weight_var}], absorb(idnr closdate_year) residuals(ln_staf_per_empl_resid)
	binscatter ln_staf_per_empl_resid ln_av_per_empl_resid  [w=${weight_var}], xtitle("Ln(Value-Added per Employee)") ytitle("Ln(Wage Costs per Employee)") ///
	note("Rent-sharing coefficients" "Level-on-level specification: 0${rent_sharing_coef} (se 0${rent_sharing_se})" "Log-log specification: 0${ln_rent_sharing_coef} (se 0${ln_rent_sharing_se})")
	graph export "${figures}/ln_rent_sharing_Austria_panel.pdf", replace


* Panel plus industry-year FEs
destring nace_prim_code, gen(nace_prim_code_num)
gen industry_year_fe = nace_prim_code_num*10^5 + (closdate_year - 1900)

reghdfe staf_per_empl av_per_empl  [w=${weight_var}], absorb(idnr closdate_year industry_year_fe)  vce(cluster idnr)
global rent_sharing_coef = round(_b[av_per_empl],0.001)
global rent_sharing_se = round(_se[av_per_empl],0.001)

	* Residualize outcome and regressor
	cap drop av_per_empl_resid staf_per_empl_resid
	quietly reghdfe av_per_empl  [w=${weight_var}], absorb(idnr closdate_year industry_year_fe) residuals(av_per_empl_resid)
	quietly reghdfe staf_per_empl  [w=${weight_var}], absorb(idnr closdate_year industry_year_fe) residuals(staf_per_empl_resid)
	binscatter staf_per_empl_resid av_per_empl_resid  [w=${weight_var}], xtitle("Value-Added per Employee") ytitle("Wage Costs per Employee") ///
	note("Rent-sharing coefficients" "Level-on-level specification: 0${rent_sharing_coef} (se 0${rent_sharing_se})")
	graph export "${figures}/rent_sharing_Austria_panel_industy_year_fx.pdf", replace

	* Ln panel plus industry-year FEs
	cap drop ln_av_per_empl_resid ln_staf_per_empl_resid
	reghdfe ln_staf_per_empl ln_av_per_empl  [w=${weight_var}], absorb(idnr closdate_year industry_year_fe)  vce(cluster idnr)
	global ln_rent_sharing_coef = round(_b[ln_av_per_empl],0.001)
	global ln_rent_sharing_se = round(_se[ln_av_per_empl],0.001)
	cap drop ln_av_per_empl_resid ln_staf_per_empl
	quietly reghdfe ln_av_per_empl  [w=${weight_var}], absorb(idnr closdate_year industry_year_fe) residuals(ln_av_per_empl_resid)
	quietly reghdfe ln_staf_per_empl  [w=${weight_var}], absorb(idnr closdate_year industry_year_fe) residuals(ln_staf_per_empl_resid)
	binscatter ln_staf_per_empl_resid ln_av_per_empl_resid  [w=${weight_var}], xtitle("Ln(Value-Added per Employee)") ytitle("Ln(Wage Costs per Employee)") ///
	note("Rent-sharing coefficients" "Level-on-level specification: 0${rent_sharing_coef} (se 0${rent_sharing_se})" "Log-log specification: 0${ln_rent_sharing_coef} (se 0${ln_rent_sharing_se})")
	graph export "${figures}/ln_rent_sharing_Austria_panel_industy_year_fx.pdf", replace


log close

*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================

cap file close fh 

local specs  DiD Diff RD 
local name_A "Agriculture, forestry, fishing" 
local name_B "Mining and quarrying" 
local name_C "Manufacturing"
local name_D "Electricity, gas, steam, and air conditioning supply"
local name_E "Water supply, sewerage, waste management/remediation"
local name_F "Construction"
local name_G "Wholesale and retail trade; repair of motor vehicles"
local name_H "Transportation and storage" 
local name_I "Accommodation and food service activities" 
local name_J "Information and communication" 
local name_K "Financial and insurance activities"
local name_L "Real estate activities"
local name_M "Professional, scientific, and technical activities" 
local name_N "Administrative and support service activities" 
local name_O "Public administration and defense; compulsatory social security"
local name_P "Education"
local name_Q "Human health and social work activities" 
local name_R "Arts, entertainment, and recreation" 
local name_S "Other services activities"
local name_T "Activities of households as employers; undifferentiate goods and servies producting activitiies of households for own use"
local name_U "Activities of extraterritorial organizations and bodies"

local columns "l c c c | l c c c " 

local blankline " & & & & & & & "

local specline " NACE Industry Classification & DiD  &  Diff & RD  &  NACE Industry Classification & DiD & Diff & RD "

	file open fh using "${tables}/TableA2.tex", write replace 

	file write fh "\begin{tabular}{`columns'}" _n ///
	"\hline \hline" _n ///
	"`blankline' \\" _n ///
	"`specline' \\ " _n ///
	"\hline" _n 
	
	global outcomes
	foreach letter in B C F G H J K L M N R S {
		global outcomes $outcomes i_nace_`letter'
	}

		
foreach outcome in $outcomes {

local letter = substr("`outcome'", -1,1) 

	local bline`letter' "`letter': `name_`letter'' "
	local sline`letter' ""
	local AGmean_line`letter'		"\hspace{0.5cm} Control Mean: Post-Reform Stock Cs"
	local nonAGmean_line`letter'	"\hspace{0.5cm} Control Mean: Post-Reform LLCs "


foreach spec in `specs' {

	use "${iab}/213/Industry_`spec'_i_nace_`letter'_spec1.dta", clear
	
			foreach var in b s controlmean_AG controlmean_nonAG  p pag pind {
			
				if inlist("`var'","p", "pag", "pind") {
					local display 
				}
				else if inlist("`var'", "N", "Nfirms", "N_AG", "N_nonAG") {
					local display %8.0fc
				}
				else if inlist("`var'", "controlmean_AG", "controlmean_nonAG") & "`outcome'" == "av" {
					local display %5.2f
				}
				
				else {
					qui su `var' 
					if int(abs(r(mean))*1000)<1 {
						local display %5.4f
					}
					else {
						local display %5.3f 
					}
				}
				
				if inlist("`var'", "p", "pag", "pind") {
					replace `var' = 1 if `var' == .
				}
				
				qui su `var'
				
				local `var': di `display' `r(mean)'
			}
			
			local s "(`s')"

			foreach var in p pag pind {
				if ``var'' > .1 {
					local star_`var' ""
				}
				if inrange(``var'',.05,.1) {
					local star_`var' "$^{*}$"
				}
				if inrange(``var'',.01,.05) {
					local star_`var' "$^{**}$"
				}
				if ``var'' <= .01 {
					local star_`var' "$^{***}$"
				}
			}
			
			if "`spec'" == "Diff" |  "`spec'" == "RD" {
			
			local controlmean_nonAG "n/a"
			
			}
			
			if "`spec'" == "RD" & ("`letter'" == "B"  | "`letter'" == "L"  | "`letter'" == "R"  | "`letter'" == "S") {
			
			local b "$\times$"
			local s 
			local star_p
			local controlmean_AG 
			local controlmean_nonAG 
			}

			local bline`letter' "`bline`letter'' & `b'`star_p' " 
			local sline`letter'  "`sline`letter'' & `s' "
			local AGmean_line`letter'  "`AGmean_line`letter'' & `controlmean_AG' " 
			local nonAGmean_line`letter'  "`nonAGmean_line`letter'' & `controlmean_nonAG' "	
			
} // Specification (each column)  
} // Outcome (each row) 

	local lineN "\textit{N}, Firms  "
	local lineNag "\textit{N}, Stock Cs. "
	local lineNgmbh "\textit{N}, LLCs "
	local linejointp "Joint P-Value"
	
***** Joint P-value from DiD

foreach spec in `specs'{

if  "`spec'" == "RD" {
use "${iab}/214/Industry_`spec'_i_nace_C_spec1.dta", clear
}

if "`spec'" == "DiD" |  "`spec'" == "Diff" {
use "${iab}/213/Industry_`spec'_i_nace_C_spec1.dta", clear
}
	foreach var in Nfirms N_AG N_nonAG  {
			
		if inlist("`var'","p", "pag", "pind") {
			local display 
		}
		else if inlist("`var'", "N", "Nfirms", "N_AG", "N_nonAG") {
			local display %8.0fc
		}
		else if inlist("`var'", "controlmean_AG", "controlmean_nonAG") & "`outcome'" == "av" {
			local display %5.2f
		}
				
		else {
			qui su `var' 
			if int(abs(r(mean))*1000)<1 {
				local display %5.4f
			}
			else {
				local display %5.3f 
			}
		}
				
		if inlist("`var'", "p", "pag", "pind") {
			replace `var' = 1 if `var' == .
		}
				
		qui su `var'
				
		local `var': di `display' `r(mean)'
	}
			 
	qui su p_jointtest
	local p_jointtest: di %5.3f `r(mean)'
	
	if "`spec'" == "Diff" |  "`spec'" == "RD" {
			
			local N_nonAG "n/a"
			
			}
	
	local lineN " `lineN' & `Nfirms' "  
	local lineNag " `lineNag' & `N_AG' "
	local lineNgmbh " `lineNgmbh' & `N_nonAG' "
	local linejointp  "`linejointp' & `p_jointtest' "

}


local partner1_1 "B"
local partner2_1 "K"

local partner1_2 "C"
local partner2_2 "L"

local partner1_3 "F"
local partner2_3 "M"

local partner1_4 "G"
local partner2_4 "N"

local partner1_5 "H"
local partner2_5 "R"

local partner1_6 "J"
local partner2_6 "S"


forval i = 1/6 {
file write fh "`blankline' \\" _n ///
" `bline`partner1_`i''' & `bline`partner2_`i''' \\" _n ///
" `sline`partner1_`i''' & `sline`partner2_`i''' \\" _n ///
" `AGmean_line`partner1_`i''' & `AGmean_line`partner2_`i''' \\" _n ///
" `nonAGmean_line`partner1_`i''' & `nonAGmean_line`partner2_`i''' \\" _n
}

file write fh "`blankline' \\ \cmidrule{5-8}" _n ///
" & & & & `lineN' \\" _n ///
" & & & &  `lineNag' \\ " _n ///
" & & & & `lineNgmbh' \\" _n ///
" & & & & `linejointp' \\" _n ///
" `blankline' \\" _n "\hline \hline" _n "\end{tabular}" _n 

file close fh



/*******************************************************************************

	DESCRIPTION: Creates reform-specific worker-year panels by adjusting
		the top-coding. Creates all UIB and earnings variables needed for main analysis.

*******************************************************************************/




********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/02a_Build_RegressionVariables`curr_date'", replace




********************************************************************************
***** Looping over the different reforms included
	* Global -- saving a subset of variables for all years in the sample
********************************************************************************
foreach reform in $reforms Global {




********************************************************************************
***** Loading data for subset of reform-specific years
********************************************************************************
local restriction if inrange(year,`reform' - $keepPre, `reform' + $keepPost)

if "`reform'" == "Global" {
	local restriction
}


***** Number of years to keep for each ``reform''
use $temp/01_Panel_all_full_sample.dta `restriction', clear
drop dearnings

***** Subset of variables for the Global reform
if "`reform'" == "Global" {
	keep svnr benr year avg_dearnings avg_dbg_euro avg_dsz_euro
}

su year
local start_yr = r(min)
local end_yr = r(max)


***** Setting up data as panel
sort svnr year
xtset svnr year

* Asserting that the panel is balanced (ex. no missing between obs)
bysort svnr (year): gen obs_gap = year - year[_n - 1]
assert obs_gap == 1 if !mi(obs_gap)
drop obs_gap




****************************************************************************
* Editing Earnings Variables + Generating Controls
****************************************************************************


***** Merging on the Austrian CPI to convert from real to nominal shillings
foreach yrFwd in $earnF {
	gen year_f`yrFwd' = year + `yrFwd'
	rename (year year_f`yrFwd') (tempyear year)
	fmerge m:1 year using "${userData}/CPI_AUT.dta", assert(match using) keep(match) nogen
	rename (tempyear year CPI_2000) (year year_f`yrFwd' CPI_2000_f`yrFwd')
}
fmerge m:1 year using "${userData}/CPI_AUT.dta", assert(match using) keep(match) nogen

* Some asserts
bysort svnr (year): assert CPI_2000 == CPI_2000_f1[_n - 1] if !mi(CPI_2000_f1[_n - 1])
bysort svnr (year): assert CPI_2000 == CPI_2000_f2[_n - 2] if !mi(CPI_2000_f2[_n - 2])


***** Leap years
gen leap_year = inlist(year, $leapYears)
gen day_per_year = cond(leap_year == 1, 366, 365)

foreach yrFwd in $earnF {
	gen leap_year_f`yrFwd' = inlist(year_f`yrFwd', $leapYears)
	gen day_per_year_f`yrFwd' = cond(leap_year_f`yrFwd' == 1, 366, 365)
}


***** Converting dearnings to nominal monthly Austrian Shillings from daily 2000 Euros
	* Multiply by 13.7603 to get from Euros to Shillings
	* Multiply by the number of days per year/months
		* Incorporate leap years https://kalender-365.de/leap-years.php
	* Multiplying by the CPI deflator to get to nominal Shillings
gen adj_earnings = avg_dearnings*$euroToShilling*(day_per_year/12)*(CPI_2000/100)

***** Generate log earnings
gen lnearnings = log(adj_earnings)

if "`reform'" != "Global" {
foreach yrFwd in $earnF {
	gen adj_earnings_afterchange_f`yrFwd' = avg_dearnings_afterchange_f`yrFwd' *$euroToShilling*(day_per_year_f`yrFwd'/12)*(CPI_2000_f`yrFwd'/100)
	drop CPI_2000_f`yrFwd' day_per_year_f`yrFwd' leap_year_f`yrFwd' year_f`yrFwd'
}
}


***** Annual earnings definition for UIB calculation
	* Note -- these are ``annualized'' earnings values
	* Ex. if you work for one day a year, this is the total earnings if you had the same daily wage all year long
gen bg_ann = avg_dbg_euro*day_per_year*$euroToShilling*(CPI_2000/100)
gen sz_ann = avg_dsz_euro *day_per_year*$euroToShilling*(CPI_2000/100)



***** Some asserts
assert bg_ann + sz_ann > adj_earnings if !mi(adj_earnings)
assert adj_earnings > 0 if (bg_ann > 0 & !mi(bg_ann)) | (sz_ann > 0 & !mi(sz_ann))
assert !mi(bg_ann) if !mi(sz_ann)

drop avg_dearnings CPI_2000 day_per_year leap_year


***** Calculating net income - used for replacement rates after 2000
gross_to_net, bg_ats(bg_ann) sz_ats(sz_ann)
rename yearly_earn_ats_net net_earnings
drop bg_ats_net sz_ats_net


***** Some asserts
assert net_earnings <= bg_ann + sz_ann if !mi(bg_ann + sz_ann)
assert !mi(net_earnings) if !mi(bg_ann + sz_ann)


***** Generating some control variables
if "`reform'" != "Global" {

	* Polynomials of experience, tenure, and age (in years)
	replace tenure = tenure/365
	replace exp25 = exp25/365
	foreach var in exp25 tenure refage {
		gen `var'_sq = `var'^2
		gen `var'_cub = `var'^3
	}

	***** Some asserts
	assert tenure < 150 if !mi(tenure)
	assert exp25 <= 26 if !mi(exp25)
	assert !mi(tenure) if status == 3
	assert !mi(exp25) if status == 3

}



if "`reform'" == "Global" {
	drop CPI_2000_f* day_per_year_f* leap_year_f*
}




****************************************************************************
***** Harmonizing earnings caps across time
	* The earnings cap falls at different places in the earnings distribution in different years
****************************************************************************
**** Earnings cap for each year
cap program drop earnings_max_austria
earnings_max_austria, new_monthly_earn_max(x_earn_max) year_t(year)
cap program drop earnings_min_austria
earnings_min_austria, new_monthly_earn_min(x_earn_min) year_t(year)


**** Calculating the cutoff percentile for each year
gen cutoff_pct = .
forvalues year = `start_yr'/`end_yr' {

	* Total observations w/ non-missing earnings
	count if !mi(adj_earnings) & year == `year'
	local num_obs = r(N)

	* Number of observations with earnings less than 1000 below cap
	* the 1000 below is to make sure we don't capture people at the cap
	count if adj_earnings <= x_earn_max - 1000 & year == `year'
	local lessCap_obs = r(N)

	* Identifying the earnings cap in the data -- some obs > cap so 99th percentile
	qui su adj_earnings if year == `year', d
	local earn_max = r(p99)

	* Statutory earnings cap
	su x_earn_max if year == `year', mean
	local earn_max_stat = r(mean)

	local earn_cap_pct = (`lessCap_obs'/`num_obs')*100
	display "Maximum Earnings for Year `year' = `earn_max'"
	display "Maximum Earnings for Year `year' = `earn_max_stat'"
	display "Earnings Cap Percentile for Year `year' = `earn_cap_pct'"

	* Cutoff percentile for each year
	replace cutoff_pct = `earn_cap_pct' if year == `year'
}


***** Defining percentiles of the income distribution
gquantiles earn_pct = adj_earnings, xtile by(year) nquantiles(400)
replace earn_pct = earn_pct/4
assert inrange(earn_pct, 0, 100) if !mi(earn_pct)


**** Defining the minimum earnings cap percentile cutoff across the years of the reform sample.
local range if inrange(year, `reform' - $preYrs, `reform' + $postYrs)
if "`reform'" == "Global" {
	local range
}
qui su cutoff_pct `range'
local min_cutoff = r(min)
gen min_cutoff = `min_cutoff'


***** Winsorizing earnings so outliers aren't affecting earnings averages
	* creates adj_earnings_w
foreach var in adj net {
	winsor2 `var'_earnings, cuts(0 99) by(year)
}


***** Replacing annual earnings above the minimum cap percentile with the
    * average earnings of individuals around minimum cap percentile for that year

* Indicator for being at the earnings cap
gen at_earnCap = cond(!mi(adj_earnings),0,.)
forvalues year = `start_yr'/`end_yr' {

	foreach var in adj net {

		***** Earnings right around earnings percentile of the cutoff
		su `var'_earnings_w if inrange(earn_pct, `min_cutoff' - .25, `min_cutoff' + .25 ) & year == `year'
		local max_earn_`year' = r(mean)

		replace `var'_earnings = `max_earn_`year'' if earn_pct >= `min_cutoff' & !mi(earn_pct) & year == `year'


		***** Replacing earnings for the after-change measures
		if "`reform'" != "Global" {
			if "`var'" == "adj" {
			foreach yrFwd in $earnF {
				replace adj_earnings_afterchange_f`yrFwd' = `max_earn_`year'' if year == `year' - `yrFwd' & adj_earnings_afterchange_f`yrFwd' > `max_earn_`year''
			}
			}
		}
	}

	replace at_earnCap = 1 if earn_pct >= `min_cutoff' & !mi(earn_pct) & year == `year'

}


***** Some asserts
assert adj_earnings <= x_earn_max if !mi(adj_earnings)
assert !mi(adj_earnings) if !mi(bg_ann + sz_ann)

* Checking that the afterchange and adj_earnings max earnings are similar
if "`reform'" != "Global" {
	local check_st =`reform' - $preYrs + 1
	local check_end = `reform' + $postYrs
	foreach yrFwd in $earnF {
	forvalues year = `check_st'/`check_end' {

		di "`year'"

		su adj_earnings_afterchange_f`yrFwd' if year == `year'
		local after_max = r(max)

		su adj_earnings if year == `year' + `yrFwd'
		local adj_max = r(max)

		assert abs(`after_max'/`adj_max' - 1) < .005

	}
	}
}
***** Dropping variables
	* Earnings percentiles defined again on the restricted sample
drop earn_pct cutoff_pct earn_pct adj_earnings_w net_earnings_w




****************************************************************************
* Generating earnings growth measures + inflated wages used to define RRs
****************************************************************************
sort svnr year
foreach year_fwd in $earnF {

	* Future/lagged earnings (used to calculate RRs)
	bysort svnr (year): gen earn_f`year_fwd' = f`year_fwd'.adj_earnings
	bysort svnr (year): gen earn_l`year_fwd' = l`year_fwd'.adj_earnings

	***** Earnings difference
		* zero future earnings -> missing earnings change
	bysort svnr (year): gen earn_Diff_f`year_fwd' = ((f`year_fwd'.adj_earnings - adj_earnings)/adj_earnings)*100
	replace earn_Diff_f`year_fwd' = . if mi(f`year_fwd'.adj_earnings)

	***** Wage growth values (used to calculate RR instruments)
		* Average wage growth each year (from t to t + 1)
	gen wage_grwth`year_fwd' = earn_f`year_fwd' / adj_earnings
	replace wage_grwth`year_fwd' = . if mi(earn_f`year_fwd')

	bys year: gegen avg_wage_grwth`year_fwd' = mean(wage_grwth`year_fwd')

	assert abs(wage_grwth`year_fwd' - (earn_Diff_f`year_fwd' + 100)/ 100) < .01 if !mi(wage_grwth`year_fwd')


	***** Wage growth values net (used to calculate RR instruments)
		* Average wage growth each year (from t to t + 1)
	sort svnr year
	gen wage_net_grwth`year_fwd' = f`year_fwd'.net_earnings / net_earnings
	replace wage_net_grwth`year_fwd' = . if mi(f`year_fwd'.net_earnings )

	bys year: gegen avg_wage_net_grwth`year_fwd' = mean(wage_net_grwth`year_fwd')



	***** Wages at period t inflated by wage growth between t and t + 1
	gen infl`year_fwd'_adj_earnings = avg_wage_grwth`year_fwd' * adj_earnings
	gen infl`year_fwd'_net_earnings = avg_wage_net_grwth`year_fwd' * net_earnings

	sort svnr year
	if "`reform'" != "Global" {

		***** Number of months employed, unemployed, sick, and non-employed X years into the future.
			* Note that this is cumulative.
			* We first create the variable with the value for 1 year into the future.
			* Then, if we are looking more years into the future, we add the value for the year before.
			* Normalize by the number of months, i.e. 12 for 1-year outcomes, 24 for 2-year outcomes
		foreach var in emp UE sick non_emp {
			gen byte mth_`var'_f`year_fwd' = f`year_fwd'.mth_`var'
			if `year_fwd' > 1 {
				local year_before = `year_fwd' - 1
				replace mth_`var'_f`year_fwd' = f`year_before'.mth_`var' + f`year_fwd'.mth_`var'
			}
			replace mth_`var'_f`year_fwd' = mth_`var'_f`year_fwd' /(12*`year_fwd')
		}
	} // Non-global code block
}

***** Some asserts
foreach year_fwd in $earnF {
	assert !mi(earn_Diff_f`year_fwd') if !mi(adj_earnings) & !mi(f`year_fwd'.adj_earnings) & adj_earnings != 0
}

if "`reform'" != "Global" {
	assert mth_UE_f1 + mth_sick_f1 - mth_non_emp_f1 < .01 if !mi(mth_non_emp_f1)
	assert mth_UE_f2 + mth_sick_f2 - mth_non_emp_f2 < .01 if !mi(mth_non_emp_f2)

	foreach var in emp UE sick non_emp {
		foreach year_fwd in $earnF {
			assert mth_`var'_f`year_fwd' <= 1 if !mi(mth_`var'_f`year_fwd')
		}

		assert mth_`var'_f2*24 >= mth_`var'_f1*12 if !mi(mth_`var'_f1) & !mi(mth_`var'_f2)

	}

	assert mth_UE_f1 > 0 if EUE_f1 == 1
	assert mth_UE_f2 > 0 if EUE_f2 == 1
}



****************************************************************************
***** Calculating UIB levels and replacement rates
	* A note on naming conventions -- many variables are called some variant of BRBY
	* The first two letters refer to the RR schedule used
		* BR -- base year RR schedule -- year t
		* RR -- reform year RR schedule -- year t + 1
	* The second two letters refer to the earnings concept used
		* BY -- base year earnings
		* RY -- reform year earnings
		* iBY -- inflated base year earnings
****************************************************************************
if "`reform'" != "Global" {

**** Generating lagged net earnings for calculating replacement rates after 2000
bysort svnr (year): gen net_earn_L = l$post95_RRLag.net_earnings

***** Individuals UIB based on current schedule and current earnings concept
	* new_var - variable name for the monthly UIB
	* year - replacement rate schedule to use
	* inc_gross - MONTHLY GROSS income. Used to calculate the RRs before 1996
	* inc_gross_lag - LAGGED MONTHLY GROSS income. Used to calculate RRs 1996-2000
	* inc_net - ANNUAL NET income. Used to calculate the RRs after 2000
UIB_calc_austria, new_var(UIBt_Wt) year_t(year) inc_gross(adj_earnings) inc_gross_lag(earn_l$post95_RRLag) inc_net(net_earn_L)


***** Some checks on the UIBs (add others)
assert !mi(UIBt_Wt) if adj_earnings != 0 & !mi(adj_earnings) & year < 1996
assert !mi(UIBt_Wt) if earn_l$post95_RRLag != 0 & !mi(earn_l$post95_RRLag) & year >= 1996 & year < 2001


***** Current replacement rate
gen BRBY = UIBt_Wt/adj_earnings

foreach i in $earnF {


	***** Gross and Net Income Values used to calculate RRs from 1996 onward

	* Number of lags to use for future years
	* One year in future -> current income
	* Two years in future -> t + 1 income
	local RRLag = `i' - $post95_RRLag

	***** Actual future (lagged) income
	bysort svnr (year): gen adj_earnings_L`RRLag' = f`RRLag'.adj_earnings
	bysort svnr (year): gen net_earn_L`RRLag' = f`RRLag'.net_earnings

	***** Predicted future (lagged) income
		* One year in the future -> dont need used inflate income b/c current income
		* NOTE - THIS WILL BREAK IF WE CHANGE $post95_RRLag
		* REWRITE IN THAT CASE
	* Results in the current earnings
	if `i' == 1 {
		gen infl_adj_earnings_L`RRLag' = f`RRLag'.adj_earnings
		gen infl_net_earn_L`RRLag' = f`RRLag'.net_earnings
	}
		* Other years in the future -> need to use inflated
	else {
		gen infl_adj_earnings_L`RRLag' = infl`RRLag'_adj_earnings
		gen infl_net_earn_L`RRLag' = infl`RRLag'_net_earnings
	}

	if `i' == 1 & $post95_RRLag == 1 {
		assert infl_adj_earnings_L`RRLag' == adj_earnings
	}

	assert infl_adj_earnings_L`RRLag' == adj_earnings_L`RRLag' if `i' == 1
	assert infl_net_earn_L`RRLag' == net_earn_L`RRLag' if `i' == 1


	***** Calculating replacement rates based on wage growth
	gen nxtyear = year + `i'


	***** UIB based on future schedule and realized future earnings
	UIB_calc_austria, new_var(UIBt1_Wt1_f`i') year_t(nxtyear) inc_gross(earn_f`i') inc_gross_lag(adj_earnings_L`RRLag') inc_net(net_earn_L`RRLag')


	***** UIB based on future schedule and predicted future earnings
	UIB_calc_austria, new_var(UIBt1_iWt_f`i') year_t(nxtyear) inc_gross(infl`i'_adj_earnings) inc_gross_lag(adj_earnings_L`RRLag') inc_net(infl_net_earn_L`RRLag')
	drop nxtyear


	***** UIB based on current schedule but predicted future wages
	UIB_calc_austria, new_var(UIBt_iWt_f`i') year_t(year) inc_gross(infl`i'_adj_earnings) inc_gross_lag(infl_adj_earnings_L`RRLag') inc_net(infl_net_earn_L`RRLag')


	***** UIB based on current schedule but realized future wages
	UIB_calc_austria, new_var(UIBt_Wt1_f`i') year_t(year) inc_gross(earn_f`i') inc_gross_lag(adj_earnings_L`RRLag') inc_net(net_earn_L`RRLag')


	* Actual future replacement rate  RR(RY)
	gen RRRY_f`i' = UIBt1_Wt1_f`i'/adj_earnings

	* Current RR schedule with predicted future earnings BR(iBY)
	gen RRRYt_f`i' = UIBt_iWt_f`i'/adj_earnings

	* Future RR schedule with predicted future earnings RR(iBY)
	gen RRRYt1_f`i' = UIBt1_iWt_f`i'/adj_earnings

	* Current schedule but with realized future income. BR(RY)
	gen BRRY_f`i' = UIBt_Wt1_f`i' / adj_earnings

	**** Replacing 0 RRs with missing so not included in analysis

	foreach var in BRBY RRRY_f`i' RRRYt_f`i' RRRYt1_f`i' BRRY_f`i' {
		replace `var' = . if `var' == 0
	}

	**** Generating replacement rate differences
	gen RRdiff_f`i'_RRRY_BRBY = RRRY_f`i' - BRBY // Actual intertemporal RR change
	gen RRdiff_f`i'_RRiBY_BRiBY = RRRYt1_f`i' - RRRYt_f`i' // RR instrument
	gen RRdiff_f`i'_RRRY_BRRY = RRRY_f`i' - BRRY_f`i'

}

***** Converting all RRs and RR differences to differences multiplied by 100
ds RR* BR*
foreach var in `r(varlist)' {
	replace `var' = 100*`var'
}

}




****************************************************************************
* Variables we want to define after the sample restrictions
****************************************************************************
* Defining percentiles of the income distribution
gquantiles earn_pct = adj_earnings, xtile by(year) nquantiles(800)
replace earn_pct = earn_pct/8

* binning earnings percentile - to non-parametrically control for earnings
gen earn_pct_bin = round(earn_pct, 1)




****************************************************************************
* Save Tax Schedule by Reform-Year-Percentile
****************************************************************************

	if "`reform'" != "Global" {
		preserve

		keep net_earnings adj_earnings earn_pct at_earnCap year
		gen netoftaxrate = net_earnings / (12*adj_earnings)

		fcollapse (mean) netoftaxrate at_earnCap, by(earn_pct year)
		gen reform = `reform'

		save $temp/02a_NetofTaxRate_Reform`reform'.dta, replace

		restore
	}





****************************************************************************
* Saving dataset for the regression analysis
****************************************************************************
if "`reform'" != "Global" {
	keep if inrange(year,`reform' - $preYrs - 1, `reform' + $postYrs)
}

compress
save ${temp}/02a_Reform`reform'.dta, replace

} // Reforms

log close

/*******************************************************************************

  DESCRIPTION: Calculate a variety of firm characteristics:
		firm size, share on UI in last two years, within-firm dispersion
		in earnings and earnings growth

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/06c_Heterogeneity_Build_FirmCharacteristics`curr_date'", replace




****************************************************************************
* Loading data
****************************************************************************
foreach reform in $reforms {
	use svnr year adj_earnings wage_grwth1 benr tenure exp25 nace08 whitecoll at_earnCap ///
		svnr_spell_id stat_prespell stayer_f1 status ///
		using ${temp}/02b_Reform`reform'.dta, clear
	cap drop __0000*

	keep if status == 3
	drop status


	****************************************************************************
	* Firm Size and Share on UI in Last 2 Years
	****************************************************************************

	* Firm size
	gen employee = 1
	bys benr year: gegen firmsize = sum(employee)

	* Share of firm unemployed in the past two years
	gen ind = svnr_spell_id < 24 & stat_prespell == 1
	bys benr year: gegen num_nonemp_last2y = sum(ind)
	gen firm_shNonemp2 = num_nonemp_last2y / firmsize
	drop ind




	****************************************************************************
	* Calculating within-firm dispersion in earnings growth
	****************************************************************************
	***** All variables should be created on uncapped sample to avoid spurious zeroes.
		* Note -- this drops all firms where the only observations are at the earnings cap
		* yet these observations shouldn't appear in the final sample anyway.
	keep if at_earnCap == 0

	xtset, clear
	xtset svnr year

	* Calculating individual earnings growth relative to next year
	gen adj_earnings_growth = wage_grwth1 - 1
	winsor2 adj_earnings_growth,  cuts(${winsor_pct}) by(year)

	* Calculating firm-year dispersion of adj_earnings_growth
	gen adj_earnings_growth_same_firm = adj_earnings_growth_w if stayer_f1 == 1

	* Standard deviation by firm-year in earnings growth
	bys benr year: gegen wage_growth_SD = sd(adj_earnings_growth_same_firm)



	****************************************************************************
	* Calculate wage dispersion beyond CBA (proxied by experience/tenure/industry cells)
	****************************************************************************

	* Calculate tenure categories in three-year steps up to 15 years
	gen tenure_cat = 1 if tenure != . & tenure < 3
	local i = 2
	forvalues k = 3(3)12 {
		replace tenure_cat = `i' if tenure >= `k' & tenure < `k'+3
		local ++i
	}
	sum tenure_cat
	replace tenure_cat = r(max)+1 if tenure !=. & tenure >= 15

	* Calculate experience categories in 5-year steps up to 25 years
	gen exp_cat = 1 if exp25 != . & exp25 < 5
	local i = 2
	forval k = 5(5)15 {
		replace exp_cat = `i' if exp25 >= `k' & exp25 < `k' + 5
		local ++i
	}
	sum exp_cat
	replace exp_cat = r(max)+1 if exp25 != . & exp25 >= 20


	* Regress earnings on year by industry by white_coll by tenure_cat by exp_cat dummies
	winsor2 adj_earnings,  cuts(${winsor_pct}) by(year)
	qui reghdfe adj_earnings_w, ///
		absorb(year#nace08#whitecoll#tenure_cat#exp_cat) residuals(CBA_residuals)

	* Calculate mean squared residuals as well as SD of residuals at firm-year level
	bys benr year: gegen CBA_residuals_SD = sd(CBA_residuals)


	****************************************************************************
	* Clean up
	****************************************************************************

	***** Asserting that dropping duplicates doesn't drop any info
	foreach var in wage_growth_SD CBA_residuals_SD firmsize firm_shNonemp2 {

		bysort benr year: gegen `var'_max = max(`var')
		assert `var' == `var'_max
		drop `var'_max
	}

	duplicates drop benr year, force
	keep benr year wage_growth_SD CBA_residuals_SD firmsize firm_shNonemp2

	sort benr year
	compress

	gen reform = `reform'
	* Take the value from two years before (i.e. 1972 for 1974)
	save ${temp}/06c_FirmLevelInfo_Reform`reform'.dta, replace
} // Looping through reforms


****************************************************************************
* Appending together reforms
****************************************************************************

clear
set obs 1
gen filler = 1
foreach reform in  $reforms {
	append using ${temp}/06c_FirmLevelInfo_Reform`reform'.dta
	erase ${temp}/06c_FirmLevelInfo_Reform`reform'.dta
}
drop if filler == 1
drop filler

compress
save ${temp}/06c_FirmLevelInfo.dta, replace

log close

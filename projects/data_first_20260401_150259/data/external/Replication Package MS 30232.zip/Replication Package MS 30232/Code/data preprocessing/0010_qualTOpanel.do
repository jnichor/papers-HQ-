********************************************************************************
* 0010_qualTOpanel.do 
* generates key panel file for analysis, defines treatment groups
* Input: Austria Qual-Files, Austria Beitragsgrundlagen, 0000_status.do, 0009_BenateSelfEmpl.dta,
* Output: 0010_panel_year${y}_month${m}.dta
********************************************************************************

/*
	draw basic sample:
	frequency: quarterly (feb, may, aug, nov) 15th of the month
	years 1972-2015 (test-sample: 1985-1990)
	age range: max age=65
	drop those listed as Beamte once (ex-post possible as well)
*/

//// set globals
global ASSD /home/data/group_zweim/daten/Austria/ASSD2016
global REV /home/data/group_zweim/daten/Austria/REV2008
global UIF /home/data/group_zweim/projekte/UIFirms
global dofiles $UIF/dofiles
global data $UIF/data
global temp $UIF/temp
global script /home/data/group_zweim/pruh/daten/utilities
cd $temp

* batch 1: 1983-1987
* batch 2: 1988-1992
* batch 3: 1993-1998
* batch 4: 1977-1982
* batch 6: 1972-1976
global bn = 6
global yearvon = 1972
global yearbis = 1976
global qualvon = 1
global qualbis = 40

//// loop over qual files
timer clear 1
timer on 1
set more off
forvalues q=$qualvon/$qualbis {

	noi di `q'
	global q = `q'
	use $ASSD/qualifikation/qual_$q.dta, clear
	*drop if year(bdat)<$yearvon
	*drop if year(vdat)>$yearbis
	
	* exclude civil servants
	merge m:1 svnr using $data/0009_Beamte_SelfEmpl.dta, keep(1) nogen
	
	run $dofiles/0000_status.do
	
	merge m:1 svnr using $temp/stammdaten.dta, keepusing(birthmonth birthyear frau stsl) keep(3) nogen
	replace birthmonth = 6 if birthmonth==.
	
	save $temp/0010_qual_$bn.dta, replace
	
	// loop over points in time
	forvalues y = $yearvon(1)$yearbis {
	
		noi di "q: " `q' ", year: " $y
	
		global y = `y'
	
		// calculate duration per svnr-benr-year
		use $temp/0010_qual_$bn.dta, clear
		keep if status==3 | status==10
		keep if year(vdat)<=$y & year(bdat)>=$y
		replace bdat=mdy(12,31,$y) if year(bdat)>$y
		replace vdat=mdy(1,1,$y) if year(vdat)<$y
		run $script/normspell2pr.do "svnr benr" vdat bdat 1
		g dur = bdat-vdat+1
		collapse (sum) dur, by(svnr benr)
		assert dur<=366
		g year = $y
		save $temp/0010_tenure_year_$bn.dta, replace
	
		foreach m of numlist 1 2 3 4 5 6 7 8 9 10 11 12 {
		
			global m = `m'
		
			use $temp/0010_qual_$bn.dta, clear
			g ref = mdy($m,15,$y)
			keep if inrange(ref,vdat, bdat)
			g refage = (ref-mdy(birthmonth,15,birthyear))/365.25
			keep if refage<65
			
			* keep 1 status (may still be several spells per status)
			g prio = 1 if status==3 // employment
			replace prio = 2 if status==1 // UI/UA
			replace prio = 3 if status==8 // Parental Leave
			replace prio = 4 if inlist(status,2,4,5) // DI, OA, Sickness
			replace prio = 5 if status==10 // Minor Employment
			replace prio = 6 if prio==. // non-employment (may contain Beamte and Self-employed)
			
			* keep all spells with highest priority per individual
			egen mprio = min(prio), by(svnr)
			keep if prio==mprio
			
			* define blue/white-collar
			#d ;
			g byte whitecoll = 
			qual == "14" | qual == "15" | qual == "16" | qual == "A6" | qual == "B4" | qual == "B5" | /*neu*/
			qual == "B9" | qual == "C4" | qual == "C7" | qual == "E4" | qual == "G4" | qual == "G5" |
			qual == "G6" | qual == "G7" | qual == "JZ" | /*neu*/
			qual == "P2" | qual == "P4" | qual == "Y4" | qual == "Z4" | qual == "ZD" | qual == "ZJ" if status==3;
			#d cr
			
			* count number of parallel spells
			egen numjobs = total(1), by(svnr)
			
			* keep employment spell with highest tenure in that year
			merge m:1 svnr benr using $temp/0010_tenure_year_$bn.dta, keep(1 3) nogen
			bysort svnr ref (dur): keep if _n==_N
			
			drop origin qual prio mprio dur year ktkz vdat bdat
			
			order svnr benr ref
			
			compress
			
			save $temp/0010_status_$bn.dta, replace
			
			// Experience per ref
			use $temp/0010_qual_$bn.dta, clear
			append using $REV/rev_qualifikation.dta
			drop birth*
			merge m:1 svnr using $temp/stammdaten.dta, keepusing(birthmonth birthyear) keep(3) nogen
			g ref = mdy($m,15,$y)
			* age restriction
			g refage = (ref-mdy(birthmonth,15,birthyear))/365.25
			keep if refage<65
			*
			keep if svnrklasse==$q
			drop if vdat>ref
			replace bdat = ref if bdat>ref
			run $dofiles/0000_status.do
			keep if inlist(status,3,10) | (status==2 & ktkz=="K")
			run $script/normspell2pr.do "svnr ref" vdat bdat 30
			* experience for 1y, 2y, 5y, 10y, 15y, 20y, 25y
			foreach p of numlist 1 2 5 10 15 20 25 {
				g vdat1 = vdat
				replace vdat1 = . if bdat<ref-`p'*365.25
				replace vdat1 = ref-`p'*365.25 if vdat1<ref-`p'*365.25
				g temp = bdat-vdat1+1
				egen exp`p' = total(temp), by(svnr ref)
				assert exp`p'<=`p'*366.25
				drop temp vdat1
			
			} // p
			bysort svnr ref: keep if _n==1
			keep svnr ref exp*
			save $temp/0010_ref_exp_$bn.dta, replace
			
			// Tenure per ref
			use $temp/0010_status_$bn.dta, clear
			keep if inlist(status,3,10) // employment and minor-employment
			keep svnr ref benr
			save $temp/0010_svnrbenr_$bn.dta, replace
			*
			use $temp/0010_qual_$bn.dta, clear
			g ref = mdy($m,15,$y)
			* age restriction
			*merge m:1 svnr using $temp/stammdaten.dta, keepusing(birthmonth birthyear frau stsl) keep(3) nogen
			g refage = (ref-mdy(birthmonth,15,birthyear))/365.25
			keep if refage<65
			*
			keep if vdat<=ref
			replace bdat = ref if bdat>ref
			run $dofiles/0000_status.do
			keep if inlist(status,3,10) | (status==2 & ktkz=="K")
			merge m:1 svnr benr ref using $temp/0010_svnrbenr_$bn.dta, keep(2 3)
			assert _merge==3
			drop _merge
			
			* connect spells per benr that are at most 1 day apart
			run $script/normspell2pr.do "svnr benr" vdat bdat 1
			
			* tenure as implied by the current spell
			g dur = bdat-vdat+1
			bysort svnr (vdat): g tenuresev = dur[_N]
			
			* tenure as implied over all svnr-benr spells
			egen tenure = total(dur), by(svnr benr ref)
			
			bysort svnr ref: keep if _n==1
			keep svnr ref benr tenuresev tenure
			compress
			save $temp/0010_ref_tenure_$bn.dta, replace
			*
			erase $temp/0010_svnrbenr_$bn.dta
			
			// yearly and daily earnings with current benr
			use $temp/0010_status_$bn.dta, clear
			g contryear = $y
			merge m:1 svnr benr contryear using $ASSD/beitragsgrundlagen/bg_$q.dta, keepusing(bg_euro sz_euro dailywage) keep(1 3) nogen
			g year = contryear
			merge m:1 year using $script/figures_AT.dta, keep(3) keepusing(CPI_2000) nogen
			replace bg_euro = bg_euro/(CPI_2000/100)
			replace sz_euro = sz_euro/(CPI_2000/100)
			g dearnings = dailywage/(CPI_2000/100)
			drop dailywage CPI_2000 contryear
			bysort svnr ref: keep if _n==1
			compress
			save $temp/0010_ref_earnings_$bn.dta, replace
			
						
			use $temp/0010_status_$bn.dta, clear
			merge 1:1 svnr ref using $temp/0010_ref_exp_$bn.dta, nogen keep(3)
			merge 1:1 svnr ref using $temp/0010_ref_tenure_$bn.dta, nogen
			merge 1:1 svnr ref using $temp/0010_ref_earnings_$bn.dta, nogen
			
			// define PBD
			
			* REBP
			* criteria: i) age 50 or older ii) 780 weeks in the last 25 years iii) location iv) UI start or in progress June 1988
			g eREBP = refage>=50 & exp25>=780*7
			
			* 1989 Reform
			* define PBD for individuals 
			* depends on income, experience, age
			
			* minimum eligibility pre and post
			g PBD2_89 = exp2>=52*7			
			* extended eligibility pre and post
			g PBD30_89 = exp5>=156*7
			* extended eligibility for age 40 and older, only post
			g PBD39_89 = refage>=40 & refage<50 & exp10>=312*7
			* extened eligibility for age 50 and older, only post
			g PBD52_89 = refage>=50 & exp15>=468*7
			* extended RR for low earnings, only post
			g RR_89 = dearnings*30*13.7603<=12610
			
			compress
			
			if $q==$qualvon {
							0010_panelBal_year${y}_month${m}.dta
				save $data/0010_panelBal_year${y}_month${m}.dta, replace
			}
			else {
				append using $data/0010_panelBal_year${y}_month${m}.dta
				save $data/0010_panelBal_year${y}_month${m}.dta, replace
			}
	
		} // m
	} // y
	
} // q
timer off 1
timer list 1
di "Hours: " r(t1)/3600
di "per year: " r(t1)/3600/($yearbis-$yearvon+1)

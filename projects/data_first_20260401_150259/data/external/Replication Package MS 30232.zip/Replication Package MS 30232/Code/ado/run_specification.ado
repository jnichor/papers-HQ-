/*

	DESCRIPTION: This runs the specification and creates the figure. It partials out the outcome and instrument values according to the controls and runs all regressions on this saved cache.

	LAST UPDATED: 01/13/2020

	PARAMETER INPUT DESCRIPTION:  One must define the following:

		1) outcomes: the list of outcome variables. Note that one should do all the time horizons at once due to the saved cache.
		2) instr_aggreg: the aggregations of the instrument (percentile-, firm-, or industry-level)
		3) controlname: the name of the specification that you want to to give
		4) instr_yrFwd: the time horizon of the instrument (almost always 1)
		5) absorbvars: the list of control variables. Normally we define this varlist as a local,.
			e.g. controls1,. controls2, etc., and loop over them.
		6) coefflist: the list of interactions to include in event time, e.g. l3 l2 l0.
		7) aux_info: the regression output to keep. OPTIONS:
			- coeff: the coefficient estimate
			- SE: the standard error estimate
			- R: the R-squared value
			- N: the number of observations
			- F: the F test of the pre-period placebo treatment estimates
			- avg: the average value of the outcome in the base year e = 0.
			- For horse race, we should also have Fbenr, Fpct, and Wald
		8) cluster: the cluster variable
		9) samplename: the name you wish to give in the saved dta file and figure
		10) yrFwd: the time horizon of the outcome

*/

* must define names of specifications beforehand, i.e. controlname and control variables
* string can include:
program run_specification
	syntax, outcomes(varlist) ///
	instr_aggreg(string) ///
	controlname(string) ///
	instr_yrFwd(string) ///
	regvars(string) ///
	absorbvars(string) ///
	coefflist(string) ///
	aux_info(string) ///
	cluster(string) ///
	samplename(string) ///
	yrFwd(string)


preserve

***** Adding auxiliary information for matrix column names
local number_aux_info = 0
foreach x in `aux_info' {
	local control_name_list `control_name_list' `controlname'_`x'
	local number_aux_info = `number_aux_info' + 1
}


***** Number of rows to include for stored coefficients
local number_rows = 1 //Start with 1 because we need the excluded year
foreach i in `coefflist' {
	local number_rows = `number_rows' + 1
}

local short = substr("`instr_aggreg'",1,1)
ds interaction_`instr_aggreg'_*_f`yrFwd'

***** Regression variables to include in main specification
	* RRinstrument -- baseline RR instrument
	* regvars -- additional regression variables to add
	* r(varlist) -- interacted treatment w/ the RR instrument
local reg_vars RRinstrument_`instr_aggreg'_f`instr_yrFwd' `regvars' `r(varlist)'


***** String to test the equality of all pre-period coefficients
local test_str test
foreach yr in `coefflist' {
	if "`yr'" != "l0" {
		local test_str `test_str' interaction_`instr_aggreg'_`yr'_f`yrFwd' =
	}
}
local test_str `test_str' 0




****************************************************************************
* Running regression + saving coefficient estimates
****************************************************************************
foreach outcome in `outcomes' {
	* Matrix to store estimated treatment - control for DiD figures
	matrix `outcome'`instr_aggreg'`group' = J(`number_rows', `number_aux_info' + 1,.)
	matrix colnames `outcome'`instr_aggreg'`group' = year `control_name_list'

	**** Loops through the three different control specifications

	local col_counter = 2

	* Running regressions
	noi reghdfe `outcome' `reg_vars', ///
		absorb(`absorbvars') ///
		vce(cluster `cluster') ///
		/*poolsize(10)*/ ///
		nosample ///
		verbose(0)

	estimates store `controlname'

	* Testing the equality of the placebo effects
	`test_str'
	global F`group'_`outcome'_`short' = r(p)

	* Saving the estimated coeff diffs in the table and for the figure
	local row_counter = 1

	foreach yr in `coefflist' {

		local x = substr("`yr'", -1, 1)

		if substr("`yr'", 1, 1) == "l" {
			local n = 0 - `x'
		}

		if substr("`yr'", 1, 1) == "f" {
			local n = 0 + `x'
		}

		if `col_counter' == 2 {
			mat `outcome'`instr_aggreg'`group'[`row_counter',1] = `n'
		}
		local i = 0
		foreach x in `aux_info' {
			if "`x'" == "coeff" {
				mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = _b[interaction_`instr_aggreg'_`yr'_f`yrFwd']
			}

			if "`x'" == "SE" {
				mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = _se[interaction_`instr_aggreg'_`yr'_f`yrFwd']
			}

			if "`x'" == "R" {
				mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = e(r2)
			}

			if "`x'" == "N" {
				mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = e(N)
			}

			if "`x'" == "avg" {
				qui su `outcome' if yr_l0 == 1
				mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] = r(mean)
			}

			if "`x'" == "F" {
				mat `outcome'`instr_aggreg'`group'[`row_counter',`col_counter' + `i'] =  ${F`group'_`outcome'_`short'}
			}

			local i = `i' + 1
		}

		local row_counter = `row_counter' + 1

	} //Rows of matrix
} //Outcomes

****************************************************************************
* Exporting coefficients
****************************************************************************

foreach outcome in `outcomes' {
	* Matrix to dataset
	clear
	svmat `outcome'`instr_aggreg'`group', names(col)

	* Creating confidence intervals for each estimates
	gen `controlname'_UB = `controlname'_coeff + 1.96*`controlname'_SE
	gen `controlname'_LB = `controlname'_coeff - 1.96*`controlname'_SE

	* generating zero values for excluded year - not estimated but extra row included for it
	replace year = 0 - `yrFwd' if mi(year)

	foreach type in coeff UB LB {
		replace `controlname'_`type' = 0 if year == 0 - `yrFwd'
	}

	* Saving estimated coeffs
	save "${resDat}/DiD_`instr_yrFwd'_`instr_aggreg'_`outcome'_`samplename'_Spec`controlname'.dta", replace

} // Outcomes

restore
end

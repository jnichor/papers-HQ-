*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
clear
set obs 1
set more off
set checksum off
set rmsg on
cap log close

set scheme plotplainblind
* Heterogeneity Criteria
global hetgroups CBA_coverage ///
		binding_CBA_coverage ///
		akm_sd ///
		industry_akm ///
		works_council ///
		ln_av_empl ///
		tenure

* Heterogeneity Cut, 1==Above Me≈ian, 0==Below Median
global cuts 0 1

* Outcomes of Interest, 1==Above Median, 0==Below Median
global outcomes log_te_mw  akm_firm_fe
loca types Diff DiD RD
local num : list sizeof global(hetgroups)
local wname 1
local control 3
local xlabel_log_te_mw -0.5(0.2)0.6
local xlabel_akm_firm_fe -0.5(0.2)0.6



foreach type in `types'{
	foreach outcome in $outcomes {
		foreach cut in $cuts{

			matrix beta_`cut'_`outcome'`type' = J(1,`num',.)

			matrix rownames beta_`cut'_`outcome'`type' = Estimates

			matrix CI_`cut'_`outcome'`type' = J(2,`num',.)

			matrix rownames CI_`cut'_`outcome'`type' = ll95 ul95

			matrix mh_`cut'_`outcome'`type' = J(1,`num',.)

			matrix rownames mh_`cut'_`outcome'`type' = mh

		}
	}
}


foreach type in `types'{
	foreach outcome in $outcomes {
		foreach cut in $cuts{

			local i 0

			foreach hetergroup in $hetgroups {

				local ++ i
				if "`type'" == "DiD"{
					use  "$iab/209/Heterogeneity_`type'_`outcome'_Winsor`wname'_spec`control'_`hetergroup'.dta", clear
				}
				else if "`type'" == "Diff"{
					use  "$iab/210/Heterogeneity_`type'_`outcome'_Winsor`wname'_spec`control'_`hetergroup'.dta", clear
				}
				else if "`type'" == "RD"{
					use  "$iab/211/Heterogeneity_`type'_`outcome'_Winsor`wname'_spec`control'_`hetergroup'.dta", clear
				}

					matrix beta_`cut'_`outcome'`type'[1, `i'] = b[`cut'+1]

					matrix CI_`cut'_`outcome'`type'[1, `i'] = lb[`cut'+1]

					matrix CI_`cut'_`outcome'`type'[2, `i'] = ub[`cut'+1]

				if "`outcome'" ==  "akm_firm_fe"{
				   matrix mh_`cut'_`outcome'`type'[1, `i'] = lb[`cut'+1]
				}

			}
		}
	}
}



foreach outcome in $outcomes {

if "`outcome'" == "akm_firm_fe"{

coefplot (matrix(beta_0_`outcome'Diff), ci(CI_0_`outcome'Diff) ciopts(lc(gs7%60) ) mcolor(gs7%40) m(S) msize(1.4) label(Diff, Below Median)) ///
         (matrix(beta_0_`outcome'DiD), ci(CI_0_`outcome'DiD) ciopts(lc(gs10%60) lw(0.5)) mcolor(gs10%40) m(O) msize(1.4) label(DiD, ))  ///
		 (matrix(beta_0_`outcome'RD), ci(CI_0_`outcome'RD) ciopts(lc(maroon)) mcolor(maroon) m(T) msize(1.8) label(RD, ))  ///
		 (matrix(beta_1_`outcome'Diff), ci(CI_1_`outcome'Diff) ciopts(lc(gs7%60)) mcolor(gs7%40) m(Sh) msize(1.4) label(Diff, Above Median)  ) ///
         (matrix(beta_1_`outcome'DiD), ci(CI_1_`outcome'DiD) ciopts(lc(gs10%60)) mcolor(gs10%40) m(Oh) msize(1.4) label(DiD, ) )  ///
         (matrix(beta_1_`outcome'RD), ci(CI_1_`outcome'RD) ciopts(lc(maroon) lw(0.5)) mcolor(maroon) m(Th) msize(1.8) label(RD, ) )  ///
         , xline(0, lp(dash) lc(gs6))  yscale(r(0.2 7.7) lstyle(none)) xlab(`xlabel_`outcome'', labsize(3.5)) ///
		 legend(order(- "Below Median:" 2 "Diff (From Main Text)" 4 "DiD (From Main Text)" 6 "RD" - "" - "Above Median:" 8 "Diff (From Main Text)" 10  "DiD (From Main Text)" 12 "RD" )ring(0) pos(5) size(3.5) bmargin(tiny) ) ///
		 ylabel( 1 "CBA Coverage" 	2  `" "Binding" "CBA Coverage" "'  3 `""AKM Pay" "Premia SD" "' 4 "Industry AKM" 5 "Works Council"  6 `" "Log Value Added" "per Worker""'  7 "Tenure", labsize(3.5)) ///
		 ttext(0.3 -0.40 "Mean of Sorting Variable:", size(small) ) ///
		 ttext(0.8 -0.475 "Below:", size(small) )  ttext(1.2 -0.475 "Above:", size(small) )  ///
		 ttext(0.8 -0.41 "0.425", size(small)) ttext(1.2 -0.41 "0.796", size(small)) ttext(1.8 -0.41 "0.108", size(small)) ttext(2.2 -0.41 "0.254", size(small)) ///
		 ttext(2.8 -0.41 "0.135", size(small)) ttext(3.2 -0.41 "0.161", size(small)) ttext(3.8 -0.41 "0.059", size(small)) ttext(4.2 -0.41 "0.150", size(small)) ///
		 ttext(4.8 -0.41 "0.572", size(small)) ttext(5.2 -0.41 "0.835", size(small)) ttext(5.8 -0.41 "10.916", size(small)) ttext(6.2 -0.41 "11.365", size(small)) ///
		 ttext(6.8 -0.41 "3.014", size(small)) ttext(7.2 -0.41 "6.562", size(small))
graph display ,	xsize(19) ysize(9)

graph export "${figures}/figA8b.pdf", replace

}



if "`outcome'" == "log_te_mw"{

coefplot (matrix(beta_0_`outcome'Diff), ci(CI_0_`outcome'Diff) ciopts(lc(sea) lw(0.5)) mcolor(sea) m(S) msize(1.8) label(Diff, Below Median)) ///
         (matrix(beta_0_`outcome'DiD), ci(CI_0_`outcome'DiD) ciopts(lc(gs7%60)) mcolor(gs7%40) m(O) msize(1.4) label(DiD, ))  ///
		 (matrix(beta_0_`outcome'RD), ci(CI_0_`outcome'RD) ciopts(lc(gs10%60)) mcolor(gs10%40) m(T) msize(1.4) label(RD, ))  ///
		 (matrix(beta_1_`outcome'Diff), ci(CI_1_`outcome'Diff) ciopts(lc(sea) lw(0.5)) mcolor(sea) m(Sh) msize(1.8) label(Diff, Above Median)  ) ///
         (matrix(beta_1_`outcome'DiD), ci(CI_1_`outcome'DiD) ciopts(lc(gs7%60)) mcolor(gs7%40) m(Oh) msize(1.4) label(DiD, ) )  ///
         (matrix(beta_1_`outcome'RD), ci(CI_1_`outcome'RD) ciopts(lc(gs10%60)) mcolor(gs10%40) m(Th) msize(1.4) label(RD, ) )  ///
         , xline(0, lp(dash) lc(gs6))  yscale(r(0.2 7.7) lstyle(none)) xlab(`xlabel_`outcome'', labsize(3.5)) ///
		 legend(order(- "Below Median:" 2 "Diff" 4 "DiD" 6 "RD" - "" - "Above Median:" 8 "Diff" 10  "DiD" 12 "RD" )ring(0) pos(5) size(3.5) bmargin(tiny) ) ///
		 ylabel( 1 "CBA Coverage" 	2  `" "Binding" "CBA Coverage" "'  3 `""AKM Pay" "Premia SD" "' 4 "Industry AKM" 5 "Works Council"  6 `" "Log Value Added" "per Worker""'  7 "Tenure", labsize(3.5)) ///
		 ttext(0.3 -0.40 "Mean of Sorting Variable:", size(small) ) ///
		 ttext(0.8 -0.475 "Below:", size(small) )  ttext(1.2 -0.475 "Above:", size(small) )  ///
		 ttext(0.8 -0.41 "0.425", size(small)) ttext(1.2 -0.41 "0.796", size(small)) ttext(1.8 -0.41 "0.108", size(small)) ttext(2.2 -0.41 "0.254", size(small)) ///
		 ttext(2.8 -0.41 "0.135", size(small)) ttext(3.2 -0.41 "0.161", size(small)) ttext(3.8 -0.41 "0.059", size(small)) ttext(4.2 -0.41 "0.150", size(small)) ///
		 ttext(4.8 -0.41 "0.572", size(small)) ttext(5.2 -0.41 "0.835", size(small)) ttext(5.8 -0.41 "10.916", size(small)) ttext(6.2 -0.41 "11.365", size(small)) ///
		 ttext(6.8 -0.41 "3.014", size(small)) ttext(7.2 -0.41 "6.562", size(small))
graph display ,	xsize(19) ysize(9)

graph export "${figures}/figA8a.pdf", replace

}

}

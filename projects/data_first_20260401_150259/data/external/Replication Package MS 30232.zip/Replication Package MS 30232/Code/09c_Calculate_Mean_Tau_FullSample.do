/*******************************************************************************

	DESCRIPTION: estimate days in U / days in N for full sample (not just separators).

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off

***** Logging
cap log close
local curr_date = c(current_date)
log using "${logs}/09c_Calculate_Mean_Tau_FullSample_Prediction${prediction}`curr_date'", replace






****************************************************************************
* Pooled Analysis
****************************************************************************
foreach type in $types {
foreach group in $include1976 {


	***** Data sample restrictions + loading data
	if `group' == 0 { // 6 Years back
		local grprestriction inlist(reform, 1985, 1989, 2001)
		local samplename ""
	}
	if `group' == 1  { // 4 years Back
		local grprestriction inlist(reform, 1976, 1985, 1989, 2001) & inlist(yr_l5,.,0) & inlist(yr_l4,.,0)
		local samplename With76
	}


	use ${temp}/02c_PooledReforms_yrFwd1.dta if `grprestriction', clear

	* Keep if employed in December
	keep if status == 3

	if $Shorten76and89 == 1 {
		*Shorten 1976 and 1989 by 1 pct
		foreach reform in 1976 1989 {
			su earn_pct if treatment_`reform' == 1
			local min = r(min)
			su earn_pct if control_`reform' == 1
			local max = r(max)
			local new_min = `min' + 1
			local new_max = `max' - 1
			drop if reform == `reform' & earn_pct <= `new_min' & !mi(earn_pct)
			drop if reform == `reform' & earn_pct >= `new_max' & !mi(earn_pct)
		} // Looping through 1976 and 1989 code blocks
	} // Shorten 76 and 89 code block

	if "`type'" == "_stable" {
		keep if mth_emp == 12
	}

	if `group' == 2  {
		drop *_l4_f`yrFwd' *_l5_f`yrFwd' yr_l5 yr_l4
	}




	****************************************************************************
	* Generating heterogeneity groups used as predictors for tau regression
	****************************************************************************

	***** Months since UI group
		* Within-year indicator for censored value + four other quartiles
	bys reform year: gegen max = max(mths_since_UI)
	gen ms_UI_cat = 0 if mths_since_UI == max
	gquantiles temp_cat = mths_since_UI ///
	if mths_since_UI != max & !mi(mths_since_UI), ///
	xtile by(reform year) nquantiles(5)
	replace ms_UI_cat = temp_cat if !mi(temp_cat)
	drop max temp_cat


	***** Calculate tenure categories in three-year steps up to 15 years
	gen tenure_cat = 1 if tenure != . & tenure < 3
	local i = 2
	forvalues k = 3(3)12 {
		replace tenure_cat = `i' if tenure >= `k' & tenure < `k'+3
		local ++i
	}
	sum tenure_cat
	replace tenure_cat = r(max)+1 if tenure !=. & tenure >= 15


	***** Calculate experience categories in 5-year steps up to 25 years
	gen exp_cat = 1 if exp25 != . & exp25 < 5
	local i = 2
	forval k = 5(5)15 {
		replace exp_cat = `i' if exp25 >= `k' & exp25 < `k' + 5
		local ++i
	}
	sum exp_cat
	replace exp_cat = r(max)+1 if exp25 != . & exp25 >= 20


	***** Calculate age categories in 5-year steps
	gen age_cat = 1 if refage != . & refage < 30
	local i = 2
	forval k = 30(5)50 {
		replace age_cat = `i' if refage >= `k' & refage < `k' + 5
		local ++i
	}


	***** Create 3-digit NUTZ based on place of work
	gen nutz = substr(string(gkz_work),1,3)
	destring nutz, replace




	****************************************************************************
	* Looping through the different sample restrictions -- reemployed in XX years vs. never reemployed
	****************************************************************************
	qui foreach condition in $conditions {

		timer clear
		timer on 1

		preserve

		if ${prediction} == 0 {
			local add_rows 0
		}
		if ${prediction} == 1 {
			local add_rows 6 // 2 for sample size +  2 for R-squared + 2 for extra predictions
		}

		* generate summary stats matrix
		local S : list sizeof global(tausamples)
		local T : list sizeof global(taumeasures)
		local T = `T' + 6 + `add_rows'
		matrix define M = J(`T',`S',.)

		matrix colnames M = ${tausamples}
		* Local to store row labels
		local MrowLabs ""




		****************************************************************************
		* Predicting the time spent in each tausample + storing in matrix
		****************************************************************************

		* loop over tau samples
		local s = 1 // sample counter, s=1,...,S
		qui foreach tausample in $tausamples {


			noi di "Sample: `tausample'"

			***** merge tau's for the current sample
				* Won't be a complete match
				* Some individuals in the daily data won't be matched if the separations are very short
				* Some separations won't be matched (ex. an individual who separates after Dec 15th)
			noi fmerge m:1 svnr year using $temp/09b_Tau_Appended_`tausample'_WithDateType_UIvsUA_FromStartofYear.dta, keepusing(E_frac O_frac N_frac UI_frac UA_frac ENE?)

			noi tab _merge ENE_f1, m
			drop if _merge == 2
			drop _merge


			***** Calibrated wage-benefit passthrough
				* Difference between measures is whether 1 - tau includes the other time or not
			gen Sens_2 = ((1-${phi})*(UI_frac+UA_frac)) / (1-((1-${phi})*(1-UI_frac-UA_frac)))
			gen Sens_3 = ((1-${phi})*(UI_frac+UA_frac)) / (1-((1-${phi})*E_frac))

			* loop over different tau measures
			local t = 1 // tau counter, t=1,...,T
			foreach taumeasure in ${taumeasures} Sens_3 Sens_2 {

				noi di "	Measure: `taumeasure'"

				***** Adding sample restrictions in conditions
					* The EN conditions just keeps the entire sample
				if strpos("`condition'", "ENE") > 0 {
					local statement "if `condition' == 1"
				}
				else {
					local statement ""
				}

				***** Predicting tau measure
				if ${prediction}==1 {

					* do regression of tau measure on covariates
					 noi reg `taumeasure' i.nace08#i.whitecoll i.tenure_cat i.exp_cat ///
						i.nutz i.reform#i.year i.age_cat i.frau i.ms_UI_cat `statement'

					noi di "R2: `e(r2)'"
					noi di "Sample: `e(N)'"

					if "`taumeasure'" == "UI_frac" | "`taumeasure'" == "Sens_2" {
						local sample_`taumeasure' = `e(N)'
						local r2_`taumeasure' = `e(r2)'
					}

				}

				* predict tau if necessary
				if ${prediction}==1 {
					noi predict pred_`taumeasure'
					noi gstats sum pred_`taumeasure'
				}

				if ${prediction} == 0 {
					noi gstats sum `taumeasure' `statement'
				}

				* save mean in matrix
				matrix M[`t',`s'] = `r(mean)'

				* Labeling columns
				if `s' == 1 {
						local MrowLabs `MrowLabs' "E_hat_`taumeasure'"
				}

				* increase tau counter by 2 (i.e. rows because of mean and median)
				local t = `t'+1

			} // tau's




			****************************************************************************
			* Storing other information from the prediction regressions
			****************************************************************************
			if ${prediction}==1 {

				matrix M[`t',`s'] = `sample_UI_frac'
				local t = `t' + 1
				matrix M[`t',`s'] = `r2_UI_frac'
				local t = `t' + 1
				matrix M[`t',`s'] = `sample_Sens_2'
				local t = `t' + 1
				matrix M[`t',`s'] = `r2_Sens_2'
				local t = `t' + 1

				* Labeling columns
				if `s' == 1 {

					local MrowLabs `MrowLabs' "sample_UI_frac" "r2_UI_frac" "sample_Sens_2" "r2_Sens_2"
				}
			}


			***** Predicted or actual wage-benefit passthrouhgs
				* When pred is on these are the averages of the predicted pass-throughs
				* E[hat(f(tau_i))]
			local prefix
			if ${prediction} == 1 {
				local prefix pred_
			}

			* Three-state sensitivity
			noi gstats sum `prefix'Sens_3
			matrix M[`t',`s'] = `r(mean)'
			local t = `t' + 1

			* Two-state sensitivity
			noi gstats sum `prefix'Sens_2
			matrix M[`t',`s'] = `r(mean)'
			local t = `t' + 1

			* Adding names to row labels
			* Labeling columns
			if `s' == 1 {
				local MrowLabs `MrowLabs' "E_hat_Sens_3" "E_hat_Sens_2"
			}


			***** Average pass-through plugging in the individual predicted tau estimates
			if ${prediction}== 1 {

				gen sens_3state = ((1-${phi})*(`prefix'UI_frac + `prefix'UA_frac)) / (1-((1-${phi})*`prefix'E_frac))

				noi gstats sum sens_3state
				matrix M[`t',`s'] = `r(mean)'
				local t = `t' + 1
				drop sens_3state


				gen sens_2state = ((1-${phi})*(`prefix'UI_frac + `prefix'UA_frac)) / (1-((1-${phi})*(1-(`prefix'UI_frac + `prefix'UA_frac))))
				noi gstats sum sens_2state
				matrix M[`t',`s'] = `r(mean)'
				local t = `t' + 1
				drop sens_2state

				* Labeling columns
				if `s' == 1 {
					local MrowLabs `MrowLabs' "E_Sens_3_hat_tau_i" "E_Sens_2_hat_tau_i"
				}

			}


			***** Average pass-through plugging in the average predicted tau estimates
			noi gstats sum `prefix'UI_frac
			local uimean = `r(mean)'

			noi gstats sum `prefix'UA_frac
			local uamean = `r(mean)'

			noi gstats sum `prefix'E_frac
			local emean = `r(mean)'

			gen sens_exp_3 = ((1-${phi})*(`uamean'+`uimean')) / (1-((1-${phi})*`emean'))
			noi gstats sum sens_exp_3
			matrix M[`t',`s'] = `r(mean)'
			local t = `t' + 1

			gen sens_exp_2 = ((1-${phi})*(`uamean'+`uimean')) / (1-((1-${phi})*(1-(`uamean'+`uimean'))))
			noi gstats sum sens_exp_2
			matrix M[`t',`s'] = `r(mean)'
			local t = `t' + 1

			* Labeling columns
			if `s' == 1 {
				local MrowLabs `MrowLabs' "Sens_3_E_hat_tau_i" "Sens_2_E_hat_tau_i"
			}

			***** Cleaning up for the next sample loop
			drop E_frac O_frac N_frac UI_frac UA_frac ENE? sens_exp_* Sens_*

			if ${prediction} ==1 {
				drop  pred_*
			}


			* increase sample counter (i.e. columns)
			local ++s
		} // samples


		clear
		matrix rownames M = `MrowLabs'
		noi matrix list M

		svmat M, names(column)

		save ${temp}/Tau_NewTable`type'_`samplename'_age${age}_pred${prediction}_`condition'_NonSeparatorsToo.dta, replace

		restore

		timer off 1
		qui timer list 1
		local time: di %5.3f `r(t1)'/60
		noi di "Time for `condition': `time' minutes"

	} // conditions
} // With or Without 1976
} // Type

log close

/*******************************************************************************

	DESCRIPTION: Figure 3: Unemployment Benefit Schedules and Reforms



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
clear all
cap log close
local curr_date = c(current_date)
log using "${logs}/Fig3_BenefitSchedules`curr_date'", replace


****************************************************************************
* Simulating income and replacement rates
	* Income from 0 - 42500 ATS each year in 50 ATS bins
****************************************************************************
* Create simulated data
local start_year = 1972
local end_year = 2006

* Get nominal earnings range from 03a file (not distinguishing between treatment and control)
** note the year is = to reform - 1
foreach reform in 2001 1989 1985 1976 {

	use  ${temp}/03a_Nonparametric_DTAFiles/03a_NonParametric_Sample_Reform`reform'_stable.dta if in_sample_`reform'  == 1 , clear

	**** Defining different earnings concepts for the x-axis
	if `reform' == 2001 {
		local earn_cpt adj_earnings
	}
	else {
		local earn_cpt infl1_adj_earnings
	}

	local refminus1 = `reform' - 1
	su `earn_cpt' if !mi(treatment_`reform')
	local min_`refminus1' = r(min)
	local max_`refminus1' = r(max)

	}

clear

* set number of obs
local num_obs = (`end_year' - `start_year' + 1)*1200
set obs `num_obs'

gen obs_num = _n
gen year = floor((obs_num - 1)/1200) + 1972

bysort year: gen ATS_income = _n*50

* Defining the replacement rates
rr_rate_austria, new_var(replacement_rate) inc(ATS_income) year_t(year)

* Binning monthly income and taking the average replacement rate (to smooth graph)
gen ATS_bin = round(ATS_income/250,1)*250
collapse replacement_rate  x_earn_max ///
x_earn_min , by(year ATS_bin )

		* 1975.5: assume same earnings maximum/minimum as 1975
		foreach x in max min {
			qui su x_earn_`x' if year == 1976
			replace x_earn_`x' = r(mean) if year == 1976.5
		}

replace replacement_rate = replacement_rate*100
gen UIB_level = replacement_rate*ATS_bin/100

****************************************************************************
* Plotting the replacement rate for each year
****************************************************************************

local end_grph = `end_year' - 1

levelsof year if year >= 1972, local(levels)

local counter = 0
local max1975 = 15000
local range1975 20(10)60

local max1984 = 40000
local range1984 20(10)60

local max1988 = 25000
local range1988 30(10)60

local max2000 = 40000
local range2000 30(10)60



foreach year in 1975 1984 1988 2000 {
	local counter = `counter' + 1
	local letter = word("a b c d", `counter')
	local year_pl = `year' + 1

	local earnings_max = `max`year''

	foreach x in max min {
		su x_earn_`x' if year == `year'
		local base_`x' = r(mean)
		su x_earn_`x' if year == `year_pl'
		local future_`x' = r(mean)
	}

	if `year' == 1975 {
		local base_min = 2500
		local future_min = 2500
	}

	* Replacement rate figure
	tw (line replacement_rate ATS_bin if year == `year' ///
	& ATS_bin <= `base_min' & replacement_rate <= 60, lcolor(none) lpattern(none)) ///
	(line replacement_rate ATS_bin if year == `year' ///
	& inrange(ATS_bin, `base_min', `earnings_max') , lcolor(dknavy) lpattern(dash)) ///
	(line replacement_rate ATS_bin if year == `year_pl' ///
	& ATS_bin <= `future_min' & replacement_rate <= 60 , lcolor(none) lpattern(none)) ///
	(line replacement_rate ATS_bin if year == `year_pl' ///
	& inrange(ATS_bin, `future_min', `earnings_max') , lcolor(green%90) lwidth(thick) lpattern(solid) ///
	ylab(`range`year'', nogrid labsize(medium)) ///
	xlab(, nogrid labsize(medium)) ///
	xline(`min_`year'' `max_`year'', lpattern(shortdash) lcolor(gray)) ///
	legend(size(medium) label(2 "`year'") label(4 "`year_pl'") ///
	order(2 4) pos(6) col(2)) xtitle("Monthly Earnings (ATS)") ///
	ytitle("Benefits (b/w)"))

	graph export "${figures}/Fig3`letter'_BenefitSchedules.pdf", replace

	}

****************************************************************************
* Figure 3(e): percentiles are treated in each reform
****************************************************************************

**** Appending reforms together
use ${temp}/04a_BenefitChanges_byReform_Percentiles.dta, clear

tw (line RRdiff_f1_RRiBY_BRiBY earn_pct_bin if year == 1976 & in_sample == 1, lwidth(thick) lcolor(black%60) lpattern(solid)) ///
(line RRdiff_f1_RRiBY_BRiBY earn_pct_bin if year == 1985 & in_sample == 1, lwidth(thick) lcolor(blue%60) lpattern(dash) ) ///
(line RRdiff_f1_RRiBY_BRiBY earn_pct_bin if year == 1989 & in_sample == 1, lwidth(thick) lcolor(green%60) lpattern(shortdash) ) ///
(line RRdiff_f1_RRiBY_BRiBY earn_pct_bin if year == 2001 & in_sample == 1, lwidth(thick) lcolor(red%60)  lpattern(dash_dot) ///
legend(label(1 "1976") label(2 "1985") label(3 "1989") label(4 "2001") col(4) pos(6) ///
subtitle("UI Reform Year", size(vlarge)) size(vlarge)) xtitle("Earnings Percentile", size(vlarge)) ytitle("Benefit Change (db/w)", size(vlarge)) ///
xscale(range(0 100)) xlabel(0(20)100, labsize(vlarge)) ylabel(,labsize(vlarge)) xsize(10))

graph export "${figures}/Fig3e_BenefitSchedules.pdf", replace

log close

args byvar begin end

* check whether arguments are given
if "`1'" == "" | "`2'" == "" | "`3'" == "" {
	noisily display in red "missing parameters"
	exit
}

* set more off
set more off

* sort by person begin and end period	  
sort `byvar' `begin' `end'

* generate number of spells per person
qui by `byvar': gen int nsnumber = _N

* generate random number to identify files
global pr = int(10000*runiform())

* make sure `end' is not missing
replace `end' = mdy(1,1,3000) if `end'==.

* set locals
count
local number = r(N)
local recnum = r(N)
local counter = 1
local tempnum = 0
local deleted = 0
local flag = 1

* as long as we find "shorter" (i.e. intermediate) spells we go on
while `flag' == 1 {

	* we drop spells if they start later but end earlier than the previous spell
	qui by `byvar': drop if (_n > 1) & (`begin' >= `begin'[_n-1] & `end' <= `end'[_n-1])
    
	* we count how many spells we deleted and reset the flag
	count
	local onumber = `number'
	local number = r(N)
	local deleted = `deleted' + `onumber' - `number'
	local flag = (`onumber' - `number' > 0)
	
	* save spells temporarily
	qui count if nsnumber <= `counter'
	if ((r(N) >= int(`number' * 0.2)) & (int(`number' * 0.2) > 10000)) {
		preserve
		keep if nsnumber <= `counter'
		local tempnum = `tempnum' + 1
		save normspell_`tempnum'_${pr}.tmp, replace
		restore
		drop if nsnumber <= `counter'
		count
		local onumber = `number'
		local number = r(N)
	}
		
	* reset counter
	local counter = `counter' + 1
}
local loops = `counter' - 1

* append the saved files
local counter = 1
while `counter' <= `tempnum' {
	append using normspell_`counter'_${pr}.tmp
	erase normspell_`counter'_${pr}.tmp
	local counter = `counter' + 1
	}

* count number of spells
count
local number = r(N)

* finally we drop those spells where a previous spell ends earlier but starts at the same day
sort `byvar' `begin' `end'
qui by `byvar': drop if (`begin' == `begin'[_n+1] & `end' < `end'[_n+1]) & (_n < _N)

* we again count the number of deleted spells
count
local onumber = `number'
local number = r(N)
local deleted = `deleted' + `onumber' - `number'

* make sure `end' is missing again
replace `end' = . if `end'==mdy(1,1,3000)

* drop temp variables
drop nsnumber

* show results
noisily display "number of records:" `recnum'
noisily display "loops            :" `loops'
noisily display "deleted          :" `deleted'

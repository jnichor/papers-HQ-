/*******************************************************************************

	DESCRIPTION: Figure A.12 Alternate Outcomes DiD Analysis



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
clear all
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA12_AlternateOutcomes`curr_date'", replace

********************************************************************************

local suffixes1 earn_pct
local suffixes2 benr

local controlname1 none
local controlname2 mincer
local controlname3 indocc
local controlname4 ctrls
local controlname5 firmyr
local controlname6 ctrlsfirmyr
local controlname7 ind2digocc
local controlname8 ctrlsind2digocc

local control_num_list_earn_pct 1 4 6
local control_num_list_benr 1 2 3 4
local control_num_list_nace08 1 8

local sm_lab1 None
local sm_lab2 Mincer + Ind-Occ
local sm_lab3 Min + I-O + Firm FE
local sm_lab4 None, Fully Inter.
local sm_lab5 Min + I-O, Fully Inter.
local sm_lab6 Min + I-O + Firm, Fully Inter.

local a1_lab1 None
local a1_lab2 Mincer
local a1_lab3 Ind-Occ FE
local a1_lab4 Mincer + Ind-Occ
local a1_lab5 Firm FE
local a1_lab6 All Controls

local a2_lab1 Firm, None
local a2_lab2 Firm, Mincer
local a2_lab3 Firm, Ind-Occ FE
local a2_lab4 Firm, Mincer + I-O
local a2_lab5 Firm, 2d Ind-Occ
local a2_lab6 Firm, Minc + 2d I-O
local a2_lab7 Ind, None
local a2_lab8 Ind, Mincer
local a2_lab9 Ind, 2d Ind-Occ
local a2_lab10 Ind, Minc + 2d I-O

local lab1 Mover
local lab2 Recalled
local lab3 ENE
local lab4 EUE
local lab5 Mth NE
local lab6 Mth UI
local lab7 Mth Sick


local with With76
local a 1

qui foreach yrFwd in 1 2 {
foreach outcome in mover_f`yrFwd' recalled_f`yrFwd' ENE_f`yrFwd' EUE_f`yrFwd' ///
	mth_non_emp_f`yrFwd' mth_UE_f`yrFwd' mth_sick_f`yrFwd'  {

local x = 1

foreach suffix in `suffixes`a'' {
	foreach i in `control_num_list_`suffix'' {
		if `a' == 1 {
			use "${resDat}/DiD_1_`suffix'_`outcome'_`with'_stable_Spec`controlname`i''.dta", clear
			qui sum *_avg
			local cm`outcome' : di %5.3f r(mean)
			noi di "base rates for `outcome' = `cm`outcome''"
		}

		gen spec = `x'
		tempfile f`x'
		save `f`x''
		local x = `x' + 1
	}
}

clear
local x = `x' - 1
set obs 1
gen filler = 1
gen UB = .
gen LB = .
gen coeff = .
forval b = 1/`x'{
	append using "`f`b''"
}
foreach suffix in `suffixes`a'' {
	foreach i in `control_num_list_`suffix'' {
		foreach type in UB LB coeff {
			replace `type' = `controlname`i''_`type' if mi(`type')
		}
	}
}
drop if filler == 1
drop filler

	qui su spec
	local max = r(max) + 1
	qui su year
	local yearmin = r(min)
	gen n = (year - `yearmin' + 1) + (spec/`max')

	local statement
	local legend
	local order
	local xlabels
	local counter = 1

	tempfile `outcome'_`a'_`yrFwd'_`with'
	save ``outcome'_`a'_`yrFwd'_`with''

}


}

clear
set obs 1
gen yrFwd = -99

gen outcome = ""
foreach yrFwd in 1 2 {
	foreach outcome in mover_f`yrFwd' recalled_f`yrFwd' ENE_f`yrFwd' EUE_f`yrFwd'   ///
	mth_non_emp_f`yrFwd' mth_UE_f`yrFwd' mth_sick_f`yrFwd' {
		append using ``outcome'_`a'_`yrFwd'_`with''
		replace yrFwd = `yrFwd' if mi(yrFwd)
		replace outcome = substr("`outcome'",1,length("`outcome'")-3) if mi(outcome)
	}
}
	drop if yrFwd == -99
	keep if year == 0

	gen group = .
	replace group = 1 if outcome == "mover"
	replace group = 2 if outcome == "recalled"
	replace group = 3 if outcome == "ENE"
	replace group = 4 if outcome == "EUE"
	replace group = 5 if outcome == "mth_non_emp"
	replace group = 6 if outcome == "mth_UE"
	replace group = 7 if outcome == "mth_sick"

	drop n
	gen n = group
	qui su n
	local max = r(max)
	replace n = n + `max' if yrFwd == 2

	if `a' == 1 {
	replace n = n - (1/4) if spec == 1
	replace n = n + (1/4) if spec == 3
	}


local statement
	local legend
	local order
	local xlabels
	local counter = 1
	forval i = 1/7 {

		local color = word("red orange green blue purple mint brown", `i')
		local shape = word("O S T Oh Sh Th X", `i')

		local statement `statement' (rcap LB UB n ///
		if group == `i' & spec == 1, lcolor(`color')) ///
		(scatter coeff n if group == `i'  & spec == 1, ///
		msymbol(`shape') mcolor(`color')) ///
		(rcap LB UB n ///
		if group == `i' & spec == 2, lcolor(`color')) ///
		(scatter coeff n if group == `i'  & spec == 2, ///
		msymbol(`shape') mcolor(`color')) ///
		(rcap LB UB n ///
		if group == `i' & spec == 3, lcolor(`color')) ///
		(scatter coeff n if group == `i'  & spec == 3, ///
		msymbol(`shape') mcolor(`color'))


		if `a' == 1 {
			local num  6
		}
		if `a' == 2 {
			local num 10
		}
		local y = `num'*(`i'-1)+2
		local legend `legend' label(`y' "`lab`i''")
		local order `order' `y'
	}

	local midpointn = `max' + 0.5
	local midpoint1 = `max' * 0.5
	local midpoint2 = `max' * 1.5
	local xlabels1 `midpoint1' "One-Year Outcomes" `midpoint2' "Two-Year Outcomes"

	local first = 0.37
	local second = 0.8
	local third = 1 + (1/4)
	local xlabels2 `first' "   No Controls" ///
	`second' "  Min + I-O FE" ///
	`third' " All Controls"

	gen filler1 = .
	gen filler2 = .
	gen filler3 = .
	local y = `y' + `num' - 1
	local z = `y' + 1
	local k = `y' + 2
	tw `statement' (scatter filler1 n, mcolor(black) msymbol(O) xaxis(2)) ///
	(scatter filler2 n , mcolor(black) msymbol(S)) ///
	(scatter filler3 n, mcolor(black) msymbol(D) ///
	xscale(range(0(1)7.25) axis(1) lstyle(none)) ///
	xscale(range(0(1)7.25) axis(2)) ///
	legend(`legend' ///
	order(`order' ) r(1) pos(6)) xtick(`midpointn', axis(1)) ///
	xtick(0.75 1 1.25, axis(2)) ///
	xline(7.5, lp(dot) lcolor(gs1)) ///
	xlab(`xlabels2', notick angle(45) axis(2) labsize(small) )  ///
	xlab(`xlabels1', notick axis(1)) yline(0, lcolor(black)) ///
	xtitle("", axis(1)) xtitle("", axis(2)) ///
	ytitle("Alternative Outcomes" " "))
	graph export "${figures}/FigA12_AlternateOutcomes.pdf", replace

log close

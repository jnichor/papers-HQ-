*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================

set more off

cap file close fh 

* settings
local spec = 3
local wname = 1

* Store Table Names in Globals
do "${code}/Set_Table_Names.do"

local name1_upper "Difference"
local name1_lower "Industry-Year FE"
local name1_Mean "Control Mean"
local name1_Nag "\textit{N}, Stock Cs"
local name1_N "\textit{N}, Stock Cs Firm-Years"

local name2_upper "DiD"
local name2_lower "Industry-Year FE"
local name2_Mean "Control Mean"
local name2_Nag "\textit{N}, Stock Cs"
local name2_N "\textit{N}, Stock Cs Firm-Years"

local name3_upper "RD"
local name3_lower "Industry-Year FE"
local name3_Mean "Control Mean"
local name3_Nag "\textit{N}, Stock Cs"
local name3_N "\textit{N}, Stock Cs Firm-Years"

********** Placebo 1996 ***************
local name11_upper "Difference"
local name11_lower "Industry-Year FE"
local name11_Mean "Control Mean"
local name11_Nag "\textit{N}, Stock Cs"
local name11_N "\textit{N}, Stock Cs Firm-Years"

local name12_upper "DiD"
local name12_lower "Industry-Year FE"
local name12_Mean "Control Mean"
local name12_Nag "\textit{N}, Stock Cs"
local name12_N "\textit{N}, Stock Cs Firm-Years"

local name13_upper "RD"
local name13_lower "Industry-Year FE"
local name13_Mean "Control Mean"
local name13_Nag "\textit{N}, Stock Cs"
local name13_N "\textit{N}, Stock Cs Firm-Years"

********** Placebo 1997 ***************
local name21_upper "Difference"
local name21_lower "Industry-Year FE"
local name21_Mean "Control Mean"
local name21_Nag "\textit{N}, Stock Cs"
local name21_N "\textit{N}, Stock Cs Firm-Years"

local name22_upper "DiD"
local name22_lower "Industry-Year FE"
local name22_Mean "Control Mean"
local name22_Nag "\textit{N}, Stock Cs"
local name22_N "\textit{N}, Stock Cs Firm-Years"

local name23_upper "RD"
local name23_lower "Industry-Year FE"
local name23_Mean "Control Mean"
local name23_Nag "\textit{N}, Stock Cs"
local name23_N "\textit{N}, Stock Cs Firm-Years"

foreach block in 1 2 3 11 12 13 21 22 23 31 32 33{
local lineNYag`block' "\textit{N}, Firm-Years Stock Cs "
local lineNYnag`block' "\textit{N}, Firm-Years  LLCs "
local controlmean_lineAG`block' "Control Mean: Stock Cs "
local controlmean_linenAG`block' "Control Mean: LLCs "
local lineNag`block' "\textit{N}, Stock Cs "
local lineNnag`block' "\textit{N}, LLCs "
}

* set folders, filenames, sample suffixes for each sample and design
local folder
local filename
local sampsuffix

local folderDiD 202
local folderDiff 203
local folderRD 201
local folderplacebo 207



foreach block in 1 2 3 11 12 13 21 22 23 {



	local block`block'_lineB "\text{`name`block'_upper'}"
	local block`block'_lineSE "\text{`name`block'_lower'}"
	local block`block'_lineMean "\text{`name`block'_Mean'}"
	local block`block'_lineNag "\text{`name`block'_Nag'}"
	local block`block'_lineN "\text{`name`block'_N'}"

	if `block' == 1{
		clear
		forvalue i = 10(10)90 {
			append using "${iab}/`folderDiff'/Diff_log_te_p`i'_Winsor`wname'_spec`spec'.dta"
		}
	}

	if `block' == 2{
		clear
		forvalue i = 10(10)90 {
			append using "${iab}/`folderDiD'/DiD_log_te_p`i'_Winsor`wname'_spec`spec'.dta"
		}
	}

	if `block' == 3{
		clear
		forvalue i = 10(10)90 {
			local RDtype _AG
			append using "${iab}/`folderRD'/RD_log_te_p`i'_Winsor`wname'_spec`spec'`RDtype'.dta"
		}
	}


	if `block' == 11{
		clear
		forvalue i = 10(10)90 {
			append using "${iab}/`folderplacebo'/Diff_Placebo_1996_log_te_p`i'_Winsor`wname'_spec`spec'.dta"
		}
	}

	if `block' == 12{
		clear
		forvalue i = 10(10)90 {
			append using "${iab}/`folderplacebo'/DiD_Placebo_1996_log_te_p`i'_Winsor`wname'_spec`spec'.dta"
		}
	}

	if `block' == 13{
		clear
		forvalue i = 10(10)90 {
			local RDtype _AG
			append using "${iab}/`folderplacebo'/RD_Placebo_1996_log_te_p`i'_Winsor`wname'_spec`spec'`RDtype'.dta"
		}
	}

	if `block' == 21{
		clear
		forvalue i = 10(10)90 {
			append using "${iab}/`folderplacebo'/Diff_Placebo_1997_log_te_p`i'_Winsor`wname'_spec`spec'.dta"
		}
	}

	if `block' == 22{
		clear
		forvalue i = 10(10)90 {
			append using "${iab}/`folderplacebo'/DiD_Placebo_1997_log_te_p`i'_Winsor`wname'_spec`spec'.dta"
		}
	}

	if `block' == 23{
		clear
		forvalue i = 10(10)90 {
			local RDtype _AG
			append using "${iab}/`folderplacebo'/RD_Placebo_1997_log_te_p`i'_Winsor`wname'_spec`spec'`RDtype'.dta"
		}
	}

    local blank_line " "
    local columns "l "
    local colnumber_line " "
	local colnumber = 0

	forval num = 1/9 {

		* Blank line
		local blank_line "`blank_line' & "

		* Number of columns
		local columns "`columns' c "

		*Column number
		local colnumber = `colnumber' + 1
		local colnumber_line "`colnumber_line' & (`colnumber')"

		cap rename Nf N_AG
		cap rename controlmean controlmean_AG

		cap foreach var in b s p controlmean_AG N_AG N_nonAG Nfirmyears_AG Nfirmyears_nonAG controlmean_nonAG{

			if inlist("`var'","p") {
				local display
			}
			else if inlist("`var'", "N", "Nfirms", "N_AG", "N_nonAG","Nfirmyears_AG", "Nfirmyears_nonAG") {
				local display %8.0fc
			}
			else {
				qui su `var'
				if int(abs(r(mean))*1000)<1 {
					if int(abs(r(mean))*10000)<1 {
						if int(abs(r(mean))*10000)<1 {
							local display %8.6f
						}
						else {
							local display %8.5f
						}
					}
					else {
						local display %5.4f
					}
				}
				else {
					local display %5.3f
				}
			}
			local value  `var'[`num']
			local `var': di `display' `value'
		}

		local s "(`s')"

		foreach var in p {
			if ``var'' > .1 {
				local star_`var' ""
			}
			if inrange(``var'',.05,.1) {
				local star_`var' "$^{*}$"
			}
			if inrange(``var'',.01,.05) {
				local star_`var' "$^{**}$"
			}
			if ``var'' <= .01 {
				local star_`var' "$^{***}$"
			}
		}

		local block`block'_title "`block`block'_title' & "
		local block`block'_lineB "`block`block'_lineB' & `b'`star_p'"
		local block`block'_lineSE "`block`block'_lineSE' & `s'"

		if `block' == 2 | `block' == 12 | `block' == 22{
		local controlmean_lineAG`block' "`controlmean_lineAG`block'' & `controlmean_AG' "
		local controlmean_linenAG`block' "`controlmean_linenAG`block'' & `controlmean_nonAG' "
		local lineNag`block' "`lineNag`block'' & `N_AG'"
		local lineNnag`block' "`lineNnag`block'' & `N_nonAG'"
		local lineNYag`block' "`lineNYag`block'' & `Nfirmyears_AG'"
		local lineNYnag`block' "`lineNYnag`block'' & `Nfirmyears_nonAG'"
		}
	} // Outcomes in Group

} // Block



loca colnumber = `colnumber'+1
local Actual_title_line "\multicolumn{`colnumber'}{c}{\textbf{Panel A: Actual Reform (1994)}}"
local Placebo_1996_title_line "\multicolumn{`colnumber'}{c}{\textbf{Panel B: Placebo Reform 1996}}"
local Placebo_1997_title_line "\multicolumn{`colnumber'}{c}{\textbf{Panel C: Placebo Reform 1997}}"
file open fh using "${tables}/TableA3.tex", write replace
* header
file write fh "\begin{tabular}{`columns'}" _n
file write fh "\hline \hline" _n
file write fh "\textit{Outcome} & \multicolumn{8}{c}{Mean Log Wage} \\  \cmidrule(lr){2-`colnumber'} " _n
file write fh "\textit{Percentile} &  p10 & p20 &  p30  & p40 & p50  &p60 & p70 & p80 & p90 \\" _n
file write fh "\hline \hline " _n

* coefficients and SEs for different specs
foreach block in 1 2 3 11 12 13 21 22 23 {
if `block' == 1{
    file write fh  " `Actual_title_line'  \\" _n  "\hline" _n
}
if `block' == 11{
    file write fh  "\hline" _n  "`Placebo_1996_title_line' \\" _n  "\hline" _n
}
if `block' == 21{
    file write fh "\hline" _n "`Placebo_1997_title_line' \\" _n  "\hline" _n
}
	file write fh  "`blank_line' \\"  _n
	file write fh "`block`block'_lineB' \\" _n ///
		"`block`block'_lineSE' \\" _n 

if `block' == 3{

file write fh "\hline" _n ///
			"`controlmean_lineAG2' \\" _n ///
			"`lineNag2' \\" _n ///
			"`lineNYag2' \\" _n ///
			"\hline" _n ///
			"`controlmean_linenAG2' \\" _n ///
			"`lineNnag2' \\" _n ///
			"`lineNYnag2' \\" _n
}
if `block' == 13{

file write fh "\hline" _n ///
			"`controlmean_lineAG12' \\" _n ///
			"`lineNag12' \\" _n ///
			"`lineNYag12' \\" _n ///
			"\hline" _n ///
			"`controlmean_linenAG12' \\" _n ///
			"`lineNnag12' \\" _n ///
			"`lineNYnag12' \\" _n

}
if `block' == 23{

file write fh "\hline" _n ///
			"`controlmean_lineAG22' \\" _n ///
			"`lineNag22' \\" _n ///
			"`lineNYag22' \\" _n ///
			"\hline" _n ///
			"`controlmean_linenAG22' \\" _n ///
			/*"`blank_line' \\" _n*/ ///
			"`lineNnag22' \\" _n ///
			"`lineNYnag22' \\" _n
}

}

* footer
file write fh "\hline \hline" _n ///
	"\end{tabular}" _n

file close fh

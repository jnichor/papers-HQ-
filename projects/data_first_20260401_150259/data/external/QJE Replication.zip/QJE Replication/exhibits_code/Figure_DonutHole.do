*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
set more off
timer clear

set scheme plotplainblind
global outcomes  log_te_mw akm_firm_fe

global figname1_akm_firm_fe = "AKM Firm FE"
global figname1_log_te_mw  = "Mean Log Wages"
global figname1_log_te_p50 = "Log Wage, 50th Pct"
global figname1_log_te_p75 = "Log Wage, 75th Pct"
global figname1_log_te_p7525 = "Log Wage Ratio, 75th/25th Pct"
timer on 1

local ylabel_log_fias "-.5(0.5)2.5"
local ylabel_log_fias_per_empl "-.5(0.5)2.5"
local ylabel_log_av_per_empl "-.5(0.5)2.5"
local ylabel_log_te_mw "-.6(.2).4"
local ylabel_akm_firm_fe "-.3(.1).3"
local posit_log_fias 5
local posit_log_fias_per_empl 5
local posit_log_av_per_empl 5
local posit_log_te_mw 5
local posit_akm_firm_fe 5
local file_log_te_mw "figA4b"
local file_akm_firm_fe "figA4d"

global iabresults $iab/206



** Graph

********************************************************************************

foreach i in 3{
foreach outcome in $outcomes {

	clear

		foreach w in $winsor_values {

			local wname = subinstr("`w'",".","",.)

			use "${iabresults}/DonutHole_`outcome'_Winsor`wname'_BW`i'.dta", replace

		}

		local fontsize 5

		*--------------------------------------
		*--- RD
		*--------------------------------------

		* redenominate if in 1000 EUR
		qui sum c_d
		if `r(mean)' >= 1000 {
		foreach var in c_d ub_d lb_d {
			replace `var' = `var'/1000
		}
		}
        qui sum c_rd if d == 0
		global estimate : di %5.3f `r(mean)'
		qui sum s_rd if d == 0
		global seestimate : di %5.3f `r(mean)'
		global graphtexty = $estimate - 5*$seestimate
		* figure
		tw connected c_rd d , msymbol(Sh) mcolor(gray) msize(medium) || ///
		rarea ub_rd lb_rd d , color(gray%30) lwidth(medthick) || ///
		connected c_rd d if d == 0, msymbol(S) mcolor(sea) msize(medium) || ///
		rcap ub_rd lb_rd d if d == 0, color(sea) lwidth(medthick) ///
		, ///
		xtitle("Months excluded around August 10, 1994", size(`fontsize')) ///
		ytitle("") ///
		yscale(titlegap(*-40)) ///
		 ylab(`ylabel_`outcome'', labsize(`fontsize')) ///
		yline(0, lcolor(gray) lpattern(dash)) ///
		legend(off)

		//text($graphtexty 6 "RD: ${estimate} (SE ${seestimate})", size(`fontsize')) ///
		graph export "${figures}/`file_`outcome''.pdf", replace

	}
	}

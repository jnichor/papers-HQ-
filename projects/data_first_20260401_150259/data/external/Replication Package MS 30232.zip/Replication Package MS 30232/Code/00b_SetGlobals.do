/*******************************************************************************


	DESCRIPTION: Sets globals and other parameters for all data generation + analysis

	November 20th, 2019


*******************************************************************************/




********************************************************************************
* Preliminaries
********************************************************************************
clear all
set more off , permanently
set maxvar 10000
set matsize 10000
cap log close


***** Logging
cap log close
local curr_date = c(current_date)
*log using "${logs}/00b_SetGlobals`curr_date'", replace


********************************************************************************
***** Globals determining which subsets of data are pulled
********************************************************************************


***** Year ranges for loading the data
	* Splitting it up like this helps with memory issues
* Year ranges to subset data over
global start1 = 1972
global end1 = 1979

global start2 = 1980
global end2 = 1987

global start3 = 1988
global end3 = 1995

global start4 = 1996
global end4 = 2003

* Number of year ranges to loop over
	* This is just the number of year ranges above
global yrRanges 1 2 3 4

* Years to loop over in 01d (ending year minus 2)
global startYr_01d 1972
global endYr_01d 2000


***** Age ranges
global start_age = 25
global end_age = 54
global end_age = $end_age + 1 // Since ages include decimals want to include end age + 1


***** Included months
global month_start = 1
global month_end = 12


***** Sex samples included
global sexSamples male female


***** Number of future earnings change measures to include
global earnF  1  2


***** Reforms
global reforms 1976 1985 1989 2001


***** Number of years to include pre- and post-reform year for each reform year
global postYrs = 0
global preYrs = 5


***** Number of future instrument value
global instrumentF 1


***** Number of lags to use to calculate RRs 1996 and after
	* Should be 2 for Jan-June and 1 for July-Dec but since we have annual data, using 1 for now
global post95_RRLag = 1


***** Number of pre- and post-years needed (relative to reform year)
	* For each year we estimate a coefficient for, we need one year of prior data
	* and as many years of forward data as the number of forward earnings variables
	* we include.

	* The one year of prior data is for the lagged net income value. If we instead
	* use the two-year lage here we'll need to subtract two years from preYrs

	* The +1 with keepPre takes into account that we subtract this variable from
	* the reform year rather than the treatment year.

global keepPost = $postYrs + 3
global keepPre = $preYrs + $post95_RRLag + 1


***** Leap years -- used to go from daily to annual earnings
global leapYears 1972, 1976, 1980, 1984, 1988, 1992, 1996, 2000, 2004, 2008, 2012, 2016


***** Euro to Shilling conversion factor
global euroToShilling 13.7603


***** Number of percentiles below the sample cap to cut from the 1985 reform
global samplecap 3


***** Defining the treatment and control earnings ranges for each reform
	* 2001
	global treat_lb_2001 10000
	global treat_ub_2001 20500

***** Wage-benefit passthrough
global wageBen = .483
global wageBen_lo = .243

***** Indicator for shortening the 1976 and 1989 reforms by one earnings percentiles
global shorten76and89 = 1

* Winsorizing earnings growth percentile
global winsor_pct 1 99


***** Variables to put in summary statistics table
global sumstat_table_vars frau refage whitecoll exp25 tenure adj_earnings


***** Variables for heterogeneity analysis
	* indocc_mth_UE_grp -- Industry/year predicted months spend on UE next year
	* indocc_unemp_grp -- Industry/year predicted unemployment next year
	* UE_grp -- Local unemployment rate
	* UI_grp -- Months since individual UI receipt
	* nonemp_grp -- Months since individual nonemployment
	* lom_ind_growth_grp -- Leave own firm out industry growth rate
	* AKMfirm_grp -- AKM Firm FE
	* wage_growth_SD_grp -- SD of firm-level earnings growth
	* CBA_residuals_SD_grp -- SD of residuals from CBA regression
	* firmshNonemp_grp -- Share of the firm nonemployed in the past two years
	* tenure_grp -- Job tenure
	* age_grp -- Different Age Groups
	* gender_grp -- Male vs. Female
	* occ_grp -- Blue vs. White Collar
	* switch_anal1_grp -- stayer vs. mover vs. recalled
	* switch_anal2_grp -- stayer vs. recalled vs. EUE vs. ENE
global hetgroups indocc_mth_UE_grp indocc_unemp_grp UE_grp UI_grp nonemp_grp ///
				 lom_ind_growth_grp AKMfirm_grp wage_growth_SD_grp CBA_residuals_SD_grp firmshNonemp_grp  ///
				 tenure_grp age_grp gender_grp occ_grp switch_anal1_grp switch_anal2_grp


***** Parameters for the Eurobarometer Figure
global eurobar_year 2006 //year of interest
global eurobar_type 107 //ALG

*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================

* --------------- --------------- --------------- ---------------  -------------
*
* Graphical Settings
* --------------- --------------- --------------- ---------------  -------------
graph set window fontface verdana


cap mkdir "${figures}/misc"


********************************************************************************
*
*		Generate Employee Counts from Beschaeftigte
*
********************************************************************************
use "${hoppenstedt}/Hoppenstedt_Beschaeftigte.dta", clear
duplicates drop
cap drop dup
gen year = substr(stichtag, -4, 4)
duplicates tag unternehmensname profilid stichtag, gen(dup)


	gen keep = .
	replace keep = 1 if dup == 0
	* Two duplicates: Durchschnitt (average) vs. GJ-Ende (end of FY). Take Durchschnitt.
	*			   OR Konzern vs. AG. Take AG
	replace keep = 1 if dup == 1 & ///
		inlist(bemerkung, "Durchschnitt", "Durchschnitt (fest angestellt)", "durchschnitt")
	replace keep = 1 if dup == 1 & ///
		inlist(notiz, "AG", "AG Durchschnitt", "davon Inland", "AG Jahresdurchschnitt") | ///
		inlist(notiz,"Inland", "AG Jahresüberschuß", "KG", "KGaA", "KGaA Durchschnitt", ///
		"AG (Durchschnit)", "AG (Durchschnitt)")

	* Three duplicates: Konzern/Inland vs. Welt/Weltweit vs. AG. Take AG.
	*				OR 	Durchschnitt vs. 2 GJ-Ende. Take Durchschnitt.
	*				OR 	Inland vs. Ausland vs. Gesamt. Take Inland.
	*				OR 	Deutschland vs. Schweiz vs. Gesamt. Take Deutschland.
	replace keep = 1 if dup == 2 & notiz == "AG"
	replace keep = 1 if dup == 2 & bemerkung == "Durchschnitt"
	replace keep = 1 if dup == 2 & bemerkung == "Inland"
	replace keep = 1 if dup == 2 & bemerkung == "Deutschland¦2¦"

	* Four duplicates: Konzern vs. AG vs. Konzern davon Inland vs. AG davon Inland

	replace keep = 1 if dup == 3 & notiz == "AG" & bemerkung == "davon Inland" & dup == 3
	replace keep = 1 if dup == 3 & notiz == "davon Inland"
	replace keep = 1 if dup == 3 & notiz == "gemäß IAS" & bemerkung == "Durchschnitt" & rang == 1

	* Five duplicates: These are 7 large multinationals. Various countries/departments, probably includes international employment.

	drop if dup == 4

	keep if keep == 1
	drop dup




	replace year = regexs(1) + regexs(4) if regexm(stichtag, "(19|20)([0-9][0-9])(/)([0-9][0-9])$")
	replace year = "2000"  if stichtag == "1999/00"
	replace year = "1980" if stichtag == "1.7.79-30.6.80"
	replace year = "1990" if stichtag == "31.12.1990."
	replace year = "19" + regexs(5) if regexm(stichtag, "([0-9]+)(\.)([0-9]+)(\.)([789][0-9])")
	replace year = "N.A." if stichtag == "31:03.2"
	replace year = erscheinungsjahr if stichtag == "Beschäftigte" | (mi(stichtag) & !mi(anzahl))

	replace year = "" if year == "N.A." | mi(year)

	destring year, replace

	drop if mi(year)


	gen empl = anzahl
	replace empl = "1" if inlist(notiz, "Die Gesellschaft beschäftigt keine Mitarbeiter", ///
		"Die Gesellschaft hat keine eigenen Mitarbeiter")

	keep if !mi(anzahl)
	replace empl = subinstr(empl, "ca.", "", .)
	replace empl = subinstr(empl, "rd.", "", .)
	replace empl = subinstr(empl, "k.a.", "", .)
	replace empl = subinstr(empl, "-", "",. )
	replace empl = subinstr(empl, " ", "", .)
	replace empl = subinstr(empl, "1)", "", .)
	replace empl = subinstr(empl, "k.a","",.)
	replace empl = subinstr(empl, "n.a","",.)
	replace empl = regexs(1) + regexs(3) if regexm(empl, "(1)(,)([0-9][0-9][0-9])")
	replace empl = regexs(1) + regexs(3) if regexm(empl, "([0-9]+)(und)([0-9]+)")
	replace empl = subinstr(empl, ",",".",.)
	replace empl = "13" if empl == "13/11"
	replace empl = "" if strpos(empl, "e") > 0

	destring empl, replace
	replace empl = round(empl)

	gen obsyear = substr(erschei, 1, 4)
	destring obsyear, replace

	keep if inrange(year,1970, 2018)

	bys unternehmensid: egen firstyear_obs = min(obsyear)
	bys unternehmensid: egen firstyear_meas = min(year)

	keep unternehmens* profilid year empl firstyear_*

	* remove duplicates consistentyl
	duplicates drop
	bys unternehmensname year profilid (empl): keep if _n == _N
	bys unternehmensname year (profilid): keep if _n == 1
	tempfile employment
	save "`employment'"


* --------------- --------------- --------------- ---------------  -------------
*
* Plotting Board Composition by firm size and incorporation date
* --------------- --------------- --------------- ---------------  -------------


* Firm data
*-----------
use "${hoppenstedt}/Hoppenstedt_Unternehmen.dta", clear
duplicates drop

gen year = erscheinungs
replace year = subinstr(year, "-1","",.)
replace year = subinstr(year, "-2","",.)
destring year, replace

bys unternehmensname year (stammdatenunternehmen): keep if _n ==_N // keep firm-year with most info

* Find Zip Codes
gen zip =""
replace zip = regexs(2) if  regexm(stammdatenunternehmen, "(; ([0-9][0-9][0-9][0-9] ))")
replace zip = regexs(2) if  regexm(stammdatenunternehmen, "(; ([0-9][0-9][0-9][0-9][0-9] ))") & zip==""
replace zip = regexs(2) if  regexm(stammdatenunternehmen, "(, ([0-9][0-9][0-9][0-9][0-9] ))") & zip==""
replace zip = regexs(2) if  regexm(stammdatenunternehmen, "(, ([0-9][0-9][0-9][0-9] ))") & zip==""
replace zip = regexs(2) if  regexm(stammdatenunternehmen, "(,  ([0-9][0-9][0-9][0-9] ))") & zip==""
replace zip = regexs(2) if  regexm(stammdatenunternehmen, "(,  ([0-9][0-9][0-9][0-9][0-9] ))") & zip==""
replace zip = regexs(2) if  regexm(stammdatenunternehmen, "(: ([0-9][0-9][0-9][0-9][0-9] ))") & zip==""
replace zip = regexs(2) if  regexm(stammdatenunternehmen, "(: ([0-9][0-9][0-9][0-9][0-9]))") & zip==""
replace zip = regexs(2) if  regexm(stammdatenunternehmen, "(; O-([0-9][0-9][0-9][0-9] ))") & zip==""
replace zip = regexs(2) if  regexm(stammdatenunternehmen, "( ([0-9][0-9][0-9][0-9][0-9] ))") & zip==""
replace zip = subinstr(zip, " ", "",.)

tempfile zipcodes
save "`zipcodes'"

* Board Composition data
*-----------
use "${hoppenstedt}/Hoppenstedt_Aufsichtsrat.dta", clear
duplicates drop

gen year = erscheinungs
replace year = subinstr(year, "-1","",.)
replace year = subinstr(year, "-2","",.)
destring year, replace

* merge back firm data
merge m:1 unternehmensname year using "`zipcodes'", nogen  keep(1 3)

* merge employment data
merge m:1 unternehmensname year using "`employment'", keep(1 3)




* generate unique identifier
gen name = lower(unternehmensname)
replace name = substr(name,1,4)
tostring unternehmensid, replace
gen firmid =  unternehmensid + name
replace unternehmensid = firmid


bysort unternehmensid rangaufsichtsrat year (profilid): keep if _n == 1

duplicates tag unternehmensid year rangaufsichtsrat  , gen(dup)
assert dup==0
drop dup



* get year of incorporation using regular expressions
replace gru = regexs(5) if regexm(grue, "^([0-9]+)(\.)([0-9]+)(\.)([0-9][0-9][0-9][0-9])")
replace gru = regexs(3) if regexm(grue, "^([0-9][0-9][0-9][0-9])(/)([0-9][0-9][0-9][0-9])")
replace gru = regexs(1) + regexs(4) if regexm(grue, "^(19)([0-9][0-9])(/)([0-9][0-9])")
replace gru = regexs(2) if regexm(grue, "(.)([0-9][0-9][0-9][0-9])$")
destring gru, replace

*remove irregular years
drop if gru < 1000 & !mi(gru)
drop if gru > 2018 & !mi(gru)


* replace missing addresses within firms
bysort unternehmensid (stammdatenunternehmen): replace stammdatenunternehmen =  stammdatenunternehmen[_N] if stammdatenunternehmen== ""
drop if  stammdatenunternehmen ==""


* identify and remove foreign companies
*-----------
#delimit;
gen foreign = strpos(unternehmensname, "Aktiebolaget") > 0 | strpos(unternehmensname, "aktiebolaget") > 0 |
strpos(unternehmensname, "N.V") > 0 | strpos(unternehmensname, " nv") > 0
| strpos(unternehmensname, "Limited") > 0 | strpos(unternehmensname, "N. V") > 0
| strpos(unternehmensname, "Inc.") > 0  |  strpos(unternehmensname, "Société Anonyme") > 0
| strpos(unternehmensname, "Ltd.") > 0  |  strpos(unternehmensname, "Nestlé") > 0
| strpos(unternehmensname, "Aktiebolag") > 0  |  strpos(unternehmensname, "Inc.") > 0
| strpos(unternehmensname, "Sociedad Anónima") > 0 | strpos(unternehmensname, "BV") > 0
| strpos(unternehmensname, "S.p.A.") > 0  |  strpos(unternehmensname, "plc") > 0
| strpos(unternehmensname, "Plc") > 0 |  strpos(unternehmensname, "Azioni") > 0
| strpos(unternehmensname, "p.l.c") > 0 |  strpos(unternehmensname, "Società") > 0
| strpos(unternehmensname, "LTD") > 0|  strpos(unternehmensname, "PLC") > 0
| strpos(stammdatenunternehmen, "(Japan)") > 0 |  strpos(stammdatenunternehmen, "Hertogenbosch") > 0
| strpos(stammdatenunternehmen, "Vevey") > 0
| strpos(stammdatenunternehmen, "USA") > 0 | strpos(stammdatenunternehmen, "Luxem") > 0
| strpos(stammdatenunternehmen, "Kanada") > 0 | strpos(stammdatenunternehmen, "Madrid") > 0
| strpos(stammdatenunternehmen, "Spanien") > 0 | strpos(stammdatenunternehmen, "Spanien") > 0
| strpos(stammdatenunternehmen, "England") > 0 | strpos(stammdatenunternehmen, "Belgien") > 0
| strpos(stammdatenunternehmen, "Japan") > 0 | strpos(stammdatenunternehmen, "Niederlande") > 0
| strpos(stammdatenunternehmen, "Italien") > 0| strpos(stammdatenunternehmen, "Danemark") > 0
| strpos(stammdatenunternehmen, "(CH)") > 0 | strpos(stammdatenunternehmen, "(JP)") > 0
| strpos(stammdatenunternehmen, "(NL)") > 0 | strpos(stammdatenunternehmen, "(GB)") > 0
| strpos(stammdatenunternehmen, "(ES)") > 0 | strpos(stammdatenunternehmen, "Bilbao") > 0
| strpos(stammdatenunternehmen, "Madrid") > 0 | strpos(stammdatenunternehmen, "(FI)") > 0
| strpos(stammdatenunternehmen, "(FR)") > 0 | strpos(stammdatenunternehmen, "Schweiz") > 0
| strpos(stammdatenunternehmen, "CH-")  > 0| strpos(stammdatenunternehmen, "DK-")  > 0
| strpos(stammdatenunternehmen, "PT")  > 0 | strpos(stammdatenunternehmen, "Lissabon")  > 0
| strpos(stammdatenunternehmen, "(SE)")  > 0| strpos(stammdatenunternehmen, "(Schweden)") > 0
| strpos(stammdatenunternehmen, "(Sweden)") > 0 | strpos(stammdatenunternehmen, "(Finnland)") > 0
| strpos(stammdatenunternehmen, "(US)") > 0 | strpos(stammdatenunternehmen, "(LU)") > 0
|strpos(stammdatenunternehmen, "(NO)") > 0| strpos(stammdatenunternehmen, "(Norwegen)") > 0
| strpos(stammdatenunternehmen, "(IE)") > 0 | strpos(stammdatenunternehmen, "(IL)") > 0
| strpos(stammdatenunternehmen, "York") > 0| strpos(stammdatenunternehmen, "BE") > 0
| strpos(stammdatenunternehmen, "Wilmington") > 0| strpos(stammdatenunternehmen, "Tokio") > 0
| strpos(stammdatenunternehmen, "London") > 0 | strpos(stammdatenunternehmen, "Paris") > 0
| strpos(stammdatenunternehmen, "Atlanta") > 0 | strpos(stammdatenunternehmen, "Courbevoie") > 0
| strpos(stammdatenunternehmen, "Route") > 0 | strpos(stammdatenunternehmen, "Rue") > 0
| strpos(stammdatenunternehmen, "Chateu") > 0 | strpos(stammdatenunternehmen, "Zug") > 0   ;
#delimit cr

bysort	unternehmensid (foreign): replace foreign= foreign[1]



* identify worker representatives
*-----------

global worker_identifiers arbeitnehm belegschaft mitbestimmung angestellt gewerkschaft betriebsr drittelbet

foreach variable in funktionaufsichtsrat bemerkungaufsichtsrat nameaufsichtsrat ortaufsichtsrat	{
	cap drop rep_`variable'
	gen rep_`variable' = 0
	foreach worker_identifier in $worker_identifiers {
		replace rep_`variable' = 1 if rep_`variable' == 0 & strpos(lower(`variable'), "`worker_identifier'")
	}
	tab `variable' if rep_`variable'==1
}

cap drop workerrep
gen workerrep = 0
foreach variable in funktionaufsichtsrat bemerkungaufsichtsrat nameaufsichtsrat ortaufsichtsrat	{
	replace workerrep = 1 if workerrep == 0 & rep_`variable'==1
}

sum workerrep

gen none=1 if funktionaufsichtsrat==""


* Create worker share variables
*-----------
bysort unternehmensid year: gen total=_N // number of board members  in a given firm x year

* measurement error, e.g., https://digi.bib.uni-mannheim.de/aktienf%C3%BChrer/data/view.php?ID=2010.2.0804
gen error=0
replace error = 1 if strpos(nameaufsichtsrat,")")

bysort unternehmensid year: egen sum_error= total(error)

replace total = total - sum_error
bysort unternehmensid year: egen sum_workerrep=total(workerrep) // number of  worker representatives in a given firm x year
bysort unternehmensid year: egen sum_none=total(none)

gen worker_share = sum_workerrep / total
gen none_share = sum_none / total




* Firm-Year level data
*-----------
duplicates tag unternehmensid year rangaufsichtsrat  , gen(dup)
assert dup==0
drop dup
bys unternehmensid year (rangaufsichtsrat)  : keep if _n == 1


duplicates tag unternehmensid  year  , gen(dup)
assert dup==0
drop dup

* Sample restrictions
*-----------
bys unternehmensid: egen dateinc = max(gru)
* Only keep observations post incorporation
gen rel=  year - dateinc
keep if rel >= 0
** year restrictions
bys unternehmensid: egen firstyear = min(year)
keep if inrange(dateinc, 1989, 1999) & firstyear <= 1999
** drop foreign firms
keep if foreign == 0

* drop missing zipcodes and 4-digit zipcodes
drop if zip == ""
gen ziplen = strlen(zip)
count if ziplen ==4
drop if ziplen ==4 // can't classify based on this zip, was abolished in 1993

**** Dropping firms in East-Germany
* source: https://eurotender.de/pdf/Postleizahlennachlaender.pdf
****
gen west = 1
*Bundeslandern not in West-Germany Berlin, Brandenburg, Mecklenburg-Vorpommern, Saxony, Saxony-Anhalt, and Thuringia.
*Berlin
replace west = 0 if zip<= "14330" & zip>="10001"

*Brandenburg
replace west = 0 if zip<= "01998" & zip>="01941"
replace west = 0 if zip<= "03253" & zip>="03001"
replace west = 0 if zip<= "04938" & zip>="04891"
replace west = 0 if zip<= "14715" & zip>="14401"
replace west = 0 if zip<= "16949" & zip>="14723"
replace west = 0 if zip<= "17258" & zip>="17258"
replace west = 0 if zip<= "17291" & zip>="17261"
replace west = 0 if zip<= "17309" & zip>="17309"
replace west = 0 if zip<= "17321" & zip>="17321"
replace west = 0 if zip<= "17326" & zip>="17326"
replace west = 0 if zip<= "17335" & zip>="17335"
replace west = 0 if zip<= "17337" & zip>="17337"
replace west = 0 if zip<= "19357" & zip>="19307"

* Mecklenburg-Vorpommern
replace west = 0 if zip<= "17256" & zip>="17001"
replace west = 0 if zip<= "17259" & zip>="17258"
replace west = 0 if zip<= "17309" & zip>="17301"
replace west = 0 if zip<= "17321" & zip>="17309"
replace west = 0 if zip<= "17322" & zip>="17321"
replace west = 0 if zip<= "17331" & zip>="17328"
replace west = 0 if zip<= "17335" & zip>="17335"
replace west = 0 if zip<= "19260" & zip>="17337"
replace west = 0 if zip<= "19273" & zip>="19273"
replace west = 0 if zip<= "19306" & zip>="19273"
replace west = 0 if zip<= "19417" & zip>="19357"
replace west = 0 if zip<= "23999" & zip>="23921"

*Saxony
replace west = 0 if zip<= "01936" & zip>="01001"
replace west = 0 if zip<= "02999" & zip>="02601"
replace west = 0 if zip<= "04579" & zip>="04001"
replace west = 0 if zip<= "04889" & zip>="04641"
replace west = 0 if zip<= "07919" & zip>="07919"
replace west = 0 if zip<= "07951" & zip>="07951"
replace west = 0 if zip<= "07952" & zip>="07952"
replace west = 0 if zip<= "07982" & zip>="07982"
replace west = 0 if zip<= "07985" & zip>="07985"
replace west = 0 if zip<= "09669" & zip>="08001"

*Saxony-Anhalt
replace west = 0 if zip<= "06548" & zip>="06001"
replace west = 0 if zip<= "06928" & zip>="06601"
replace west = 0 if zip<= "14715" & zip>="14715"
replace west = 0 if zip<= "38489" & zip>="38481"
replace west = 0 if zip<= "39649" & zip>="38801"

*Thuringia
replace west = 0 if zip<= "04639" & zip>="04581"
replace west = 0 if zip<= "06578" & zip>="06551"
replace west = 0 if zip<= "07919" & zip>="07301"
replace west = 0 if zip<= "07950" & zip>="07920"
replace west = 0 if zip<= "07952" & zip>="07952"
replace west = 0 if zip<= "07980" & zip>="07953"
replace west = 0 if zip<= "07985" & zip>="07985"
replace west = 0 if zip<= "07989" & zip>="07985"
replace west = 0 if zip<= "96529" & zip>="96501"
replace west = 0 if zip<= "99998" & zip>="98501"

** only keep west germany
tab west
keep if west ==1

*** Categories size x age
global regressors  old_small new_small old_big new_big

gen big = empl > 500
replace big = . if mi(empl)
keep if big!=.

keep if dateinc !=1994
gen post = dateinc > 1994
gen pre = dateinc < 1994

gen old_big = pre==1&big==1
gen old_small = pre==1&big==0
gen new_big = post==1&big==1
gen new_small = post==1&big==0

* avoid firmxyears with no information on worker reps
gen cond_worker_share_percent = worker_share*100 if  none_share < 2/3
count if none_share >=2/3

* estimate regression to obtain robust confidence intervals
reg cond_worker_share_percent ${regressors} , noconst cluster(unternehmensid)

gen n_count = .
gen beta = .
gen ci_low = .
gen ci_high = .

local count_local = 1
foreach variable in $regressors {
	replace n_count = `count_local' if _n==`count_local'
	replace beta = _b[`variable'] if _n==`count_local'
	replace ci_low = _b[`variable'] - invnorm(0.975)*_se[`variable'] if _n==`count_local'
	replace ci_high = _b[`variable'] + invnorm(0.975)*_se[`variable'] if _n==`count_local'
	local ++ count_local
}

replace n_count = n_count+1 if n_count>=3
replace n_count = 3 if n_count == 2
replace n_count = 2 if n_count == 3
replace n_count = 3 if n_count == 4
replace n_count = 4 if n_count == 2
replace n_count = 2 if n_count == 3

* Graph

preserve

local fontsize 4.6
local move = 0
replace n_count = n_count-`move'
graph twoway 	///
	(bar beta n_count if n_count==1-`move', color(navy%90)) 	(rcap ci_low ci_high n_count  if n_count==1-`move', lcolor(navy)) ///
	(bar beta n_count if n_count==2-`move', color(navy%30)) 	(rcap ci_low ci_high n_count  if n_count==2-`move', lcolor(navy)) ///
	(bar beta n_count if n_count==4-`move', color(maroon%90)) 	(rcap ci_low ci_high n_count  if n_count==4-`move', lcolor(maroon)) ///
	(bar beta n_count if n_count==5-`move', color(maroon%30)) 	(rcap ci_low ci_high n_count  if n_count==5-`move', lcolor(maroon)) ///
	, ///
	graphregion(color(white)) xtitle("") ///
	ytitle("Worker Share on Board",  size(`fontsize')) ///
	legend(cols(2) order(1 "" 5 " {&le} 500 Employees" 3 "" 7 " >500 Employees") position(1) ring(0) size(`fontsize') keygap(0) colgap(1)) ///
	xlabel(1.5 "Incorporation before 1994"  4.5 "Incorporation after 1994", labsize(`fontsize')) ///
	ylabel( 0(10)55, labsize(`fontsize')) ///
	yline(33.33, lpattern(dash) lcolor(gray)) ///
	xline(2.9, lpattern(shortdash) lcolor(gs6)) ///
	xtitle(" ", size(medlarge) height(0))


graph display ,	xsize(15) ysize(9)

graph export "${figures}/misc/fig2b.pdf", replace
restore

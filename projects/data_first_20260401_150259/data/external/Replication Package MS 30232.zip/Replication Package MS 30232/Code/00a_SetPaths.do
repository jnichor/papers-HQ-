/*******************************************************************************


	DESCRIPTION: Installs required Stata packages + sets directory structure


*******************************************************************************/




********************************************************************************
***** Preliminaries
********************************************************************************


********************************************************************************
* Installing Packages
********************************************************************************
scalar install_packages = 0
if scalar(install_packages) == 1 {

	*set directory ado for externals
	if c(username) == "rlivas" {
		sysdir set PERSONAL "C:/Users/rlivas/ado/"
		sysdir set PLUS "C:/Users/rlivas/ado/plus/"
	}
	else {
		sysdir set PLUS "Q:/MarginalJobs/SYoung_Projects/ado/plus/"
		sysdir set PERSONAL "${home}/NonCompetes/Programs/ado/"

	}


	***** Following instructions for development version of REGHDFE
		* Instructions located here: http://scorreia.com/software/reghdfe/install.html

	* Install ftools (remove program if it existed previously)
	cap ado uninstall moresyntax
	cap ado uninstall ftools
	net install ftools, from("https://raw.githubusercontent.com/sergiocorreia/ftools/master/src/")

	* Install reghdfe 5.x
	cap ado uninstall reghdfe
	net install reghdfe, from("https://raw.githubusercontent.com/sergiocorreia/reghdfe/master/src/")


	* Install boottest for Stata 11 and 12
	if (c(version)<13) cap ado uninstall boottest
	if (c(version)<13) ssc install boottest

	* Install moremata (sometimes used by ftools but not needed for reghdfe)
	cap ssc install moremata

	ftools, compile
	reghdfe, compile


	***** Installing gtools
	ssc install gtools, replace all
	gtools, upgrade


	***** Installing other required packages
	ssc install tuples, replace
	ssc install estout, replace
	ssc install winsor2, replace
	ssc install carryforward, replace
	ssc install ivreg2, replace

	net install ivreghdfe, from(https://raw.githubusercontent.com/sergiocorreia/ivreghdfe/master/src/)
	ssc install ranktest, replace

	** installing scheme
	ssc install blindschemes, replace

}


********************************************************************************
* File directories -- home defined in the Master Do File
********************************************************************************
* Location of the raw data
global data = "Q:/MarginalJobs/UIFirms/data"
global qualifakation = "Q:/MarginalJobs/UIFirms/BargParam/data/qualifikation"
global utilities = "Q:/MarginalJobs/UIFirms/utilities"
global ams "D:/Austria_ASM/AMS2010"
global eurob_data "Q:/MarginalJobs/UIFirms/BargParam/data"


* Location of user provided data
global userData = "${home}/UserData"

* Temporary datasets generated from the ASSD in this script
global temp = "${home}/temp/"

* Location of the results data from which figures/tables are generated
global resDat = "${home}/final/resultsData"

* Location where you want the figures
global figures = "${home}/final/figures"

* Location where you want the tables
global tables = "${home}/final/tables"

* Location of the .do files called by this script
global dofiles = "${home}/dofiles"

* Location to store the log files
global logs = "${home}/logs"

* Location of the user-provided .ado files
sysdir set PERSONAL "${home}/dofiles/ado"

* Location of the ssc-installed .ado files
if c(username) == "rlivas" {
	sysdir set PERSONAL "C:/Users/rlivas/ado/"
	sysdir set PLUS "C:/Users/rlivas/ado/plus"
	adopath ++ "${home}/dofiles/ado"
}
else {
	sysdir set PLUS "Q:/MarginalJobs/SYoung_Projects/ado/plus/"
}


*******************************************************************************
* Scheme to use for figures
*******************************************************************************

	set scheme wagebarg, permanently

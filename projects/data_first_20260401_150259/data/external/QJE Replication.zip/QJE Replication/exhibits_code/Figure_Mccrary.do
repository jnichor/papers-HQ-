
*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================




* Visualizes McCrary test and Incorporation Selection
* --------------- --------------- --------------- ---------------  -------------


* --------------- --------------- --------------- ---------------  -------------
* Graphical Settings
* --------------- --------------- --------------- ---------------  -------------

clear all
graph set window fontface "Verdana"
set scheme plotplainblind
local fontsize 4.2
local msize 2




* --------------- --------------- --------------- ---------------  -------------
* Incorporation Selection
* --------------- --------------- --------------- ---------------  -------------
use "${iab}/208/proportion_stockselection.dta", clear


graph twoway  ///
(scatter  AG month_rel if prereformcohort==1, msymbol(O) mcolor(navy) msize(`msize')) ///
(scatter  AG month_rel if prereformcohort==0, msymbol(Oh) mcolor(maroon) msize(`msize')), ///
xline(0, lcolor(gs6) lpattern(dash)) ///
ytitle("Proportion Stock Corporations (ppt)", size(`fontsize')) ///
xtitle("Incorporation Date Relative To August 10, 1994 (Months)", size(`fontsize')) ///
legend(off) xlab(-24(12)24, labsize(`fontsize'))   ylab(0(1)5, labsize(`fontsize'))

graph export "${figures}/fig3b.pdf", replace


* --------------- --------------- --------------- ---------------  -------------
* McCrary
* --------------- --------------- --------------- ---------------  -------------


use "${iab}/208/McCrary_test.dta" , clear

sum theta
global note_theta :  di %5.3f `r(mean)'
sum theta_se
global note_se :   di %5.3f `r(mean)'


gen hi = fhat + 1.96*se_fhat
gen lo = fhat - 1.96*se_fhat

graph  twoway ///
(scatter Yj Xj if Xj < 0 & Yj != 0 , msymbol(O)  msize(`msize') mcolor(navy))           ///
(scatter Yj Xj if Xj > 0 & Yj != 0   & Xj<=24, msymbol(Oh) mcolor(maroon)  msize(`msize'))           ///
(line fhat r0 if r0 <= 0, lcolor(navy) lwidth(medthick) lpattern(solid solid))   ///
(line fhat r0 if r0 >= 0  & r0<=24  , lcolor(maroon) lwidth(medthick) lpattern(dash))   ///
(line hi lo r0 if r0 <= 0 , lcolor(navy navy) lwidth(vthin vthin) lpattern(solid solid))              ///
(line hi lo r0 if r0 >= 0 & r0<=24, lcolor(maroon maroon) lwidth(vthin vthin) lpattern(dash)),              ///
xline(0,lp(dash) lc(gs6)) ///
xtitle("Incorporation Date Relative To August 10, 1994 (Months)", size(`fontsize')) ///
ytitle("Number of Stock Corporations", size(`fontsize')) ///
xlab(-24(12)24, labsize(`fontsize')) ///
ylab(0(2)12, labsize(`fontsize')) ///
ttext(0.1 12.5 "Disc. Estimate: ${note_theta} (SE ${note_se})", size(3.7)) ///
legend(off)

graph export "${figures}/fig3a.pdf", replace

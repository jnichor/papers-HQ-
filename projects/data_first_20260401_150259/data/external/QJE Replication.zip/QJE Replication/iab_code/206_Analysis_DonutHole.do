*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/206/$today"
local output $log/206/$today

log using "`output'/206_analysis_donuthole.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*		206 Analysis Donut Hole
*
********************************************************************************

set more off
timer clear
set matsize 10000



foreach w in $winsor_values {

	use "$data\iab_wage_analysis_winsor`w'.dta" if abs(d_rel) <= ${bw_extensive} & (AG==1 | GmbH==1), clear

	* Donut hole indicator
	qui forval i = 0/$donutholes {

		* radius of dount hole
		global dh_`i' = 365*(`i'/($donutholes/2))

		* generate donut hole sample indicator, that keeps bandwidth in days fixed
		gen id_DH_`i' = inrange(d_rel,-${bw_standard}-${dh_`i'},-${dh_`i'})|inrange(d_rel,${dh_`i'},${bw_standard}+${dh_`i'})

	}

	qui replace id_DH_0 = 1 if d_rel == 0

	foreach control in 2 3 {
		qui foreach outcome in $outcomes {


			* drop sample in increments of 1 month around Aug 10 1994

			forval i = 0/$donutholes {


				* radius of donut hole
				global d`outcome'`i' = ${dh_`i'}

				*--------------------------------------
				*--- DiD Spec
				*--------------------------------------

				* regression
				noi reghdfe `outcome' i.AG##i.prereformcohort if id_DH_`i', ///
					absorb(${controls`control'}) vce(cluster cluster_variable)

				* DiD coefficient and SE
				global c`outcome'`i' = _b[1.AG#1.prereformcohort]
				global s`outcome'`i' = _se[1.AG#1.prereformcohort]

				* Control group mean at the discontinuity,
				gstats su `outcome' if d_rel >= 0 & AG == 0 & id_DH_`i'==1  & e(sample)
				global cmag0`outcome'`i' = `r(mean)'

				gstats su `outcome' if d_rel >= 0 &  AG == 1 & id_DH_`i'==1  & e(sample)
				global cmag1`outcome'`i' = `r(mean)'



				*--------------------------------------
				*--- Simple Difference Spec
				*--------------------------------------

				* regression with only Year FE (spec 2, 3)
				noi reghdfe `outcome' i.prereformcohort if id_DH_`i'==1 & AG==1, ///
					absorb(${controls`control'}) vce(cluster cluster_variable)

				* coefficient and SE
				global c_d`outcome'`i' = _b[1.prereformcohort]
				global s_d`outcome'`i' = _se[1.prereformcohort]

				* Control group mean at the discontinuity,
				gstats su `outcome' if d_rel >= 0 & e(sample)==1
				global cmag0_d`outcome'`i' = `r(mean)'

				gstats su `outcome' if d_rel >= 0 & e(sample)==1
				global cmag1_d`outcome'`i' = `r(mean)'


				*--------------------------------------
				*--- RD Spec
				*--------------------------------------

				cap drop prereformcohort_d_rel
				gen prereformcohort_d_rel = (prereformcohort==1)*d_rel

				* regression with only Year FE (spec 2)
				noi reghdfe `outcome' i.prereformcohort d_rel prereformcohort_d_rel ///
				if id_DH_`i' & AG , ///
				absorb(${controls`control'}) vce(cluster cluster_variable)

				* coefficient and SE
				global c_rd`outcome'`i' = _b[1.prereformcohort]
				global s_rd`outcome'`i' = _se[1.prereformcohort]


			} // Fractions of donut hole


		} // Outcome

		preserve
		* save DiD and simple difference coefficients
		foreach outcome in $outcomes {

			clear

			set obs 100
			* donuthole starts at 0
			gen value = _n -1
			foreach var in c s d cmag0 cmag1 c_d s_d cmag0_d cmag1_d control control_d c_rd s_rd {
				gen `var' = .
			}
			forval i = 0/$donutholes {
				foreach x in c s d cmag0 cmag1 c_d s_d cmag0_d cmag1_d c_rd s_rd {
				noi cap	replace `x' = ${`x'`outcome'`i'} if value == `i'
				}
			}

			gen ub = c + (1.96*s)
			gen lb = c - (1.96*s)

			gen ub_d = c_d + (1.96*s_d)
			gen lb_d = c_d - (1.96*s_d)

			gen ub_rd = c_rd + (1.96*s_rd)
			gen lb_rd = c_rd - (1.96*s_rd)

			replace d = 12*(d/365)


			replace control = `control'
			replace control_d = `control'

			save "`output'/DonutHole_`outcome'_Winsor`w'_BW$`bw_standard'_spec`control'.dta", replace

		} // Outcome
		restore
	} // Control

} // Winsor value

log close

/*******************************************************************************

	DESCRIPTION: Table 4 DiD Heterogeneity by transition type

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
cap file close fh
local curr_date = c(current_date)
log using "${logs}/Table_Transition`curr_date'", replace

********************************************************************************
* estimate transition rates
********************************************************************************
scalar rates = 1
if scalar(rates) == 1 {
foreach yrFwd in $earnF {
			local grprestriction inlist(reform, 1976, 1985, 1989, 2001) & inlist(yr_l5,.,0) & inlist(yr_l4,.,0)
			use "${temp}/07a_Heterogeneity_yrFwd`yrFwd'.dta" if `grprestriction', clear
			drop  *_l4_f`yrFwd' *_l5_f`yrFwd' yr_l4 yr_l5


keep if mth_emp == 12

	foreach reform in 1976 1989 {
		su earn_pct if treatment_`reform' == 1
		local min = r(min)
		su earn_pct if control_`reform' == 1
		local max = r(max)
		local new_min = `min' + 1
		local new_max = `max' - 1
		drop if reform == `reform' & earn_pct <= `new_min' & !mi(earn_pct)
		drop if reform == `reform' & earn_pct >= `new_max' & !mi(earn_pct)
	}




	flevelsof switch_anal2_grp, local(levels)
	foreach l in `levels' {
		qui gstats sum earn_Diff_f`yrFwd' if switch_anal2_grp == `l' &  yr_l0 == 1
		global grp`l'_avg_f`yrFwd': di %4.3f `r(mean)'

		qui count if switch_anal2_grp == `l' & yr_l0 == 1
		local n = `r(N)'

		qui count if !mi(stayer_f1) & yr_l0 == 1
		local m = `r(N)'

		global grp`l'_rate_f`yrFwd': di %4.3f `n'/`m'

	}

	* base-year transition rate for all movers; this replaces EE above
	qui gstats sum earn_Diff_f`yrFwd' if mover_f`yrFwd' == 1 &  yr_l0 == 1
	global grp3_avg_f`yrFwd': di %4.3f `r(mean)'

	qui count if mover_f`yrFwd' == 1 & yr_l0 == 1
	local n = `r(N)'

	qui count if !mi(stayer_f1) & yr_l0 == 1
	local m = `r(N)'

	global grp3_rate_f`yrFwd': di %4.3f `n'/`m'

	* base-year transition for EE and EUE
	foreach type in EE EUE {
		qui gstats sum earn_Diff_f`yrFwd' if `type'_f`yrFwd' == 1 & mover_f`yrFwd' == 1 & yr_l0 == 1
		global `type'_avg_spec2_f`yrFwd': di %4.3f `r(mean)'
		global `type'_avg_spec3_f`yrFwd' ${`type'_avg_spec2_f`yrFwd'}

		qui count if `type'_f`yrFwd' == 1 & mover_f`yrFwd' == 1 & yr_l0 == 1
		local n = `r(N)'

		qui count if !mi(stayer_f1) & yr_l0 == 1
		local m = `r(N)'

		global `type'_rate_f`yrFwd': di %4.3f `n'/`m'

	}




} // years forward

}
********************************************************************************
* get estimates
********************************************************************************

local type "_stable"
local pooledtype _stable
local with "With76"
local with2 `with'
local controlname4 ctrls
local ysc2 ylabel(-0.2(0.2)0.4)

	use "${resDat}/Heterogeneity_earn_Diff_f1_earn_pct_`with'`type'_Spec`controlname4'switch_anal1_grp.dta", clear
	append using "${resDat}/Heterogeneity_earn_Diff_f2_earn_pct_`with'`type'_Spec`controlname4'switch_anal1_grp.dta", gen(yrFwd2)

	local suffix RRcoeff RRSE intcoeff intSE R N F avg RRUB RRLB intUB intLB
	local long
	foreach suff in `suffix' {
		local long `long' ctrls_@`suff'
	}

gen id = _n
reshape long `long'  , i(id) j(heteroGrp, string)
drop id




append using "${resDat}/DiD_1_earn_pct_earn_Diff_f1_`with2'`pooledtype'_Spec`controlname4'.dta", gen(pooled)
append using "${resDat}/DiD_1_earn_pct_earn_Diff_f2_`with2'`pooledtype'_Spec`controlname4'.dta", gen(pooled2)

replace yrFwd2 = 0 if pooled == 1
	replace yrFwd2 = 1 if pooled2 == 1
	replace pooled = 1 if pooled2 == 1
	keep if mi(year) | year == 0

destring heteroGrp, replace ignore(lev)



	foreach x in coeff SE {
		qui su ctrls_`x' if heteroGrp == . & yrFwd2 == 0
		local pooled_`x'_f1: di %5.3f `r(mean)'

		qui su ctrls_`x' if heteroGrp == . & yrFwd2 == 1
		local pooled_`x'_f2: di %5.3f `r(mean)'


	forval i = 1/3 {
		qui su ctrls_int`x' if heteroGrp == `i' & yrFwd2 == 0
		local grp`i'_`x'_f1: di %5.3f `r(mean)'

		qui su ctrls_int`x' if heteroGrp == `i' & yrFwd2 == 1
		local grp`i'_`x'_f2: di %5.3f `r(mean)'
	}
	}

		qui su ctrls_avg if heteroGrp == . & yrFwd2 == 0
		local pooled_avg_f1: di %5.3f `r(mean)'

		qui su ctrls_avg if heteroGrp == . & yrFwd2 == 1
		local pooled_avg_f2: di %5.3f `r(mean)'


*********************
* EE and EUE sample (correspending to hetgroup 3 and 5 respectively)
*********************

local types 3 5
local lab3 EE
local lab5 EUE



foreach spec in /*firmHet_ctrlsHet*/ firmyrHet_ctrlsHet {
	foreach fwd in 1 2 {
		use "${resDat}/Heterogeneity_earn_Diff_f`fwd'_earn_pct_`with'_stable_Spec`spec'switch_anal2_grp.dta", clear
		if "`spec'" == "firmHet_ctrlsHet" {
		rename `spec'* fH_cH*
		save "${resDat}/Heterogeneity_earn_Diff_f`fwd'_earn_pct_`with'_stable_SpecfH_cHswitch_anal2_grp.dta", replace
	}
		if "`spec'" == "firmyrHet_ctrlsHet" {
			rename `spec'* fyH_cH*
			save "${resDat}/Heterogeneity_earn_Diff_f`fwd'_earn_pct_`with'_stable_SpecfyH_cHswitch_anal2_grp.dta", replace

		}
}
}

local suffix RRcoeff RRSE intcoeff intSE R N F avg RRUB RRLB intUB intLB
local specs   ctrls  indOcc_hetInt firmyr fyH_cH
local stats intcoeff intSE avg

foreach spec in `specs'{
	use "${resDat}/Heterogeneity_earn_Diff_f1_earn_pct_`with'_stable_Spec`spec'switch_anal2_grp.dta", clear
	append using "${resDat}/Heterogeneity_earn_Diff_f2_earn_pct_`with'_stable_Spec`spec'switch_anal2_grp.dta", gen(yrFwd2)
	gen yrFwd= yrFwd2+1

	local long
	foreach suff in `suffix' {
		local long `long' `spec'_@`suff'
	}

	di "`spec'"
	gen id = _n
	reshape long `long'  , i(id) j(heteroGrp, string)
	drop id
	destring heteroGrp, replace ignore(lev)

	foreach stat in `stats' {

		foreach yrfwd in 1 2 {

			foreach type in `types' {

				sum `spec'_`stat' if (yrFwd==`yrfwd' ) & (heteroGrp==`type') & (year==0)
				di "`lab`type''_`stat'_`spec'_f`yrfwd' "
				local `lab`type''_`stat'_`spec'_f`yrfwd' : di %5.3f `r(mean)'


		} //types
} // yrfwd
} // stat
} // spec




********************************************************************************
* create table in tex
********************************************************************************

cap file close fh
file open fh using "${tables}/Tab4_Transition.tex", write replace


local line1 "Est. Wage Effect "
local line2 " "
local extra1 "Base-Year Average "
local extra2 "Base-Year Transition Rate "
local ctrl1 "Mincer + Ind.-Occ. FEs "

local lab_EUE "Panel B: Employment-Unemployment-Employment Movers"
local lab_EE "Panel C: Direct Employment-to-Employment Movers"



foreach g in 0 1 2 3 {
foreach y in 1 2 {

		if `g' == 0 {
			local line1 "`line1' & `pooled_coeff_f`y''"
			local line2 "`line2' & (`pooled_SE_f`y'') "
			local extra1 "`extra1' & `pooled_avg_f`y'' "
		}

		else {
			local line1 "`line1' & `grp`g'_coeff_f`y'' "
			local line2 "`line2' & (`grp`g'_SE_f`y'') "
			local extra1 "`extra1' & `grp`g'_avg_f`y'' "

		}

		local ctrl1 "`ctrl1' & X "
		local extra2 "`extra2' &  ${grp`g'_rate_f`y'}  "
	}
}


file write fh "\begin{tabular}{l c c c c c c c c}" _n ///
"\hline \hline" _n ///
" & & & & & & & & \\" _n ///
 " & \multicolumn{8}{c}{\textbf{Panel A: Effects by Transition Type}} \\" _n "\hline \hline" _n ///
" & \multicolumn{2}{c}{Full Sample} & \multicolumn{2}{c}{Job Stayers} & \multicolumn{2}{c}{Recalled Workers} & \multicolumn{2}{c}{Job Movers} \\" _n ///
" \cmidrule(lr){2-3}   \cmidrule(lr){4-5} \cmidrule(lr){6-7}  \cmidrule(lr){8-9} Time Horizon & 1-Year  & 2-Year & 1-Year & 2-Year & 1-Year & 2-Year & 1-Year & 2-Year \\" _n "\hline" _n ///
	"  \cmidrule(lr){2-5}  \cmidrule(lr){6-9}  & (1) & (2) & (3) & (4) & (5) & (6) & (7) & (8) \\" ///
" & & & & & & & & \\" _n "`line1' \\" _n ///
"`line2' \\" _n ///
" & & & & & & & & \\" _n "\hline" _n ///
/*"`extra1' \\" _n*/ "`extra2' \\" _n ///
"\hline" _n ///
" `ctrl1' \\"  _n ///




foreach type in EUE EE {
	local line1 "Est. Wage Effect "
	local line2 " "

	local extra1 "Base-Year Average "
	local extra2 "Base-Year Transition Rate"

	local ctrl0 " Mincer + Ind.-Occ. FEs "
	//local ctrl1 " Transition-Specific Param. Earn. "
	local ctrl2 " Firm-Year FEs "
	local ctrl3 " Transition-Specific Controls "

	foreach y in  1 2  {
		foreach spec in `specs'  {
			local line1 "`line1' & ``type'_intcoeff_`spec'_f`y'' "
			local line2 "`line2' & (``type'_intSE_`spec'_f`y'') "
			local ctrl0 "`ctrl0' & X"
			//local ctrl1 "`ctrl1' & X"
			local extra2 "`extra2' &  ${`type'_rate_f`y'}"
			local extra1 "`extra1' & ``type'_avg_spec`spec'_f`y'' "

			* firm-year fes
			if inlist("`spec'", "firmyr", "fyH_cH" ) {
				local ctrl2 "`ctrl2' & X"
			}
			if !inlist("`spec'", "firmyr", "fyH_cH" ) {
				local ctrl2 "`ctrl2' & "
			}

			* interactions
			if inlist("`spec'", "indOcc_hetInt", "fyH_cH" ) {
				local ctrl3 "`ctrl3' & X"
			}
			if !inlist("`spec'", "indOcc_hetInt", "fyH_cH" ) {
				local ctrl3 "`ctrl3' & "
			}
		}
	}

	file write fh "\hline \hline" _n " & & & & & & & & \\" _n " & \multicolumn{8}{c}{\textbf{`lab_`type''}} \\" _n "\hline \hline" _n ///
	"  & \multicolumn{4}{c}{1-Year Earnings Effects} & \multicolumn{4}{c}{2-Year Earnings Effects} \\" _n ///
	"  \cmidrule(lr){2-5}  \cmidrule(lr){6-9}  & (1) & (2) & (3) & (4) & (5) & (6) & (7) & (8) \\" _n " & & & & & & & & \\" _n
	forval i = 1/2 {
		file write fh " `line`i'' \\" _n
	}
	file write fh " & & & & & & & & \\" _n " \hline" _n
	foreach i in 2 {
		file write fh "`extra`i'' \\" _n
	}
	file write fh "\hline" _n
	foreach i in 0 2 3 {
		file write fh " `ctrl`i'' \\" _n
	}
} // panels B and C

file write fh "\hline \hline" _n "\end{tabular}"
file close fh

log close

/*******************************************************************************

	DESCRIPTION: Figure A.14 Actual Benefit Receipts vs Predicted
		Receipts from Measured Pre-Separatiopn Average Earnings
		among a Sample of Separators



*******************************************************************************/

clear all
set more off

cap log close
local curr_date = c(current_date)
log using "${logs}/FigA14_UI_rule_validation`curr_date'", replace

****************************************************************************
* Crosswalk between svnr and penr
****************************************************************************

** back to Damian's dta files
	use svnr penr year using ///
	"Q:/MarginalJobs/UIFirms/BargParam/temp/SY/UIBValidation/01_bargParam_Panel_all_fullSample.dta" ///
	if penr != ., clear
	save $temp/crosswalk_svnr_penr.dta, replace

****************************************************************************
* Load AMS Databases
****************************************************************************

	use ${ams}/AMS2010/ams_leistungen.dta, clear

	**** Converting start and end of spell dates to stata dates
	* Format dates
	format lstg_vdat %td
	format lstg_bdat %td
	gen start_month = month(lstg_vdat)
	gen year = year(lstg_vdat)

	* Keeping spells with lstg_art == ALG
	keep if lstg_art == 107

	* Dropping missing svnr
	drop if mi(penr)

	* Only keeping one spell per year and individual
		* Makes merging onto the ASSD data easier
		* Can eventually verify all spells
	bysort penr year (start_month): gen obsNum = _n
	keep if obsNum == 1

	* Leap years
	gen leap_year = inlist(year, $leapYears)
	gen day_per_year = cond(leap_year == 1, 366, 365)

	* Monthly UIB payments
	gen adj_UIB = tagsatzleist*$euroToShilling*(day_per_year/12)

	keep penr year start_month adj_UIB

	* merge svnr crosswalk
	merge 1:1 year penr using ${temp}/crosswalk_svnr_penr.dta, nogen keep(3)

	tempfile ams_1
	save `ams_1'

	use ${ams}/AMS1998/ams_1987_1998.dta, clear

	* Format dates
	gen start_month = month(begdat_month)
	gen year = year(begdat)

	**** Sample Restrictions
	* Keeping spells with lstg_art == ALG
	keep if lst_art == 1 // equivalent to == 107 above
	keep if status==1 // keep only unemployed

	* Dropping missing svnr
	drop if mi(svnr)

	* Only keeping one spell per year and individual
		* Makes merging onto the ASSD data easier
		* Can eventually verify all spells
	bysort svnr year (start_month): gen obsNum = _n
	keep if obsNum == 1

	* Leap years
	gen leap_year = inlist(year, $leapYears)
	gen day_per_year = cond(leap_year == 1, 366, 365)

	* Monthly UIB payments
	gen adj_UIB = lst_hoh*(day_per_year/12) //*(CPI_2000/100)
	replace adj_UIB = adj_UIB/30 if year == 1989 // see documentation
	keep svnr year start_month adj_UIB

	append using `ams_1'

	save ${temp}/06_ams_svnr_year.dta, replace

****************************************************************************
* Load Regression Sample
****************************************************************************

	* load 02c file
	use svnr year UIBt1_Wt1_f1 UIBt1_iWt_f1 UIBt_iWt_f1 UIBt_Wt1_f1 adj_earnings mth_UE stayer_f1 ///
		using ${temp}/02c_PooledReforms_yrFwd1.dta, clear

	replace year = year + 1 // want to match prediction at year t to observed value at t+1 in AMS data
	gduplicates drop svnr year, force
	fmerge 1:1 svnr year using ${temp}/06_ams_svnr_year.dta, keep(3) nogen

	xtset svnr year

	* winsorize outcomes
	foreach prediction in UIBt1_Wt1_f1 UIBt1_iWt_f1 UIBt_iWt_f1 UIBt_Wt1_f1 {
		gen f1_`prediction'=F.`prediction'
		winsor2 f1_`prediction', cuts(1 99) replace
		winsor2 `prediction', cuts(1 99) replace
	}

	foreach variable in adj_UIB adj_earnings {
		winsor2 `variable', cuts(1 99) replace
	}

	keep if mth_UE > 0 & mth_UE != . // keep separators

	foreach prediction in UIBt1_Wt1_f1 /*UIBt1_iWt_f1 UIBt_iWt_f1 UIBt_Wt1_f1*/ {

	qui reg adj_UIB `prediction' ///
		if adj_earnings > 5000 & adj_UIB>= 6000 & adj_UIB <= 14000 & `prediction' >= 6000 & `prediction' <= 14000 & f1_`prediction'!=., robust
		global beta : di %5.3f _b[`prediction']
		global se : di %5.3f _se[`prediction']
		global r2 : di %5.3f e(r2_a)

	binscatter adj_UIB `prediction' ///
		if adj_earnings > 5000 & adj_UIB>= 6000 & adj_UIB <= 14000 & `prediction' >= 6000 & `prediction' <= 14000 & f1_`prediction'!=. ///
		, nq(100) lc(dknavy) ytitle("Actual Benefit Level") xtitle("Predicted Benefit Level (Based on Lagged Earnings)") ///
		note("{bf: Note}: {&beta}=$beta (se=${se}), R{sup: 2}=${r2}.")
	graph export "${figures}/FigA14_UI_rule_validation.pdf", replace

	}

log close

/*******************************************************************************

	DESCRIPTION: Create dataset of E-to-N spells to estimate take-up of UIB



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/04c_Diagnostic_Takeup`curr_date'", replace

********************************************************************************
* Takeup
* we disregard non-employment spells that are shorter than `d' days
local d = 1 // 0 14 28 42

	clear
	global days=`d'
	set obs 1
	save  $temp/04c_Takeup_${days}.dta, emptyok replace


	* loop over qualification levels
	noi di "`d' days: Qualification level..."
	set more off
	qui forval q=1/40  {
		global q=`q'
		noi di "...`q'"

		* use qualification files
		use svnr vdat bdat qual benr using ${qualifakation}/qual_${q}.dta, clear
		compress

		* formatting
		order svnr vdat bdat qual
		sort svnr vdat bdat qual

		* for efficiency only use persons with more than one spell (otherwise no E-N-E transition possible)
		by svnr: drop if _N==1

		/* run status file to define labor market status based on qual variable:
		- 1:  dependent employment
		- 2:  self-employment
		- 3:  civil servants                                 as far as observed
		- 4:  minor employment
		+ 5:  old-age part time                              need extra files to get this (Simon Buechi's Altersteilzeit)
		- 6:  military and civil service
		- 7:  maternity insurance
		- 8:  minor self-employment
		* 9:  quasi-employment                               employment to calculate daily earnings, otherwise not employed
		- 10: sick
		* 11: unemployment
		+ 12: retired
		+ 13: retired on disability
		- 14: parental leave
		+ 15: special pension (damaged/injured)
		+ 16: recovery/training benefit for sick/disabled
		- 17: on leave to care for family members
		+ 18: widower pension
		+ 19: receiving social assistance
		* 98: other
		* 99: unknown */
		run $utilities/definestatus.do

		* generate employment (everything that is UI eligible, see - above), other (everything that is not UI eligible, see + above), unemployment (i.e. UIB receipt), and non-employment (residual, i.e. * above + unobserved spells)
		gen byte stat=.
		replace stat=1 if qual == "38"
		replace stat=2 if inlist(status,1,2,3,4,6,7,8,10,14,17)
		replace stat=3 if inlist(status,5,12,13,15,16,18,19)
		replace stat=4 if (stat!=1 & stat!=2 & stat!=3)
		label define statvals 1 "UI" 2 "E" 3 "O" 4 "N"
		label values stat statvals

		* non-employed are the gaps, so we drop N spells without UI and keep only persons who have more than one spell (no E-N transition possible for these people)
		drop if stat==4
		by svnr: drop if _N==1

		* drop intermediate spells (e.g. if one spell is from 2005m1-2006m1, we would drop a spell lasting from 2005m5-2005m6)
		* Note: we drop intermediate spells by person and status because dropping intermediate spells *overall* might be risky for non-employment spells where time in UI < total N duration because we would drop the UIB spell!!
		noi run $utilities/dropintspells.do "svnr stat" vdat bdat

		* connect spells with same status that start within e.g. 28 days
		noi run $utilities/connectspells.do "svnr stat" vdat bdat ${days}

		* try to increase efficiency because onestatusaday.do needs some time.. (again no E-N-E transition if only one spell observed)
		by svnr: drop if _N==1

		* now we need to consider overlapping spells with different status: we prioritize UI > E > O and adjust the spells such that we have one status a day
		noi run $utilities/onestatusaday.do svnr vdat bdat stat "1 2 3"

		* save data
		append using $temp/04c_Takeup_${days}.dta
		compress
		save $temp/04c_Takeup_${days}.dta, replace
	}

	use $temp/04c_Takeup_${days}.dta, clear

	gen month = month(vdat)
	gen year = year(vdat)
	fmerge m:1 svnr year using $temp/01_Panel_all_full_sample.dta, ///
	keepusing(frau refage whitecoll) keep(1 3)
	save $temp/04c_Takeup_${days}_demographics.dta, replace

*==============================================================================
* CYCLE THROUGH DEFINITIONS

global days = 1

	use $temp/04c_Takeup_${days}_demographics.dta, clear

	duplicates drop svnr vdat bdat, force

	* generate employment duration as difference between end and start date for E spells
	gen int Edur = bdat-vdat if stat==2

	* calculate duration between end of employment and begin of UIB receipt (only if directly from E to N, i.e. no O spell in between)
	bysort svnr (vdat bdat): gen int Udur = vdat[_n+1]-bdat - 1 if (stat==2 & stat[_n+1]==1)

	bysort svnr (vdat bdat): gen UI = 1 if stat==2 & stat[_n+1] == 1
	replace UI = 0 if stat == 2 & inlist(stat[_n+1], 2, 3)

	* calculate non-employment duration as time to next employment (or other!!) start
	preserve
	drop if stat==1
	bysort svnr (vdat bdat): gen int Ndur = vdat[_n+1] - bdat - 1 //add one because a spell that starts the next day should have a 0 NE spell
	bysort svnr (vdat bdat): gen int recalled = benr == benr[_n+1]
	compress
	keep svnr vdat bdat Ndur recalled
	save $temp/04c_Takeup_temp.dta, replace
	restore
	fmerge 1:1 svnr vdat bdat using $temp/04c_Takeup_temp.dta, nogen
	erase $temp/04c_Takeup_temp.dta

	* generate E-N-E indicator: only consider E-N-E transitions where first employment is more than 2 years
	* (if not employed for enough time, people are not eligible for UI!) and the N spell is between `d' and
	* 730 days. Note: those that never transition into employment again have missing Ndur and are therefore
	* not considered as E-N-E transitions. In addition, Edur!=. ensures that we only consider E spells.
	gen byte employed_2yrs = (Edur!=. & 730<Edur)
	gen byte NE_less2yrs = (${days}<=Ndur & Ndur<=730)

	* formatting
	sort svnr vdat bdat

	* labels
	label variable status 	"labor market status (employed E, other O, and UI)"
	label variable Udur 	"days between employment and UIB receipt"
	label variable Ndur 	"days in non-employment (time to next employment/other spell)"
	label variable Edur 	"days in continous employment"

	* save data
	compress
	noi save $temp/04c_Takeup_Days${days}.dta, replace

	log close

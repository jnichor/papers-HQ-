*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================


cap log close


log using "$log/114_CBA_Betriebspanel.txt", replace text



********************************************************************************
*
*			114 CBA - Clean and Prepare LIAB/Establishment Survey Data
*
*
********************************************************************************


* 1. Define globals
*-------------------------------------------------------------------------------


	global bp_name iabbp

	global iabbp_min_jahr = 1993
	global iabbp_max_jahr = 2018

	global 	vars1993 	a75 	a56 	a57 	a57proz	 	a06b	a30ges 	a74
	global 	vars1994	bz06 	b13				b40ges 		bz05
	global 	vars1995 	cz06 	c62 	c63 	c63proz		c13 	c39ges 	cz05
	global 	vars1996 	d80 	d49  	d50 	d50proz		d12		d34ges 	d79
	global 	vars1997 	e71 	e57 	e58 	e58proz 	e12		e45ges 	e70		e70g
	global 	vars1998 	f67 	f59 	f60 	f60proz 	f11		f45ges 	f69
	global 	vars1999 	g79 	g50 	g52 	g52proz 	g11		g51		g27ges 	g78
	global 	vars2000 	h79 	h42 	h44 	h44proz		h12		h43		h47ges 	h78
	global 	vars2001 	i82 	i67 	i69 	i07 		i68		i52ges 	i80
	global 	vars2002 	j76 	j30 	j32 	j33 		j06 	j31		j41ges 	j81
	global 	vars2003 	k80 	k72 	k73 	k74 		k09 	k75a 	k23ges 	k83
	global 	vars2004 	l88a 	l64 	l66 	l67 		l09 	l65 	l30ges 	l90
	global 	vars2005 	m85a 	m52 	m54		m08 		m53 			m27ges 	m89
	global 	vars2006 	n84a 	n79 	n81 	n82 		n08 	n80 	n21ges 	n91
	global 	vars2007 	o86a 	o81 	o83 	o09 		o82 			o33ges 	o87
	global 	vars2008 	p86a 	p59 	p61 	p62 		p10 	p60		p30ges 	p89
	global 	vars2009 	q84a 	q39 	q41 	q42 		q07		q40		q47ges 	q86
	global 	vars2010 	r79a 	r50 	r52 	r53 		r10 	r51		r30ges 	r80
	global 	vars2011 	s77a 	s52 	s53 	s54 		s08 	s56a 	s26ges 	s78
	global 	vars2012 	t74a 	t48 	t50 	t51 		t08		t49		t30ges 	t77
	global 	vars2013 	u81a 	u48 	u51a 	u51c 		u08 	u49		u27ges 	u84
	global 	vars2014 	v79a 	v73 	v75a 	v75c 		v08 	v74		v25ges 	v84
	global 	vars2015 	w81 	w61 	w63a 	w63c		w07 	w62		w26ges 	w84
	global 	vars2016 	x78a 	x50 	x52a 	x52c 		x08		x51		x26ges 	x81
	global 	vars2017 	y79 	y52 	y54 	y11 		y53		y30ges 	y81
	global 	vars2018	z84 	z27ges


* 2. Load LIAB admin worker data and merge it with survey data from the Establishment Panel
*-------------------------------------------------------------------------------

	forvalues j = $iabbp_min_jahr/$iabbp_max_jahr {

	*forvalues j = 2000/2000 {
		use idnum  ${vars`j'} bula`j' using "$orig/${bp_name}_`j'.dta" , clear

		gen jahr = `j'

		tempfile `j'iabbp
		save ``j'iabbp'
	}

* 3. Append all waves of merged data and merge time consistent industry codes
*-------------------------------------------------------------------------------

	clear
	forvalues j = $iabbp_min_jahr/$iabbp_max_jahr {

		append using ``j'iabbp'
	}

	duplicates drop idnum jahr, force

* merge time-consistent industry codes

	merge 1:1 idnum jahr using "$orig/iabbp_9318_v1_bhp_7518_m06_wgen_w08_v1.dta", keepusing(w08_3_gen)
	drop _merge
	rename w08_3_gen w08_3

* comprose yearly location (state) variables to one variable

gen bula = .

		foreach j of numlist $iabbp_min_jahr/$iabbp_max_jahr {

			replace bula =  bula`j' if bula == .

			drop bula`j'

			}

drop if bula > 10
drop if bula == 0



* 4. prepare outcome variables from the survey data
*-------------------------------------------------------------------------------

	*
	egen empt_c = rowmin(a30ges b40ges c39ges d34ges e45ges f45ges g27ges h47ges i52ges j41ges k23ges l30ges m27ges n21ges o33ges p30ges q47ges r30ges s26ges t30ges u27ges v25ges w26ges x26ges y30ges z27ges)
	drop a30ges b40ges c39ges d34ges e45ges f45ges g27ges h47ges i52ges j41ges k23ges l30ges m27ges n21ges o33ges p30ges q47ges r30ges s26ges t30ges u27ges v25ges w26ges x26ges y30ges z27ges
	`llde' lab var empt_c "Anz. Beschäftigte insg."
	`llen' lab var empt_c "No. employees, in total"
	lab val empt_c ns


		*
	replace e70 = e70g if e70 >= . & e70g <.
	egen legfo_d = rowmin(a74 bz05 cz05 d79 e70 f69 g78 h78 i80 j81 k83 l90 m89 n91 o87 p89 q86 r80 s78 t77 u84 v84 w84 x81)
	replace legfo_d = -9 if legfo_d == -8
	drop a74 bz05 cz05 d79 e70 f69 g78 h78 i80 j81 k83 l90 m89 n91 o87 p89 q86 r80 s78 t77 u84 v84 w84 e70g x81
	`llde' lab var legfo_d "Rechtsform"
	`llen' lab var legfo_d "Legal form"
	cap lab drop legfo_d
	#delimit ;
	`llde' lab def legfo_d
		  1   "Einzelunternehmen"
		  2   "Personengesellschaft"
		  3   "GmbH/GmbH & Co. Kg"
		  4   "Kapitalgesellschaft"
		  5   "Körpersch. d. öffentl. Rechts"
		  6   "sonst. Rechtsform"
		  -9  "n.s."
		  ;
	`llen' lab def legfo_en
		  1   "individual comp."
		  2   "partnership"
		  3   "GmbH/GmbH & Co. Kg"
		  4   "corporation"
		  5   "corporation of public law"
		  6   "other legal form"
		  -9  "n.s."
		  ;
	# delimit cr
	lab val legfo_d legfo_d
	numlabel legfo_d, add

	*
	egen legf17_d = rowmin(y81 z84)
	drop y81 z84
	`llde' lab var legf17_d "Rechtsform"
	`llen' lab var legf17_d "Legal form"
	cap lab drop legf17_d
	#delimit ;
	`llde' lab def legf17_d
		  1   "Einzelunternehmen"
		  2   "Personengesellschaft"
		  3   "GmbH"
		  4   "Aktiengesellschaft"
		  5   "Mischform"
		  6   "Genossenschaft"
		  7   "Verein"
		  8   "Körpersch. oder Anstalt d. öffentl. Rechts"
		  9   "Stiftung"
		  10  "Sonstige Rechtsform"
		  -9  "n.s."
			  ;
	`llen' lab def legf17_en
		  1   "individual comp."
		  2   "partnership"
		  3   "GmbH"
		  4   "stock corporation"
		  5   "mixed form"
		  6   "cooperative"
		  7   "association"
		  8   "corporation of public law"
		  9   "foundation"
		  10  "other legal form"
		  -9  "n.s."
			  ;
	# delimit cr
	lab val legf17_d legf17_d
	numlabel legf17_d, add



	egen wabstd_c = rowmin(a57proz c63proz d50proz e58proz f60proz g52proz h44proz j33 k74 l67 n82 p62 q42 r53 s54 t51 u51c v75c w63c x52c)
		recode wabstd_c (-8=-9)
		drop a57proz c63proz d50proz e58proz f60proz g52proz h44proz j33 k74 l67 n82 p62 q42 r53 s54 t51 u51c v75c w63c x52c
		lab var wabstd_c "Höhe d. Löhne über Tariflohn (in %)"
		cap lab drop ns
		#delimit ;
		lab def ns
			-9	"n.s."
			;
		# delimit cr
		lab val wabstd_c ns
		numlabel ns, add
		replace wabstd_c = . if wabstd_c==-9


		*
		recode a56 (1=4) (2=3)
		egen wagree_d = rowmin(a56 c62 d49 e57 f59 g50 h42 i67 j30 k72 l64 m52 n79 o81 p59 q39 r50 s52 t48 u48 v73 w61 x50 y52)
		recode wagree_d (-8=-9)
		drop a56 c62 d49 e57 f59 g50 h42 i67 j30 k72 l64 m52 n79 o81 p59 q39 r50 s52 t48 u48 v73 w61 x50 y52
		lab var wagree_d "Geltung Tarifvertrag"
		cap lab drop wagree_d
		#delimit ;
		lab def wagree_d
			-9	"n.s."
			1	"Branchentarif"
			2	"Haus-/Firmentarif"
			3	"kein Tarifvertrag"
			4	"entw. Branchen- o. Haustartif"
			;
		# delimit cr
		lab val wagree_d wagree_d
		numlabel wagree_d, add



		*
		egen wabstd_b = rowmin(a57 c63 d50 e58 f60 g52 h44 i69 j32 k73 l66 m54 n81 o83 p61 q41 r52 s53 t50 u51a v75a w63a x52a y54)
		recode wabstd_b (-8=-9)
		drop a57 c63 d50 e58 f60 g52 h44 i69 j32 k73 l66 m54 n81 o83 p61 q41 r52 s53 t50 u51a v75a w63a x52a y54
		lab var wabstd_b "Löhne/Gehälter über Tarif"
		cap lab drop bidum
		#delimit ;
		lab def bidum
			  1   "ja"
			  2   "nein"
			  -9  "n.s."
			  ;
		# delimit cr
		lab val wabstd_b bidum

		egen wcounc_b = rowmin(a75 bz06 cz06 d80 e71 f67 g79 h79 i82 j76 k80 l88a m85a n84a o86a p86a q84a r79a s77a t74a u81a v79a w81 x78a y79)
		replace wcounc_b = 2 if (wcounc_b == 2 | wcounc_b == 3) & jahr == 2003
		drop a75 bz06 cz06 d80 e71 f67 g79 h79 i82 j76 k80 l88a m85a n84a o86a p86a q84a r79a s77a t74a u81a v79a w81 x78a y79
		lab var wcounc_b "Betriebs-/Personalrat"
		lab val wcounc_b bidum

		foreach X of varlist a06b b13 c13 d12 e12 f11 g11 h12 i07 {
			replace `X' = `X' / 1.95583 if `X' > 0 & `X' <.
		}
		egen bvole_c = rowmin(a06b b13 c13 d12 e12 f11 g11 h12 i07 j06 k09 l09 m08 n08 o09 p10 q07 r10 s08 t08 u08 v08 w07 x08 y11)
		recode bvole_c (-8=-9)
		drop a06b b13 c13 d12 e12 f11 g11 h12 i07 j06 k09 l09 m08 n08 o09 p10 q07 r10 s08 t08 u08 v08 w07 x08 y11
		lab var bvole_c "Geschäftsvolumen (in EUR)"
		lab val bvole_c ns

		egen worientb = rowmin(g51	h43	i68	j31	k75a l65 m53 n80 o82 p60	q40	r51	s56a t49	u49	v74	w62	x51	y53)
		recode worientb (-8=-9)
		drop g51	h43	i68	j31	k75a l65 m53 n80 o82 p60	q40	r51	s56a t49	u49	v74	w62	x51	y53
		lab var worientb "Orientierung am Branchentarifvertrag"
		#delimit ;
		lab def Lworientb
			  1   "ja"
			  2   "nein"
			  -9  "n.s."
			  ;
		#delimit cr
		label val worientb Lworientb


		gen premium_above_CBA = wabstd_c if (wabstd_c!=.)&(wabstd_c!=-9)

		gen ind_level_CBA = wagree_d==1 if (wagree_d!=.)&(wagree_d!=-9)
		gen firm_level_CBA = wagree_d==2 if (wagree_d!=.)&(wagree_d!=-9)
		gen no_CBA = wagree_d==3 if (wagree_d!=.)&(wagree_d!=-9)

		gen CBA_coverage = 1-no_CBA
		gen binding_CBA_coverage =  (1-no_CBA)&(wabstd_b!=1) // CBA coverage (at industry or firm level), and firm does not pay above wages

		gen above_CBA_wages = wabstd_b==1 if (wabstd_b!=.)&(wabstd_b!=-9)
			gen under_CBA_wages = 1 - above_CBA_wages

		gen no_CBA_noorient_CBA = (wagree_d == 3 & worientb == 2) if (wagree_d!=.)&(wagree_d!=-9)&(worientb!=.)&(worientb!=-9)
		gen no_CBA_but_orient_CBA = (wagree_d == 3 & worientb == 1) if (wagree_d!=.)&(wagree_d!=-9)&(worientb!=.)&(worientb!=-9)

		gen works_council =   wcounc_b if (wcounc_b!=.)&(wcounc_b!=-9)
		tab works_council
		replace works_council = 1-(works_council-1)

		gen revenue = bvole_c if (bvole_c!=.)&(bvole_c!=-9)



		save $data/cba_bp.dta, replace



* 5. collapse
*-------------------------------------------------------------------------------


		keep if legfo_d==3|legfo_d==4 // only keep LLCs and stock corporations


		foreach var in empt_c CBA_coverage binding_CBA_coverage works_council {
			winsor2 `var',  cut(1 99) replace by(jahr)
		}

		gcollapse (count) n_bet = idnum (rawsum) n_emp = empt_c  (mean) CBA_coverage binding_CBA_coverage works_council [w=empt_c], by(w08_3)

		compress
		sort w08_3

		rename w08_3 nace_d3

		save "${data}/betriebspanel_industry_heterogeneity.dta", replace


log close

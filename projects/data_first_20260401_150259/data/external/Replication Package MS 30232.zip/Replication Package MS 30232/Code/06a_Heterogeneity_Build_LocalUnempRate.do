/*******************************************************************************

  DESCRIPTION: Calculate local unemployment rates

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/06a_Heterogeneity_Build_LocalUnempRate`curr_date'", replace




********************************************************************************
***** Loading individual status + location data -> carrying forward
	* Here we use gkz_work instead of the residence gkz -> available before 1987
	* It should be available for all employed individuals but some firms are
	* missing it.
********************************************************************************
use svnr year status gkz_work using "$temp/01_Panel_all_full_sample.dta", clear


***** Imputing missing location variables
	* First carrying forward -> location while unemployed is last firm
	* Then carrying backward -> when missing location of last firm
bys svnr (year): carryforward gkz, replace
gen minus_year = -year
bys svnr (minus_year): carryforward gkz, replace


drop if gkz==.


****************************************************************************
* Calculating unemployment rates
****************************************************************************
gen unemployed = status == 1

* denominator: unemployed, sick, employed, self-employed, parental leave, minor employment
gen denominator = inlist(status, 1, 2, 3, 6, 7, 8, 10)

* Average unemployment rate by gkz
keep if denominator == 1
fcollapse unemployed, by(year gkz)
rename unemployed unemp_rate_gkz

compress
save ${temp}/06a_LocalUnempRate.dta, replace

clear
log close

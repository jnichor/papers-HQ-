/*******************************************************************************

	DESCRIPTION: Figure A.15 Quality of Wage Prediction Procedure



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
clear all
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA15_Quality_WagePrediction`curr_date'", replace

********************************************************************************

local with allyrs
local yrFwd 1
local i 1

use ${temp}/04d_`with'_f`yrFwd'.dta, clear

foreach var in A`i'_b A`i'_Rsq sdgrwth {
	qui su `var'
	local `var': di %4.3f `r(mean)'
}

	tw (line P`i'_b pct, yaxis(1)  lcolor(red) lwidth(medthick) lpattern(dash)) ///
	(line P`i'_Rsq pct, yaxis(1)  lcolor(green) lwidth(medthick) lpattern(longdash_dot)) ///
	(line std_wage_grwth`yrFwd' pct, lcolor(navy) yaxis(2) lwidth(medthick) ///
	ytitle("Slope, R{sup:2}", axis(1)) ytitle("Standard Deviation", ///
	axis(2)) xtitle("Earnings Percentile") ///
	yscale(range(0(0.2)1.2) axis(1)) ylabel(0(0.2)1.4, axis(1)) ///
	note("Slope for Total Sample: `A`i'_b'" ///
	"R{sup:2} for Total Sample: `A`i'_Rsq'" ///
	"S.D. of  Total Sample: `sdgrwth'" ) ///
	legend(label(1 "Slope") label(2 "R{sup:2}") label(3 "Standard Deviation") r(1) pos(6)))

	graph export ${figures}/FigA15_Quality_WagePrediction.pdf, replace

log close

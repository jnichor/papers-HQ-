/*******************************************************************************

	DESCRIPTION: Figure A.17 PBD Reform nonparametric



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
clear all
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA17_PBD_NonParametric`curr_date'", replace

********************************************************************************

local treatYr 1988

local color1 sea
local color2 sky

local s1 S
local s2 O

local h1
local h2 h

	**** One and two-year earnings outcomes
	foreach yrfwd in $earnF {

		local letter = word("a b", `yrfwd')

		use "${temp}/05b_NonParametricData_f`yrfwd'.dta", clear

		* Defining reference years and figure information
		if `yrfwd' == 1 {
			local contYr = 1987
			local chngLen "One"
			local treatLeg "'88-'89"
			local contLeg "'87-'88"
}
		else if `yrfwd' == 2 {
			local contYr = 1986
			local chngLen "Two"
			local treatLeg "'88-'90"
			local contLeg "'86-'88"
			drop if age_round == 38
}


		tw (connected earn_Diff_f`yrfwd'`treatYr' age_round, ///
		lcolor(reddish) mcolor(reddish) msymbol(T`h`yrfwd'')) ///
		(connected earn_Diff_f`yrfwd'`contYr' age_round, ///
		lcolor(brown) mcolor(brown) msymbol(D`h`yrfwd'')) ///
		(connected diff age_round, lcolor(`color`yrfwd'') ///
		mcolor(`color`yrfwd'') msymbol(`s`yrfwd''`h`yrfwd'') xline(38.5, lpattern(dash) lcolor(black)) ///
		 ytitle("Wage Growth dw/w (By Group and Diff.)") ///
		 xtitle("Age") yline(0, lcolor(gray%50) lpattern(solid)) ///
		 legend(label(1 "Wage Growth `treatLeg'") ///
		 label(2 "Wage Growth `contLeg'") label(3 "Difference") ///
		 order(2 1 3) cols(1) pos(6) ))

		graph export "${figures}/FigA17`letter'_PBD_NonParametric.pdf", replace


	} // Years forward

log close

/*******************************************************************************

	DESCRIPTION: Figure A.11 Robustness Check: Different Donut Holes



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
clear all
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA11_DonutHole`curr_date'", replace

********************************************************************************

local hole_list 1 5 10 15 20 25

**** Loading results with different holes missing
foreach sample in percentile nominal {
local x = 1
foreach hole in `hole_list' {
		use "${resDat}/DiD_1_earn_pct_earn_Diff_f1_With76_stable_Hole_`sample'_`hole'pt_Specctrls.dta", clear

		gen x = `x'

		gen holeSize = `hole'
		tempfile f`x'
		save `f`x''
		local x = `x' + 1
}

clear
local x = `x' - 1
set obs 1
gen filler = 1
forval b = 1/`x'{
	append using "`f`b''"
}

drop if filler == 1
drop filler

gen predline = .54

label define pctDrop 1 "1 %" 5 "5 %" 10 "10 %" 15 "15 %" 20 "20 %" 25 "25 %"

if "`sample'" == "percentile" {
	local xlab = "Percentiles"
}
else if "`sample'" == "nominal" {
	local xlab = "Earnings Range"
}

twoway (rcap ctrls_UB ctrls_LB x if year == 0, lcolor(gray) lwidth(medthick)) ///
	(scatter ctrls_coeff x if year == 0, msymbol(S) msize(medlarge) mcolor(gray) yline(0, lcolor(gray%80) lpattern(shortdash)) lcolor(gray) ///
	xlab(, labsize(medium) nogrid) ylab(, labsize(medium) nogrid) ///
	legend(off) xtitle("Percentage of `xlab' Dropped") ytitle("Wage-Benefit Sensitivity") ///
	xlabel(1 "1 %" 2 "5 %" 3 "10 %" 4 "15 %" 5 "20 %" 6 "25 %" ))

	graph export "${figures}/FigA11_DonutHole_`sample'.pdf", replace

}

log close

* ado file creating earnings maxima by year
* source: Austrian laws on Höchstbeitragsgrundlage
* The laws prescribe a monthly maximum, since Austrian wages are paid out in
* 14 rather than 12 installments, we need to scale up the monthly maximum
* by 14/12 to arrive at monthly maxima corresponding to monthly 
* earnings measures of yearly_earnings/12.
* Before 1965, wages were paid out in 13 installments, so the maxima are scaled
* by 13/12 for 1957 through 1964.
* After 2001, values were only given in Euro (1 EUR = 13.7603 ATS). To convert 
* back to nominal ATS, we multiply by 13.7603. 

program earnings_max_austria
	syntax, new_monthly_earn_max(string) year_t(varname)
	
	// Social security earnings maximum
	cap drop `new_monthly_earn_max'
	gen `new_monthly_earn_max' = .
	replace `new_monthly_earn_max' =	13/12*3600	if `year_t'==	1957
	replace `new_monthly_earn_max' =	13/12*3600	if `year_t'==	1958
	replace `new_monthly_earn_max' =	13/12*3600	if `year_t'==	1959
	replace `new_monthly_earn_max' =	13/12*3600	if `year_t'==	1960
	replace `new_monthly_earn_max' =	13/12*4800	if `year_t'==	1961
	replace `new_monthly_earn_max' =	13/12*4800	if `year_t'==	1962
	replace `new_monthly_earn_max' =	13/12*4800	if `year_t'==	1963
	replace `new_monthly_earn_max' =	13/12*4800	if `year_t'==	1964
	replace `new_monthly_earn_max' =	14/12*5400	if `year_t'==	1965
	replace `new_monthly_earn_max' =	14/12*5850	if `year_t'==	1966
	replace `new_monthly_earn_max' =	14/12*6300	if `year_t'==	1967
	replace `new_monthly_earn_max' =	14/12*6750	if `year_t'==	1968	
	replace `new_monthly_earn_max' =	14/12*7200	if `year_t'==	1969
	replace `new_monthly_earn_max' =	14/12*7650	if `year_t'==	1970
	replace `new_monthly_earn_max' =	14/12*8100	if `year_t'==	1971
	replace `new_monthly_earn_max' =	14/12*8700	if `year_t'==	1972
	replace `new_monthly_earn_max' =	14/12*9450	if `year_t'==	1973
	replace `new_monthly_earn_max' =	14/12*10500	if `year_t'==	1974
	replace `new_monthly_earn_max' =	14/12*11700	if `year_t'==	1975
	replace `new_monthly_earn_max' = 	14/12*13200	if `year_t'==	1976
	replace `new_monthly_earn_max' = 	14/12*15000	if `year_t'==	1977
	replace `new_monthly_earn_max' = 	14/12*16800	if `year_t'==	1978
	replace `new_monthly_earn_max' = 	14/12*18600	if `year_t'==	1979
	replace `new_monthly_earn_max' = 	14/12*19500	if `year_t'==	1980
	replace `new_monthly_earn_max' = 	14/12*20400	if `year_t'==	1981
	replace `new_monthly_earn_max' = 	14/12*21600	if `year_t'==	1982
	replace `new_monthly_earn_max' = 	14/12*22800	if `year_t'==	1983
	replace `new_monthly_earn_max' = 	14/12*24000	if `year_t'==	1984
	replace `new_monthly_earn_max' = 	14/12*24600	if `year_t'==	1985
	replace `new_monthly_earn_max' = 	14/12*25800	if `year_t'==	1986
	replace `new_monthly_earn_max' = 	14/12*26400	if `year_t'==	1987
	replace `new_monthly_earn_max' = 	14/12*27600	if `year_t'==	1988
	replace `new_monthly_earn_max' = 	14/12*28200	if `year_t'==	1989
	replace `new_monthly_earn_max' = 	14/12*28800	if `year_t'==	1990
	replace `new_monthly_earn_max' = 	14/12*30000	if `year_t'==	1991
	replace `new_monthly_earn_max' = 	14/12*31800	if `year_t'==	1992
	replace `new_monthly_earn_max' = 	14/12*33600	if `year_t'==	1993
	replace `new_monthly_earn_max' = 	14/12*36000	if `year_t'==	1994
	replace `new_monthly_earn_max' = 	14/12*37800	if `year_t'==	1995
	replace `new_monthly_earn_max' = 	14/12*39000	if `year_t'==	1996
	replace `new_monthly_earn_max' = 	14/12*40800	if `year_t'==	1997
	replace `new_monthly_earn_max' = 	14/12*42000	if `year_t'==	1998
	replace `new_monthly_earn_max' = 	14/12*42600	if `year_t'==	1999
	replace `new_monthly_earn_max' = 	14/12*43200	if `year_t'==	2000
	replace `new_monthly_earn_max' = 	14/12*44400	if `year_t'==	2001
	replace `new_monthly_earn_max' = 	14/12*13.7603*3270	if `year_t'==	2002
	replace `new_monthly_earn_max' = 	14/12*13.7603*3360	if `year_t'==	2003
	replace `new_monthly_earn_max' = 	14/12*13.7603*3450	if `year_t'==	2004
	replace `new_monthly_earn_max' = 	14/12*13.7603*3630	if `year_t'==	2005
	replace `new_monthly_earn_max' = 	14/12*13.7603*3750	if `year_t'==	2006
	replace `new_monthly_earn_max' = 	14/12*13.7603*3840	if `year_t'==	2007
	replace `new_monthly_earn_max' = 	14/12*13.7603*3930	if `year_t'==	2008
	replace `new_monthly_earn_max' = 	14/12*13.7603*4020	if `year_t'==	2009
	replace `new_monthly_earn_max' = 	14/12*13.7603*4110	if `year_t'==	2010
	replace `new_monthly_earn_max' = 	14/12*13.7603*4200	if `year_t'==	2011
	replace `new_monthly_earn_max' = 	14/12*13.7603*4230	if `year_t'==	2012
	replace `new_monthly_earn_max' = 	14/12*13.7603*4440	if `year_t'==	2013
	replace `new_monthly_earn_max' = 	14/12*13.7603*4530	if `year_t'==	2014
	replace `new_monthly_earn_max' = 	14/12*13.7603*4650	if `year_t'==	2015
	replace `new_monthly_earn_max' = 	14/12*13.7603*4860	if `year_t'==	2016
	replace `new_monthly_earn_max' = 	14/12*13.7603*4980	if `year_t'==	2017
	replace `new_monthly_earn_max' = 	14/12*13.7603*5130	if `year_t'==	2018


	
end	

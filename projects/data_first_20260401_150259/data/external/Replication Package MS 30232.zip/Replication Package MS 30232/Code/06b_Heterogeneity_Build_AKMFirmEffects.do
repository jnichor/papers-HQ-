/*******************************************************************************

  DESCRIPTION: Calculate AKM firm effects.



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/06b_Heterogeneity_Build_AKMFirmEffects`curr_date'", replace



***** Selecting years to include for each reform
	* Four years before each reform except for the 1976 reform where we have two years
foreach reform in $reforms {
	forval i = 1/4 {
		local r`reform'`i' = `reform' - `i'
		if `r`reform'`i'' < 1974 {
		}
		else {
			local list`reform' `list`reform'' `r`reform'`i''
		}
	}
}

****************************************************************************
* Loading earnings for each reform + editing earnings variables
****************************************************************************
foreach reform in $reforms {
foreach year in `list`reform'' {

* Take a window of up to 10 years (shorter for 1976 reform), ending two years
* before reform.

use svnr year benr refage avg_dearnings status ///
 using "$temp/01_Panel_all_full_sample.dta" if inrange(year, `year' - 10, `year') , clear

* Setting up data as panel
xtset svnr year

**** Converting dearnings to nominal Austrian Shillings from daily 2000 Euros
	* Multiply by 13.7603 to get from Euros to Shillings
	* Multiply by the number of days per year/months
	* Incorporate leap years https://kalender-365.de/leap-years.php
	* Multilying by the CPI deflator to get to nominal Shillings

fmerge m:1 year using "${userData}/CPI_AUT.dta", assert(match using) keep(match) nogen

* Leap years
gen leap_year = inlist(year, $leapYears)
gen day_per_year = cond(leap_year == 1, 366, 365)

* Monthly earnings definition
gen adj_earnings = avg_dearnings*$euroToShilling*(day_per_year/12)*(CPI_2000/100)

* Age and log earnings definitions
gen refage_sq = refage^2
gen refage_cub = refage^3

gen lnearnings = log(adj_earnings)
winsor2 lnearnings,  cuts(${winsor_pct}) by(year)

* Numeric benr variable for
rename benr benr_str
gegen benr = group(benr_str)


****************************************************************************
* Regress ln(w) on worker and firm FEs, year dummies, and cubic of age
****************************************************************************
reghdfe lnearnings_w refage_* if status == 3, absorb(workerFE = svnr firmFE = benr yearFE = year) groupvar(mobility_group) verbose(2)

* Extract largest connected set

bys mobility_group: egen n_obs_mobility_group = count(svnr) if mobility_group!=.
sum n_obs_mobility_group, detail
keep if n_obs_mobility_group==r(max)


****************************************************************************
* Keep firm FEs + saving year specific file
****************************************************************************
drop benr
rename benr_str benr

keep year benr firmFE
keep if year == `year' & !mi(benr) & !mi(firmFE)
duplicates drop

tempfile temp`year'
save `temp`year''

} // years




****************************************************************************
* Appending together AKM estimates for each year of a specific reform
****************************************************************************
clear
set obs 1
gen filler = 1
foreach year in `list`reform'' {
append using "`temp`year''"
erase "`temp`year''"
}

gen reform = `reform'

save ${temp}/06b_Reform`reform'.dta, replace

} // Reforms




****************************************************************************
* Append reform files
****************************************************************************
clear
set obs 1
gen filler = 1
foreach reform in $reforms {
	append using ${temp}/06b_Reform`reform'.dta
	erase ${temp}/06b_Reform`reform'.dta
}
drop if filler == 1
drop filler
save ${temp}/06b_AKMFirmEffects.dta, replace

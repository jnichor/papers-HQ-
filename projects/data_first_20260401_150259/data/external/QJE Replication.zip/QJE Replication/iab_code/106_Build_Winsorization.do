*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================



cap log close

cap log using $log\106_Build_Winsorization.txt, text replace


********************************************************************************
*
*
*			106 Build Winsorization and Analysis Variables
*
*
********************************************************************************



* Load data
********************************************************************************
use "${data}/iab_wage_analysis.dta", clear


* Winsorization
********************************************************************************
local w = 1  // Winsorize at 1% level in a given year if w=1


foreach outcome in $outcomes  {
	noi di "		Winsor value: `w'%"


	local dont_winsor = 0
	foreach test in $nonwins_outcomes {
		if "`outcome'" == "`test'" {
			local dont_winsor = 1
		}
	}
	noi di "`dont_winsor'"
	timer on 3
	if `dont_winsor' == 1 {
		cap gen `outcome'_`w'`i' = `outcome'
	}
	else if `dont_winsor' == 0 {
		local lower = `w'
		local upper = 100 - `w'
		winsor2 `outcome', replace cut(`lower' `upper') by(jahr)
	}
}



* Create additional regressors
********************************************************************************
	gen const = 1
	egen cluster_variable = group($default_cluster)
	egen nace_d2_grp = group(nace_d2)
	gen firm_age = jahr - year(dateinc)
	gen AG_prereformcohort = 10*AG + prereformcohort

	*bin by quarters
	egen _bins = cut(d_rel), at(-1825(91.25)1916.25)
	egen quarters = group(_bins)
	drop _bins

	gen prereformcohort_d_rel = (prereformcohort==1)*d_rel



* Save data
********************************************************************************

compress
save "${data}/iab_wage_analysis_winsor`w'.dta", replace

/*******************************************************************************

	DESCRIPTION: Calculate LOM industry growth measures.

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
cap log close
set more off
local curr_date = c(current_date)
log using "${logs}/06e_Heterogeneity_Build_IndustryGrowthRate`curr_date'.smcl", replace

****************************************************************************
* Calculate LOM Industry Growth Measure
* LOM -- Leave Out My
****************************************************************************
**** Use those who are in sample 2 years before the reform (i.e. 1982 for 1985 reform)

use svnr year benr nace08 status using "$temp/01_Panel_all_full_sample.dta" if benr != "" & nace08 != . & status == 3, clear
drop status


**** Create measure

	rename benr benr_str
	gegen benr = group(benr_str)

	* Collapsing down to get employment by firm and industry
	gen emp = 1
	collapse (sum) emp (first) benr_str nace08, by(benr year)

	* Total industry employment
	bysort nace08 year: gegen ind_emp = total(emp)

	* Firm employment next year
	xtset benr year
	gen emp_next = F.emp
	replace emp_next = 0 if mi(emp_next)

	bysort nace08 (year benr): gen ind_emp_next = ind_emp[_n + 1]
	bysort nace08 year (benr): replace ind_emp_next = ind_emp_next[_N]

	sort nace08 year
	assert ind_emp_next == ind_emp[_n + 1] if nace08 == nace08[_n + 1] & year == year[_n + 1] - 1

	* Leave-out industry size
	gen lom_n_ind = ind_emp - emp //Industry population without one's own firm
	gen lom_n_ind_next = ind_emp_next - emp_next

	assert lom_n_ind >= 0
	assert lom_n_ind_next >= 0

	bys benr year: gen lom_ind_growth = (lom_n_ind_next - lom_n_ind) / lom_n_ind

	* Winsorize growth rates
	winsor2 lom_ind_growth, by(year) cut(${winsor_pct})

****************************************************************************
* Keep only Firm Observations
****************************************************************************
	drop benr
	rename benr_str benr
	isid benr year
	keep year benr lom_ind_growth lom_ind_growth_w
	save ${temp}/06e_IndustryGrowthRate.dta, replace

log close

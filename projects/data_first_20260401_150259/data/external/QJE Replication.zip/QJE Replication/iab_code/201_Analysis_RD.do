*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/201/$today"
local output $log/201/$today

log using "`output'/201_Analysis_RD.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*			201 Analysis RD
*
********************************************************************************

foreach legal in AG GmbH {
	foreach robust in 1 2 3 {

		foreach w in $winsor_values {
			noi di "Winsorization `w' %"

			use "$data\iab_wage_analysis_winsor`w'.dta" if abs(d_rel) <= ${bw_standard} & `legal'==1 ${robust`robust'}, clear




			 foreach i in $specifications {


				timer on 2
				noi di "Specification `i'"


				foreach outcome in $outcomes  {


					timer on 2
					noi di "	Outcome: `outcome'"

					timer on 3


					* store estimates in a global
					if `i'==1 {
						noi reg `outcome' i.prereformcohort d_rel prereformcohort_d_rel, ///
					 vce(cluster cluster_variable)
						global c_rd`outcome'`w'`i' = _b[_cons]
					}
					if `i'>1 {
						noi reghdfe `outcome' i.prereformcohort d_rel prereformcohort_d_rel, ///
						absorb(${controls`i'}) vce(cluster cluster_variable)
							global c_rd`outcome'`w'`i' = 0
					}


					global slope1_rd`outcome'`w'`i' = _b[d_rel]
					global slope2_rd`outcome'`w'`i' = _b[prereformcohort_d_rel]

					global b_rd`outcome'`w'`i' = _b[1.prereformcohort]
					global s_rd`outcome'`w'`i' = _se[1.prereformcohort]
					global p`outcome'`w'`i' = (2 * ttail(e(df_r), abs(_b[1.prereformcohort]/_se[1.prereformcohort])))

					global N`outcome'`w'`i' = `e(N)'

					* Number of AGs
					gdistinct idnr if e(sample) == 1
					global Nf`outcome'`w'`i' = `r(ndistinct)'


					* Control group mean at the discontinuity
					gstats su `outcome' if d_rel >= 0
					global cm`outcome'`w'`i' = `r(mean)'


					timer off 3
					qui timer list 3
					noi di "		Time for regression: `r(t3)' seconds"
					timer clear 3

					timer off 2
					qui timer list 2
					noi di "	Time for outcome: `r(t2)' seconds"
					timer clear 2

				} // Outcomes

			} // Specifications

		} // Winsor values


		foreach w in $winsor_values {

			foreach i in $specifications {

				qui foreach outcome in $outcomes {
							* Save data
							clear
							set obs 1
							gen spec = `i'
							gen outcome = "`outcome'"
							gen winsor = `w'
							gen bandwidth = $bw_standard
							gen N = ${N`outcome'`w'`i'}
							gen b = ${b_rd`outcome'`w'`i'}
							lab var b "1.prereformcohort"
							gen s = ${s_rd`outcome'`w'`i'}
							gen p = ${p`outcome'`w'`i'}

							* for plotting
							gen c=  ${c_rd`outcome'`w'`i'}
							lab var c "_cons"
							gen slope1=  ${slope1_rd`outcome'`w'`i'}
							lab var slope1 "d_rel"
							gen slope2=  ${slope2_rd`outcome'`w'`i'}
							lab var slope2 "prereformcohort_d_rel"

							gen controlmean = ${cm`outcome'`w'`i'}
							gen Nf= ${Nf`outcome'`w'`i'}


							save "`output'/RD_`outcome'_Winsor`w'_spec`i'${robustness`robust'}_`legal'.dta", replace

						} // Outcomes
				} // Specifications
			} // winsor values




	} // Robustness
} // legal
log close

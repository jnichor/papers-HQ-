*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================

********************************************************************************
*
*
*			Store table names in globals 
*
*
********************************************************************************


global name1_log_empl "Log Emp"
global name2_log_empl "(BvD)"

global name1_az_ges500plus_d "$\mathbb{1}$(Emp$>500$) "
global name2_az_ges500plus_d "(IAB)"

global name1_log_az_ft_ges "Log Emp"
global name2_log_az_ft_ges "(IAB)"

global name1_log_staf "Log"
global name2_log_staf "Wage Bill"

global name1_log_toas "Log"
global name2_log_toas "Total A."
global name1_log_fias "Log"
global name2_log_fias "Fixed A."
global name1_log_cuas "Log"
global name2_log_cuas "Current A."
global name1_log_tfas "Log"
global name2_log_tfas "Tang. A."
global name1_log_ifas "Log"
global name2_log_ifas "Intang. A."
global name1_log_ofas "Log Other"
global name2_log_ofas "Fixed A."
global name1_log_opre "Log"
global name2_log_opre "Revenue"
global name1_log_av "Log Value"
global name2_log_av "Added"
global name1_av_opre "Value Added" //In-House
global name2_av_opre "/Revenue" // Share
global name1_capital_share "Labor"
global name2_capital_share "Share"

global name1_opre_per_empl "Revenue"
global name2_opre_per_empl "per Emp"
global name1_av_per_empl "Value Add."
global name2_av_per_empl "per Emp"

global name1_labor_share "Labor"
global name2_labor_share "Share"

global name1_log_labor_share "Log Labor"
global name2_log_labor_share "Share"

global name1_log_opre_per_empl "Log Rev"
global name2_log_opre_per_empl "per Emp"
global name1_log_av_per_empl "Log VA"
global name2_log_av_per_empl "per Emp"

global name1_log_staf_per_empl "Log Wage Bill"
global name2_log_staf_per_empl "per Emp"

global name1_tfas_per_empl "Tang. A."
global name2_tfas_per_empl "per Emp"

global name1_fias_per_empl "Fixed A."
global name2_fias_per_empl "per Emp"

global name1_log_tfas_per_empl "TangA"
global name2_log_tfas_per_empl "per Emp"

global name1_log_fias_per_empl "Log Fixed A."
global name2_log_fias_per_empl "per Emp"


global name1_ebta_opre "EBITDA"
global name2_ebta_opre "/Revenue"
global name1_ebit_opre "EBIT"
global name2_ebit_opre "/Revenue"
global name1_plat_opre "PLAT"
global name2_plat_opre "/Revenue"
global name1_ebta_shfd "EBITDA"
global name2_ebta_shfd "/Equity"
global name1_ebit_shfd "EBIT"
global name2_ebit_shfd "/Equity"
global name1_plat_shfd "PLAT"
global name2_plat_shfd "/Equity"
global name1_ebta_toas "EBITDA"
global name2_ebta_toas "/Total A."
global name1_ebit_toas "EBIT"
global name2_ebit_toas "/Total A."
global name1_plat_toas "PLAT"
global name2_plat_toas "/Total A."
global name1_log_TFPr_fias "TFP"
global name2_log_TFPr_fias "(Fixed A.)"
global name1_log_TFPr_tfas "TFP"
global name2_log_TFPr_tfas "(Tang. A.)"
global name1_TFPr_fias "TFP"
global name2_TFPr_fias "(Fixed A.)"
global name1_TFPr_tfas "TFP"
global name2_TFPr_tfas "(Tang. A.)"

global name1_az_gq_per_empl "Low-"
global name2_az_gq_per_empl "Skilled \%"

global name1_az_mq_per_empl "Med-"
global name2_az_mq_per_empl "Skilled \%"

global name1_az_hq_per_empl "High-"
global name2_az_hq_per_empl "Skilled \%"

global name1_log_az_gq_per_empl "Log Low-"
global name2_log_az_gq_per_empl "Skilled \%"

global name1_log_az_mq_per_empl "Log Med-"
global name2_log_az_mq_per_empl "Skilled \%"

global name1_log_az_hq_per_empl "Log High-"
global name2_log_az_hq_per_empl "Skilled \%"

global name1_log_emp "Log Emp"
global name2_log_emp "(BvD)"

global name1_log_az_ges "Log Emp"
global name2_log_az_ges "(IAB)"

global name1_av "Value"
global name2_av "Added"

global name1_log_te_med "Log Wage,"
global name2_log_te_med "Wage"

global name1_log_te_p25 "Log Wage,"
global name2_log_te_p25 "p25"

global name1_log_te_p50 "Log Wage,"
global name2_log_te_p50 "p50"

global name1_log_te_p75 "Log Wage,"
global name2_log_te_p75 "p75"

global name1_akm_firm_fe "AKM Firm"
global name2_akm_firm_fe "Fixed Effect"

global name1_pers_fe "AKM Worker"
global name2_pers_fe "Fixed Effect"

global name1_az_ft_zens "Above"
global name2_az_ft_zens "SS Maximum"

global name1_az_ft_zens_per_empl "\% Above SocSec"
global name2_az_ft_zens_per_empl "Maximum"

global name1_az_ft_zens_p_empl "\% Above SocSec"
global name2_az_ft_zens_p_empl "Maximum"

global name1_az_zens_per_empl "\% Above"
global name2_az_zens_per_empl "SS Maximum"

global name1_bet_effekt_all_firm "Log Wage,"
global name2_bet_effekt_all_firm "AKM Firm"

global name1_log_ten_ges "Log"
global name2_log_ten_ges "Tenure"

global name1_fscl_per_empl "Outsourceable"
global name2_fscl_per_empl "(FSCL) \%"

global name1_fscl "Outsourceable"
global name2_fscl "(FSCL)"

global name1_s_dlog_capital_share "Capital"
global name2_s_dlog_capital_share "share"

global name1_s_dlog_labor_share "Labor"
global name2_s_dlog_labor_share "share"

global name1_log_av_opre "Log"
global name2_log_av_opre "VA / Rev"

global name1_log_te_mw "Log Wage,"
global name2_log_te_mw "Mean"

global name1_log_te_p7525 "Within-Firm"
global name2_log_te_p7525 "log$\big(\frac{\text{p75}}{\text{p25}}\big)$)"

global name1_ln_mincer_residuals "Log Wage,"
global name2_ln_mincer_residuals "Mincer Resid."

global name1_ln_m_residuals "Log Wage,"
global name2_ln_m_residuals "Mincer Resid."

global name1_log_te_p7525 "Within-Firm"
global name2_log_te_p7525 "log$\big(\frac{\text{p75}}{\text{p25}}\big)$)"

global name1_log_opre_per_empl "Log Revenue"
global name2_log_opre_per_empl "per Emp."

global name1_log_tfas_per_empl "Log Tang. A."
global name2_log_tfas_per_empl "per Emp."

global name1_separation_p_empl "Separation"
global name2_separation_p_empl "Rate (Annual)"

global name1_pl_opre "Net Income"
global name2_pl_opre "/Revenue"


global name1_pl_toas "Net Income"
global name2_pl_toas "/Total A."



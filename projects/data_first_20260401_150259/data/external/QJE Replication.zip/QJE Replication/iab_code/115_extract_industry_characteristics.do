*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================


cap log close

log using "$log/115_extract_industry_characteristics.txt", replace text


********************************************************************************
*
*
*			115 Extract Industry Characteristics
*
*
********************************************************************************



* Load data
********************************************************************************

use idnr jahr separation tenure using $data\idnr_jahr_collapsed_siab.dta, clear

* Merge additional BvD data
********************************************************************************


* Merge header information from BvD
*-------------------------------------------------------------------------------

tostring idnr, gen(_BVDID)

gen BVDID = "DE" + _BVDID
drop _BVDID


merge m:1 BVDID using $orig\header.dta, keepusing(BVDID FEDERAL_STATE LEGALFRM NATPCOD NATSCOD1 NATSCOD2) // header.dta has basic firm info
keep if _merge==3


drop _merge



* Add worker and firm effect
*===============================================================================


merge m:1 idnr jahr using "${data}/akm.dta"
drop if _merge == 2
drop _merge

* Adjust AKMs by year effects because not comparable across years
reg akm_firm_fe i.jahr
predict akm_firm_fe_hat
replace akm_firm_fe = akm_firm_fe-akm_firm_fe_hat
drop akm_firm_fe_hat


*  Merge financial information from BvD
*-------------------------------------------------------------------------------
gen YEAR = jahr



merge m:1 BVDID YEAR using $orig\Finanzenfertig.dta, keepusing(EMPL AV)
drop if _merge==2
drop _merge

drop BVDID YEAR
rename *, lower


*  Define industry variable (5-digit NACE) and implement industries test, i.e. drop industries of Tendenzbetriebe, Public Utilities, Public Administration, etc.
*-------------------------------------------------------------------------------

gen nace_d5 = natpcod
replace nace_d5 = natscod1 if natpcod == .
replace nace_d5 = natscod2 if natpcod == . &  natscod2 == .
drop if nace_d5==.

* Create coarser NACE industry codes
forval i = 3/3 {
	gen nace_d`i' = floor(nace_d5/(10^(5-`i')))
	}


*  Create additional variables
*-------------------------------------------------------------------------------

foreach var of varlist av  {
	replace `var' = . if `var' <= 0
	replace `var' = 100*`var'/62.9436768006212	if jahr == 1990
	replace `var' = 100*`var'/65.4910288078316	if jahr == 1991
	replace `var' = 100*`var'/68.8028970737547	if jahr == 1992
	replace `var' = 100*`var'/71.8815351801058	if jahr == 1993
	replace `var' = 100*`var'/73.8173455045538	if jahr == 1994
	replace `var' = 100*`var'/75.0767883662429	if jahr == 1995
	replace `var' = 100*`var'/76.1651957775791	if jahr == 1996
	replace `var' = 100*`var'/77.6423201215354	if jahr == 1997
	replace `var' = 100*`var'/78.349784938904	if jahr == 1998
	replace `var' = 100*`var'/78.8084709193957	if jahr == 1999
	replace `var' = 100*`var'/79.9435243626463	if jahr == 2000
	replace `var' = 100*`var'/81.5294894477363	if jahr == 2001
	replace `var' = 100*`var'/82.6878659069441	if jahr == 2002
	replace `var' = 100*`var'/83.5430431587083	if jahr == 2003
	replace `var' = 100*`var'/84.9346497774882	if jahr == 2004
	replace `var' = 100*`var'/86.248513009744	if jahr == 2005
	replace `var' = 100*`var'/87.6090222739143	if jahr == 2006
	replace `var' = 100*`var'/89.6225759848864	if jahr == 2007
	replace `var' = 100*`var'/91.9782005965641	if jahr == 2008
	replace `var' = 100*`var'/92.265851126703	if jahr == 2009
	replace `var' = 100*`var'/93.2842894901676	if jahr == 2010
	replace `var' = 100*`var'/95.2200998146156	if jahr == 2011
	replace `var' = 100*`var'/97.1325871231064	if jahr == 2012
	replace `var' = 100*`var'/98.5941627897579	if jahr == 2013
	replace `var' = 100*`var'/99.4882117347841	if jahr == 2014
	replace `var' = 100*`var'/100				if jahr == 2015
	replace `var' = 100*`var'/100.491748624771	if jahr == 2016
	replace `var' = 100*`var'/102.008668111352	if jahr == 2017
	replace `var' = 100*`var'/103.775629271545	if jahr == 2018
	replace `var' = 100*`var'/105.275879313219	if jahr == 2019
}
replace empl = . if empl<0

gen ln_av_empl = ln(av/empl)


*  Collapse at nace_d3 level
*-------------------------------------------------------------------------------

foreach var of varlist akm_firm_fe ln_av_empl  separation tenure {
	winsor2 `var',  cut(1 99) replace by(jahr)
	gen `var'_AG = `var' if legalfrm==4
}

gcollapse (sd) akm_sd = akm_firm_fe akm_sd_AG = akm_firm_fe_AG  (mean) ln_av_empl = ln_av_empl industry_akm = akm_firm_fe separation_rate = separation tenure = tenure ln_av_empl_AG = ln_av_empl_AG industry_akm_AG = akm_firm_fe_AG separation_rate_AG = separation_AG tenure_AG = tenure_AG [w=empl], by(nace_d3)

sort nace_d3
compress

save "${data}/bvd_akm_industry_heterogeneity.dta", replace


log close

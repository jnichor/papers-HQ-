/*******************************************************************************

	DESCRIPTION: Pool reform samples together to create a pooled sample,
		renaming variables as needed for the main analysis.

*******************************************************************************/


********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/02c_Build_PooledSample`curr_date'", replace



****************************************************************************
****	Defining instruments X lags + earnings adjustments
****************************************************************************

***** Looping through the four reforms
foreach reform in $reforms {


***** Looping through years forward
foreach yrFwd in $earnF {

	***** Number of years to keep for each reform
		* Ends up being the same but would differ for preYrs > 5
	local start_yr = `reform' - (${preYrs} + 1)

	if `reform' == 1976 {
		local start_yr = `reform' - 4
	}

	local end_yr = `reform' - 1

	***** Loading reform sample
		* keeping years in timeframe and individuals in the treatment and control groups
	use ${temp}/02b_Reform`reform'.dta if inrange(year, `start_yr', `end_yr') & (in_sample_`reform' == 1), clear


	***** Individual-level values
	foreach y in $earnF {
		rename RRdiff_f`y'_RRiBY_BRiBY RRChange_f`y' // RR Instrument
		rename RRdiff_f`y'_RRRY_BRRY realizedRRChange_f`y' // Actual RR Change
	}


	***** Aggregated-level values
	foreach suffix in earn_pct benr indocc {
		rename (RRdiff_f1_`reform'_`suffix' RRdiff_f1_`reform'_`suffix'_nettax) ///
		(RRinstrument_`suffix'_f1 RRinstrument_`suffix'_f1_nettax)
	}


	***** Defining locals of years to include in regressions and for the placebo year tests
		* Differs by outcomes because different years are included based on 1 or 2 yr earn growth

	* Treated year and year excluded from estimation
	local excld_yr = `reform' - (`yrFwd' + 1)
	local treat_yr = `reform' - 1

	* Years to include in regression
	if `yrFwd' == 2 {
		local drop_yr `reform' - 2
	}

	if `yrFwd' == 3 {
		local drop_yr `reform' - 3, `reform' - 2
	}


	***** Defining all years to estimate regression coeffs for
	local yr_list ""

	* One year fwd -> all years except exclude year
	if `yrFwd' == 1 {

		* All years except the excluded year
		forvalues yr = `start_yr'/`end_yr' {
			if `yr' != `excld_yr' {
				local yr_list `yr_list' `yr'
			}
		}
	}

	***** For other years forward -> drop drop years + don't include them in list
	if `yrFwd' != 1 {

		drop if inlist(year, `drop_yr')

		forvalues yr = `start_yr'/`end_yr' {
			if `yr' != `excld_yr' & !inlist(`yr', `drop_yr') {
				local yr_list `yr_list' `yr'
			}
		}
	}

	***** Some asserts
	assert year != `reform' - 2 if `yrFwd' > 1
	assert year != `reform'
	assert inlist(treatment_`reform' + control_`reform', 1 ,2) if `reform' != 1985 // 1985 has the mid range


	***** Generating year dummies and year interacted with instrument
		* Event time is relative to treatment, i.e. for year t, e = t - r + 1
		* Coeff of interest is e = 0.
	gen sum_inds = 0
	foreach yr in `yr_list' {
		* Event time -- given current setup -> all lags
		local x = `yr' - `reform' + 1
		if `x' > 0 {
			local letter f
		}
		if `x' <= 0 {
			local letter l
		}
		local x = abs(`x')
		gen yr_`letter'`x' = year == `yr'

		* Event time X instrument - overall + net earnings
		foreach suffix in earn_pct benr indocc {
			gen interaction_`suffix'_`letter'`x'_f`yrFwd' = RRinstrument_`suffix'_f1 * yr_`letter'`x'
			gen inter_nt_`suffix'_`letter'`x'_f`yrFwd' = RRinstrument_`suffix'_f1_nettax * yr_`letter'`x'
		} //level of instrument aggregation

		* For assert
		replace sum_inds = sum_inds + yr_`letter'`x'
	}

	***** Some asserts
	assert sum_inds == 1 if year != `excld_yr'
	assert sum_inds == 0 if year == `excld_yr'
	drop sum_inds


	gen reform = `reform'

	assert in_sample_`reform' == 1

	save ${temp}/02c_file`reform'_yrFwd`yrFwd'.dta, replace

} // Years forward
} // Reforms


****************************************************************************
***** Appending together the four reform for each year forward
****************************************************************************
foreach yrFwd in $earnF {

	clear

	set obs 1
	gen filler = 1

	foreach reform in $reforms {
		append using ${temp}/02c_file`reform'_yrFwd`yrFwd'.dta
		erase ${temp}/02c_file`reform'_yrFwd`yrFwd'.dta
	} //Reforms

	drop if filler == 1
	drop filler

	****************************************************************************
	***** Create takeup and UI duration variables from months UI outcome:
	****************************************************************************

	* Takeup -- nonemployed next year + at least month on UI
	gen takeup_f`yrFwd' = mth_UE_f`yrFwd' > 0 & !mi(mth_UE_f`yrFwd') & mth_non_emp_f`yrFwd' > 0 & !mi(mth_non_emp_f`yrFwd')
	replace takeup_f`yrFwd' = . if mi(mth_UE_f`yrFwd')
	replace takeup_f`yrFwd' = . if  mth_non_emp_f`yrFwd' == 0

	* UI duration -- number of months on UI conditional on UI takeup -- never == 0
	gen UIdur_f`yrFwd' = mth_UE_f`yrFwd' if mth_UE_f`yrFwd' > 0 & !mi(mth_UE_f`yrFwd') & mth_non_emp_f`yrFwd' > 0 & !mi(mth_non_emp_f`yrFwd')
	replace UIdur_f`yrFwd' = . if mi(mth_UE_f`yrFwd')
	replace UIdur_f`yrFwd' = . if  mth_non_emp_f`yrFwd' == 0

	* Unconditional UI Duration -- number of months on UI conditional on one month non emp -- can equal 0
	gen UIdur_f`yrFwd'_NE = mth_UE_f`yrFwd' if  mth_non_emp_f`yrFwd' > 0 & !mi(mth_non_emp_f`yrFwd')
	replace UIdur_f`yrFwd'_NE = . if mi(mth_UE_f`yrFwd')
	replace UIdur_f`yrFwd'_NE = . if  mth_non_emp_f`yrFwd' == 0

	***** Some Asserts
	assert mth_UE_f`yrFwd' <= mth_non_emp_f`yrFwd'
	assert UIdur_f`yrFwd' > 0 & !mi(UIdur_f`yrFwd') if takeup_f`yrFwd' ==1
	assert UIdur_f`yrFwd' == UIdur_f`yrFwd'_NE if UIdur_f`yrFwd'_NE != 0
	assert UIdur_f`yrFwd' != 0

	compress
	save ${temp}/02c_PooledReforms_yrFwd`yrFwd'.dta, replace

} // Years forward



log close

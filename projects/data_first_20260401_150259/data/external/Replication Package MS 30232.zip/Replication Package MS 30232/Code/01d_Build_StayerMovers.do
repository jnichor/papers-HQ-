/*******************************************************************************

	DESCRIPTION: Creates labor market transitions



*******************************************************************************/




********************************************************************************
***** Preliminaries
********************************************************************************
cap log close
local curr_date = c(current_date)
log using "${logs}/01d_Build_StayerMovers`curr_date'", replace



****************************************************************************
* Looping though male + female samples, random group splits, and specific years
****************************************************************************

foreach sex_sample in $sexSamples {
forval group = 1/2 {
forval year = $startYr_01d/$endYr_01d {

	***** Loading current year + next two years
	use svnr m_date dearnings status_temp benr_temp using ${temp}/01_SpellData_`sex_sample'_Group`group'.dta if inrange(year(dofm(m_date)),`year',`year'+2), clear

	gen year = year(dofm(m_date))
	xtset svnr m_date





	****************************************************************************
	* Last firm employed each year and number of firms per year
	* These are only kept for the current year (ex. year == `year')
	****************************************************************************
	***** The last firm at which the worker is employed each year
	bysort svnr year (m_date) : gen last_firm_empl = benr_temp if !missing(benr)
	by svnr year: replace last_firm_empl = last_firm_empl[_n-1] if mi(benr) & _n > 1
	by svnr year: replace last_firm_empl = last_firm_empl[_N]


	***** Number of unique firms per year
	bysort svnr year benr: gen first_benr_obs = 1 if _n == 1 & !mi(benr)
	bysort svnr year: gegen number_firms = sum(first_benr_obs)
	drop first_benr_obs

	***** Some asserts
	assert last_firm_empl == benr_temp if month(dofm(m_date)) == 12 & !mi(benr)

	assert number_firms <= 12 & number_firms >= 0
	assert number_firms	>= 1 if !mi(benr)

	assert last_firm_empl == benr_temp if number_firms == 1 & !mi(benr)
	assert number_firms > 1 if last_firm_empl != benr_temp & !mi(benr)




	****************************************************************************
	***** Generating variables for being at the same firm as December in the base year
		* Generally, we won't care about anything generated for the actual base year
		* Ex. we just pull the values for future years back to the base year to define mover/etc.
	****************************************************************************

	* Firm in December of the first year (relative to future earnF years)
	gen benr_december = benr_temp if month(dofm(m_date)) == 12 & year == `year'
	* Sorting by benr_december -> missings to start
	bysort svnr (benr_december): replace benr_december = benr_december[_N]

	* Same firm as the firm in December of the first year
	gen samefirm = benr_december == benr_temp & !mi(benr_temp)




	****************************************************************************
	* Constructing indicators for being a job stayer or job mover
	* We construct this for every year in $earnF
	* For years in $earnF beyond one year -- we pretend that all subsequent observations are from the same year
	****************************************************************************
	foreach yr_fwd in $earnF {

		***** Code specific to each forward year
			* The year and month changes make us ``pretend'' that one year extended over the whole period
		local num_months = `yr_fwd'*12
		gen year_temp = year
		replace year_temp = `year' + 1 if inrange(year, `year' + 1, `year' + `yr_fwd')
		gen month_temp = 12*(year - year_temp) + month(dofm(m_date))
		assert year == year_temp if `yr_fwd' == 1
		assert month == month_temp if `yr_fwd' == 1

		* Months at the same firm as last december
		bys svnr year_temp: gegen tempsum = sum(samefirm)


		***** Defining stayers
			* Stayer: same firm in December for every month in the following year
		gen byte stayer_yrback = tempsum == `num_months'


		***** Some asserts
		* benr_december constant within svnr
		gen mi_benr_dec = mi(benr_december)
		bysort svnr (m_date): gen first_obs = _n == 1
		bysort svnr (m_date): assert mi_benr_dec == mi_benr_dec[_n - 1] if first_obs != 1
		drop mi_benr_dec first_obs

		* benr_december = benr for December of the first year
		assert benr_december == benr_temp if month_temp == 12 & year_temp == `year'

		* Some asserts on the same firm definitions
		assert samefirm == 1 if month_temp == 12 & year_temp == `year' & status == 3 & !mi(benr_temp)
		assert tempsum <= `num_months'
		assert tempsum >= 1 if samefirm == 1

		* Stayer assert
		assert stayer_yrback != 1 if benr_december != benr_temp

		drop tempsum




		****************************************************************************
		* Generating indicators for the first month you change labor market status + firms
		* firstmove -- first month you appear in a different firm than the firm last december
		* firstchange -- first month you appear in a different labor market state than last december
		* Note these are missing if such moves never occur during the year
		* For individuals not employed -> strange behavior but shouldn't matter for eventual sample
		****************************************************************************
		gen firstmove = .
		gen firstchange = .
		forval m = 1/`num_months' {
			if `m' == 1 {
				gen tempsum = 0
				gen tempsum2 = 0
			}
			replace firstmove = `m' if benr_december != benr_temp & !mi(benr_temp) & status == 3 &  month_temp== `m' & tempsum == 0
			replace firstchange = `m' if status != 3 &  month_temp  == `m' & tempsum2 == 0
			drop tempsum tempsum2
			bys svnr year_temp: gegen tempsum = sum(firstmove)
			bys svnr year_temp: gegen tempsum2 = sum(firstchange)
		}

		bys svnr year_temp: gegen m_firstmove = firstnm(firstmove)
		bys svnr year_temp: gegen m_firstchange = firstnm(firstchange)
		drop firstmove firstchange tempsum tempsum2


		***** Some asserts
		assert mi(m_firstmove) if stayer_yrback == 1
		assert mi(m_firstchange) if stayer_yrback == 1

		assert m_firstmove <= month_temp if benr_december != benr_temp & !mi(benr_temp)
		assert m_firstchange <= month_temp if status != 3




		****************************************************************************
		***** Generating variables for later returning to the original firm
			* Used to define recalls vs. movers
		****************************************************************************
		* Return for recalls -- same firm after firm OR labor market status change
		gen return_recall = benr_temp == benr_december & status == 3 & ///
			((month_temp > m_firstchange & !mi(m_firstchange)) | ///
			(month_temp > m_firstmove & !mi(m_firstmove)))
		bys svnr year_temp: gegen tempsum_recall = sum(return_recall)

		* Return for movers -- same firm after firm  changes
		* Diff from above Firm 1 -> UE -> Firm 1 is recall but not mover
		gen return_mover = benr_temp == benr_december & status == 3 &  month_temp  > m_firstmove & !mi(m_firstmove)
		bys svnr year_temp: gegen tempsum_mover = sum(return_mover)


		***** Defining recalled individuals
			* If you are back at old firm for at least a month after the status change/move, you are recalled.
		gen byte recalled_yrback = tempsum_recall > 0 & !mi(tempsum_recall)


		***** Defining movers
			* Movers: workers at a new firm who never return to old firm
			* Note the return definition differs from the previous return def because switching to nonemployment doesn't count as a mover
		gen byte mover_yrback = tempsum_mover == 0 & !mi(m_firstmove)
		replace mover_yrback = 0 if recalled_yrback == 1


		***** Some asserts

		* some individuals with less than 12 months observed in a year
		bysort svnr year_temp: gen num_obs = _N

		assert stayer_yrback + recalled_yrback + mover_yrback == 1 if status == 3 & !mi(benr_temp) & month_temp  == `num_months' & num_obs == `num_months'
		assert stayer_yrback + recalled_yrback == 1 if status == 3 & !mi(benr_temp) & benr_temp == benr_december & month_temp  == `num_months' & num_obs == `num_months'

		assert recalled_yrback + mover_yrback == 1 if status == 3 & benr_temp != benr_december & !mi(benr_temp)
		assert stayer_yrback != 1 if status != 3 | benr_temp != benr_december

		drop tempsum* return* num_obs




		****************************************************************************
		***** Specifying the type of move -- EE, ENE, and EUE
		****************************************************************************

		* First month you are employed after the first period of nonemployment
		gen monthafterchange = month_temp  if  month_temp >= m_firstchange & !mi(m_firstchange) & status == 3
		bys svnr year_temp (m_date): gegen fmthempl_after = firstnm(monthafterchange)

		* Indicator for nonemployment between employment spells
		gen NE_before_move = status != 3 &  month_temp  >= m_firstchange &  month_temp  < fmthempl_after & !mi(m_firstchange) & !mi(fmthempl_after)
		bys svnr year_temp: gegen len_NE_premove = sum(NE_before_move)

		* Classifying mover spells as direct E to E trans or E to nonemp to E trans
		gen byte EE_yrback = len_NE_premove == 0 & mover_yrback == 1
		gen byte ENE_yrback = len_NE_premove > 0 & !mi(len_NE_premove)

		drop NE_before_move

		* Indicator of UI receipt between job changes
		gen UI_before_move = status == 1 &  month_temp  >= m_firstchange &  month_temp  < fmthempl_after & !mi(m_firstchange) & !mi(fmthempl_after)
		bys svnr year_temp: gegen len_UI_premove = sum(UI_before_move)

		* Classifying a spell as an EUE move
		gen byte EUE_yrback = len_UI_premove > 0 & !mi(len_UI_premove)
		drop UI_before_move monthafterchange fmthempl_after


		***** Some asserts
		assert (stayer_yrback == 0 & EE_yrback == 0) if status != 3 & !mi(benr_december) & month_temp == 1
		assert EE_yrback == 0 if ENE_yrback == 1 | EUE_yrback == 1
		assert ENE_yrback == 1 if EUE_yrback == 1




		****************************************************************************
		***** Changing earnings for movers and recalled workers
		****************************************************************************
		***** Average earnings only after your labor market status changes (for movers and recalled)
		gen afterchange = 0

		* Observations "after change" for movers
		replace afterchange = 1 if ///
			(( month_temp  > m_firstchange & !mi(m_firstchange)) | ///
			( month_temp  >= m_firstmove & !mi(m_firstmove))) ///
			 & status == 3 & mover_yrback == 1

		* Observations "after change" for recalled workers
		replace afterchange =  1 if ///
			(( month_temp  > m_firstchange & !mi(m_firstchange)) | ///
			( month_temp  > m_firstmove & !mi(m_firstmove))) ///
			& benr_temp == benr_december & recalled_yrback == 1

		* After change variables only take observations from the last year
		* Note -- here year is used rather than year_temp
		replace afterchange = 0 if year != `year' + `yr_fwd'

		* After change for recalled workers
		bys svnr year_temp afterchange (m_date): gegen tempmean = mean(dearnings)
		replace tempmean = . if afterchange == 0
		bys svnr year_temp (m_date): gegen avg_dearnings_afterchange = firstnm(tempmean)
		drop tempmean afterchange

		***** Some asserts
		assert mi(avg_dearnings_afterchange) if stayer_yrback == 1




		****************************************************************************
		***** Renaming based on the $earnF years forward
		****************************************************************************
		rename stayer_yrback stayer_`yr_fwd'yrback
		rename mover_yrback mover_`yr_fwd'yrback
		rename recalled_yrback recalled_`yr_fwd'yrback
		rename EE_yrback EE_`yr_fwd'yrback
		rename ENE_yrback ENE_`yr_fwd'yrback
		rename EUE_yrback EUE_`yr_fwd'yrback
		rename len_NE_premove len_NE_`yr_fwd'premove
		rename len_UI_premove len_UI_`yr_fwd'premove
		rename avg_dearnings_afterchange avg_dearnings_`yr_fwd'afterchange

		drop year_temp month_temp m_first*

	} // Different years forward in $earnF


	****************************************************************************
	***** Pulling the variables from future observations into the base year
	****************************************************************************
	* Keep only variables that will be merged back with whole dataset
	keep svnr m_date year *yrback avg_dearnings_* len_* last_firm_empl number_firms
	keep if  month(dofm(m_date))  == 12

	* Move movers/stayers construction back to base year
	xtset svnr year

	* Looping through number of forward years to define this for
	foreach yr_fwd in $earnF {
		foreach var in stayer mover recalled EE ENE EUE {
			gen `var'_f`yr_fwd' = f1.`var'_`yr_fwd'yrback
		}
		foreach var in NE UI {
			gen len_`var'_premove_f`yr_fwd' = f1.len_`var'_`yr_fwd'premove
		}
		gen avg_dearnings_afterchange_f`yr_fwd' = f1.avg_dearnings_`yr_fwd'afterchange
	}

	drop *_?yrback avg_dearnings_?afterchange len_*_?premove

	keep if year == `year'


	***** Some asserts on the one- and two-year classifications
	assert recalled_f2 == 1 if recalled_f1 == 1
	assert stayer_f1 == 1 if stayer_f2 == 1
	assert EE_f2 != 1 if (ENE_f1 == 1 | EUE_f1 == 1)
	assert mi(avg_dearnings_afterchange_f1) if stayer_f1 == 1
	assert mi(avg_dearnings_afterchange_f2) if stayer_f2 == 1

	save ${temp}/01_SeparationTypes_`sex_sample'_`year'`group'.dta, replace
} // Year Samples
} // Random group splits




****************************************************************************
***** Appending together separation types across years
****************************************************************************
clear
set obs 1
gen filler = 1

forval year = $startYr_01d/$endYr_01d {
	forval group = 1/2 {
		append using ${temp}/01_SeparationTypes_`sex_sample'_`year'`group'.dta
	}
}

drop if filler == 1
drop filler

compress
save ${temp}/01_SeparationTypes_`sex_sample'.dta, replace

forval year = $startYr_01d/$endYr_01d {
	forval group = 1/2 {
		erase ${temp}/01_SeparationTypes_`sex_sample'_`year'`group'.dta
	}
}

} // Sex samples


log close

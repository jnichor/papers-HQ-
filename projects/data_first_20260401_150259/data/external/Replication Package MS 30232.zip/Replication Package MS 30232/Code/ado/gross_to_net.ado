/*


DESCRIPTION:
This dofile transforms gross yearly earnings (not from minor employment)
to net earnings according to 2001 rates for a white collar employee without children.

Files takes two inputs which should be regular earnings in austrian schilling (bg_ats)
and special payments in austrian schilling (sz_ats).

The conversion rate from euro to schilling is factor 13.7603

Call like this: gross_to_net, bg_ats sz_ats

For questions: johanna.posch@econ.uzh.ch

LAST UPDATED:
This version has been updated 18 December 2019 by Nelson Mesker
Following were added:
Tax deductibles: Missing arbeitnehmerabsetzbetrag (750)
For tax basis: werbungskosten (1800), Sonderausgaben (819)



Sources:
Einkommensteuergesetz 1988 paragraph 16,18, 33  dated in 2001

see: https://www.ris.bka.gv.at/eli/bgbl/1988/400/P16/NOR40018829


*/

program gross_to_net
	syntax, bg_ats(varname) sz_ats(varname)

	////////////////////REGULAR INCOME///////////////////
	/*Social security contributions according to §51 ASVG (from 1/1/2001) and §2 AMPFG (UI).
	In addition there is a 0.5% "Wohnbauförderungsbeitrag" (§ 3 BG ueber die Einhebung eines Wohnbauförderungsbeitrages)
	and a 0.5% "Arbeiterkamerumlage" (§61 Arbeiterkammergesetz).
	The latter two are only levied on regular income.*/
	//substracting social security contributions
	g bg_sv_base=`bg_ats'

	g sv_contrib=0.037*bg_sv_base + 0.0925*bg_sv_base + 0.03*bg_sv_base + 0.01*bg_sv_base //in order: health insurance, pension, UI, other(Union contr etc)

	//determine tax base
	// we deduct Work-related expenses (Werbungskosten) and Special expenses (Sonderausgaben)
	g bg_tax_base=`bg_ats'-sv_contrib -1800 -819

	//calculate tax burden
	/*Tax rates on regular income are according to §33 (1) Einkommensteuergesetz*/
	g tax_burden=0
	qui replace tax_burden=0.21*(bg_tax_base-50000) if bg_tax_base>50000
	qui replace tax_burden=0.31*(bg_tax_base-100000) + 10500 if bg_tax_base>100000
	qui replace tax_burden=0.41*(bg_tax_base-300000) + 72500 if bg_tax_base>300000
	qui replace tax_burden=0.5*(bg_tax_base-700000) + 236500 if bg_tax_base>700000

	//calculate tax credit
	/*Tax alleviations on regular income are according to §33 (3) & (5) Einkommensteuergesetz*/
	g tax_allev=12200
	qui replace tax_allev=12200-1600*(bg_tax_base-122000)/(135000-122000) if bg_tax_base>122000
	qui replace tax_allev=10600+1300*(bg_tax_base-135000)/(150000-135000) if bg_tax_base>135000
	qui replace tax_allev=11900-500*(bg_tax_base-150000)/(200000-150000) if bg_tax_base>150000
	qui replace tax_allev=11400-2000*(bg_tax_base-200000)/(250000-200000) if bg_tax_base>200000
	qui replace tax_allev=9400-967*(bg_tax_base-250000)/(300000-250000) if bg_tax_base>250000
	qui replace tax_allev=8433-8433*(bg_tax_base-300000)/(487400-300000) if bg_tax_base>300000
	qui replace tax_allev=0 if bg_tax_base>487400

	// Einkommensteuergesetz 1988
	// We deduct Commuting tax credit (Verkehrsabsetzbetrag) and Wage earner’s tax credit (Arbeitnehmerabsetzbetrag)
	g tax_net=tax_burden-tax_allev -4000 -750
	qui replace tax_net= 0 if tax_net<0

	//Implementing §33(8) on negative tax burdens
	g bg_ats_net=`bg_ats'-sv_contrib-tax_net

	drop tax_burden tax_allev
	drop sv_contrib bg_tax_base bg_sv_base

	////////////////////SPECIAL PAYMENTS (holiday bonuses)///////////////////
	//substracting social security contributions
	/*According to §49 ASVG special payments - if resulting from 13th and 14th salary are
	earnings in the sense of contributing to the base of §44 and are thus subject to
	social security contributions*/
	g sz_sv_base=`sz_ats'

	g sv_contrib_sz=0.037*sz_sv_base + 0.0925*sz_sv_base + 0.03*sz_sv_base //in order: health insurance, pension, UI

	//determine tax base
	g sz_tax_base=`sz_ats'-sv_contrib_sz

	//calculate tax burden
	/*Special payments are subject to a flat tax. See §67 Einkommensteuergesetz*/
	g sz_tax_burden=0
	qui replace sz_tax_burden=0.06*(sz_tax_base-8500) if sz_tax_base>23000


	g sz_ats_net=`sz_ats'-sv_contrib_sz-sz_tax_burden

	g yearly_earn_ats_net=bg_ats_net+sz_ats_net

	drop sz_sv_base sv_contrib_sz sz_tax_base sz_tax_burden

end

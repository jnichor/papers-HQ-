/*
	
*/

capture program drop UIB_calc_austria
program UIB_calc_austria
	syntax, new_var(string) year_t(varname) inc_gross(varname) inc_gross_lag(varname) inc_net(varname)
		* new_var - variable name for the monthly UIB
		* year - replacement rate schedule to use
		* inc_gross - MONTHLY GROSS income. Used to calculate the RRs before 1996
		* inc_gross_lag - LAGGED MONTHLY GROSS income. Used to calculate RRs 1996-2000
		* inc_net - ANNUAL NET income. Used to calculate the RRs after 2000

	cap drop `new_var'
	gen `new_var' = .

	****************************************************************************
	* Calculating the replacement rates up to and including 2000
	****************************************************************************
	cap drop x_mon_ben
	gen x_mon_ben =.
	
	cap drop x_day_ben
	gen x_day_ben = .

	**** Picking which gross income to use for UIB calculations
		* Before 1996 it was based on the last month or six months' earnings
		* 1996 and after, it was based on two years ago if you lost your job Jan-Jun
		* and was based on the previous year if you lost your job July-Dec. 
	gen RR_earn = . 
	replace RR_earn = `inc_gross' if `year_t' <= 1995
	replace RR_earn = `inc_gross_lag' if `year_t' >= 1996

	**** Calculating the daily and monthly benefits
	cap program drop rr_rate_austria_1970s
	rr_rate_austria_1970s, inc(RR_earn) year_t("`year_t'")
	cap program drop rr_rate_austria_1980s	
	rr_rate_austria_1980s, inc(RR_earn) year_t("`year_t'")
	cap program drop rr_rate_austria_1990s	
	rr_rate_austria_1990s, inc(RR_earn) year_t("`year_t'")
	
	drop RR_earn

	// Replacement rate calculation
	replace `new_var' = x_day_ben*365/12 if `new_var'==.
	replace `new_var' = x_mon_ben if `new_var'==.

	****************************************************************************
	* Calculating the replacement rates after 2000
	****************************************************************************

	**** Calculate Social security earnings maximum three years in the past 
	gen yrLag = `year_t' - 3
	cap program drop earnings_max_austria
	qui earnings_max_austria, new_monthly_earn_max(x_earn_max_lag) year_t(yrLag)
	drop yrLag
	
	* After 2000: UIB is 55% of net income. If gross income is above 12/14 of the 
	* Höchstbeitragsgrundlage (the actual monthly maximum prescribed by law, not the 	
	*by-installment ASSD maximum) from 3 years before, then UIB is capped at 55% 
	* of the net income at the Höchstbeitragsgrundlage from 3 years before. 
	* There is also a UIB floor corresponding to the lesser of 55% of the 
	* Ausgleichzulagenrichtsatz or 60% of net income.
	su `year_t'
	if r(max) > 2000 {

		* Normal replacement rate - not above minimum or maximum
		replace `new_var' = (0.55*`inc_net')/12 if `year_t' > 2000
		levelsof `year_t' if `year_t' > 2000, local(years)
		foreach y in `years' {
		
			* Minimum
			local azrs2001 = 8437
			replace `new_var' = min((12*`azrs2001')/12, (0.60*`inc_net')/12) if 0.55*`inc_net' < 12*`azrs2001' & `year_t' == `y'
			
			* Maximum
			su x_earn_max_lag if `year_t' == `y'
			local max_l3 = r(mean)
			su `inc_net' if `inc_gross_lag' >= (12/14)*`max_l3' & `year_t' == `y'
			local netinc_at_max_l3 = r(min)
			replace `new_var' = (0.55*`netinc_at_max_l3')/12 if `inc_gross_lag' >= (12/14)*`max_l3' & `year_t' == `y'
		}
		
	}
	drop x_day_ben
	drop x_mon_ben
	drop x_earn_max_lag

end

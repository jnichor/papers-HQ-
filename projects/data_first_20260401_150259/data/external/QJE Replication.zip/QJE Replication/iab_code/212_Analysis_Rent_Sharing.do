*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/212/$today"
local output $log/212/$today

log using "`output'/212_Analysis_rent_sharing.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*		212 Rent Sharing Analyis
*
********************************************************************************

* Local macros
*-------------------------------------------------------------------------------

local restriction1 "const"
local restriction2 "abs(d_rel)<= 2*365"
local restriction3 "const"
local restriction4 "abs(d_rel)<= 2*365"


local controls1 const
local controls2 const
local controls3 nace_d2_grp
local controls4 nace_d2_grp

use idnr jahr nace_d2_grp const d_rel av empl cluster_variable akm_firm_fe AG GmbH prereformcohort using "$data\iab_wage_analysis_winsor1.dta" if  abs(d_rel)<=${bw_rentsharing}&jahr>=2006, clear


* Data restrictions
*-------------------------------------------------------------------------------
gen sample = (av>0)&(empl>0)&(av!=.)&(empl!=.)&(akm_firm_fe!=.) // restrict to non-missing, positive observations of BvD value added and employment, AKM Firm FE
keep if sample==1

gen legal_form_year = jahr*10 + AG // for winsorization within legal form and year

* Build variables for Graphical analysis
*-------------------------------------------------------------------------------
gen firm_category = .
replace firm_category = 1 if (AG==1)&(prereformcohort==1)
replace firm_category = 2 if (AG==1)&(prereformcohort==0)
replace firm_category = 3 if (GmbH==1)&(prereformcohort==1)
replace firm_category = 4 if (GmbH==1)&(prereformcohort==0)

*** Create and clean mean log value added
gen ln_av_emp = ln(av/empl)
winsor2 ln_av_emp, cut(1 99) replace  by(AG jahr)
egen meanlnavemp = mean(ln_av_emp), by (idnr)
winsor2 meanlnavemp, cut(1 99) replace  by(AG jahr)
global meanlnavemp_label "Labor Productivity (log(VA/Empl.))"

*** Create and clean mean AKM Firm FE
egen mean_akmfirmfe = mean(akm_firm_fe), by(idnr)
winsor2 mean_akmfirmfe, cut(1 99) replace by(AG jahr)
global mean_akmfirmfe_label "Pay Premium (AKM Firm Effect)"


*** Keep only one observation per firm
cap drop _tag
*tag because invariant within firm
egen _tag = tag(idnr) if !mi(mean_akmfirmfe) & !mi(meanlnavemp)
keep if _tag==1
duplicates drop idnr, force

*
* Graphical analysis
*-------------------------------------------------------------------------------
estimates clear
foreach regressor in  meanlnavemp {
	foreach outcome_variable in mean_akmfirmfe {
		foreach r in  1 2 3 4 { // restrictions

			 mkdir "`output'/restriction`r'"

			** restricting the bandwidth
			cap drop bandwidth_sample
			gen bandwidth_sample = 0
			replace bandwidth_sample = 1 if `restriction`r''

			*Residualize (or not residualize) and then create binned data
			if `r'<=2 {
				local regressor_binning  `regressor'
				local outcome_variable_binning  `outcome_variable'

				local regressor_binning_AG   `regressor'
				local outcome_variable_binning_AG  `outcome_variable'
			}
			if `r'>=3 {
					cap drop r_`regressor'* r_`outcome_variable'*

				reghdfe `outcome_variable' `regressor' if bandwidth_sample, absorb(`controls`r'')
				gen _esample = e(sample)

				reghdfe  `outcome_variable'  if _esample==1, absorb(`controls`r'') resid
				predict r_`outcome_variable'  if _esample==1,  residuals

				reghdfe  `regressor'  if _esample==1, absorb(`controls`r'') resid
				predict r_`regressor' if _esample==1,  residuals

				drop _esample

				* replace with residualised version
				local regressor_binning  r_`regressor'
				local outcome_variable_binning  r_`outcome_variable'

				reghdfe `outcome_variable' `regressor' if AG & bandwidth_sample, absorb(`controls`r'')
				gen _esample = e(sample)


				reghdfe  `outcome_variable'  if _esample==1 & AG & bandwidth_sample , absorb(`controls`r'') resid
				predict r_`outcome_variable'_AG  if _esample==1 & AG & bandwidth_sample,  residuals

				reghdfe  `regressor'  if _esample==1 & AG & bandwidth_sample , absorb(`controls`r'') resid
				predict r_`regressor'_AG if _esample==1 & AG & bandwidth_sample,  residuals

				drop _esample

				* replace with residualised version
				local regressor_binning_AG  r_`regressor'_AG
				local outcome_variable_binning_AG  r_`outcome_variable'_AG

			}

			* Create binned data for graphs
			preserve
				keep if bandwidth_sample==1
				xtile  _bin_var= `regressor_binning' , n(20)
		 		egen	bin_var= group(_bin_var)
				collapse `regressor_binning' `outcome_variable_binning' , by(bin_var)
				save "`output'/restriction`r'/bins_rent_`regressor'_`outcome_variable'_0.dta", replace
			restore
			preserve
				keep  if (AG==1) & (bandwidth_sample==1)
				xtile  _bin_var= `regressor_binning_AG' , n(20)
				egen	bin_var= group(_bin_var)
				collapse `regressor_binning_AG' `outcome_variable_binning_AG', by(bin_var prereformcohort)
				save "`output'/restriction`r'/bins_rent_`regressor'_`outcome_variable'_2.dta", replace
			restore
			preserve
				keep if bandwidth_sample==1
				xtile  _bin_var= `regressor_binning' , n(20)
				egen	bin_var= group(_bin_var)
				collapse `regressor_binning' `outcome_variable_binning', by(bin_var prereformcohort AG)
				save "`output'/restriction`r'/bins_rent_`regressor'_`outcome_variable'_4.dta", replace
			restore

			* Baseline specification - average rent sharing without group differentiation
			****************************

			global variant `regressor'`outcome_variable'`r'

			reghdfe  `outcome_variable'  `regressor' if bandwidth_sample, ///
				absorb(`controls`r'') cluster(cluster_variable)

			global b${variant}0 = _b[`regressor']
			local coeff: di %4.3f ${b${variant}0}
			global s${variant}0  = _se[`regressor']
			local SE: di %4.3f ${s${variant}0}
			global p${variant}0 = (2 * ttail(e(df_r), abs( ${b${variant}0} /${s${variant}0})))
			global N${variant}0  `e(N)'


			*****************************
			* All 4 groups
			****************************
			reghdfe  `outcome_variable'  c.`regressor'##i.prereformcohort##i.AG if bandwidth_sample, ///
			absorb(`controls`r'')  cluster(cluster_variable)

			global b0${variant}4 = _b[c.`regressor']
			global s0${variant}4 = _se[c.`regressor']
			global p0${variant}4 = (2 * ttail(e(df_r), abs( ${b0${variant}4} /${s0${variant}4})))

			global c1${variant}4 = _b[1.prereformcohort]
			global b1${variant}4 = _b[1.prereformcohort#c.`regressor']
			global s1${variant}4 = _se[1.prereformcohort#c.`regressor']
			global p1${variant}4 = (2 * ttail(e(df_r), abs( ${b1${variant}4} /${s1${variant}4})))

			global c2${variant}4 = _b[1.AG]
			global b2${variant}4 = _b[1.AG#c.`regressor']
			global s2${variant}4 = _se[1.AG#c.`regressor']
			global p2${variant}4 = (2 * ttail(e(df_r), abs( ${b2${variant}4} /${s2${variant}4})))

			global c3${variant}4 = _b[1.prereformcohort#1.AG]
			global b3${variant}4 = _b[1.prereformcohort#1.AG#c.`regressor']
			global s3${variant}4 = _se[1.prereformcohort#1.AG#c.`regressor']
			global p3${variant}4 = (2 * ttail(e(df_r), abs( ${b3${variant}4} /${s3${variant}4})))

			global N${variant}4  `e(N)'

			local did: di %4.3f  ${b3${variant}4}
			local didse: di %4.3f ${s3${variant}4}


			*****************************
			* Stock only
			*****************************
			reghdfe `outcome_variable'  c.`regressor'##i.prereformcohort ///
				if firm_category < 3 & bandwidth_sample, ///
				absorb(`controls`r'')  cluster(cluster_variable)

			global b0${variant}2 = _b[c.`regressor']
			global s0${variant}2 = _se[c.`regressor']
			global p0${variant}2 = (2 * ttail(e(df_r), abs( ${b0${variant}2} /${s0${variant}2})))

			global c1${variant}2 = _b[1.prereformcohort]
			global b1${variant}2 = _b[1.prereformcohort#c.`regressor']
			global s1${variant}2 = _se[1.prereformcohort#c.`regressor']
			global p1${variant}2 = (2 * ttail(e(df_r), abs( ${b1${variant}2} /${s1${variant}2})))

			global N${variant}2  `e(N)'

			local coeff: di %4.3f ${b1${variant}2}
			local SE: di %4.3f ${s1${variant}2}

		} // restrictions
	} // var
} // regressors



* Globals to dataset
*-------------------------------------------------------------------------------
foreach regressor in  meanlnavemp {
foreach outcome_variable in mean_akmfirmfe {
foreach r in  1 2 3 4 {

clear
			set obs 1

			global variant `regressor'`outcome_variable'`r'

			gen outcome = "`outcome_variable'"
			gen regressor = "`regressor'"
			gen N = ${N${variant}0}
		*	gen c = ${c${variant}0}
			gen b = ${b${variant}0}
			gen s = ${s${variant}0}
			gen p = ${p${variant}0}
			save "`output'/restriction`r'/rent_`regressor'_`outcome_variable'_0.dta", replace


			clear
			set obs 1
			gen outcome = "`outcome_variable'"
			gen regressor = "`regressor'"
			gen N = ${N${variant}2}
		*	gen c0= ${c0${variant}2}
			gen b0 = ${b0${variant}2}
			gen s0 = ${s0${variant}2}
			gen p0 = ${p0${variant}2}

			gen c1= ${c1${variant}2}
			gen b1 = ${b1${variant}2}
			gen s1 = ${s1${variant}2}
			gen p1 = ${p1${variant}2}

			save "`output'/restriction`r'/rent_`regressor'_`outcome_variable'_2.dta", replace


			clear
			set obs 1
			gen outcome = "`outcome_variable'"
			gen regressor = "`regressor'"
			gen N = ${N${variant}4}

		*	gen c0= ${c0${variant}4}
			gen b0 = ${b0${variant}4}
			gen s0 = ${s0${variant}4}
			gen p0 = ${p0${variant}4}

			gen c1= ${c1${variant}4}
			gen b1 = ${b1${variant}4}
			gen s1 = ${s1${variant}4}
			gen p1 = ${p1${variant}4}

			gen c2= ${c2${variant}4}
			gen b2 = ${b2${variant}4}
			gen s2 = ${s2${variant}4}
			gen p2 = ${p2${variant}4}

			gen c3= ${c3${variant}4}
			gen b3 = ${b3${variant}4}
			gen s3 = ${s3${variant}4}
			gen p3 = ${p3${variant}4}

			save "`output'/restriction`r'/rent_`regressor'_`outcome_variable'_4.dta", replace


		} // restrictions

} // var

} // regressors




log close

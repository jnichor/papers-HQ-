/*******************************************************************************

	DESCRIPTION: merges the data files constructed in 01a-01d and constructs a
	             balanced annual panel.

*******************************************************************************/




********************************************************************************
***** Preliminaries
********************************************************************************
cap log close
local curr_date = c(current_date)
log using "${logs}/01e_Build_AnnualPanel`curr_date'", replace




****************************************************************************
* Looping through different sex samples
****************************************************************************
foreach sex_sample in $sexSamples {




****************************************************************************
* Appending together the December samples + balancing the panel
****************************************************************************
clear
set obs 1
gen filler = 1

foreach i in $yrRanges {
	append using ${temp}/01_December_`sex_sample'_${start`i'}_${end`i'}.dta
}
drop if filler == 1
drop filler

***** Balancing the panel -- the spellData was previously balanced but not the monthly files
xtset svnr year
tsfill
replace status = 20 if status == .

gen date = mdy(12,1,year)
replace m_date = mofd(date) if mi(m_date)
drop date

****************************************************************************
* Merging on spell-variables and transition types
****************************************************************************
***** Merge spell variables
	* Not all observations in using are matched
	* Ex. individual who dies in June of a year is in using but not master
	* Only keeping observations in using -- all matched
fmerge 1:1 svnr m_date using ${temp}/01_SpellVariables_`sex_sample'.dta, assert(match using) keep(match) nogen


***** Merge transition types
	* Not all observations in using or master are matched
	* Not matched observations in master should have year greater than $endYr_01d
	* Not matched observations in using should be similar to the unmatched observations w/ spell variables
fmerge 1:1 svnr m_date year using ${temp}/01_SeparationTypes_`sex_sample'.dta
assert year > $endYr_01d if _merge == 1
drop if _merge == 2
drop _merge

tempfile appended`sex_sample'
save `appended`sex_sample'', replace

} // Different sex samples




****************************************************************************
* Append male and female samples
****************************************************************************
use `appendedmale', clear
append using `appendedfemale'

compress
save $temp/01_Panel_all_full_sample.dta, replace


log close

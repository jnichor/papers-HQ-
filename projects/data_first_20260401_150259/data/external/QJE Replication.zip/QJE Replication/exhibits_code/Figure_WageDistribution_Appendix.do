*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
set more off
clear all

* settings
local spec = 3
local wname = 1
set scheme plotplainblind

	* set folders, filenames, sample suffixes for each sample and design
local folder
local filename
local sampsuffix
local folderDiD 202
local folderDiff 203
local folderRD 201

clear

forvalue i = 10(10)90 {
	append using "${iab}/`folderDiD'/DiD_log_te_p`i'_Winsor`wname'_spec`spec'.dta"
	append using "${iab}/`folderDiff'/Diff_log_te_p`i'_Winsor`wname'_spec`spec'.dta"
	append using "${iab}/`folderRD'/RD_log_te_p`i'_Winsor`wname'_spec`spec'_AG.dta"
}

gen n = _n
forvalue i = 1(1)9 {
	replace n = `i' if outcome == "log_te_p`i'0"
}

***** Contructing Confidence Interval
gen ub =  b + s*1.96
gen lb = b - s*1.96


* tag simple difference estimates conveniently like so
gen i_DiD = (bag != . & slope1 == .)
replace i_DiD = 0 if i_DiD !=1
gen i_RD = slope1 != .
replace i_RD = 0 if i_RD !=1



* Diff first, DiD second, RD last
replace n = n - 0.15 if i_DiD == 0 & i_RD == 0
replace n = n       if i_DiD
replace n = n + 0.15 if i_RD


* generate DiD figure by wage percentiles
tw 	///
	(connected 	b 		n if i_DiD == 0 & i_RD == 0 , lc(gs10%40) lp(solid) mc(gs10) m(S) msize(medium)) ///
	(rcap 		ub lb 	n if i_DiD == 0 & i_RD == 0, lc(gs10) lp(solid) lwidth(medthick)) ///
	(connected 	b 		n if i_DiD		, lc(gs7%40) lp(dash) mc(gray) m(o) msize(medium)) ///
	(rcap 		ub lb 	n if i_DiD		, lc(gs7%60) lp(solid) lwidth(medthick)) ///
	(connected 	b 		n if i_RD		, lc(maroon%40) lp(shortdash_dot) mc(maroon) m(T) msize(large)) ///
	(rcap 		ub lb 	n if i_RD		, lc(maroon) lp(solid) lwidth(medthick)) ///
	, ///
	yline(0, lpattern(solid) lcolor(red)) ///
	ylab(-.2(.1).5,labsize(medium)) xlab(1 "p10" 2 "p20" 3 "p30" 4 "p40"  5 "p50" 6"p60" 7"p70" 8"p80" 9"p90", labsize(medium)) ///
	legend( order(5 "RD" 1 "Difference (From Main Text)" 3 "DiD (From Main Text)") col(2) size(3)  pos(2) ring(0) rows(1) ) ///
	ytitle("") xtitle("Within-Firm Wage Percentile", size(medium))

	graph export "$figures/figA5.pdf", replace

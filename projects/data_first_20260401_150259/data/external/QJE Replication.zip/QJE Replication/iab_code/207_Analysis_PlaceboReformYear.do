*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/207/$today"
local output $log/207/$today

log using "`output'/207_Analysis_PlaceboReformYear.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*		207 Analysis of the Placebo Reform Years
*
********************************************************************************


	foreach w in $winsor_values {
		use "$data\iab_wage_analysis_winsor`w'.dta" ///
		 if abs(d_rel) <= ${bw_extensive} & (AG == 1 | GmbH == 1) , clear

		tempfile data
		save `data'

		foreach placeboyear in $placebo_reform_years {

			noi di "Placebo year: `placeboyear'"
			use `data', clear

			*firm age for age plots

			drop prereformcohort
			replace d_rel = d_rel + mdy(8,10,1994) - mdy(8,10,`placeboyear')
			gen prereformcohort  = d_rel < 0
			keep if abs(d_rel) <= ${bw_standard}


			foreach i in $specifications {

				timer on 2

				noi di "Specification `i'"

				foreach outcome in $outcomes  {

					timer on 2
					noi di "	Outcome: `outcome'"

					*--------------------------------------
					*--- DiD Design
					*--------------------------------------
					noi reghdfe `outcome' i.AG##i.prereformcohort ///
					, absorb(${controls`i'}) vce(cluster cluster_variable)

					* Coefficients
					global b`outcome'`w'`i' = _b[1.AG#1.prereformcohort]
					global s`outcome'`w'`i' = _se[1.AG#1.prereformcohort]
					global p`outcome'`w'`i' = (2 * ttail(e(df_r), abs(_b[1.AG#1.prereformcohort]/_se[1.AG#1.prereformcohort])))
					global bag`outcome'`w'`i' = _b[1.AG]
					global sag`outcome'`w'`i' = _se[1.AG]
					global pag`outcome'`w'`i' = (2 * ttail(e(df_r), abs(_b[1.AG]/_se[1.AG])))
					global bpre`outcome'`w'`i' = _b[1.prereformcohort]
					global spre`outcome'`w'`i' = _se[1.prereformcohort]
					global ppre`outcome'`w'`i' = (2 * ttail(e(df_r), abs(_b[1.prereformcohort]/_se[1.prereformcohort])))
					global N`outcome'`w'`i' `e(N)'

					* Control group mean at the discontinuity
					gstats su `outcome' if e(sample)==1 & AG==1
					global Nfyag1`outcome'`w'`i' = `r(N)'

					gstats su `outcome' if e(sample)==1 & AG==0
					global Nfyag0`outcome'`w'`i' = `r(N)'

					gstats su `outcome' if d_rel >= 0 & AG == 0
					global cmag0`outcome'`w'`i' = `r(mean)'

					gstats su `outcome' if d_rel >= 0 &  AG == 1
					global cmag1`outcome'`w'`i' = `r(mean)'

					* Number of AGs and GmbHs
					gdistinct idnr if e(sample) == 1
					global Nf`outcome'`w'`i' = `r(ndistinct)'

					gdistinct idnr if e(sample) == 1 & AG == 1
					global Nag1`outcome'`w'`i' = `r(ndistinct)'

					gdistinct idnr if e(sample) == 1 & AG == 0
					global Nag0`outcome'`w'`i' = `r(ndistinct)'

					noi di "DiD ran successfully"

					*--------------------------------------
					*--- Simple Difference Design
					*--------------------------------------
					noi reghdfe `outcome' i.prereformcohort if AG == 1 ///
					, absorb(${controls`i'}) vce(cluster cluster_variable)

					* Coefficients
					global b_d`outcome'`w'`i' = _b[1.prereformcohort]
					global s_d`outcome'`w'`i' = _se[1.prereformcohort]
					global p_d`outcome'`w'`i' = (2 * ttail(e(df_r), abs(_b[1.prereformcohort]/_se[1.prereformcohort])))
					global N_d`outcome'`w'`i' `e(N)'

					gstats su `outcome' if d_rel >= 0 &  AG == 1
					global cmag1_d`outcome'`w'`i' = `r(mean)'

					* Number of AGs and GmbHs
					gdistinct idnr if e(sample) == 1
					global Nf_d`outcome'`w'`i' = `r(ndistinct)'

					gdistinct idnr if e(sample) == 1 & AG == 1
					global Nag1_d`outcome'`w'`i' = `r(ndistinct)'


					noi di "Simple Difference ran successfully"

					*--------------------------------------
					*--- RD Spec
					*--------------------------------------
					cap drop prereformcohort_d_rel
					gen prereformcohort_d_rel = (prereformcohort==1)*d_rel

					foreach legal in AG GmbH {
					noi reghdfe `outcome' i.prereformcohort d_rel prereformcohort_d_rel ///
					if `legal', ///
					absorb(${controls`i'}) vce(cluster cluster_variable)

					* Coefficients
					global b_rd`outcome'`w'`i'`legal' = _b[1.prereformcohort]
					global s_rd`outcome'`w'`i'`legal' = _se[1.prereformcohort]
					global p_rd`outcome'`w'`i'`legal' = (2 * ttail(e(df_r), abs(_b[1.prereformcohort]/_se[1.prereformcohort])))
					global N_rd`outcome'`w'`i'`legal' = `e(N)'

					* Control group mean at the discontinuity
					gstats su `outcome' if d_rel >= 0 &  `legal'
					global cmag1_rd`outcome'`w'`i'`legal' = `r(mean)'

					* Number of AGs and GmbHs
					gdistinct idnr if e(sample) == 1
					global Nf_rd`outcome'`w'`i'`legal' = `r(ndistinct)'

					gdistinct idnr if e(sample) == 1 & `legal'
					global Nag1_rd`outcome'`w'`i'`legal' = `r(ndistinct)'


					noi di "RD ran successfully"

					timer off 2
					qui timer list 2
					noi di "	Time for outcome: `r(t2)' seconds"
					timer clear 2
} // legal
				} // Outcomes

			} // Specifications

			foreach i in $specifications {

				foreach outcome in $outcomes {

					* Save DiD data
					clear
					set obs 1
					gen spec = `i'
					gen outcome = "`outcome'"
					gen winsor = `w'
					gen bandwidth = $bw_standard
					gen N = ${N`outcome'`w'`i'}
					gen b = ${b`outcome'`w'`i'}
					gen s = ${s`outcome'`w'`i'}
					gen p = ${p`outcome'`w'`i'}
					gen bag = ${bag`outcome'`w'`i'}
					gen sag = ${sag`outcome'`w'`i'}
					gen pag = ${pag`outcome'`w'`i'}
					gen bpre = ${bpre`outcome'`w'`i'}
					gen spre = ${spre`outcome'`w'`i'}
					gen ppre = ${ppre`outcome'`w'`i'}
					gen controlmean_AG = ${cmag1`outcome'`w'`i'}
					gen controlmean_nonAG = ${cmag0`outcome'`w'`i'}
					gen Nfirmyears_AG = ${Nfyag1`outcome'`w'`i'}
				    gen Nfirmyears_nonAG = ${Nfyag0`outcome'`w'`i'}
					gen Nfirms = ${Nf`outcome'`w'`i'}
					gen N_AG = ${Nag1`outcome'`w'`i'}
					gen N_nonAG = ${Nag0`outcome'`w'`i'}
					gen placeboreform = `placeboyear'

					save "`output'/DiD_Placebo_`placeboyear'_`outcome'_Winsor`w'_spec`i'.dta", replace


					* Save Difference data
					clear
					set obs 1
					gen spec = `i'
					gen outcome = "`outcome'"
					gen winsor = `w'
					gen bandwidth = $bw_standard
					gen N = ${N_d`outcome'`w'`i'}
					gen b = ${b_d`outcome'`w'`i'}
					gen s = ${s_d`outcome'`w'`i'}
					gen p = ${p_d`outcome'`w'`i'}
					gen controlmean_AG = ${cmag1_d`outcome'`w'`i'}
					gen Nfirms = ${Nf_d`outcome'`w'`i'}
					gen N_AG = ${Nag1_d`outcome'`w'`i'}
					gen placeboreform = `placeboyear'

					save "`output'/Diff_Placebo_`placeboyear'_`outcome'_Winsor`w'_spec`i'.dta", replace


					* Save RD data

					foreach legal in AG GmbH {

						clear
						set obs 1
						gen spec = `i'
						gen outcome = "`outcome'"
						gen winsor = `w'
						gen bandwidth = $bw_standard
						gen N = ${N_rd`outcome'`w'`i'`legal'}
						gen b = ${b_rd`outcome'`w'`i'`legal'}
						gen s = ${s_rd`outcome'`w'`i'`legal'}
						gen p = ${p_rd`outcome'`w'`i'`legal'}
						gen controlmean_AG = ${cmag1_rd`outcome'`w'`i'`legal'}
						gen Nfirms = ${Nf_rd`outcome'`w'`i'`legal'}
						gen N_AG = ${Nag1_rd`outcome'`w'`i'`legal'}
						gen placeboreform = `placeboyear'

						save "`output'/RD_Placebo_`placeboyear'_`outcome'_Winsor`w'_spec`i'_`legal'.dta", replace
						} // legal

				} // Outcome
			} // Specification
		} // Placebo Years
	} // Winsor values




log close

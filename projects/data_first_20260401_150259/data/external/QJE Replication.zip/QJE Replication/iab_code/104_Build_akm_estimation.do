*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================


cap log close

log using "$log/104_Build_akm_estimation.txt", replace text


********************************************************************************
*
*
*			104 AKM Estimation
*
*
********************************************************************************

forvalues middle_year = $akm_start_year/$akm_end_year {
	clear
	local siab_start_year = `middle_year' - ${akm_radius_in_years}
	local siab_end_year = `middle_year' + ${akm_radius_in_years}

	forvalues siab_year = `siab_start_year'/`siab_end_year' {

		append using "$data/siab_bvdid_clean_AKM_`siab_year'.dta"

	} // append input data


	keep idnr persnr logdailywage edu_exp_* jahr

	* AKM regression
	reghdfe logdailywage edu_exp_*, absorb(pers_fe = persnr akm_firm_fe = idnr year_fe =  jahr, savefe) groupvar(mobility_group) poolsize(1)

	* Extract largest connected set
	bys mobility_group: egen n_obs_mobility_group = count(persnr) if mobility_group!=.
	sum n_obs_mobility_group, detail
	keep if n_obs_mobility_group==r(max)

	* Clean up and keep only year in the middle
	keep if jahr==`middle_year'
	collapse pers_fe akm_firm_fe jahr, by(idnr)
	sort idnr
	compress

	* Save
 	save "${data}/akm_`middle_year'.dta", replace
} // estimation windows


clear
forvalues middle_year = $akm_start_year/$akm_end_year {

	append using "${data}/akm_`middle_year'.dta"
	erase "${data}/akm_`middle_year'.dta"

} // append AKM data


save "${data}/akm.dta", replace

log close

/*******************************************************************************

	DESCRIPTION: estimate days in U / days in N for all individuals (not just separators).

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off


***** Logging
cap log close
local curr_date = c(current_date)
log using "${logs}/09b_Build_TauEstimates_FullSample`curr_date'", replace





********************************************************************************
***** Looping through different sample restrictions to generate tau for
	* These different tau samples correspond to the different columns in the tau tables
	* Ret’nt or Disability -- DeathRetDis`age'_PermEU
	* Retirement -- DeathRet`age'_PermEU
	* No restriction -- Death`age'
********************************************************************************
foreach x in $tau_samples {

	noi di "Prepare data for N > ${day}..."

	foreach year in $prereformyears {
		timer clear
		timer on 1




		********************************************************************************
		***** Identifying all spells that
		********************************************************************************

		***** Loading spells where individuals are alive and less than 70 on the first of the month
		noi use "${temp}/09b_Data_Tau_year${vyear}-${byear}_age${vage}-${bage}_days1_qualappended_Adjusted_UIvsUA.dta" if bdat >= mdy(1,1,`year') & floor(birthdat + 70*360.25) >= mdy(1,1,`year') & deathdat >= mdy(1,1,`year'), clear


		* Find the date that is 16 years after the first of the year
		gen sixteenyearslater = mdy(1,1,`year') + (16*365)
		format sixteenyearslater %d
		gen datetype_text = "16 Years Later"



		* Variables aren't used for full-sample estimates
		foreach i in ${returnWorkLim} {
			gen ENE`i' = 1
		}




		********************************************************************************
		***** For each age limit -- calculating the counting ending date based on different criteria
		********************************************************************************
		foreach age in $age_limit {

			***** Ending at the minimum of 16 years later, turning age $age_limit, or death
			if "`x'" == "Death`age'" {
				* Persons who first turn 70
				replace sixteenyearslater =  floor(birthdat + `age'*365.25)	if floor(birthdat + `age'*365.25)<sixteenyearslater

				* Persons who first die
				replace datetype_text = "Death" 					if deathdat<sixteenyearslater	& !mi(deathdat)
				replace sixteenyearslater = deathdat				if deathdat<sixteenyearslater	& !mi(deathdat)

			}

			***** Ending at 16 years later, turning age limit, death, or absorbing retirement or disability
			if "`x'" == "DeathRetDis`age'_PermEU" {
				* Persons who first turn 70
				replace sixteenyearslater =  floor(birthdat + `age'*365.25)	if floor(birthdat + `age'*365.25)<sixteenyearslater

				* Persons who first die
				replace datetype_text = "Death" 					if deathdat<sixteenyearslater	& !mi(deathdat)
				replace sixteenyearslater = deathdat				if deathdat<sixteenyearslater	& !mi(deathdat)


				***** Absorbing retirement or disability
					* Note defines last_EUenddate as last EU end date before sixteen years later
					* this causes problems for very old people but it won't matter
				* Find the end date of each E or U spell
				gen EU_enddate = bdat if inlist(status, 1,2,3) & vdat < sixteenyearslater & bdat <= sixteenyearslater
				* Find the last end date of each E/U spell in the data
				bys svnr (vdat bdat): gegen last_EUenddate = max(EU_enddate)
				* Find the start dates of any retirement or disability spell after the last end date of E/U spells
				gen RD_startdate_postEU = vdat if vdat > last_EUenddate & (retirement == 1 | disability == 1)
				* Find the earliest start date of the retirement/disability spells after the last end date of E/U spells
				bys svnr (vdat bdat): gegen first_RDstart_postEU = min(RD_startdate_postEU)
				* Replace the last day of counting with this date if it is earlier than the date of turning `age' or dying
				replace datetype_text = "R/D Post"					if first_RDstart_postEU<sixteenyearslater	& !mi(first_RDstart_postEU)		// persons on disability before age 54
				replace sixteenyearslater = first_RDstart_postEU		if first_RDstart_postEU<sixteenyearslater & !mi(first_RDstart_postEU)
				* Drop temporary variables
				drop EU_enddate last_EUenddate RD_startdate_postEU
			}

			if "`x'" == "DeathRet`age'_PermEU" {
				* Persons who first turn 70
				replace sixteenyearslater =  floor(birthdat + `age'*365.25)	if floor(birthdat + `age'*365.25)<sixteenyearslater

				* Persons who first die
				replace datetype_text = "Death" 					if deathdat<sixteenyearslater	& !mi(deathdat)
				replace sixteenyearslater = deathdat				if deathdat<sixteenyearslater	& !mi(deathdat)


				***** Absorbing retirement

				* Find the end date of each E or U spell
				gen EU_enddate = bdat if inlist(status, 1,2,3) & vdat < sixteenyearslater & bdat <= sixteenyearslater
				* Find the last end date of each E/U spell in the data
				bys svnr (vdat bdat): gegen last_EUenddate = max(EU_enddate)
				* Find the start dates of any retirement or disability spell after the last end date of E/U spells
				gen RD_startdate_postEU = vdat if vdat > last_EUenddate & retirement == 1
				* Find the earliest start date of the retirement/disability spells after the last end date of E/U spells
				bys svnr (vdat bdat): gegen first_RDstart_postEU = min(RD_startdate_postEU)
				* Replace the last day of counting with this date if it is earlier than the date of turning `age' or dying
				replace datetype_text = "R Post"					if first_RDstart_postEU<sixteenyearslater	& !mi(first_RDstart_postEU)		// persons on disability before age 54
				replace sixteenyearslater = first_RDstart_postEU		if first_RDstart_postEU<sixteenyearslater & !mi(first_RDstart_postEU)
				* Drop temporary variables
				drop EU_enddate last_EUenddate RD_startdate_postEU
			} //
		} // Age limits




		********************************************************************************
		***** Total amount of time spent in each state up until the ending date
		********************************************************************************
		* Total find from separation to end -- sometimes negative for individuals over 70
		gen total_time = sixteenyearslater - mdy(1,1,`year') + 1

		* Keep only spells that start before 16 years post-separation
		drop if vdat > sixteenyearslater

		* Keep only portion of subsequent spells that is within 16 years of separation + within current year
		replace vdat = mdy(1,1,`year') if vdat <= mdy(12,31,`year'-1)
		replace bdat = sixteenyearslater if bdat > sixteenyearslater

		gen byte UI = status == 1
		gen byte UA = status == 2
		gen byte E = status == 3
		gen byte O = status == 4

		gen datetype = .
		replace datetype = 1 if datetype_text == "16 Years Later"
		replace datetype = 2 if datetype_text == "Death"
		replace datetype = 3 if datetype_text == "Retirement"
		replace datetype = 4 if datetype_text == "Disability"
		replace datetype = 5 if datetype_text == "R/D Post"
		gen length = bdat - vdat + 1

		fcollapse (sum) E UI UA O (mean) total_time ENE* datetype [weight = length], by(svnr)
		gen tot_obs_time = E + UI + UA + O
		assert tot_obs_time <= total_time
		drop tot_obs_time

		ds E UI UA O
		foreach var in `r(varlist)' {
			gen `var'_frac = `var' / total_time
		}

		gen N_frac = 1 - UI_frac - UA_frac - E_frac - O_frac



		compress
		save ${temp_qual}/09b_Tau_Year`year'_`x'_WithDateType_UIvsUA_FromStartofYear.dta, replace
		timer off 1
		qui timer list 1
		local time: di %5.3f `r(t1)'/60
		noi di "Time for `year': `time' minutes"

	}
}




***** Appending together the tau samples
foreach x in $tau_samples {
clear
set obs 1
gen year = 999
foreach year in $prereformyears {
	append using ${temp_qual}/09b_Tau_Year`year'_`x'_WithDateType_UIvsUA_FromStartofYear.dta
	replace year = `year' - 1 if mi(year)
}
drop if year == 999
save ${temp}/09b_Tau_Appended_`x'_WithDateType_UIvsUA_FromStartofYear.dta, replace
}


log close

*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/205/$today"
local output $log/205/$today

log using "`output'/205_analysis_bandwidth.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*		205 Analysis Bandwidth
*
********************************************************************************

foreach w in $winsor_values { // winsor values

	noi di "Winsorization `w' %"

	* load winsorized data
	use "$data\iab_wage_analysis_winsor`w'.dta" ///
	if abs(d_rel) <= ${bw_extensive} & (AG==1 | GmbH==1), clear

	tempfile data
	save `data'
	foreach robust in 1 /*2 3*/ { // robustness checks
 foreach outcome in $outcomes { // outcomes
			foreach i in 2 3 { // specifications
				forval j = 6/$bandwidth_windows { // fraction of bandwidth



						use `data', clear
					 	noi capture {



							* create bandwidth global
							* global b`outcome'`j' = (`j'/(($bandwidth_windows)/2.5)) * ${bw_standard}
							global b`outcome'`j' = (`j'/12) * 365


							*--------------------------------------
							*--- DiD Spec
							*--------------------------------------
							noi di "Design : Difference in Difference "
							noi di "	Outcome: `outcome'"
							noi di "Specification: ${controls`i'}"
							noi di "	Bandwidth Window: Month <= `j'"

							noi reghdfe `outcome' i.AG##i.prereformcohort ///
							if abs(d_rel) <= ${b`outcome'`j'} ${robust`robust'}, ///
							a(${controls`i'}) vce(cluster cluster_variable)

							* Coefficient and SE
							global c_did`outcome'`w'`robust'`i'`j' = _b[1.AG#1.prereformcohort]
							global s_did`outcome'`w'`robust'`i'`j' = _se[1.AG#1.prereformcohort]

							* Number of AGs
							gdistinct idnr if e(sample) & AG
							global Nag1_did`outcome'`w'`robust'`i'`j' = `r(ndistinct)'

							* Control Mean
							gstats su `outcome' if d_rel >= 0 & e(sample) & AG
							global cmag1_did`outcome'`w'`robust'`i'`j' = `r(mean)'


							*--------------------------------------
							*--- Simple Difference Spec
							*--------------------------------------
							noi di "Design : Simple Difference "
							noi di "Specification: ${controls`i'}"
							noi di "	Bandwidth Window: Month <= `j'"
							noi di "	Outcome: `outcome'"

							* regression with only Year FE (spec 2)
							noi reghdfe `outcome' i.prereformcohort ///
							if abs(d_rel) <= ${b`outcome'`j'} & AG==1 ${robust`robust'}, ///
							absorb(${controls`i'}) vce(cluster cluster_variable)

							* coefficient and SE
							global c_d`outcome'`w'`robust'`i'`j' = _b[1.prereformcohort]
							global s_d`outcome'`w'`robust'`i'`j' = _se[1.prereformcohort]

							* Number of AGs
							gdistinct idnr if e(sample) & AG
							global Nag1_d`outcome'`w'`robust'`i'`j' = `r(ndistinct)'

							* Control Mean
							gstats su `outcome' if d_rel >= 0 & e(sample) & AG
							global cmag1_d`outcome'`w'`robust'`i'`j' = `r(mean)'


							*--------------------------------------
							*--- RD Spec
							*--------------------------------------
							noi di "Design : Regression Discontinuity "
							noi di "Specification: ${controls`i'}"
							noi di "	Bandwidth Window: Month <= `j'"
							noi di "	Outcome: `outcome'"


							* regression with only Year FE (spec 2)
							noi reghdfe `outcome' i.prereformcohort d_rel prereformcohort_d_rel ///
							if abs(d_rel) <= ${b`outcome'`j'} & AG==1 ${robust`robust'} , ///
							absorb(${controls`i'}) vce(cluster cluster_variable)

							* coefficient and SE
							global c_rd`outcome'`w'`robust'`i'`j' = _b[1.prereformcohort]
							global s_rd`outcome'`w'`robust'`i'`j' = _se[1.prereformcohort]

							* Number of AGs
							gdistinct idnr if e(sample)==1 & AG==1
							global Nag1_rd`outcome'`w'`robust'`i'`j' = `r(ndistinct)'

							* Control Mean
							gstats su `outcome' if d_rel >= 0 & e(sample)==1 & AG==1
							global cmag1_rd`outcome'`w'`robust'`i'`j' = `r(mean)'
						} //capture

				} // Bandwidth in months

			} // Specifications
		} // Outcomes
	} // Robustness checks

	foreach robust in 1 /*2 3*/ { // robustness checks
		foreach i in 2 3 /*1*/ { // specifications
			foreach outcome in $outcomes {



				clear
				qui set obs 100
				qui gen value = _n
				qui gen b = (12 * (value/24) * ${bw_standard})/365
				qui replace b = . if value > 60

				qui foreach var in c s Nag1 cmag1 {
					foreach design in did d rd {
						qui gen `var'_`design' = .
						forval j = 6/$bandwidth_windows {


							qui cap replace `var'_`design' = ${`var'_`design'`outcome'`w'`robust'`i'`j'} if value == `j'
						}
					}
				}

				qui foreach design in did d rd {
					gen ub_`design' = c_`design' + (1.96*s_`design')
					gen lb_`design' = c_`design' - (1.96*s_`design')
				}

				save "`output'/Bandwidth_`outcome'_Winsor`w'_spec`i'${robustness`robust'}.dta", replace

			} // Outcome
		} // specifications
	} // robustness


} // winsorvalues

log close

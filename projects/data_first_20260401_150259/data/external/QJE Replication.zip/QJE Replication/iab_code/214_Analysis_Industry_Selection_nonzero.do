*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/213/$today"
local output $log/213/$today

log using "`output'/213_Industry_Selection_nonzero.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*		213 Industry Composition Balance test (nonzero)
*
********************************************************************************


use "$data\iab_wage_analysis_winsor1.dta"if abs(d_rel) <= ${bw_standard} & (AG == 1 | GmbH == 1) , clear


* Create Level 1 NACE codes by classifying 2-digit NACE codes from here:
* http://www.export.gov.il/files/EEN/ListNACEcodes.pdf

gen i_nace_A = inlist(nace_d2, 01, 02, 03)
gen i_nace_B = inlist(nace_d2, 05, 06, 07, 08, 09)
gen i_nace_C = inlist(nace_d1, 1, 2) | inlist(nace_d2, 30, 31, 32, 33)
gen i_nace_D = inlist(nace_d2, 35)
gen i_nace_E = inlist(nace_d2, 36, 37, 38, 39)
gen i_nace_F = inlist(nace_d2, 41, 42, 43)
gen i_nace_G = inlist(nace_d2, 45, 46, 47)
gen i_nace_H = inlist(nace_d2, 49, 50, 51, 52, 53)
gen i_nace_I = inlist(nace_d2, 55, 56)
gen i_nace_J = inlist(nace_d2, 58, 59, 60, 61, 62, 63)
gen i_nace_K = inlist(nace_d2, 64, 65, 66)
gen i_nace_L = inlist(nace_d2, 68)
gen i_nace_M = inlist(nace_d2, 69, 70, 72, 73, 74)
gen i_nace_N = inlist(nace_d2, 77, 78, 79, 80, 81, 82)
gen i_nace_O = inlist(nace_d2, 84)
gen i_nace_P = inlist(nace_d2, 85)
gen i_nace_Q = inlist(nace_d2, 86, 87, 88)
gen i_nace_R = inlist(nace_d2, 90, 91, 92, 93)
gen i_nace_S = inlist(nace_d2, 94, 95, 96)
gen i_nace_T = inlist(nace_d2, 97, 98)
gen i_nace_U = inlist(nace_d2, 99)

cap estimates drop _all

* Quarterly controls
cap drop cohort i
gen cohort = qofd(dateinc)
format %tq cohort

* Drop if no firms in the category
ds i_nace_*
qui foreach var in `r(varlist)' {
	gstats sum `var'
	if `r(mean)' == 0 {
		drop `var'
		noi di "No firm has `var' = 1, so `var' is dropped."
	}
}

ds i_nace_*
local nace_list `r(varlist)'

* Create the number of the observation within firm ID
bys idnr (jahr): gen i = _n
keep if i == 1

foreach i in 1  {

	estimates drop _all
	timer on 2

	noi di "Specification `i'"

	foreach type in nace {
		foreach outcome in ``type'_list'  {
			timer on 2

			noi di "	Outcome: `outcome'"

			local letter = substr("`outcome'", -1,1)


			*--------------------------------------
			*--- DiD Design
			*--------------------------------------

            qui count  if AG & prereformcohort & `outcome'==1
			local npre = `r(N)'
			qui count if AG & prereformcohort == 0 & `outcome'==1
			local npost = `r(N)'
			if  `npost' <= 1 {

				noi di "		Skipping `outcome'"
				global c`outcome'`wname'`i' = .
				global s`outcome'`wname'`i' = .
				global p`outcome'`wname'`i' = .
				global cag`outcome'`wname'`i' = .
				global sag`outcome'`wname'`i' = .
				global pag`outcome'`wname'`i' = .
				global cind`outcome'`wname'`i' = .
				global sind`outcome'`wname'`i' = .
				global pind`outcome'`wname'`i' = .
				global N`outcome'`wname'`i' = .
				global cmag0`outcome'`wname'`i' = .
				global cmag1`outcome'`wname'`i' = .
				global Nf`outcome'`wname'`i' = .
				global Nag1`outcome'`wname'`i' = .
				global Nag0`outcome'`wname'`i' = 0

			}
			else {
			reg `outcome' i.AG##i.prereformcohort

			estimates store did_`outcome'`i'

			reg `outcome' i.AG##i.prereformcohort , vce(robust)


			global c`outcome'`i' = _b[1.AG#1.prereformcohort]
			global s`outcome'`i' = _se[1.AG#1.prereformcohort]
			global p`outcome'`i' = (2 * ttail(e(df_r), abs(_b[1.AG#1.prereformcohort]/_se[1.AG#1.prereformcohort])))
			global cag`outcome'`i' = _b[1.AG]
			global sag`outcome'`i' = _se[1.AG]
			global pag`outcome'`i' = (2 * ttail(e(df_r), abs(_b[1.AG]/_se[1.AG])))
			global cind`outcome'`i' = _b[1.prereformcohort]
			global sind`outcome'`i' = _se[1.prereformcohort]
			global pind`outcome'`i' = (2 * ttail(e(df_r), abs(_b[1.prereformcohort]/_se[1.prereformcohort])))
			global N`outcome'`i' `e(N)'


			gdistinct idnr if e(sample) == 1
			global Nf`outcome'`i' = `r(ndistinct)'

			gdistinct idnr if e(sample) == 1 & AG == 1
			global Nag1`outcome'`i' = `r(ndistinct)'

			gdistinct idnr if e(sample) == 1 & AG == 0
			global Nag0`outcome'`i' = `r(ndistinct)'

			* Control group mean at the discontinuity, i.e. in the first 30 days of the reform
			gstats su `outcome' if d_rel >= 0 & AG == 0
			global cmag0`outcome'`i' = `r(mean)'

			gstats su `outcome' if d_rel >= 0  & AG == 1
			global cmag1`outcome'`i' = `r(mean)'

            }

			*--------------------------------------
			*--- Simple Difference Design
			*--------------------------------------

			qui count  if AG & prereformcohort & `outcome'==1
			local npre = `r(N)'
			qui count if AG & prereformcohort == 0 & `outcome'==1
			local npost = `r(N)'
			if  `npost' <= 1 {

				noi di "		Skipping `outcome'"
				global c_d`outcome'`wname'`i' = .
				global s_d`outcome'`wname'`i' = .
				global p_d`outcome'`wname'`i' = .
				global cag_d`outcome'`wname'`i' = .
				global sag_d`outcome'`wname'`i' = .
				global pag_d`outcome'`wname'`i' = .
				global cind_d`outcome'`wname'`i' = .
				global sind_d`outcome'`wname'`i' = .
				global pind_d`outcome'`wname'`i' = .
				global N_d`outcome'`wname'`i' = .
				global cmag0_d`outcome'`wname'`i' = .
				global cmag1_d`outcome'`wname'`i' = .
				global Nf_d`outcome'`wname'`i' = .
				global Nag1_d`outcome'`wname'`i' = .
				global Nag0_d`outcome'`wname'`i' = 0

			}

			else {

				reg `outcome' i.prereformcohort if AG

				estimates store diff_`outcome'`i'

				reg `outcome' i.prereformcohort  if AG, vce(robust)


				* Coefficients
				global c_d`outcome'`wname'`i' = _b[1.prereformcohort]
				global s_d`outcome'`wname'`i' = _se[1.prereformcohort]
				global p_d`outcome'`wname'`i' = (2 * ttail(e(df_r), abs(_b[1.prereformcohort]/_se[1.prereformcohort])))
				global cag_d`outcome'`wname'`i' = .
				global sag_d`outcome'`wname'`i' = .
				global pag_d`outcome'`wname'`i' = .
				global cind_d`outcome'`wname'`i' = .
				global sind_d`outcome'`wname'`i' = .
				global pind_d`outcome'`wname'`i' = .
				global N_d`outcome'`wname'`i' `e(N)'

				* Control group mean at the discontinuity
				//gstats su `outcome' if d_rel >= 0 & AG == 0
				global cmag0_d`outcome'`wname'`i' = .

				gstats su `outcome' if d_rel >= 0 &  AG == 1
				global cmag1_d`outcome'`wname'`i' = `r(mean)'

				* Number of AGs and GmbHs
				gdistinct idnr if e(sample) == 1
				global Nf_d`outcome'`wname'`i' = `r(ndistinct)'

				gdistinct idnr if e(sample) == 1 & AG == 1
				global Nag1_d`outcome'`wname'`i' = `r(ndistinct)'

				//gdistinct idnr if e(sample) == 1 & AG == 0
				global Nag0_d`outcome'`wname'`i' = 0

			}

			*--------------------------------------
			*--- RD Design
			*--------------------------------------


			qui count  if AG & prereformcohort & `outcome'==1
			local npre = `r(N)'
			qui count if AG & prereformcohort == 0 & `outcome'==1
			local npost = `r(N)'
			if  `npost' <= 1 {

				noi di "		Skipping `outcome'"
				global c_rd`outcome'`wname'`i' = .
				global s_rd`outcome'`wname'`i' = .
				global p_rd`outcome'`wname'`i' = .
				global cag_rd`outcome'`wname'`i' = .
				global sag_rd`outcome'`wname'`i' = .
				global pag_rd`outcome'`wname'`i' = .
				global cind_rd`outcome'`wname'`i' = .
				global sind_rd`outcome'`wname'`i' = .
				global pind_rd`outcome'`wname'`i' = .
				global N_rd`outcome'`wname'`i' = .
				global cmag0_rd`outcome'`wname'`i' = .
				global cmag1_rd`outcome'`wname'`i' = .
				global Nf_rd`outcome'`wname'`i' = .
				global Nag1_rd`outcome'`wname'`i' = .
				global Nag0_rd`outcome'`wname'`i' = 0

			}

			else {

				reg `outcome' i.prereformcohort d_rel prereformcohort_d_rel if AG

				estimates store RD_`outcome'`i'

				reg `outcome' i.prereformcohort d_rel prereformcohort_d_rel if AG, vce(robust)


				* Coefficients
				global c_rd`outcome'`wname'`i' = _b[1.prereformcohort]
				global s_rd`outcome'`wname'`i' = _se[1.prereformcohort]
				global p_rd`outcome'`wname'`i' = (2 * ttail(e(df_r), abs(_b[1.prereformcohort]/_se[1.prereformcohort])))
				global cag_rd`outcome'`wname'`i' = .
				global sag_rd`outcome'`wname'`i' = .
				global pag_rd`outcome'`wname'`i' = .
				global cind_rd`outcome'`wname'`i' = .
				global sind_rd`outcome'`wname'`i' = .
				global pind_rd`outcome'`wname'`i' = .
				global N_rd`outcome'`wname'`i' `e(N)'

				* Control group mean at the discontinuity
				//gstats su `outcome' if d_rel >= 0 & AG == 0
				global cmag0_rd`outcome'`wname'`i' = .

				gstats su `outcome' if d_rel >= 0 &  AG == 1
				global cmag1_rd`outcome'`wname'`i' = `r(mean)'

				* Number of AGs and GmbHs
				gdistinct idnr if e(sample) == 1
				global Nf_rd`outcome'`wname'`i' = `r(ndistinct)'

				gdistinct idnr if e(sample) == 1 & AG == 1
				global Nag1_rd`outcome'`wname'`i' = `r(ndistinct)'

				//gdistinct idnr if e(sample) == 1 & AG == 0
				global Nag0_rd`outcome'`wname'`i' = 0

			}


			timer off 2
			qui timer list 2
			noi di "	Time for outcome: `r(t2)' seconds"
			timer clear 2

		} // Outcomes

		* joint p-value for DiD
		suest did_i_`type'_*, vce(robust)
		noi test 1.AG#1.prereformcohort

		global did_chi_`type'`i' = r(chi2)
		global did_p_`type'`i' = r(p)

		noi di "	DiD p-value for `sample' `famowner' `type'`i' : ${did_p_`type'`i'}"


		* joint p-value for Diff
		suest diff_i_`type'_*, vce(robust)
		noi test 1.prereformcohort

		global diff_chi_`type'`i' = r(chi2)
		global diff_p_`type'`i' = r(p)

		noi di "	Diff p-value for `sample' `famowner' `type'`i' : ${diff_p_`type'`i'}"


		* joint p-value for RD
		suest RD_i_`type'_*, vce(robust)
		noi test 1.prereformcohort

		global RD_chi_`type'`i' = r(chi2)
		global RD_p_`type'`i' = r(p)

		noi di "	RD p-value for `sample' `famowner' `type'`i' : ${RD_p_`type'`i'}"



	} // Industry 

} // Specifications

foreach i in 1  {

	foreach type in nace {
		foreach outcome in ``type'_list'  {


			* Save data from DiD regressions
			clear
			set obs 1
			gen spec = `i'
			gen outcome = "`outcome'"
			gen winsor = 1
			gen bandwidth = $bw_standard
			gen b = ${c`outcome'`i'}
			gen s = ${s`outcome'`i'}
			gen p = ${p`outcome'`i'}
			gen bag = ${cag`outcome'`i'}
			gen sag = ${sag`outcome'`i'}
			gen pag = ${pag`outcome'`i'}
			gen bind = ${cind`outcome'`i'}
			gen sind = ${sind`outcome'`i'}
			gen pind = ${pind`outcome'`i'}
			gen controlmean_AG = ${cmag1`outcome'`i'}
			gen controlmean_nonAG = ${cmag0`outcome'`i'}
			gen N  = ${N`outcome'`i'}
			gen Nfirms = ${Nf`outcome'`i'}
			gen N_AG = ${Nag1`outcome'`i'}
			gen N_nonAG = ${Nag0`outcome'`i'}
			gen chi_jointtest = ${did_chi_`type'`i'}
			gen p_jointtest = ${did_p_`type'`i'}

			save "`output'/Industry_DiD_`outcome'_spec`i'.dta", replace


			* Save Difference data
			clear
			set obs 1
			gen spec = `i'
			gen outcome = "`outcome'"
			gen winsor = 0
			gen bandwidth = $bw_standard
			gen N = ${N_d`outcome'`wname'`i'}
			gen b = ${c_d`outcome'`wname'`i'}
			gen s = ${s_d`outcome'`wname'`i'}
			gen p = ${p_d`outcome'`wname'`i'}
			gen bag = ${cag_d`outcome'`wname'`i'}
			gen sag = ${sag_d`outcome'`wname'`i'}
			gen pag = ${pag_d`outcome'`wname'`i'}
			gen bind = ${cind_d`outcome'`wname'`i'}
			gen sind = ${sind_d`outcome'`wname'`i'}
			gen pind = ${pind_d`outcome'`wname'`i'}
			gen controlmean_AG = ${cmag1_d`outcome'`wname'`i'}
			gen controlmean_nonAG = ${cmag0_d`outcome'`wname'`i'}
			gen Nfirms = ${Nf_d`outcome'`wname'`i'}
			gen N_AG = ${Nag1_d`outcome'`wname'`i'}
			gen N_nonAG = ${Nag0_d`outcome'`wname'`i'}
			gen chi_jointtest = ${diff_chi_`type'`i'}
			gen p_jointtest = ${diff_p_`type'`i'}

			save "`output'/Industry_Diff_`outcome'_spec`i'.dta", replace


			* Save RD data
			clear
			set obs 1
			gen spec = `i'
			gen outcome = "`outcome'"
			gen winsor = 0
			gen bandwidth = $bw_standard
			gen N = ${N_rd`outcome'`wname'`i'}
			gen b = ${c_rd`outcome'`wname'`i'}
			gen s = ${s_rd`outcome'`wname'`i'}
			gen p = ${p_rd`outcome'`wname'`i'}
			gen bag = ${cag_rd`outcome'`wname'`i'}
			gen sag = ${sag_rd`outcome'`wname'`i'}
			gen pag = ${pag_rd`outcome'`wname'`i'}
			gen bind = ${cind_rd`outcome'`wname'`i'}
			gen sind = ${sind_rd`outcome'`wname'`i'}
			gen pind = ${pind_rd`outcome'`wname'`i'}
			gen controlmean_AG = ${cmag1_rd`outcome'`wname'`i'}
			gen controlmean_nonAG = ${cmag0_rd`outcome'`wname'`i'}
			gen Nfirms = ${Nf_rd`outcome'`wname'`i'}
			gen N_AG = ${Nag1_rd`outcome'`wname'`i'}
			gen N_nonAG = ${Nag0_rd`outcome'`wname'`i'}
			gen chi_jointtest = ${RD_chi_`type'`i'}
			gen p_jointtest = ${RD_p_`type'`i'}

			save "`output'/Industry_RD_`outcome'_spec`i'.dta", replace


		} // Outcome
	} // Industry or State
} // Specification







log close



program rr_rate_austria
	syntax, new_var(string) inc(varname) year_t(varname)

	cap drop `new_var'
	gen `new_var' = .

	cap drop x_mon_ben
	gen x_mon_ben =.

	cap drop x_day_ben
	gen x_day_ben = .

	cap program drop rr_rate_austria_1970s
	rr_rate_austria_1970s, inc("`inc'") year_t("`year_t'")
	cap program drop rr_rate_austria_1980s
	rr_rate_austria_1980s, inc("`inc'") year_t("`year_t'")
	cap program drop rr_rate_austria_1990s
	rr_rate_austria_1990s, inc("`inc'") year_t("`year_t'")

	// Calculate Social security earnings maximum
	cap program drop earnings_max_austria
	earnings_max_austria, new_monthly_earn_max(x_earn_max) year_t(`year_t')
	cap program drop earnings_min_austria
	earnings_min_austria, new_monthly_earn_min(x_earn_min) year_t(`year_t')
	// Replacement rate calculation
	replace `new_var' = x_day_ben*365/12/`inc' if `new_var'==.
	replace `new_var' = x_mon_ben/`inc' if `new_var'==.

	* After 2000: UIB is 55% of net income. If gross income is above 12/14 of the
	* Höchstbeitragsgrundlage (the actual monthly maximum prescribed by law, not the
	*by-installment ASSD maximum) from 3 years before, then UIB is capped at 55%
	* of the net income at the Höchstbeitragsgrundlage from 3 years before.
	* There is also a UIB floor corresponding to the lesser of 55% of the
	* Ausgleichzulagenrichtsatz or 60% of net income.
	qui su `year_t'
	if r(max) > 2000 {
		gen anninc = 12*`inc'
		gen simulbg = (12/14)*anninc
		gen simulsz = (2/14)*anninc
		gross_to_net, bg_ats(simulbg) sz_ats(simulsz)
		replace `new_var' = (0.55*yearly_earn_ats_net)/anninc if `year_t' > 2000
		qui levelsof `year_t' if `year_t' > 2000, local(years)
		foreach y in `years' {
		
			* Minimum
			local azrs2001 = 8437
			replace `new_var' = min((12*`azrs2001')/anninc, (0.60*yearly_earn_ats_net)/anninc) if 0.55*yearly_earn_ats_net < 12*`azrs2001' & `year_t' == `y'

			* Maximum
			qui su x_earn_max if `year_t' == `y' - 3
			local max_l3 = r(mean)
			qui su yearly_earn_ats_net if `inc' >= (12/14)*`max_l3' & `year_t' == `y'
			local netinc_at_max_l3 = r(min)
			replace `new_var' = (0.55*`netinc_at_max_l3')/anninc if `inc' >= (12/14)*`max_l3' & `year_t' == `y'
		}

	drop anninc
	}
	drop x_day_ben
	drop x_mon_ben

end

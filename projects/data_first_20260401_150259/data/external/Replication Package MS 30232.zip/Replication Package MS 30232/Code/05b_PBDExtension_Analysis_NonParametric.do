/*******************************************************************************

	DESCRIPTION: Non-parametric analysis of PBD extension reform by age.



*******************************************************************************/

****************************************************************************
***** Preliminaries
****************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/05b_PBDExtension_Analysis_NonParametric`curr_date'", replace

****************************************************************************
* Treatment and control parameters
****************************************************************************
* Control start and end ages
local cnt_start = 35
local cnt_end = 38

* Treatment start and end ages
local treat_start = 39
local treat_end = 42

* Weeks of experience in the past 10 years required to be eligible for
local exp_weeks = 312

* Year to normalize treatment efect equal to zero for
local excld_yr = 1987

* Starting and ending years
local start_yr = 1983
local end_yr = 1989




	use ${temp}/05a_DataSet.dta, clear

	**** One and two-year earnings outcomes
	foreach yrfwd in $earnF {
		preserve

		local treatYr = 1988

		* Defining reference years and figure information
		if `yrfwd' == 1 {
			local contYr = 1987
			local chngLen "One"
			local treatLeg "'88-'89"
			local contLeg "'87-'88"
		}
		else if `yrfwd' == 2 {
			local contYr = 1986
			local chngLen "Two"
			local treatLeg "'88-'90"
			local contLeg "'86-'88"
			drop if age_round == 38
		}


		fcollapse earn_Diff_f`yrfwd', by(age_round year)

		reshape wide earn_Diff_f`yrfwd', i(age_round) j(year)

		gen diff = earn_Diff_f`yrfwd'`treatYr' - earn_Diff_f`yrfwd'`contYr'

		su diff, mean
		replace diff = diff - r(mean)
		save ${temp}/05b_NonParametricData_f`yrfwd'.dta, replace
				restore
} //yrfwd

log close

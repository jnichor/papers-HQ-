/*******************************************************************************

	DESCRIPTION: Figure 4: Benefit Changes and Wage Effects by Reform



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/Fig4_NonParametric`curr_date'", replace

local counter = 0

local xrange_2001 10000 28000
local xrange_1989 6000 16000
local xrange_1985 12000 27000
local xrange_1976 2200 5000

local xtick_2001 10000(2500)28000
local xtick_1989 6000(2000)16000
local xtick_1985 12000(3000)27000
local xtick_1976 2000(1000)5000




********************************************************************************
***** Nonparametric figures for each reform
********************************************************************************
foreach reform in 1976 1985 1989 2001 {
	local counter = `counter' + 1
	local letter = word("a b c d", `counter')

	use  ${temp}/03a_Nonparametric_DTAFiles/03a_NonParametric_Sample_Reform`reform'_stable.dta if in_sample_`reform'  == 1 , replace

	**** Defining different earnings concepts for the x-axis
	if `reform' == 2001 {
		local earn_cpt adj_earnings
	}
	else {
		local earn_cpt infl1_adj_earnings
	}

	if `reform' == 1985 {
		su earn_pct_bin if treatment_`reform' > 0 & !mi(treatment_`reform')
		local relPct = r(min)
	}
	else {
		su earn_pct_bin if treatment_`reform' >0  & !mi(treatment_`reform')
		local relPct = r(max)
	}

	**** For 2001, requiring that the entire percentile is treated
	if `reform' == 2001 {
		local relPct = `relPct' - 1
	}

	su `earn_cpt' if earn_pct_bin == `relPct'
	local zeroEarn = r(mean)


	* Plotting additional line for 1985
	if "`reform'" == "1985" {
		local addLine 16700
	}
	else {
		local addLine `zeroEarn'
	}

	**** Creating sequence of figures that progressivly adds lines
	tw (connected diff_w_pbo1 `earn_cpt', lcolor(sea) mcolor(sea) msymbol(S) msize(medium)) ///
	(connected diff_w_pbo2 `earn_cpt', lcolor(sky) mcolor(sky) msymbol(Oh) msize(medium)) ///
			(line RRdiff_f1_RRiBY_BRiBY `earn_cpt', lcolor(green%90) lwidth(thick) lpattern(solid) ) ///
			(line PredWgGrth1 `earn_cpt', lcolor(dkorange) lpattern(dash) lwidth(medthick) ///
			ytitle("Change (Pct Pts)", size(medium)) ///
			xtitle("Monthly Earnings (ATS)", size(medium)) ///
			yline(0,lpattern(solid) lcolor(gray)) ///
			/*xline(`zeroEarn', lpattern(dash) lcolor(black)) ///
			xline(`addLine', lpattern(dash) lcolor(black))*/ ///
			xsc(r(`xrange_`reform'')) ///
			xlab(`xtick_`reform'', labsize(medium)) ylab(, labsize(medium)) ///
			legend(label(1 "One-Year Effects (dw/w)") ///
			label(2 "Two-Year Effects (dw/w)") ///
			label(3 "Benefit Change (db/w)" ) ///
			label(4 "Predicted Wage Effects" ) ///
			order(3 4 1 2) on col(2) pos(6) size(medium)) ///
			note("`note1'" "`note2'") )
	graph display, xsize(18) ysize(10)
	graph export "${figures}/Fig4`letter'_NonParametric.pdf", replace
}

log close

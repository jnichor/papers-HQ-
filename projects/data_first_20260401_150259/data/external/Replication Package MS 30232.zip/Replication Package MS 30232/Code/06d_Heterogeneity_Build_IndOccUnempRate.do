/*******************************************************************************

  DESCRIPTION: Calculate industry-occupation separation measures.

*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/06d_Heterogeneity_Build_IndOccUnempRate`curr_date'", replace




****************************************************************************
* Calculate Separation Measures
****************************************************************************

**** Use full panel
use svnr year tenure exp25 mth_UE status nace08 whitecoll refage using ///
${temp}/01_Panel_all_full_sample.dta, clear

**** Unemployment-related measures using industry-occupations.

xtset svnr year

* Unemployed in next year
gen unemp_nextyr = F.status == 1
replace unemp_nextyr = . if mi(F.status)

* Number of months unemployed in next year
gen mth_UE_nextyr = F.mth_UE
replace mth_UE_nextyr = . if mi(F.status)

keep if status == 3

****************************************************************************
* Regressions to Calculate Industry-Occupation Averages
****************************************************************************
* Keep only those with non-missing industry
keep if !mi(nace08)

**** Regressions without controls
foreach var in unemp mth_UE {

	reghdfe `var'_nextyr, absorb(`var'FE_cont = year#nace08#whitecoll, save resid)
	predict indocc_`var', d //Only want predicted from FEs

}

* Drop duplicates -- first dropping missings -> make sure we don't pick up a missing
keep year nace08 whitecoll indocc*
drop if indocc_unemp == . | indocc_mth_UE == .
gduplicates drop year nace08 whitecoll, force


save ${temp}/06d_IndOccUnempRate.dta, replace

log close

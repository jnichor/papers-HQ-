*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*						August 20, 2020
*						  Orbis-ADIAB
*===============================================================================
cap log close

local today : di %td_CY-N-D  date("$S_DATE", "DMY") " $S_TIME"
local today = trim("`today'")
local today = subinstr("`today'",":","-",2)
local today = subinstr("`today'"," ","_",1)
global today `today'

mkdir "$log/211/$today"
local output $log/211/$today

log using "`output'/211_Analysis_RD_Heterogeneity.txt", replace text

timer clear
est clear

timer on 1
********************************************************************************
*
*		211 RD Heterogeneity
*
********************************************************************************

foreach w in $winsor_values { // winsorization values

	use "$data\iab_wage_analysis_winsor`w'.dta"  if abs(d_rel) <= ${bw_standard} & AG==1, clear

	* merge CBA agreements data
	merge m:1 nace_d3 using "$data/betriebspanel_industry_heterogeneity.dta", keep(1 3) nogen

	* merge industry_AKM data
	* +++ JH +++ merge m:1 nace_d3 using "${data}/akm_measures_heterogeneity.dta", keep(1 3) nogen
	merge m:1 nace_d3 using "${data}/bvd_akm_industry_heterogeneity.dta", keep(1 3) nogen


	* construct heterogeneity cuts
	foreach hetergroup in $hetgroups { // heterogeneity groups
		cap drop `hetergroup'_grp
		qui sum `hetergroup', d
		gen `hetergroup'_grp = (`hetergroup' >= r(p50) & `hetergroup' != .)

		* levels of each heterogeneity group
		levelsof `hetergroup'_grp, local(levels)
		qui sum `hetergroup'_grp
		local size = `r(max)'+1
	}

	global treatment d_rel prereformcohort_d_rel prereformcohort cons

	qui foreach i in 2 3 { // Specifications

		noi di "Specification `i'"

		foreach outcome in $heterogeneity_outcomes  { // outcomes

			noi di "	Outcome: `outcome'"

			foreach hetergroup in $hetgroups { // heterogeneity groups

				* interact indicator for each level with treatment
				cap drop Het*
				foreach level in `levels' {
					foreach var in $treatment {
						gen double Het`level'`var' = (`hetergroup'_grp == `level') * `var'
					}
				}

				* regression variables
				local reg_vars Het*

				*----------------------------------------------
				*-- RD Regression with heterogeneity
				*----------------------------------------------

				noi di "		Regressing..."

				reghdfe `outcome' `reg_vars', ///
					a(${controls`i'}) vce(cluster cluster_variable)

				foreach l in `levels' {

					* interacted coefficient and se
					global b_`hetergroup'_`l' = _b[Het`l'prereformcohort]
					global s_`hetergroup'_`l' = _se[Het`l'prereformcohort]

					* control mean: AG
					qui sum `outcome' if `hetergroup'_grp == `l' & d_rel >= 0 & AG == 1 & e(sample) == 1
					global cmag1_`hetergroup'_`l' = `r(mean)'

					* mean value of heterogeneity variable at each cut
					qui sum `hetergroup' if `hetergroup'_grp == `l' & e(sample) ==1
					global mh_`hetergroup'_`l' = `r(mean)'

				} // levels of heterogeneity group

				preserve
				noi di "		Storing Results..."

				clear
				set obs `size'
				gen outcome = "`outcome'"
				gen cut = _n-1
				gen hetergroup = "`hetergroup'_grp"

				foreach var in b s lb ub cmag1 mh {
					gen `var' = .
				}
				foreach var in b s cmag1 mh {
					foreach l in `levels' {
						replace `var' = ${`var'_`hetergroup'_`l'} if cut == `l'
					}
				}

				replace ub = b + 1.96 * s
				replace lb = b - 1.96 * s

				* save the results
				save "`output'/Heterogeneity_RD_`outcome'_Winsor`w'_spec`i'_`hetergroup'.dta", replace
				restore

			} // heterogeneity groups
		}  // outcomes
	} // specifications
} // winsorization

log close

*===============================================================================
*
*						LABOR IN THE BOARDROOM
*		(c)	Simon Jaeger, Benjamin Schoefer, Joerg Heining
*							2020-20-08
*===============================================================================

Add the following Hoppenstedt .dta files here:

Hoppenstedt_Aufsichtsrat
Hoppenstedt_Beschaeftigte
Hoppenstedt_Unternehmen

/*******************************************************************************

	DESCRIPTION: Figure A.16 PBD Reform



*******************************************************************************/

********************************************************************************
***** Preliminaries
********************************************************************************
clear all
set more off
cap log close
local curr_date = c(current_date)
log using "${logs}/FigA16_PBD_Reform`curr_date'", replace

********************************************************************************

* Graph Settings

set obs 21

gen age = _n + 29
gen PBD_treated = cond(age < 40, 30.1, 39)
gen PBD_control = 30

line PBD_treated age, lcolor(green%90) lwidth(thick) lpattern(solid) || ///
 line PBD_control age,  lcolor(dknavy) lwidth(medthick) lpattern(dash) ///
 legend(label(1 "Treated Year (1988)") label(2 "Control Year (1987)") pos(6)) ///
 xtitle("Age") ytitle("Potential UI Duration Eligibility (Weeks)")

graph export ${figures}/FigA16_PBD_Reform.pdf, replace

log close
